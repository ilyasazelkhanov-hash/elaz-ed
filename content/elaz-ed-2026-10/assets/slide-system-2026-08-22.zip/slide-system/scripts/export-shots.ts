import { mkdir, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { createServer, type ViteDevServer } from "vite";
import { chromium, type Browser } from "playwright";

/**
 * Выгрузка слайдов ОТДЕЛЬНЫМИ картинками.
 *
 * Запуск:
 *   npm run export:shots            — все презентации из реестра
 *   npm run export:shots -- showcase — только указанную
 *   npm run export:shots -- showcase 1  — в одинарном разрешении (1920×1080)
 *
 * Результат — export/shots/<идентификатор>/NN.png
 *
 * === Зачем отдельно от export:pdf ===
 *
 * PDF отдают заказчику, а картинки нужны для другого: превью в переписке,
 * иллюстрации к статье, согласование одного слайда без пересылки всего файла.
 * Механика съёмки та же самая (и повторена намеренно, а не вынесена в общий
 * модуль: у выгрузок разный жизненный цикл, и связывать их — значит ломать
 * обе разом при правке одной).
 *
 * Масштаб по умолчанию 2 — снимок 3840×2160. Причина та же, что в PDF: на
 * одинарном разрешении текст мылится при увеличении. Для статьи, где картинку
 * всё равно ужмут, второй аргумент 1 экономит вес примерно вчетверо.
 */

const PORT = 5198;
const OUT_DIR = resolve(process.cwd(), "export", "shots");

async function main() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith("-"));
  const scaleArg = args.find((a) => /^[12]$/.test(a));
  const scale = scaleArg ? Number(scaleArg) : 2;
  const requested = args.filter((a) => a !== scaleArg);

  await mkdir(OUT_DIR, { recursive: true });

  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;

  try {
    server = await createServer({ logLevel: "warn", server: { port: PORT, strictPort: true } });
    await server.listen();
    browser = await chromium.launch();

    const ids = requested.length ? requested : await listDecks(browser);
    if (!ids.length) {
      console.error("Нет ни одной презентации в реестре");
      process.exitCode = 1;
      return;
    }

    for (const id of ids) await shootDeck(browser, id, scale);
  } finally {
    await browser?.close();
    await server?.close();
  }
}

async function listDecks(browser: Browser) {
  const page = await browser.newPage();
  await page.goto(`http://localhost:${PORT}/`, { waitUntil: "networkidle" });
  const ids = await page.evaluate(() =>
    Array.from(document.querySelectorAll<HTMLAnchorElement>("a[href^='?deck=']")).map(
      (a) => a.href.split("?deck=")[1],
    ),
  );
  await page.close();
  return ids;
}

async function shootDeck(browser: Browser, id: string, scale: number) {
  const page = await browser.newPage({
    viewport: { width: 1920, height: 1080 },
    deviceScaleFactor: scale,
  });

  await page.goto(`http://localhost:${PORT}/?deck=${id}`, { waitUntil: "networkidle" });

  const missing = await page.evaluate(() =>
    Boolean(document.querySelector("h1")?.textContent?.includes("не найдена")),
  );
  if (missing) {
    console.error(`✗ ${id} — нет в реестре, пропущено`);
    await page.close();
    return;
  }

  // Шрифты и картинки — до съёмки, иначе снимок уйдёт с запасным шрифтом
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate(() =>
    Promise.all(
      Array.from(document.images)
        .filter((img) => !img.complete)
        .map((img) => new Promise((done) => img.addEventListener("load", done, { once: true }))),
    ),
  );

  const dir = resolve(OUT_DIR, id);
  await mkdir(dir, { recursive: true });

  const canvases = page.locator(".slide-print-page .slide-canvas");
  const slides = await canvases.count();

  for (let i = 0; i < slides; i++) {
    const buf = await canvases.nth(i).screenshot({ scale: "device" });
    await writeFile(resolve(dir, `${String(i + 1).padStart(2, "0")}.png`), buf);
  }

  const px = scale === 2 ? "3840×2160" : "1920×1080";
  console.log(`✓ ${id} — ${slides} слайд(ов) → export/shots/${id}/ (${px})`);
  await page.close();
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
