import { mkdir } from "node:fs/promises";
import { resolve } from "node:path";
import { createServer, type ViteDevServer } from "vite";
import { chromium, type Browser } from "playwright";

/**
 * Выгрузка презентации в PDF.
 *
 * Запуск:
 *   npm run export:pdf            — все презентации из реестра
 *   npm run export:pdf -- demo    — только указанную
 *
 * Результат — export/<идентификатор>.pdf
 *
 * === Как это работает ===
 *
 * 1. Поднимается обычный dev-сервер Vite (тот же, что у `npm run dev`).
 *    Собирать проект незачем: страница печати служебная, она не выкладывается,
 *    а сборка добавила бы минуту к каждой выгрузке.
 *
 * 2. Headless-браузер открывает /?deck=<id> — страницу, где все слайды идут
 *    подряд, каждый в блоке с break-after: page.
 *
 * 3. page.pdf() печатает всё одним вызовом и получает многостраничный PDF.
 *
 * === Почему не по слайду с последующей склейкой ===
 *
 * Склейка требует ещё одной библиотеки и на ней же ломается: встроенные
 * шрифты дублируются в каждом куске, размер файла растёт кратно числу
 * слайдов, а нумерация страниц начинается заново в каждом фрагменте.
 *
 * === Почему размер страницы не задаётся здесь ===
 *
 * preferCSSPageSize: true заставляет браузер взять размер из правила @page
 * в src/styles/slide.css, где он равен холсту слайда. Продублировать 1920×1080
 * в этом файле означало бы завести второй источник правды: поменяли бы холст
 * в токенах — и PDF молча начал бы обрезать слайды по старому размеру.
 */

const PORT = 5199;
const OUT_DIR = resolve(process.cwd(), "export");

async function main() {
  const requested = process.argv.slice(2).filter((arg) => !arg.startsWith("-"));

  await mkdir(OUT_DIR, { recursive: true });

  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;

  try {
    server = await createServer({
      // logLevel warn: обычный вывод Vite забивает лог выгрузки
      logLevel: "warn",
      server: { port: PORT, strictPort: true },
    });
    await server.listen();

    browser = await launchBrowser();

    const ids = requested.length ? requested : await readDeckIds(browser);
    if (!ids.length) {
      console.error("В реестре нет ни одной презентации — src/deck/registry.ts");
      process.exitCode = 1;
      return;
    }

    for (const id of ids) {
      await exportDeck(browser, id);
    }
  } finally {
    await browser?.close();
    await server?.close();
  }
}

/**
 * Playwright устанавливает пакет, но НЕ скачивает сами браузеры — это
 * отдельный шаг. Без внятного сообщения ошибка выглядит как «Executable
 * doesn't exist at …», по которой непонятно, что делать.
 */
async function launchBrowser() {
  try {
    return await chromium.launch();
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes("Executable doesn't exist")) {
      console.error(
        "Не установлен браузер для Playwright. Установить один раз:\n\n" +
          "  npx playwright install chromium\n",
      );
      process.exit(1);
    }
    throw error;
  }
}

/** Список презентаций спрашивается у самой страницы — реестр там один */
async function readDeckIds(browser: Browser): Promise<string[]> {
  const page = await browser.newPage();
  await page.goto(`http://localhost:${PORT}/`, { waitUntil: "networkidle" });

  const ids = await page.evaluate(() =>
    Array.from(document.querySelectorAll<HTMLAnchorElement>("a[href^='?deck=']")).map(
      (a) => a.href.split("?deck=")[1],
    ),
  );

  await page.close();
  return ids;
}

async function exportDeck(browser: Browser, id: string) {
  /*
   * deviceScaleFactor 2 — слайд снимается в 3840×2160.
   *
   * На одинарном разрешении текст в PDF был бы ровно той плотности, что
   * на экране, и при показе на 4K-панели или при увеличении в просмотрщике
   * заметно мылился бы. Двойное даёт запас и остаётся в разумном весе.
   */
  const page = await browser.newPage({
    viewport: { width: 1920, height: 1080 },
    deviceScaleFactor: 2,
  });

  const errors: string[] = [];
  page.on("pageerror", (error) => errors.push(error.message));

  await page.goto(`http://localhost:${PORT}/?deck=${id}`, { waitUntil: "networkidle" });

  const missing = await page.evaluate(() =>
    Boolean(document.querySelector("h1")?.textContent?.includes("не найдена")),
  );
  if (missing) {
    console.error(`✗ ${id} — нет в реестре, пропущено`);
    await page.close();
    return;
  }

  /*
   * Ждать загрузки шрифтов обязательно. Без этого браузер печатает страницу
   * запасным системным шрифтом: метрики другие, строки переносятся иначе,
   * и в PDF уезжает вёрстка — при том что на экране всё было верно.
   */
  await page.evaluate(() => document.fonts.ready);

  /*
   * Картинки грузятся не всегда к networkidle: те, что появились после
   * гидратации, могут ещё быть в пути. Печать не ждёт их сама — на их месте
   * в PDF окажется пустота.
   */
  await page.evaluate(() =>
    Promise.all(
      Array.from(document.images)
        .filter((img) => !img.complete)
        .map((img) => new Promise((done) => img.addEventListener("load", done, { once: true }))),
    ),
  );

  const canvases = page.locator(".slide-print-page .slide-canvas");
  const slides = await canvases.count();
  const path = resolve(OUT_DIR, `${id}.pdf`);

  /*
   * === Каждый слайд снимается КАРТИНКОЙ, а потом картинки печатаются в PDF ===
   *
   * Печатать вёрстку напрямую через page.pdf() нельзя, и это выяснилось
   * дорогой ценой.
   *
   * Chromium при печати НЕ переводит в вектор ни градиенты, ни размытые тени,
   * ни режимы наложения. Он растеризует их в картинки с альфа-масками
   * и группами прозрачности. Часть движков просмотра такие картинки рисует,
   * а Quartz — движок macOS, на котором работает «Просмотр», — теряет:
   * свечение на тёмных слайдах пропадает целиком, а от размытой тени
   * остаются жёсткие серые прямоугольники по контуру карточки.
   *
   * Симптом коварный: у автора в предпросмотре всё хорошо, а заказчик
   * открывает файл и видит плоские слайды с артефактами.
   *
   * Замена SVG-градиентом не помогла — Chromium растеризует и его.
   *
   * Поэтому слайд снимается скриншотом при удвоенном разрешении (3840×2160),
   * и в PDF кладётся уже готовая картинка. Как выглядит в браузере — так и
   * будет в файле, на любом движке.
   *
   * ЦЕНА РЕШЕНИЯ: текст в PDF перестаёт быть текстом, его нельзя выделить
   * и найти поиском. Для презентации это приемлемо — её смотрят, а не
   * цитируют; для документа было бы нет.
   */
  const shots: string[] = [];
  for (let i = 0; i < slides; i++) {
    const buf = await canvases.nth(i).screenshot({ scale: "device" });
    shots.push(buf.toString("base64"));
  }

  const printer = await browser.newPage({
    viewport: { width: 1920, height: 1080 },
    deviceScaleFactor: 1,
  });
  await printer.setContent(
    `<style>
       @page { size: 1920px 1080px; margin: 0 }
       html, body { margin: 0; padding: 0; background: #fff }
       img { display: block; width: 1920px; height: 1080px; break-after: page }
       img:last-child { break-after: auto }
     </style>` + shots.map((b) => `<img src="data:image/png;base64,${b}">`).join(""),
  );
  await printer.pdf({ path, printBackground: true, preferCSSPageSize: true });
  await printer.close();

  await page.close();

  if (errors.length) {
    console.error(`⚠ ${id} — во время рендера были ошибки:\n   ${errors.join("\n   ")}`);
  }
  console.log(`✓ ${id} — ${slides} слайд(ов) → export/${id}.pdf`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
