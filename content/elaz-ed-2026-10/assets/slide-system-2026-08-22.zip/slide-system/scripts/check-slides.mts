/**
 * Проверка всех слайдов всех презентаций.
 *
 *   npm run check              — все деки
 *   npm run check -- my-deck   — один дек
 *
 * Ищет шесть дефектов, каждый из которых уже случался на этом проекте:
 *
 *   1. Переполнение контейнера   — содержимое выше своего бокса
 *   2. Наложение текста          — два блока налезают друг на друга
 *   3. Выход за холст            — блок уехал за 1920×1080
 *   4. Недостаточный контраст    — ниже порога WCAG для своего кегля
 *   5. Пустой слайд              — на слайде только шапка и подвал
 *   6. Переполнение по ширине    — содержимое ШИРЕ своего бокса
 *
 * === Почему это отдельный скрипт, а не проверка глазами ===
 *
 * Все шесть невидимы при обычном просмотре. Переполнение в 5px не видно
 * вовсе — а в PDF оно уносит с собой весь блок. Пустой слайд проходит
 * любую другую проверку: там нечему переполняться и нечему налезать.
 */
import { createServer, type ViteDevServer } from "vite";
import { chromium, type Browser } from "playwright";

const PORT = 5212;

/**
 * Замер передаётся СТРОКОЙ, а не функцией.
 *
 * tsx собирает файл через esbuild с keepNames, и в сериализованную функцию
 * попадает ссылка на служебный хелпер `__name`, которого в странице нет —
 * page.evaluate падает с ReferenceError прямо на первом же вызове.
 */
const AUDIT = `(() => {
  const pages = [...document.querySelectorAll(".slide-print-page")];
  const lum = (r, g, b) => {
    const f = (v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; };
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
  };
  const parse = (s) => (s.match(/[\\d.]+/g) || []).map(Number);
  const over = (fg, bg) => { const [r, g, b, a = 1] = fg; return [r*a+bg[0]*(1-a), g*a+bg[1]*(1-a), b*a+bg[2]*(1-a)]; };
  const bgOf = (el) => {
    let n = el;
    while (n && n !== document.body) {
      const p = parse(getComputedStyle(n).backgroundColor);
      if (p.length >= 3 && (p[3] === undefined || p[3] > 0.9)) return p.slice(0, 3);
      n = n.parentElement;
    }
    return [255, 255, 255];
  };

  /*
   * Подложка, нарисованная НЕ фоном, а фигурой SVG.
   *
   * bgOf выше ищет background-color по цепочке предков. Этого достаточно,
   * пока текст лежит на залитом блоке, и слепо ровно там, где подложка
   * нарисована фигурой: у сот ответственности (blocks/honeycomb.tsx) подпись
   * стоит абсолютом ПОВЕРХ <polygon fill="#8e51ff">, а background-color
   * у неё и у всех её предков прозрачен. bgOf доходит до холста и возвращает
   * белый — то есть белая подпись на фиолетовой соте читается проверкой как
   * белое по белому, k = 1.07, и шесть годных подписей объявляются дефектом.
   *
   * Обратная ошибка тут опаснее прямой: чтобы дек стал зелёным, автор
   * начинает править не то, что сломано.
   *
   * Поэтому: если обычная проверка не прошла, ищем фигуру SVG, лежащую
   * ПОД центром текста. Ищем не hit-тестом (elementsFromPoint работает
   * только в пределах окна, а печатная страница — это 20+ слайдов в столбик,
   * из которых в окне один), а обходом соседей-<svg> по той же цепочке
   * предков с проверкой попадания центра строки в габарит фигуры.
   *
   * Габарит, а не сама форма: для шестиугольника с подписью по центру этого
   * достаточно, а разбирать геометрию path в проверке нечем.
   *
   * Функция вызывается ТОЛЬКО при уже провалившемся замере, поэтому новых
   * дефектов она спрятать не может — она может лишь снять ложное
   * срабатывание.
   */
  /*
   * Подложка, нарисованная ГРАДИЕНТОМ.
   *
   * Тот же класс слепоты, что и у svgBehind, только краска лежит не в SVG,
   * а в background-image. Так залиты акцентные ячейки стопки слоёв
   * (blocks/layers.tsx через plusSurface): background-color у них
   * прозрачен, и bgOf доходит до холста. В светлой теме ошибка милосердна —
   * холст белый, тёмная подпись на нём «проходит», — а в тёмной те же
   * ячейки дают k = 1.01 и объявляются дефектом, хотя реально подпись лежит
   * на светлом крае фиолетового градиента и её цвет посчитан glyphOn.
   *
   * ⚠️ Раньше эта функция вызывалась ТОЛЬКО после провалившегося замера — и
   * ровно поэтому не видела целый класс дефектов. Пример из этого же блока:
   * тёмная подпись на тёмном крае фиолетового градиента давала 2.88:1 при
   * пороге 3, но bgOf доходил до светлой карточки #f0f0f0, там та же подпись
   * давала 15:1, замер «проходил», и до градиента дело не доходило вовсе.
   * Милосердие проверки к светлой теме и было тем случаем, когда зелёный
   * результат хуже отсутствия проверки. Теперь градиент, если он найден,
   * ЗАМЕЩАЕТ фон-краску: он её физически перекрывает.
   *
   * Точка градиента берётся ПОД САМИМ ТЕКСТОМ, а не худшая по всей заливке.
   * Для горизонтальной заливки (90deg / to right) это считается точно: ход
   * строки снимается Range, положение переводится в долю ширины залитого
   * элемента, цвет — линейной интерполяцией между стопами. Разница не
   * теоретическая: у ячейки в 1308 точек текст занимает четверть ширины, и
   * «худший стоп» отбраковал бы вёрстку, которая специально ставит подпись
   * в безопасную часть хода.
   *
   * Для всех прочих градиентов (radial, наклонные, стопы без процентов)
   * позиция не разбирается и берётся ХУДШАЯ точка — то есть проверка
   * остаётся строгой там, где не умеет считать точно.
   *
   * Полупрозрачные точки складываются с непрозрачным фоном снизу.
   */
  const gradientBehind = (el, under) => {
    let n = el;
    while (n && n !== document.body) {
      const cs = getComputedStyle(n);
      const img = cs.backgroundImage;
      if (img && img.includes("gradient")) {
        const raw = [...img.matchAll(/(rgba?\\([^)]+\\))(?:\\s+([\\d.]+)%)?/g)]
          .map((m) => ({ c: parse(m[1]), p: m[2] === undefined ? null : +m[2] / 100 }))
          .filter((x) => x.c.length >= 3);
        if (raw.length) {
          const solid = raw.map((x) => ({ c: over(x.c, under), p: x.p }));
          const horizontal =
            /linear-gradient\\(\\s*(90deg|to right)/.test(img) &&
            solid.length >= 2 &&
            solid.every((x) => x.p !== null);
          const box = n.getBoundingClientRect();
          if (!horizontal || box.width <= 0) return solid.map((x) => x.c);
          const rg2 = document.createRange();
          rg2.selectNodeContents(el);
          const ls = [...rg2.getClientRects()].filter((l) => l.width > 0);
          if (!ls.length) return solid.map((x) => x.c);
          const at = (p) => {
            let i = 1;
            while (i < solid.length - 1 && solid[i].p < p) i++;
            const a = solid[i - 1], b = solid[i];
            const t = b.p === a.p ? 0 : (p - a.p) / (b.p - a.p);
            return a.c.map((v, j) => v + (b.c[j] - v) * Math.min(1, Math.max(0, t)));
          };
          const L = Math.min(...ls.map((l) => l.left));
          const R = Math.max(...ls.map((l) => l.right));
          const out = [];
          for (let x = L; x <= R; x += 1)
            out.push(at(Math.min(1, Math.max(0, (x - box.left) / box.width))));
          return out;
        }
      }
      /* Непрозрачная краска ближе к тексту перекрывает градиент выше по
         цепочке — дальше идти незачем */
      const bc = parse(cs.backgroundColor);
      if (n !== el && bc.length >= 3 && (bc[3] === undefined || bc[3] > 0.99)) return null;
      n = n.parentElement;
    }
    return null;
  };

  const svgBehind = (el) => {
    const r = el.getBoundingClientRect();
    const cx = (r.left + r.right) / 2;
    const cy = (r.top + r.bottom) / 2;
    let n = el;
    while (n && n !== document.body) {
      const par = n.parentElement;
      if (!par) break;
      for (const sib of par.children) {
        if (sib === n || sib.tagName.toLowerCase() !== "svg") continue;
        for (const sh of sib.querySelectorAll("polygon,rect,circle,ellipse,path")) {
          const b = sh.getBoundingClientRect();
          if (cx < b.left || cx > b.right || cy < b.top || cy > b.bottom) continue;
          const f = parse(getComputedStyle(sh).fill);
          if (f.length >= 3 && (f[3] === undefined || f[3] > 0.9)) return f.slice(0, 3);
        }
      }
      n = par;
    }
    return null;
  };

  const issues = [];
  pages.forEach((p, i) => {
    const n = i + 1;
    const c = p.querySelector(".slide-canvas");
    if (!c) { issues.push({ n, тип: "нет холста" }); return; }
    const cb = c.getBoundingClientRect();

    // 1. Переполнение и уход содержимого ВВЕРХ.
    //
    //    Порогов два, потому что это два разных дефекта.
    //
    //    «Переполнение» > 16px — содержимое не помещается, слайд надо
    //    разгружать. Порог не ниже, потому что у контейнера с текстом
    //    scrollHeight на 2–10px больше clientHeight из-за выносных
    //    элементов шрифта, а у меры намеренно выступает метка нормы.
    //
    //    «Уходит вверх» — точное условие, при котором блок ПРОПАДАЕТ в PDF:
    //    первый ребёнок начинается выше своего контейнера. Так ведёт себя
    //    центрирование при переполнении, и постраничная вёрстка выбрасывает
    //    такой фрагмент целиком. Ловится при любой величине.
    [...c.querySelectorAll("*")].forEach((e) => {
      if (!e.children.length || !e.clientHeight) return;
      const d = e.scrollHeight - e.clientHeight;
      if (d > 16) issues.push({ n, тип: "переполнение", px: d, cls: String(e.className).slice(0, 44) });

      /*
       * 6а. То же по ШИРИНЕ. Отдельная проверка, а не «то же с другой осью»:
       *     по высоте переполнение обрезается низом слайда, по ширине —
       *     наезжает на соседнюю колонку, и в PDF это два разных брака.
       *
       *     Порог 4px, и он НЕ равен вертикальным 16.
       *
       *     Вертикальные 16 нужны из-за выносных элементов шрифта: у бокса
       *     с текстом scrollHeight законно больше clientHeight на 2–10px.
       *     По горизонтали такого источника нет — ширина бокса считается
       *     ровно из ширины строки, поэтому фон здесь только от округления
       *     (scrollWidth и clientWidth целые, каждое округляется).
       *
       *     4px взяты по самому крупному ЗАКОННОМУ выступу, который на
       *     этих слайдах есть: у меры (blocks/chartsParts.tsx:180, Meter)
       *     метка нормы шириной 4px стоит с marginLeft:-2, и при норме,
       *     совпадающей с потолком шкалы, ровно половина метки — 2px —
       *     торчит за дорожку. Замер на слайде 18 реального дека:
       *     scrollWidth 688 при clientWidth 686. Порог 4 = удвоенный этот
       *     выступ, и он же совпадает с порогом проверки наложения ниже.
       *
       *     Что порог пропускает: выступ до 4px включительно. На соседнюю
       *     колонку он не наедет — желоб сетки 24px, — но и увидеть его
       *     эта проверка не сможет.
       */
      const dw = e.scrollWidth - e.clientWidth;
      if (dw > 4) issues.push({ n, тип: "переполнение по ширине", px: dw, cls: String(e.className).slice(0, 44) });

      const first = e.firstElementChild;
      if (!first) return;
      /*
       * Строчный первый ребёнок пропускается. У крупного кегля с плотным
       * межстрочным (display-l это 128/128) рамка глифов выше строчного
       * бокса примерно на 6% кегля — она законно вылезает вверх на 8px,
       * и это типографика, а не дефект вёрстки.
       */
      if (getComputedStyle(first).display.startsWith("inline")) return;
      const up = e.getBoundingClientRect().top - first.getBoundingClientRect().top;
      if (up > 1) issues.push({ n, тип: "содержимое уходит вверх", px: Math.round(up), cls: String(e.className).slice(0, 44) });
    });

    /*
     * Перечень тегов — слепое пятно этой проверки, и расширять его надо
     * при каждом новом виде текстового узла на слайде.
     *
     * blockquote добавлен после слайда-заявления (StatementSlide): цитата
     * набрана именно им, в перечне его не было, и проверка объявила слайд
     * ПУСТЫМ — при том что на нём стоял текст на 44px во всю ширину.
     * Хуже другое: раз узел не попадал в leaves, у него не проверялся
     * и КОНТРАСТ. То есть инструмент не просто ошибся в одну сторону,
     * а молча пропускал целый класс дефектов на всех таких слайдах.
     *
     * Отсюда правило: новый семантический тег в шаблоне или блоке —
     * повод дописать его сюда, а не повод переписать шаблон под проверку.
     */
    const leaves = [...c.querySelectorAll("span,p,h1,h2,h3,li,code,div,blockquote")].filter(
      (e) => e.textContent.trim() && ![...e.children].some((ch) => ch.textContent.trim()),
    );

    const boxes = [];
    leaves.forEach((e) => {
      const r = e.getBoundingClientRect();
      const s = getComputedStyle(e);
      const b = { e, x1: r.left-cb.left, y1: r.top-cb.top, x2: r.right-cb.left, y2: r.bottom-cb.top, t: e.textContent.trim().slice(0, 24) };

      // 3. Выход за холст
      if (b.y1 < -1 || b.y2 > 1081 || b.x1 < -1 || b.x2 > 1921)
        issues.push({ n, тип: "за холстом", txt: b.t });
      if (b.x2 > b.x1 && b.y2 > b.y1) boxes.push(b);

      /*
       * 6б. Строка ШИРЕ собственного бокса.
       *
       *     Проверка 6а листовой текст не видит: у строчного элемента
       *     clientWidth и scrollWidth равны нулю, а у обращённого в блок
       *     (ребёнок flex-контейнера) целые пиксели прячут доли. Поэтому ширина
       *     строки меряется Range по содержимому — тем же способом, что
       *     в layout-verification.md, и с долями пикселя.
       *
       *     Range даёт ШИРИНУ ХОДА строки (advance), а не рамку самих
       *     глифов: свес курсива, боковые свесы букв и тень в неё не
       *     входят и здесь не ловятся. Зато нет и систематического фона —
       *     ширина бокса считается ровно из этого же хода. Замер по всем
       *     125 слайдам четырёх деков: наибольшее расхождение у строки,
       *     которая помещается, — 0.02px (реальный дек, слайд 29). Порог 4px
       *     взят тот же, что у 6а, и он в 200 раз выше этого фона.
       *
       *     Два разных исхода, поэтому и сообщения два:
       *       — бокс обрезает (overflow hidden/clip, обычно класс truncate) —
       *         текст ТЕРЯЕТСЯ, но соседа не трогает;
       *       — бокс не обрезает — текст выходит наружу и в PDF ложится
       *         на соседнюю колонку.
       *
       *     Что порог пропускает: свес до 4px. Для кегля 24 это меньше
       *     одного знака, то есть ни один символ целиком не пропадёт.
       */
      const rg = document.createRange();
      rg.selectNodeContents(e);
      const lines = [...rg.getClientRects()];
      if (lines.length) {
        const inL = r.left + parseFloat(s.borderLeftWidth) + parseFloat(s.paddingLeft);
        const inR = r.right - parseFloat(s.borderRightWidth) - parseFloat(s.paddingRight);
        const out = Math.max(
          inL - Math.min(...lines.map((l) => l.left)),
          Math.max(...lines.map((l) => l.right)) - inR,
        );
        const clips = s.overflowX === "hidden" || s.overflowX === "clip";
        if (out > 4)
          issues.push({
            n,
            тип: clips ? "текст обрезан по ширине" : "текст шире своего бокса",
            px: Math.round(out),
            txt: b.t,
          });
      }

      // 4. Контраст. Порог 3:1 от 24px (крупный текст), иначе 4.5:1
      const ratio = (bg) => {
        const L1 = lum(...over(parse(s.color), bg)), L2 = lum(...bg);
        return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
      };
      const px = parseFloat(s.fontSize);
      const порог = px >= 24 ? 3 : 4.5;

      /*
       * ⚠️ ГРАДИЕНТ, ЗАЛИВАЮЩИЙ САМИ БУКВЫ, — ЭТО ЦВЕТ ТЕКСТА, А НЕ ФОН.
       *
       * Единственный способ залить буквы в CSS — сделать текст прозрачным
       * и обрезать фон по его форме: background-clip: text. Тогда
       * getComputedStyle(...).color возвращает rgba(0,0,0,0), замер
       * «текст против фона» даёт ровно 1, и годная подпись объявляется
       * дефектом — а править автору нечего, потому что сломано не в вёрстке.
       *
       * Поймано на строке состояния мокапа панели (blocks/cards/
       * agentThinkingCard.tsx, свойство gradient): подпись залита
       * ink-secondary → ink → ink-secondary, то есть заведомо контрастна,
       * а проверка сообщала k = 1.
       *
       * Поэтому при background-clip: text замер переворачивается: точки
       * градиента — это КРАСКА БУКВ, а фон берётся с предков (bgOf у
       * прозрачного элемента и так уходит вверх по цепочке). Строгость не
       * теряется: берётся ХУДШАЯ точка градиента.
       */
      const clip = s.webkitBackgroundClip || s.backgroundClip;
      if (clip === "text") {
        const bg = bgOf(e);
        const paints = gradientBehind(e, bg);
        const paintRatio = (fg) => {
          const L1 = lum(...over(fg, bg)), L2 = lum(...bg);
          return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05);
        };
        const kt = paints ? Math.min(...paints.map(paintRatio)) : ratio(bg);
        if (kt < порог)
          issues.push({ n, тип: "контраст", txt: b.t, px, k: Math.round(kt * 100) / 100 });
        return;
      }

      let k = ratio(bgOf(e));
      /* Провал по фону-краске — повод посмотреть, нет ли под текстом
         фигуры SVG: см. svgBehind. Пересчёт только вниз по числу дефектов */
      if (k < порог) {
        const shape = svgBehind(e);
        if (shape) k = ratio(shape);
      }
      /* Градиентная заливка перекрывает фон-краску, поэтому она НЕ запасной
         вариант при провале, а замена замера. См. gradientBehind */
      const stops = gradientBehind(e, bgOf(e));
      if (stops) k = Math.min(...stops.map(ratio));
      if (k < порог)
        issues.push({ n, тип: "контраст", txt: b.t, px, k: Math.round(k * 100) / 100 });
    });

    // 2. Наложение. Вложенность наложением не считается, порог 4px гасит
    //    касание соседних боксов строк.
    for (let a = 0; a < boxes.length; a++)
      for (let b2 = a + 1; b2 < boxes.length; b2++) {
        const A = boxes[a], B = boxes[b2];
        if (A.e.contains(B.e) || B.e.contains(A.e)) continue;
        const ox = Math.min(A.x2, B.x2) - Math.max(A.x1, B.x1);
        const oy = Math.min(A.y2, B.y2) - Math.max(A.y1, B.y1);
        if (ox > 4 && oy > 4) issues.push({ n, тип: "наложение", txt: A.t + " ↔ " + B.t });
      }

    // 5. Пустой слайд. Считаются только блоки в рабочей области ниже шапки:
    //    заголовок и подвал есть всегда и о наполненности ничего не говорят.
    //
    //    Порог 2, а не 3: у обложки и финального слайда законно бывает всего
    //    два блока — крупный заголовок и подзаголовок. Ловим случай, когда
    //    от слайда осталась одна шапка.
    const meaningful = boxes.filter((b) => b.y1 > 340 && b.y2 < 980).length;
    if (meaningful < 2) issues.push({ n, тип: "пустой слайд", txt: "значимых блоков: " + meaningful });
  });

  return { слайдов: pages.length, issues };
})()`;

async function main() {
  const requested = process.argv.slice(2).filter((a) => !a.startsWith("-"));

  let server: ViteDevServer | undefined;
  let browser: Browser | undefined;
  let failed = 0;

  try {
    server = await createServer({ logLevel: "warn", server: { port: PORT, strictPort: true } });
    await server.listen();
    browser = await chromium.launch();

    const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
    await page.goto(`http://localhost:${PORT}/`, { waitUntil: "networkidle" });
    const all: string[] = await page.evaluate(
      `Array.from(document.querySelectorAll("a[href^='?deck=']")).map(a => a.href.split("?deck=")[1])`,
    );
    const decks = requested.length ? requested : all;

    for (const id of decks) {
      await page.goto(`http://localhost:${PORT}/?deck=${id}`, { waitUntil: "networkidle" });
      await page.evaluate("document.fonts.ready");

      const { слайдов, issues } = (await page.evaluate(AUDIT)) as {
        слайдов: number;
        issues: { n: number; тип: string; [k: string]: unknown }[];
      };

      if (!issues.length) {
        console.log(`✓ ${id} — ${слайдов} слайд(ов), дефектов нет`);
        continue;
      }

      failed += issues.length;
      console.log(`✗ ${id} — ${слайдов} слайд(ов), дефектов ${issues.length}:`);
      const bySlide = new Map<number, string[]>();
      for (const i of issues) {
        const parts = Object.entries(i)
          .filter(([k]) => k !== "n")
          .map(([k, v]) => `${k}: ${v}`)
          .join(", ");
        bySlide.set(i.n, [...(bySlide.get(i.n) ?? []), parts]);
      }
      for (const [n, list] of [...bySlide].sort((a, b) => a[0] - b[0]))
        for (const line of list) console.log(`    слайд ${n} — ${line}`);
    }
  } finally {
    await browser?.close();
    await server?.close();
  }

  /* Ненулевой код возврата: проверку можно поставить перед выгрузкой */
  if (failed) process.exitCode = 1;
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
