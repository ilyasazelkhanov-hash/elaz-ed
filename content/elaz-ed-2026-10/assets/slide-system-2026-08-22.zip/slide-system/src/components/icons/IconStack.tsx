import { Children, type ReactNode } from "react";
import { SQUARE } from "./IconSquare";

/**
 * Стопка квадратов внахлёст. Перенесена из донорского мобильного проекта (ToolStack).
 *
 * === Зачем стопка вместо одной иконки ===
 *
 * Одна иконка называет раздел. Стопка из трёх ПОКАЗЫВАЕТ, что внутри: три
 * образца вместе пересказывают подпись ещё до того, как её прочитали.
 * На слайде это работает сильнее, чем на телефоне, — до подписи взгляд
 * доходит позже.
 *
 * === Про Children.toArray ===
 *
 * Обязателен, и это не перестраховка. Если детей передают вперемешку —
 * элемент и массив, — обычный children.map считает вложенный массив ОДНИМ
 * ребёнком, и квадраты из него встают друг под друга вместо ряда.
 */
export default function IconStack({ children }: { children: ReactNode }) {
  return (
    <div className="flex">
      {Children.toArray(children).map((child, i, all) => (
        <span
          key={i}
          style={{
            marginLeft: i ? -SQUARE.overlap : 0,
            /* Первый сверху: стопка читается слева направо */
            zIndex: all.length - i,
            display: "grid",
          }}
        >
          {child}
        </span>
      ))}
    </div>
  );
}
