import type { CSSProperties } from "react";
import { BRAND_COLORS, BRAND_PATHS, type BrandSlug } from "./brandPaths";
import { glyphOn, plusSurface } from "../lib/color";

/**
 * Плитка с логотипом бренда и веер из трёх таких плиток.
 * Перенесены из донорского мобильного проекта (src/stories/screens/brandTile.tsx).
 *
 * Отличие от BrandMark: тот рисует ГОЛЫЙ знак, эта — знак на фирменной
 * цветной плитке. Голый знак нужен в ряду логотипов («на чём собрано»),
 * плитка — когда бренд это отдельный объект на слайде.
 *
 * Оформление плитки — тот же рецепт plusSurface, что у иконочных квадратов:
 * ход по светлоте и белая кромка. Так брендовая плитка и системная иконка
 * читаются как один материал, а не как два разных элемента.
 */

export interface BrandTileProps {
  brand: BrandSlug;
  size: number;
  /** Переопределить фирменный цвет: например, когда два знака рядом слились */
  tone?: string;
  style?: CSSProperties;
}

export default function BrandTile({ brand, size, tone, style }: BrandTileProps) {
  const fill = tone ?? BRAND_COLORS[brand];

  return (
    <div
      className="grid shrink-0 place-items-center"
      style={{
        width: size,
        height: size,
        /*
         * Радиус привязан к размеру: 0.27 от стороны. Фиксированное число
         * здесь не годится — при нём мелкие плитки выглядят круглее крупных,
         * хотя это одна и та же форма.
         */
        borderRadius: Math.round(size * 0.27),
        /* Размер передаётся, чтобы кромка выросла вместе с плиткой:
           донорский 1px был выверен для стороны 36 */
        ...plusSurface(fill, size),
        ...style,
      }}
    >
      <svg
        width={size * 0.55}
        height={size * 0.55}
        viewBox="0 0 24 24"
        /*
         * Цвет глифа по правилу, а не на глаз: белый везде, где белый даёт
         * хотя бы 3:1 (порог WCAG для нетекстовой графики), иначе тёмный.
         * Выбор «что контрастнее» тут неверен — он давал бы чёрный мяч
         * Dribbble, хотя у самого Dribbble он белый.
         */
        fill={glyphOn(fill)}
        aria-hidden="true"
      >
        <path d={BRAND_PATHS[brand]} />
      </svg>
    </div>
  );
}

/** Сторона плитки в веере */
const TILE = 80;

/** Наклон крайних плиток. Центральная остаётся прямой — иначе веер «падает» */
const TILT = [-8, 0, 8];

/** Насколько плитки заходят друг на друга */
const OVERLAP = 22;

/**
 * Веер из трёх знаков.
 *
 * Приём для случая «мы работаем с этими инструментами»: три знака одним
 * объектом занимают меньше места, чем ряд, и читаются как группа, а не как
 * перечисление.
 */
export function BrandFan({ brands, size = TILE }: { brands: BrandSlug[]; size?: number }) {
  const overlap = Math.round((OVERLAP / TILE) * size);

  return (
    <div className="flex shrink-0 items-center">
      {brands.slice(0, 3).map((brand, index) => (
        <BrandTile
          key={brand}
          brand={brand}
          size={size}
          style={{
            marginLeft: index === 0 ? 0 : -overlap,
            transform: `rotate(${TILT[index]}deg)`,
            zIndex: index,
          }}
        />
      ))}
    </div>
  );
}
