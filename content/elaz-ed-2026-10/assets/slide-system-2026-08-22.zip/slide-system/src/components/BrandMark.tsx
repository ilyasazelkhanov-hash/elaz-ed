import { BRAND_PATHS, BRAND_COLORS, type BrandSlug } from "./brandPaths";

/**
 * Логотип бренда.
 *
 * Пути — из simple-icons (лицензия CC0-1.0), перенесены из донорского мобильного проекта вместе с
 * файлом brandPaths.ts. Все нормализованы в viewBox 24×24, поэтому
 * масштабируются одинаково.
 *
 * === Рисовать логотипы от руки запрещено ===
 *
 * Приближение от руки всегда читается как подделка: пропорции и толщина
 * штрихов не совпадают с оригиналом, и в ряду с настоящими знаками
 * самодельный выпадает. На клиентской презентации это к тому же выглядит
 * как неуважение к чужой марке.
 *
 * Нужного бренда нет в наборе — ОСТАНОВИТЬСЯ И СПРОСИТЬ. Не писать
 * `"название" as BrandSlug`: `as` отключает проверку типов, BRAND_PATHS[brand]
 * вернёт undefined, и логотип молча исчезнет со слайда — ни ошибки сборки,
 * ни ошибки в консоли, просто пустое место, которое заметят на показе.
 *
 * === Про монохром ===
 *
 * Шесть знаков из шестнадцати фирменно почти чёрные (github, anthropic,
 * vercel, apple, openai, cursor). На тёмном слайде их фирменный цвет — это
 * невидимость. Поэтому tone="ink" (знак цветом текста темы) здесь не запасной
 * вариант, а основной для тёмных слайдов и для рядов логотипов, где пёстрая
 * россыпь фирменных цветов разваливает строй.
 */

export type BrandTone = "brand" | "ink" | "onMedia";

export interface BrandMarkProps {
  brand: BrandSlug;
  /** Сторона квадрата знака в пикселях холста */
  size?: number;
  tone?: BrandTone;
  className?: string;
  /**
   * Подпись для доступности. По умолчанию берётся slug бренда.
   * В PDF роли не играет, но Storybook и веб-версия её используют.
   */
  title?: string;
}

const TONE_CLASSES: Record<BrandTone, string> = {
  brand: "",
  ink: "text-ink",
  onMedia: "text-on-media",
};

export default function BrandMark({
  brand,
  size = 64,
  tone = "brand",
  className,
  title,
}: BrandMarkProps) {
  const path = BRAND_PATHS[brand];

  return (
    <svg
      viewBox="0 0 24 24"
      width={size}
      height={size}
      role="img"
      aria-label={title ?? brand}
      className={[TONE_CLASSES[tone], className].filter(Boolean).join(" ")}
      // Фирменный цвет приходит из данных пакета, а не подбирается пипеткой.
      // В монохромных режимах цвет берётся от класса через currentColor.
      fill={tone === "brand" ? BRAND_COLORS[brand] : "currentColor"}
    >
      <path d={path} />
    </svg>
  );
}
