import type { ButtonHTMLAttributes, ReactNode, Ref } from "react";

/**
 * Кнопка. Перенесена из донорского мобильного проекта (src/components/Button.tsx).
 *
 * === Что изменилось при переносе ===
 *
 * Высоты пересчитаны под холст 1920px: донорские 56/48/40/36 превратились в
 * 80/68/56/48. Закон донора «радиус = половина высоты» сохранён, то есть
 * кнопка всегда капсула.
 *
 * Цвета переехали с прямых на роли темы: было bg-action-primary (всегда
 * чёрный), стало bg-action — в светлой теме чёрный, в тёмной белый. Чёрная
 * кнопка на тёмном слайде это дыра, а не элемент.
 *
 * === Зачем кнопка в презентации ===
 *
 * Не для нажатия — PDF не кликают. Кнопка на слайде это ИЗОБРАЖЕНИЕ призыва:
 * «оставить заявку», «перейти на сайт», подпись к QR-коду. Поэтому она
 * рисуется, но интерактивных состояний (hover, focus-visible) намеренно не
 * получает — в PDF их не существует, а в Storybook они создавали бы ложное
 * впечатление работающего элемента.
 */

export type ButtonVariant = "primary" | "secondary" | "outline" | "onMedia";

/**
 * Размер задаёт высоту, радиус, горизонтальные поля и кегль разом — по канону
 * это связка, а не независимые параметры.
 */
export type ButtonSize = "xl" | "l" | "m" | "s";

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  /** Растянуть на всю ширину родителя */
  fullWidth?: boolean;
  children?: ReactNode;
  ref?: Ref<HTMLButtonElement>;
}

/**
 * Классы записаны полными литералами. Собирать их из кусков нельзя: Tailwind
 * сканирует исходники как текст и склеенных имён не находит — утилита просто
 * не попадёт в сборку, а элемент останется без стиля.
 */
const VARIANT_CLASSES: Record<ButtonVariant, string> = {
  primary: "bg-action text-action-fg",
  secondary: "bg-fill text-ink",
  outline: "bg-transparent text-ink border-2 border-line",
  onMedia: "bg-on-media-fill text-on-media backdrop-blur-md",
};

/** Радиус — ровно половина высоты: 80→40, 68→34, 56→28, 48→24 */
const SIZE_CLASSES: Record<ButtonSize, string> = {
  xl: "h-20 rounded-button-xl px-10 text-title-l",
  l: "h-17 rounded-button-l px-9 text-title-m",
  m: "h-14 rounded-button-m px-8 text-body-l",
  s: "h-12 rounded-button-s px-6 text-body-m",
};

/*
 * border-none здесь намеренно НЕ используется: он задаёт border-style: none,
 * и тогда обводка варианта outline не рисуется вовсе — border-2 задаёт только
 * толщину, а без стиля рамки её не видно. Сброс рамки у кнопки и так делает
 * preflight Tailwind.
 */
const BASE_CLASSES =
  "inline-flex items-center justify-center gap-3 select-none whitespace-nowrap shadow-none";

export default function Button({
  variant = "primary",
  size = "xl",
  fullWidth = false,
  type = "button",
  className,
  children,
  ref,
  ...rest
}: ButtonProps) {
  const classes = [
    BASE_CLASSES,
    VARIANT_CLASSES[variant],
    SIZE_CLASSES[size],
    fullWidth ? "w-full" : "",
    className,
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <button {...rest} ref={ref} type={type} className={classes}>
      {children}
    </button>
  );
}
