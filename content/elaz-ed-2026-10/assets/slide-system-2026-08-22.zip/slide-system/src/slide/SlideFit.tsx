import { useLayoutEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";

/**
 * Вписывание слайда в доступное место.
 *
 * Холст всегда нарисован в 1920×1080, а показать его нужно в окне любого
 * размера. Обёртка измеряет себя и сжимает холст через transform: scale.
 *
 * === Почему JS, а не CSS ===
 *
 * Чистого CSS для «вписать блок фиксированного размера в контейнер по
 * меньшей стороне» нет. Приём с делением длины на длину в calc()
 * (`calc(100cqw / 1920px)`) даёт безразмерное число по спецификации, но
 * поддержан не везде, а при неподдержке правило молча отбрасывается — слайд
 * останется в натуральную величину и вылезет за окно без единой ошибки.
 * ResizeObserver работает везде и ведёт себя предсказуемо.
 *
 * === Почему размеры измеряются, а не берутся из констант ===
 *
 * offsetWidth холста возвращает его РАЗМЕР ПО МАКЕТУ и не зависит от уже
 * применённой трансформации (в отличие от getBoundingClientRect, который
 * вернул бы уже сжатое число и загнал расчёт в петлю). Значит, размер холста
 * можно просто спросить у него самого — и не держать копию чисел 1920/1080
 * в TypeScript рядом с теми же числами в tokens.css. Второй источник правды
 * рано или поздно разъезжается с первым.
 */

export interface SlideFitProps {
  children?: ReactNode;
  className?: string;
  style?: CSSProperties;
}

export default function SlideFit({ children, className, style }: SlideFitProps) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  useLayoutEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;

    const measure = () => {
      const canvas = wrap.querySelector<HTMLElement>(".slide-canvas");
      if (!canvas) return;

      const naturalWidth = canvas.offsetWidth;
      const naturalHeight = canvas.offsetHeight;
      if (!naturalWidth || !naturalHeight) return;

      const box = wrap.getBoundingClientRect();
      setScale(Math.min(box.width / naturalWidth, box.height / naturalHeight));
    };

    measure();

    const observer = new ResizeObserver(measure);
    observer.observe(wrap);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={wrapRef}
      className={["slide-fit", className].filter(Boolean).join(" ")}
      // Соотношение задаётся здесь, а не в CSS-классе: так обёртка сама
      // добирает высоту под ширину, и в типичном случае (слайд в колонку)
      // мерить нечего — высота всегда ровно под холст.
      style={{ aspectRatio: "16 / 9", ...style, ["--slide-scale" as string]: scale }}
    >
      {children}
    </div>
  );
}
