import type { CSSProperties, ReactNode } from "react";

/**
 * Слайд — холст 1920×1080 фиксированного размера.
 *
 * Компонент НЕ занимается вписыванием в окно: он всегда рисует полный размер.
 * Вписывание — задача SlideFit, и это разделение намеренное. Слайд, который
 * сам себя масштабирует, невозможно измерить: getBoundingClientRect вернёт
 * числа после трансформации, и «отступ 120px» окажется, например, 74.9px.
 *
 * Тема задаётся атрибутом data-theme, а не набором классов. Благодаря этому
 * тему можно вкладывать: светлую карточку внутрь тёмного слайда — достаточно
 * повесить data-theme="light" на карточку, и всё её поддерево переключится.
 * Как это работает со стороны CSS — см. src/styles/themes.css.
 */

export type SlideTheme = "light" | "dark";

/*
 * Про снятый проп skin.
 *
 * Пока донорская стилистика обкатывалась, она жила отдельным слоем
 * (src/styles/skin-board.css) и включалась пропом skin="board". Теперь она
 * СТАЛА системой: значения переехали в themes.css и tokens.css, слой удалён,
 * проп снят. Второго визуального слоя больше нет, и заводить его обратно
 * не нужно — иначе появятся два источника правды на одни и те же роли.
 */

export interface SlideProps {
  /** Тема слайда. По умолчанию светлая */
  theme?: SlideTheme;
  /**
   * Фон слайда, если он отличается от canvas темы: акцентная заливка,
   * градиент. Обычные слайды его не задают.
   */
  background?: string;
  children?: ReactNode;
  className?: string;
  style?: CSSProperties;
}

export default function Slide({
  theme = "light",
  background,
  children,
  className,
  style,
}: SlideProps) {
  const classes = ["slide-canvas", className].filter(Boolean).join(" ");

  return (
    <div
      data-theme={theme}
      className={classes}
      style={background ? { ...style, background } : style}
    >
      {children}
    </div>
  );
}

/**
 * Рабочая область слайда — 1680×904 внутри полей 120×88.
 *
 * Отдельный компонент, а не поля на самом холсте: фоновые слои (фотография,
 * световое пятно, зерно) должны лежать во всю площадь холста, ПОД полями.
 * Если бы поля были на холсте, фон получил бы белую рамку по краю.
 *
 * Порядок использования:
 *   <Slide theme="dark">
 *     <img className="absolute inset-0 h-full w-full object-cover" />
 *     <div className="slide-media-scrim" />
 *     <SlideBody> …текст… </SlideBody>
 *   </Slide>
 */
export interface SlideBodyProps {
  children?: ReactNode;
  className?: string;
}

export function SlideBody({ children, className }: SlideBodyProps) {
  const classes = ["slide-safe", className].filter(Boolean).join(" ");
  return <div className={classes}>{children}</div>;
}
