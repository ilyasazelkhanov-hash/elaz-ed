import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Sample } from "./showcase";

/**
 * Витрина скруглений.
 *
 * Значения взяты у донорского дашборда (замер: применяются 4 · 6 · 10 · 16
 * · 24 при макете ~1440px) и умножены на 4/3 под холст 1920px. Полный вывод
 * каждого числа, включая экстраполированную ступень `hero`, — в шапке блока
 * СКРУГЛЕНИЯ в src/styles/tokens.css.
 */

const meta = {
  title: "Токены/Скругления",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const RADII = [
  { cls: "rounded-micro", token: "rounded-micro", value: "6px", note: "мелкие элементы · донор 4" },
  { cls: "rounded-tile", token: "rounded-tile", value: "12px", note: "плитки, превью · донор 10" },
  {
    cls: "rounded-card",
    token: "rounded-card",
    value: "20px",
    note: "карточки, строки · донор 16",
  },
  { cls: "rounded-panel", token: "rounded-panel", value: "32px", note: "панели, блоки · донор 24" },
  { cls: "rounded-hero", token: "rounded-hero", value: "48px", note: "во всю ширину · донор ×1.5" },
  { cls: "rounded-capsule", token: "rounded-capsule", value: "400px", note: "капсула. НЕ 999px" },
];

const BUTTON_RADII = [
  { cls: "rounded-button-xl", token: "rounded-button-xl", value: "40px", note: "высота 80" },
  { cls: "rounded-button-l", token: "rounded-button-l", value: "34px", note: "высота 68" },
  { cls: "rounded-button-m", token: "rounded-button-m", value: "28px", note: "высота 56" },
  { cls: "rounded-button-s", token: "rounded-button-s", value: "24px", note: "высота 48" },
];

export const Скругления: Story = {
  render: () => (
    <div>
      <Section title="Общие">
        {RADII.map((r) => (
          <Sample
            key={r.token}
            name={r.token}
            note={r.note}
            expected={r.value}
            property="border-top-left-radius"
            className={`${r.cls} bg-fill-strong w-full`}
            height={96}
          />
        ))}
      </Section>

      <Section
        title="Кнопки"
        hint="Радиус — ровно половина высоты, то есть кнопка всегда капсула. ⚠️ Единственное место, где донор не применён: у донора кнопки скруглены на 10, то есть НЕ капсулой; 10 × 4/3 = 13.33, на сетке 4 это 12 — ровно rounded-tile. После пересчёта карточки в 20 разрыв стал заметнее: кнопка высотой 48 несёт радиус 24 рядом с карточкой в 20, то есть самый мелкий элемент слайда оказывается самым круглым. Менять закон кнопки молча нельзя — вопрос вынесен заказчику."
      >
        {BUTTON_RADII.map((r) => (
          <Sample
            key={r.token}
            name={r.token}
            note={r.note}
            expected={r.value}
            property="border-top-left-radius"
            className={`${r.cls} bg-fill-strong w-full`}
            height={80}
          />
        ))}
      </Section>

      <Section
        title="Концентричность"
        hint="Внутренний радиус = внешний МИНУС поле. Слева правильно: панель 32, поле 20 (p-5), плитка 12 — то есть rounded-tile. Справа обе по 32 — внутреннее скругление кажется круглее внешнего, и углы выглядят разъехавшимися. ⚠️ Card зашит как rounded-panel + p-8, то есть 32 и 32: правило требует от вложенного блока прямого угла, и скруглённая плитка внутри Card его нарушает всегда."
      >
        <div className="flex gap-12">
          <div className="bg-surface-muted rounded-panel p-5">
            <div className="bg-accent-blue rounded-tile h-40 w-64" />
            <p className="text-caption text-ink-secondary mt-4">32 − 20 = 12 ✓</p>
          </div>
          <div className="bg-surface-muted rounded-panel p-5">
            <div className="bg-accent-red rounded-panel h-40 w-64" />
            <p className="text-caption text-ink-secondary mt-4">32 и 32 ✗</p>
          </div>
        </div>
      </Section>
    </div>
  ),
};
