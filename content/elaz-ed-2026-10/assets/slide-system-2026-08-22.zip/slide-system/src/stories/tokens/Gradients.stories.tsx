import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section } from "./showcase";
import {
  accentStops,
  accentSurface,
  areaFill,
  areaStops,
  barFill,
  barStops,
  contrast,
  runContrast,
  type GradientStop,
} from "../../lib/color";
import { CHART_EMPHASIS, CHART_MUTED, CHART_SERIES } from "../../lib/chartPalette";

/**
 * Витрина градиентных рецептов.
 *
 * Она устроена не как «полюбуйтесь на образцы», а как остальные витрины
 * токенов: рядом с каждым образцом стоит ЧИСЛО, посчитанное тут же, и его
 * порог. Плоские заливки в системе были заменены градиентом ровно потому,
 * что контраст при этом обязан остаться на месте, — и проверять это надо
 * тем же способом, каким принималось решение.
 *
 * ⚠️ Контраст считается ПО ВСЕМУ ходу (`runContrast`, 101 точка), а не по
 * концам: если светлота текста лежит МЕЖДУ светлотами крайних стопов, ход
 * проваливается в середине, а на концах выглядит приличным. Пример такой
 * ловушки — в последней секции.
 */

const meta = { title: "Токены/Градиенты" } satisfies Meta;
export default meta;
type Story = StoryObj<typeof meta>;

/** Поверхности системы: на них меряется контраст самой фигуры */
const SURFACES = [
  { name: "холст", light: "#f7f7f7", dark: "#121212" },
  { name: "карточка", light: "#ffffff", dark: "#262626" },
  { name: "подложка", light: "#f0f0f0", dark: "#1c1c1c" },
];

/** Худший контраст стопов ко всем шести поверхностям обеих тем */
function worstToSurfaces(stops: GradientStop[]) {
  let worst = Infinity;
  for (const s of SURFACES)
    for (const bg of [s.light, s.dark])
      for (const stop of stops) worst = Math.min(worst, contrast(stop.color, bg));
  return worst;
}

function Verdict({ value, floor, what }: { value: number; floor: number; what: string }) {
  const ok = value >= floor;
  return (
    <span className={`text-caption ${ok ? "text-success-fg" : "text-error-fg"}`}>
      {ok ? "✓" : "✗"} {what} {value.toFixed(2)}:1 при пороге {floor}
    </span>
  );
}

export const Градиенты: Story = {
  render: () => (
    <div>
      <Section
        title="barFill — столбик, полоса, сегмент, клетка"
        hint="Краска остаётся НИЖНИМ стопом, вверх идёт осветление на 1.8 пункта светлоты. Якорь снизу выбран замером: палитра графиков стоит на пороге 3:1 впритык (lime-700 на тёмной карточке — 3.04), и любое затемнение её роняет. Оттого градиент не стоит фигуре ни одного пункта контраста: худшая точка — та же самая, что была у плоской заливки."
      >
        {CHART_SERIES.map((c) => (
          <div key={c} className="flex items-center gap-6">
            <code className="text-body-m text-ink w-40 shrink-0">{c}</code>
            <div
              className="rounded-tile h-24 w-80 shrink-0"
              style={{ background: barFill(c) }}
              aria-hidden="true"
            />
            <div className="flex flex-col gap-1">
              <span className="text-caption text-ink-secondary">
                стопы {barStops(c)[0].color} → {barStops(c)[1].color}
              </span>
              <Verdict
                value={worstToSurfaces(barStops(c))}
                floor={3}
                what="фигура к худшей поверхности"
              />
            </div>
          </div>
        ))}

        <div className="flex items-center gap-6">
          <code className="text-body-m text-ink w-40 shrink-0">CHART_MUTED</code>
          <div
            className="rounded-tile h-24 w-80 shrink-0"
            style={{ background: barFill(CHART_MUTED) }}
            aria-hidden="true"
          />
          <span className="text-caption text-ink-secondary max-w-xl">
            Приглушённая краска — это переменная CSS, а не hex: светлоту её в JS не сдвинуть.
            barFill возвращает такое значение плоским, и это ровно то, что нужно — приглушённое
            обязано остаться тихим. Место вызова из-за этого обходится без условия.
          </span>
        </div>
      </Section>

      <Section
        title="areaFill — площадь под линией"
        hint="Тот же цвет, что у линии ряда, от 0.55 сверху до 0.04 снизу — числа донора. Порог 3:1 площадь НЕ берёт и брать не должна: носитель смысла у линейного графика это сама линия, а площадь показывает, с какой стороны от неё лежит величина."
      >
        {[CHART_EMPHASIS, CHART_SERIES[2]].map((c) => (
          <div key={c} className="flex items-center gap-6">
            <code className="text-body-m text-ink w-40 shrink-0">{c}</code>
            <div className="w-80 shrink-0">
              {/* SVG-запись того же рецепта: те же стопы, но stop-color и
                  stop-opacity раздельными атрибутами. Рядом с CSS-образцом
                  выше она стоит намеренно — если рецепты разойдутся, разница
                  будет видна здесь, а не на слайде клиента */}
              <svg viewBox="0 0 320 96" className="block h-24 w-80" aria-hidden="true">
                <defs>
                  <linearGradient id={`area-${c.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
                    {areaStops(c).map((s) => (
                      <stop
                        key={s.offset}
                        offset={s.offset}
                        stopColor={s.color}
                        stopOpacity={s.opacity}
                      />
                    ))}
                  </linearGradient>
                </defs>
                <path
                  d="M0 78 L64 52 L128 62 L192 24 L256 36 L320 10 L320 96 L0 96 Z"
                  fill={`url(#area-${c.slice(1)})`}
                />
                <path
                  d="M0 78 L64 52 L128 62 L192 24 L256 36 L320 10"
                  fill="none"
                  stroke={c}
                  strokeWidth={3}
                />
              </svg>
            </div>
            <div className="flex flex-col gap-1">
              <span className="text-caption text-ink-secondary">
                SVG: stop-color + stop-opacity
              </span>
              <span className="text-caption text-ink-secondary">CSS: {areaFill(c)}</span>
              <Verdict value={contrast(c, "#f7f7f7")} floor={3} what="ЛИНИЯ к светлому холсту" />
            </div>
          </div>
        ))}
      </Section>

      <Section
        title="accentSurface — акцентная плашка с подписью"
        hint="Донорский ход целиком: краска сверху, −4.9 пункта светлоты вниз. Здесь полный ход допустим, потому что худший случай у плашки другой — не «фигура против фона», а «подпись против заливки». Затемнение вниз белой подписи не вредит вовсе, а самый светлый стоп совпадает с исходной краской: градиент не стоит подписи ничего. Цвет подписи считает glyphOn, а не вписан руками."
      >
        {[CHART_EMPHASIS, "#155dfc", "#50a2ff", "#ffcc00"].map((c) => {
          const surface = accentSurface(c);
          const min = runContrast(accentStops(c), surface.color, "#ffffff");
          return (
            <div key={c} className="flex items-center gap-6">
              <code className="text-body-m text-ink w-40 shrink-0">{c}</code>
              <div
                className="rounded-card text-title-m flex h-24 w-80 shrink-0 items-center px-6"
                style={surface}
              >
                Акцентная плашка
              </div>
              <div className="flex flex-col gap-1">
                <span className="text-caption text-ink-secondary">
                  подпись {surface.color} · плоская дала бы {contrast(c, surface.color).toFixed(2)}
                </span>
                <Verdict value={min} floor={3} what="подпись по всему ходу" />
              </div>
            </div>
          );
        })}
      </Section>

      <Section
        title="Почему контраст меряется по всему ходу"
        hint="Слева ход чёрный → белый с подписью #767676. На обоих концах контраст выше 4.5, то есть проверка по стопам такой градиент пропустит. На деле подпись пропадает в середине: её светлота лежит МЕЖДУ светлотами концов, и контраст проваливается до 1:1. Ровно этот класс дефекта уже стоил слайда в blocks/layers.tsx."
      >
        <div className="flex items-center gap-6">
          <div
            className="rounded-card text-title-m flex h-24 w-160 shrink-0 items-center justify-around"
            style={{
              background: "linear-gradient(90deg, #000000 0%, #ffffff 100%)",
              color: "#767676",
            }}
          >
            <span>край</span>
            <span>середина</span>
            <span>край</span>
          </div>
          <div className="flex flex-col gap-1">
            <span className="text-caption text-ink-secondary">
              концы {contrast("#000000", "#767676").toFixed(2)} и{" "}
              {contrast("#ffffff", "#767676").toFixed(2)}
            </span>
            <Verdict
              value={runContrast(
                [
                  { offset: 0, color: "#000000", opacity: 1 },
                  { offset: 1, color: "#ffffff", opacity: 1 },
                ],
                "#767676",
                "#ffffff",
              )}
              floor={3}
              what="минимум по ходу"
            />
          </div>
        </div>
      </Section>
    </div>
  ),
};
