import { useLayoutEffect, useRef, useState, type ReactNode } from "react";

/**
 * Вспомогательные компоненты витрины токенов.
 *
 * Ключевая идея перенесена из донорского мобильного проекта: рядом с образцом показывается
 * ФАКТИЧЕСКОЕ вычисленное значение из браузера, а не то, что написано в коде.
 * Если токен не подхватился Tailwind, утилита не сгенерируется, и в витрине
 * будет видно «0px» вместо ожидаемого числа — сломаться молча не получится.
 *
 * Здесь эта проверка важнее, чем в доноре: там тема была одна, а здесь у
 * половины токенов два значения, и переключение держится на слове `inline`
 * в @theme. Стоит его потерять — тёмная тема перестанет переключаться, при
 * этом код останется валидным и сборка пройдёт. Витрина ловит ровно это.
 */

export type ThemeName = "light" | "dark";

/** Значение токена: одно на обе темы или разное */
export type Expected = string | Record<ThemeName, string>;

/**
 * Определяет активную тему по ближайшему предку с data-theme.
 * Нужна, чтобы показывать ожидаемое значение именно текущей темы.
 */
export function useActiveTheme<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [theme, setTheme] = useState<ThemeName>("light");

  useLayoutEffect(() => {
    const host = ref.current?.closest("[data-theme]");
    const value = host?.getAttribute("data-theme");
    setTheme(value === "dark" ? "dark" : "light");
  });

  return { ref, theme };
}

export function useComputed<T extends HTMLElement>(property: string) {
  const ref = useRef<T>(null);
  const [value, setValue] = useState("—");

  useLayoutEffect(() => {
    if (!ref.current) return;
    const computed = getComputedStyle(ref.current).getPropertyValue(property).trim();
    setValue(computed || "(пусто)");
  });

  return { ref, value };
}

export function Section({
  title,
  hint,
  children,
}: {
  title: string;
  hint?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="mb-16">
      <h2 className="text-headline-s text-ink mb-2">{title}</h2>
      {hint ? <div className="text-body-m text-ink-secondary mb-6 max-w-4xl">{hint}</div> : null}
      <div className="flex flex-col gap-4">{children}</div>
    </section>
  );
}

/**
 * Строка витрины: имя токена, образец, сверка факта с ожиданием.
 *
 * Сравнение нормализует запись: браузер возвращает цвета в rgb(), тени —
 * со своим порядком пробелов, и посимвольное сравнение давало бы ложные
 * расхождения на каждой строке.
 */
export function Row({
  name,
  expected,
  actual,
  note,
  children,
}: {
  name: string;
  expected: Expected;
  actual: string;
  note?: string;
  children: ReactNode;
}) {
  const { ref, theme } = useActiveTheme<HTMLDivElement>();
  const want = typeof expected === "string" ? expected : expected[theme];
  const matches = normalize(actual) === normalize(want);

  return (
    <div ref={ref} className="flex items-start gap-6">
      <div className="w-64 shrink-0 pt-1">
        <code className="text-body-m text-ink">{name}</code>
        {note ? <p className="text-caption text-ink-tertiary mt-1">{note}</p> : null}
      </div>

      <div className="w-80 shrink-0">{children}</div>

      <div className="text-caption flex flex-col gap-1 pt-1">
        <span className="text-ink-secondary">ожидалось {want}</span>
        <span className={matches ? "text-success-fg" : "text-error-fg"}>
          {matches ? "✓ совпадает" : `✗ фактически ${actual}`}
        </span>
      </div>
    </div>
  );
}

/**
 * Образец, который сам себя замеряет: рисуется классом, читает у себя
 * вычисленное свойство и отдаёт его в Row.
 */
export function Sample({
  className,
  property,
  expected,
  name,
  note,
  height = 56,
}: {
  className: string;
  property: string;
  expected: Expected;
  name: string;
  note?: string;
  height?: number;
}) {
  const { ref, value } = useComputed<HTMLDivElement>(property);

  return (
    <Row name={name} expected={expected} actual={value} note={note}>
      <div ref={ref} className={className} style={{ height }} />
    </Row>
  );
}

/**
 * Приводит запись к виду, в котором её можно сравнивать.
 *
 * Две причины, по которым посимвольное сравнение не годится:
 *
 * 1. Пробелы. Браузер возвращает `rgb(21, 93, 252)` и свой порядок пробелов
 *    в тенях — записанное в коде `rgb(21,93,252)` не совпало бы ни разу.
 *
 * 2. Шестнадцатеричная запись. В токенах цвет удобно писать как #155dfc,
 *    а getComputedStyle ВСЕГДА отдаёт rgb() — без перевода витрина показывала
 *    бы «не совпадает» на каждой строке, то есть была бы бесполезна.
 */
function normalize(value: string) {
  return hexToRgb(dropEmptyShadowLayers(value.replace(/\s+/g, "").toLowerCase()));
}

/**
 * Убирает из box-shadow пустые слои Tailwind.
 *
 * Tailwind 4 собирает тень из ПЯТИ слоёв, и утилита выглядит так:
 *
 *   .shadow-card {
 *     --tw-shadow: var(--t-shadow-card);
 *     box-shadow: var(--tw-inset-shadow), var(--tw-inset-ring-shadow),
 *                 var(--tw-ring-offset-shadow), var(--tw-ring-shadow),
 *                 var(--tw-shadow);
 *   }
 *
 * Незанятые слои равны `0 0 #0000`, и getComputedStyle честно возвращает их
 * все: перед настоящим значением стоят четыре `rgba(0, 0, 0, 0) 0px 0px 0px
 * 0px`. Сравнение с текстом токена из-за этого не совпадало НИКОГДА — все
 * шесть строк витрины теней горели красным независимо от значений.
 *
 * Найдено при переносе системы на стилистику донора: ожидания в витрине
 * поменялись, строки остались красными, и оказалось, что дело не в новых
 * значениях, а в самой сверке. Пустой слой ничего не рисует, поэтому
 * выбрасывать его безопасно; настоящие слои с ненулевой альфой остаются.
 */
function dropEmptyShadowLayers(value: string) {
  // Слои разделены запятой, но запятые есть и ВНУТРИ rgb()/rgba() — поэтому
  // режется только запятая, за которой начинается новый цвет.
  return value
    .split(/,(?=rgba?\()/)
    .filter((layer) => layer !== "rgba(0,0,0,0)0px0px0px0px")
    .join(",");
}

function hexToRgb(value: string) {
  const match = /^#([0-9a-f]{6})$/.exec(value);
  if (!match) return value;

  const int = parseInt(match[1], 16);
  const r = (int >> 16) & 255;
  const g = (int >> 8) & 255;
  const b = int & 255;
  return `rgb(${r},${g},${b})`;
}
