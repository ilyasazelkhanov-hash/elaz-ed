import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Sample, type Expected } from "./showcase";

/**
 * Витрина цветов.
 *
 * ВАЖНО: класс каждого образца записан ПОЛНЫМ ЛИТЕРАЛОМ ("bg-accent-blue"),
 * а не собран из кусков (`bg-${token}`). Tailwind сканирует исходники как
 * текст и динамически склеенных имён не видит — такие утилиты не попадут
 * в сборку, и образец останется прозрачным.
 *
 * Значения — стилистика донорского дашборда, ставшая основной системой
 * (из прежней осталась только типографика). Ожидания в этом файле обновлены
 * вместе с палитрой: витрина, показывающая старые числа, хуже её отсутствия.
 *
 * Семантические роли показывают РАЗНОЕ ожидаемое значение в светлой и тёмной
 * теме. Переключить тему — тулбар «Тема» сверху. Если при переключении числа
 * не меняются, значит потеряно слово `inline` в @theme (src/styles/themes.css).
 */

const meta = {
  title: "Токены/Цвета",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

type Swatch = { cls: string; token: string; value: Expected; note?: string };

const SEMANTIC: Swatch[] = [
  {
    cls: "bg-canvas",
    token: "bg-canvas",
    value: { light: "#f7f7f7", dark: "#121212" },
    note: "фон слайда. СЕРЫЙ, а не белый: карточка видна тем, что светлее фона",
  },
  {
    cls: "bg-surface",
    token: "bg-surface",
    value: { light: "#ffffff", dark: "#262626" },
    note: "карточка, панель. Против холста всего 1.07:1 — границу держит обводка",
  },
  {
    cls: "bg-surface-muted",
    token: "bg-surface-muted",
    value: { light: "#f0f0f0", dark: "#1c1c1c" },
    note: "приглушённая подложка — самая тёмная светлая поверхность, на ней и калибруется текст",
  },
  {
    cls: "bg-action",
    token: "bg-action",
    value: { light: "#0a0a0a", dark: "#fafafa" },
    note: "основное действие — инвертируется. 18.48:1 / 17.95:1",
  },
  {
    cls: "bg-action-fg",
    token: "bg-action-fg",
    value: { light: "#ffffff", dark: "#121212" },
    note: "текст на действии. 19.80:1 / 17.95:1",
  },
  {
    cls: "bg-fill",
    token: "bg-fill",
    value: { light: "#f5f5f5", dark: "#1f1f1f" },
    note: "пилюля, вторичная кнопка. Заливки донора непрозрачные, а не краска под процентом",
  },
  {
    cls: "bg-fill-strong",
    token: "bg-fill-strong",
    value: { light: "#ebebeb", dark: "#2f2f2f" },
  },
  {
    cls: "bg-line",
    token: "bg-line",
    value: { light: "#ebebeb", dark: "#2f2f2f" },
    note: "разделитель, обводка. Несёт объём ВМЕСТО тени — теней в системе больше нет",
  },
  {
    cls: "bg-scrim",
    token: "bg-scrim",
    value: { light: "rgba(0,0,0,0.38)", dark: "rgba(0,0,0,0.6)" },
    note: "затемнение под выносом",
  },
];

const TEXT: Swatch[] = [
  {
    cls: "bg-ink",
    token: "text-ink",
    value: { light: "#0a0a0a", dark: "#fafafa" },
    note: "основной. 18.48:1 / 17.95:1 на холсте",
  },
  {
    cls: "bg-ink-secondary",
    token: "text-ink-secondary",
    value: { light: "#6a6a6a", dark: "#a3a3a3" },
    note: "вторичный. Затемнён с донорских #737373: те давали 4.16:1 на приглушённой подложке. Сейчас 5.05 / 5.41 / 4.75 — холст / карточка / приглушённая",
  },
  {
    cls: "bg-ink-tertiary",
    token: "text-ink-tertiary",
    value: { light: "#838383", dark: "#7d7d7d" },
    note: "третичный. 3.54 / 3.79 / 3.33 в светлой и 4.55 / 3.68 / 4.14 в тёмной — ТОЛЬКО кегль ≥24px, теперь в ОБЕИХ темах",
  },
  {
    cls: "bg-accent-fg",
    token: "text-accent-fg",
    value: { light: "#155dfc", dark: "#50a2ff" },
    note: "акцентный ТЕКСТ. Синяя шкала заказчика: blue-600 в светлой, blue-400 в тёмной. 4.90 / 5.25 / 4.60 в светлой (холст / карточка / приглушённая), 7.09 / 5.73 / 6.45 в тёмной. ⚠️ На сильной заливке #ebebeb — 4.40, ниже 4.5: акцентным текстом на bg-fill-strong не набирать",
  },
];

const ACCENTS: Swatch[] = [
  {
    cls: "bg-accent-blue",
    token: "accent-blue",
    value: "#0088ff",
    note: "сырая краска. Акцентом системы БЫЛА до скина board. Акцент сегодня — синяя шкала заказчика (#155dfc), тон снова близкий, но это ДРУГОЕ значение: см. text-accent-fg выше",
  },
  { cls: "bg-accent-orange", token: "accent-orange", value: "#ff8d28" },
  { cls: "bg-accent-cyan", token: "accent-cyan", value: "#00c3d0" },
  { cls: "bg-accent-teal", token: "accent-teal", value: "#008575" },
  { cls: "bg-accent-green", token: "accent-green", value: "#34c759" },
  { cls: "bg-accent-red", token: "accent-red", value: "#ff3b30" },
  { cls: "bg-accent-yellow", token: "accent-yellow", value: "#ffcc00" },
  { cls: "bg-accent-indigo", token: "accent-indigo", value: "#5856d6" },
  { cls: "bg-accent-purple", token: "accent-purple", value: "#af52de" },
  { cls: "bg-accent-pink", token: "accent-pink", value: "#ff2d55" },
  { cls: "bg-accent-brown", token: "accent-brown", value: "#a2845e" },
];

const STATUS: Swatch[] = [
  { cls: "bg-success", token: "success", value: "#34c759", note: "краска, одна на обе темы" },
  { cls: "bg-error", token: "error", value: "#ff3b30" },
  { cls: "bg-warning", token: "warning", value: "#ffcc00" },
  {
    cls: "bg-success-fg",
    token: "text-success-fg",
    value: { light: "#007a33", dark: "#00c950" },
    note: "статусный ТЕКСТ — переворачивается. 4.98:1 на своей заливке в светлой, 5.16:1 в тёмной",
  },
  {
    cls: "bg-error-fg",
    token: "text-error-fg",
    value: { light: "#c81e28", dark: "#ff6b60" },
    note: "донорский #fb2c36 на своей заливке даёт 3.13:1 и для текста не годится",
  },
  {
    cls: "bg-warning-fg",
    token: "text-warning-fg",
    value: { light: "#8a6100", dark: "#ffd60a" },
    note: "4.98:1 на своей заливке",
  },
  {
    cls: "bg-success-fill",
    token: "bg-success-fill",
    value: { light: "#dbfce7", dark: "rgba(0,201,80,0.16)" },
    note: "заливка статусной пилюли. В светлой теме непрозрачная (донорская), в тёмной — краска под 16%: непрозрачная мятная плашка на тёмном слайде выглядит дырой",
  },
];

function Swatches({ items }: { items: Swatch[] }) {
  return (
    <>
      {items.map((s) => (
        <Sample
          key={s.token}
          name={s.token}
          note={s.note}
          expected={s.value}
          property="background-color"
          className={`${s.cls} rounded-tile shadow-hairline w-full`}
          height={48}
        />
      ))}
    </>
  );
}

export const Семантика: Story = {
  render: () => (
    <div>
      <Section
        title="Поверхности и заливки"
        hint="Роли, а не краски. Значение зависит от темы — переключите тулбар «Тема» и посмотрите, что числа изменились. Это и есть проверка, что двухтемность работает."
      >
        <Swatches items={SEMANTIC} />
      </Section>

      <Section
        title="Текст"
        hint="Ровно четыре цвета текста и больше не заводить. Третичный даёт 3.33:1 на приглушённой подложке в светлой теме и 3.68:1 на карточке в тёмной — этого хватает только для кегля от 24px, и теперь ограничение действует в ОБЕИХ темах, а не только в светлой. Мельче набирать вторичным, иерархию держать размером."
      >
        <Swatches items={TEXT} />
      </Section>
    </div>
  ),
};

export const Палитра: Story = {
  render: () => (
    <div>
      <Section
        title="Акценты"
        hint="Одинаковы в обеих темах: это краски, а не роли. ⚠️ Это единственное, что не перешло на донора: у донора одиннадцати акцентных красок нет, а подбирать замену на глаз запрещено. Поэтому акцентный ТЕКСТ (text-accent-fg) идёт по шкале заказчика, а эти заливки остались прежними — решение по ним за заказчиком."
      >
        <Swatches items={ACCENTS} />
      </Section>

      <Section
        title="Статусы"
        hint="Краска и текст — разные роли, и текст переворачивается. Донорский зелёный #00c950 на донорской же светлой плашке #dbfce7 даёт 2.02:1 — им у донора набраны крупные цифры, а не подписи; для светлой темы взят затемнённый #007a33 (4.98:1). В тёмной теме наоборот: #007a33 на тёмной плитке нечитаем, там работает #00c950."
      >
        <Swatches items={STATUS} />
      </Section>
    </div>
  ),
};
