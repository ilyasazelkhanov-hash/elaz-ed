import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Sample } from "./showcase";

/**
 * Витрина отступов и сетки слайда.
 *
 * Базовая шкала — сетка 4px, совпадает с дефолтом Tailwind, переопределять
 * нечего. Здесь только семантические отступы: это зафиксированные решения,
 * а не произвольные числа.
 */

const meta = {
  title: "Токены/Отступы и сетка",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const SPACING = [
  { cls: "p-slide-x", token: "spacing-slide-x", value: "120px", note: "боковое поле слайда" },
  { cls: "p-slide-y", token: "spacing-slide-y", value: "88px", note: "верх и низ слайда" },
  { cls: "p-block", token: "spacing-block", value: "64px", note: "между смысловыми блоками" },
  { cls: "p-stack", token: "spacing-stack", value: "32px", note: "между элементами блока" },
  { cls: "p-gutter", token: "spacing-gutter", value: "24px", note: "желоб сетки" },
  { cls: "p-column", token: "spacing-column", value: "118px", note: "ширина колонки" },
];

export const Отступы: Story = {
  render: () => (
    <Section
      title="Семантические отступы"
      hint="Числа не произвольные: 1920 − 2×120 = 1680 рабочей ширины, 1080 − 2×88 = 904 рабочей высоты."
    >
      {SPACING.map((s) => (
        <Sample
          key={s.token}
          name={s.token}
          note={s.note}
          expected={s.value}
          property="padding-left"
          className={`${s.cls} bg-fill rounded-tile w-full`}
          height={64}
        />
      ))}
    </Section>
  ),
};

export const Сетка: Story = {
  render: () => (
    <div>
      <Section
        title="12 колонок"
        hint="Колонка 118px, желоб 24px. 12×118 + 11×24 = 1680 — ровно рабочая ширина слайда. Целое число не случайно: на дробной колонке элементы, стоящие на разных колонках, разъезжаются на доли пикселя, и на 1920px это видно."
      >
        {/* Сетка показана в натуральную величину, поэтому блок шире окна —
            это нормально, у слайда ширина 1920 */}
        <div className="bg-surface-muted" style={{ width: 1920 }}>
          <div className="slide-safe" style={{ height: 400 }}>
            <div className="slide-grid h-full">
              {Array.from({ length: 12 }, (_, i) => (
                <div
                  key={i}
                  className="bg-accent-blue/20 border-accent-blue/40 rounded-micro flex items-start justify-center border pt-4"
                >
                  <span className="text-caption text-ink-secondary">{i + 1}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      <Section
        title="Типичные раскладки"
        hint="Не изобретать новые: слайды одной презентации должны быть узнаваемо одной системы."
      >
        <div className="bg-surface-muted" style={{ width: 1920 }}>
          <div className="slide-safe gap-block" style={{ height: 560 }}>
            <div className="slide-grid" style={{ height: 150 }}>
              <div className="bg-accent-blue/25 rounded-tile col-span-6 grid place-items-center">
                <span className="text-body-m text-ink">6 + 6 — текст и картинка</span>
              </div>
              <div className="bg-accent-blue/25 rounded-tile col-span-6 grid place-items-center" />
            </div>

            <div className="slide-grid" style={{ height: 150 }}>
              <div className="bg-accent-teal/25 rounded-tile col-span-4 grid place-items-center">
                <span className="text-body-m text-ink">4 + 4 + 4 — три карточки</span>
              </div>
              <div className="bg-accent-teal/25 rounded-tile col-span-4 grid place-items-center" />
              <div className="bg-accent-teal/25 rounded-tile col-span-4 grid place-items-center" />
            </div>

            <div className="slide-grid" style={{ height: 150 }}>
              <div className="bg-accent-purple/25 rounded-tile col-span-7 grid place-items-center">
                <span className="text-body-m text-ink">7 + 5 — текст с выносом</span>
              </div>
              <div className="bg-accent-purple/25 rounded-tile col-span-5 grid place-items-center" />
            </div>
          </div>
        </div>
      </Section>
    </div>
  ),
};
