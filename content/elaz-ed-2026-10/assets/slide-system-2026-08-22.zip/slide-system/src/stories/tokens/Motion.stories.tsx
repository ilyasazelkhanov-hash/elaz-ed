import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Sample } from "./showcase";

/**
 * Витрина анимации.
 *
 * === Честная оговорка ===
 *
 * Выбранный формат выдачи — PDF, а в PDF анимации нет. Эти токены работают
 * только при просмотре в Storybook и пригодятся, если позже появится
 * веб-версия презентации с перелистыванием.
 *
 * Практический вывод: содержимое слайда НЕ должно зависеть от движения.
 * Если смысл блока раскрывается только в анимации — в PDF этот слайд будет
 * непонятным, и заметит это клиент, а не мы.
 */

const meta = {
  title: "Токены/Анимация",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const EASINGS = [
  {
    cls: "ease-spring",
    token: "ease-spring",
    value: "cubic-bezier(0.32, 0.72, 0, 1)",
    note: "появление слайда, вход блока",
  },
  {
    cls: "ease-smooth",
    token: "ease-smooth",
    value: "cubic-bezier(0.22, 0.61, 0.18, 1)",
    note: "появление контента, загрузка картинки",
  },
  {
    cls: "ease-bounce",
    token: "ease-bounce",
    value: "cubic-bezier(0.34, 1.56, 0.64, 1)",
    note: "акцентное появление, с перелётом",
  },
  {
    cls: "ease-in-cubic",
    token: "ease-in-cubic",
    value: "cubic-bezier(0.32, 0, 0.67, 0)",
    note: "уход элемента",
  },
];

const DURATIONS = [
  { cls: "duration-micro", token: "duration-micro", value: "0.2s", note: "микропереход" },
  { cls: "duration-reveal", token: "duration-reveal", value: "0.26s", note: "появление контента" },
  { cls: "duration-slide", token: "duration-slide", value: "0.42s", note: "смена слайда" },
  { cls: "duration-bounce", token: "duration-bounce", value: "0.6s", note: "акцент с перелётом" },
];

const BLURS = [
  { cls: "backdrop-blur-xs", token: "blur-xs", value: "blur(6px)" },
  { cls: "backdrop-blur-sm", token: "blur-sm", value: "blur(12px)" },
  { cls: "backdrop-blur-md", token: "blur-md", value: "blur(16px)" },
  { cls: "backdrop-blur-lg", token: "blur-lg", value: "blur(20px)" },
  { cls: "backdrop-blur-xl", token: "blur-xl", value: "blur(24px)" },
];

export const Кривые: Story = {
  render: () => (
    <Section
      title="Кривые"
      hint="Перенесены из донорского мобильного проекта без изменений: кривая не зависит от размера носителя. Из донорского набора убраны длительности, привязанные к мобильным шитам — шитов на слайде нет."
    >
      {EASINGS.map((e) => (
        <Sample
          key={e.token}
          name={e.token}
          note={e.note}
          expected={e.value}
          property="transition-timing-function"
          className={`${e.cls} bg-fill rounded-tile w-full transition-all`}
          height={48}
        />
      ))}
    </Section>
  ),
};

export const Длительности: Story = {
  render: () => (
    <Section title="Длительности">
      {DURATIONS.map((d) => (
        <Sample
          key={d.token}
          name={d.token}
          note={d.note}
          expected={d.value}
          property="transition-duration"
          className={`${d.cls} bg-fill rounded-tile w-full transition-all`}
          height={48}
        />
      ))}
    </Section>
  ),
};

export const Размытие: Story = {
  render: () => (
    <Section
      title="Размытие"
      hint="Работает поверх картинки — на слайде это подложка под текстом, лежащим на фотографии."
    >
      <div className="rounded-panel relative overflow-hidden" style={{ height: 220, width: 900 }}>
        <div className="from-accent-blue via-accent-purple to-accent-orange absolute inset-0 bg-gradient-to-r" />
        <div className="absolute inset-0 flex items-center gap-6 p-8">
          {BLURS.map((b) => (
            <div
              key={b.token}
              className={`${b.cls} rounded-tile bg-on-media-fill text-on-media text-caption grid flex-1 place-items-center`}
              style={{ height: 140 }}
            >
              {b.token}
            </div>
          ))}
        </div>
      </div>
    </Section>
  ),
};
