import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Row, useComputed } from "./showcase";

/**
 * Витрина типографики.
 *
 * Проверяет три числа сразу: кегль, межстрочный и межбуквенный. Последний —
 * самое хрупкое место: он считается по формуле −(размер × 0.02), и если при
 * добавлении размера его подобрали на глаз, здесь это видно немедленно.
 */

const meta = {
  title: "Токены/Типографика",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

type Scale = {
  cls: string;
  token: string;
  size: string;
  line: string;
  tracking: string;
  weight: string;
  use: string;
};

const SCALE: Scale[] = [
  {
    cls: "text-display-l",
    token: "display-l",
    size: "128px",
    line: "128px",
    tracking: "-2.56px",
    weight: "600",
    use: "обложка",
  },
  {
    cls: "text-display-m",
    token: "display-m",
    size: "96px",
    line: "100px",
    tracking: "-1.92px",
    weight: "600",
    use: "разделитель раздела",
  },
  {
    cls: "text-display-s",
    token: "display-s",
    size: "72px",
    line: "76px",
    tracking: "-1.44px",
    weight: "600",
    use: "крупная цифра",
  },
  {
    cls: "text-headline-l",
    token: "headline-l",
    size: "56px",
    line: "60px",
    tracking: "-1.12px",
    weight: "600",
    use: "заголовок слайда",
  },
  {
    cls: "text-headline-m",
    token: "headline-m",
    size: "44px",
    line: "48px",
    tracking: "-0.88px",
    weight: "600",
    use: "заголовок в две строки",
  },
  {
    cls: "text-headline-s",
    token: "headline-s",
    size: "36px",
    line: "40px",
    tracking: "-0.72px",
    weight: "600",
    use: "подзаголовок",
  },
  {
    cls: "text-title-l",
    token: "title-l",
    size: "30px",
    line: "36px",
    tracking: "-0.6px",
    weight: "500",
    use: "заголовок карточки",
  },
  {
    cls: "text-title-m",
    token: "title-m",
    size: "26px",
    line: "32px",
    tracking: "-0.52px",
    weight: "500",
    use: "подпись к блоку",
  },
  {
    cls: "text-body-l",
    token: "body-l",
    size: "24px",
    line: "32px",
    tracking: "-0.48px",
    weight: "500",
    use: "основной текст",
  },
  {
    cls: "text-body-m",
    token: "body-m",
    size: "20px",
    line: "28px",
    tracking: "-0.4px",
    weight: "500",
    use: "текст в карточке",
  },
  {
    cls: "text-label",
    token: "label",
    size: "18px",
    line: "24px",
    tracking: "-0.36px",
    weight: "500",
    use: "пилюля, тег",
  },
  {
    cls: "text-caption",
    token: "caption",
    size: "16px",
    line: "20px",
    tracking: "-0.32px",
    weight: "500",
    use: "номер слайда, сноска",
  },
];

function TypeRow({
  item,
  property,
  expected,
}: {
  item: Scale;
  property: string;
  expected: string;
}) {
  const { ref, value } = useComputed<HTMLParagraphElement>(property);

  return (
    <Row name={`${item.token} · ${property}`} note={item.use} expected={expected} actual={value}>
      <p ref={ref} className={`${item.cls} text-ink truncate`}>
        Съешь ещё
      </p>
    </Row>
  );
}

export const Кегль: Story = {
  render: () => (
    <Section
      title="Размеры"
      hint="Двенадцать размеров, шкала закрыта. Инлайновый fontSize запрещён: размер вне шкалы ломает сравнимость слайдов внутри одной презентации."
    >
      {SCALE.map((item) => (
        <TypeRow key={item.token} item={item} property="font-size" expected={item.size} />
      ))}
    </Section>
  ),
};

export const Межстрочный: Story = {
  render: () => (
    <Section
      title="Межстрочный интервал"
      hint="Сжимается с ростом кегля: 1.0 у display-l против 1.4 у body-m. Крупному тексту большой интерлиньяж не нужен — строки и так далеко друг от друга. Все значения кратны 4px, той же сетке, что и отступы."
    >
      {SCALE.map((item) => (
        <TypeRow key={item.token} item={item} property="line-height" expected={item.line} />
      ))}
    </Section>
  ),
};

export const Межбуквенный: Story = {
  render: () => (
    <Section
      title="Межбуквенный интервал"
      hint="Везде −(размер × 0.02). Это формула, а не подбор: при добавлении нового размера считать по ней. Единственное исключение во всей системе — набор прописными в пилюле, там интервал положительный."
    >
      {SCALE.map((item) => (
        <TypeRow key={item.token} item={item} property="letter-spacing" expected={item.tracking} />
      ))}
    </Section>
  ),
};

export const Насыщенность: Story = {
  render: () => (
    <Section
      title="Вес"
      hint="Ровно два: 600 для display и headline, 500 для остального. Третий вес в одной системе читается как другой шрифт."
    >
      {SCALE.map((item) => (
        <TypeRow key={item.token} item={item} property="font-weight" expected={item.weight} />
      ))}
    </Section>
  ),
};

export const Образец: Story = {
  render: () => (
    <div className="flex max-w-6xl flex-col gap-8">
      {SCALE.map((item) => (
        <div key={item.token} className="border-line flex flex-col gap-2 border-b pb-8">
          <code className="text-caption text-ink-tertiary">
            {item.token} — {item.size}/{item.line}, вес {item.weight} · {item.use}
          </code>
          <p className={`${item.cls} text-ink`}>Съешь ещё этих мягких булок</p>
        </div>
      ))}
    </div>
  ),
};
