import type { Meta, StoryObj } from "@storybook/react-vite";
import { Section, Sample, type Expected } from "./showcase";

/**
 * Витрина теней — точнее, того, что от них осталось.
 *
 * После перехода на донорскую стилистику размытых теней в системе НЕТ:
 * у донора их нет ни на одном элементе, объём держат обводка и разница
 * заливок. Четыре токена высоты (card, float, overlay, thumbnail) стали
 * одной и той же волосяной обводкой в 1px цветом линии темы.
 *
 * Имена сохранены все шесть: переименование заставило бы править 125 слайдов
 * четырёх деков ради косметики. Но иерархия высоты схлопнулась — четыре
 * значения совпадают, и витрина это показывает честно, а не делает вид,
 * что уровней по-прежнему четыре.
 *
 * От темы значения по-прежнему зависят: обводка в светлой теме #ebebeb,
 * в тёмной #2f2f2f. Переключите тулбар «Тема» и убедитесь, что числа
 * меняются — это проверка, что слово inline в @theme на месте.
 *
 * Инлайновый box-shadow в компонентах запрещён — только эти утилиты.
 */

const meta = {
  title: "Токены/Тени",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

type Shade = { cls: string; token: string; value: Expected; note: string };

/*
 * Ожидаемые значения записаны в том порядке и формате, в котором их
 * возвращает getComputedStyle: цвет ПЕРЕД смещениями. Это не опечатка —
 * браузер переписывает сокращённую запись box-shadow по-своему, и сравнивать
 * приходится с его вариантом, а не с исходным текстом токена.
 */
const SHADOWS: Shade[] = [
  {
    cls: "shadow-card",
    token: "shadow-card",
    note: "карточки, панели",
    value: {
      light: "rgb(235, 235, 235) 0px 0px 0px 1px",
      dark: "rgb(47, 47, 47) 0px 0px 0px 1px",
    },
  },
  {
    cls: "shadow-float",
    token: "shadow-float",
    note: "приподнятый элемент, вынос. Совпадает с shadow-card: у донора второго уровня высоты нет",
    value: {
      light: "rgb(235, 235, 235) 0px 0px 0px 1px",
      dark: "rgb(47, 47, 47) 0px 0px 0px 1px",
    },
  },
  {
    cls: "shadow-overlay",
    token: "shadow-overlay",
    note: "блок поверх слайда. Тоже совпадает — если понадобится настоящая высота, значение надо спросить у заказчика, а не подобрать",
    value: {
      light: "rgb(235, 235, 235) 0px 0px 0px 1px",
      dark: "rgb(47, 47, 47) 0px 0px 0px 1px",
    },
  },
  {
    cls: "shadow-thumbnail",
    token: "shadow-thumbnail",
    note: "скриншот продукта на слайде",
    value: {
      light: "rgb(235, 235, 235) 0px 0px 0px 1px",
      dark: "rgb(47, 47, 47) 0px 0px 0px 1px",
    },
  },
  {
    cls: "shadow-hairline",
    token: "shadow-hairline",
    note: "контур ВНУТРИ цветной плитки или фотографии — роль другая, чем у обводки карточки, поэтому значение осталось нашим. 1px, а не 0.5: половина пикселя пропадает при масштабировании",
    value: {
      light: "rgba(0, 0, 0, 0.06) 0px 0px 0px 1px inset",
      dark: "rgba(255, 255, 255, 0.1) 0px 0px 0px 1px inset",
    },
  },
  {
    cls: "shadow-focus",
    token: "shadow-focus",
    note: "кольцо выделения. Идёт за акцентом теми же каналами: сейчас rgba(21,93,252,.16) в светлой и rgba(80,162,255,.24) в тёмной — кольцо чужого тона читалось бы как другой смысл",
    value: {
      light: "rgba(127, 34, 254, 0.16) 0px 0px 0px 6px",
      dark: "rgba(166, 132, 255, 0.24) 0px 0px 0px 6px",
    },
  },
];

export const Тени: Story = {
  render: () => (
    <div>
      <Section
        title="Набор"
        hint="Шесть имён, четыре из которых дают одно и то же кольцо в 1px. Это не недосмотр, а устройство донора: у донора размытых теней нет вовсе. Побочная выгода — Chromium не печатает размытые тени в вектор, он их растеризует, а «Просмотр» macOS эти растры терял; обводка с нулевым размытием печатается вектором."
      >
        {SHADOWS.map((s) => (
          <Sample
            key={s.token}
            name={s.token}
            note={s.note}
            expected={s.value}
            property="box-shadow"
            className={`${s.cls} bg-surface rounded-card w-full`}
            height={96}
          />
        ))}
      </Section>

      <Section
        title="Чем теперь отделяется карточка"
        hint="Замер: белая карточка против серого холста — 1.07:1, обводка #ebebeb на холсте — 1.11:1. Порог 3.0 для нетекстовой графики не проходит ни то ни другое. На мониторе с полуметра граница видна, на проекторе с засветкой может пропасть совсем. Числа зафиксированы, решение за заказчиком: это устройство донора, а не ошибка переноса."
      >
        <div className="bg-canvas flex items-center gap-8 p-8">
          <div className="bg-surface shadow-card rounded-card text-title-m text-ink flex h-40 w-80 items-center justify-center">
            Карточка на холсте
          </div>
          <div className="bg-surface-muted rounded-card text-title-m text-ink flex h-40 w-80 items-center justify-center">
            Приглушённая, без обводки
          </div>
        </div>
      </Section>

      <Section
        title="Кнопка тени не имеет"
        hint="Правило пережило смену системы без изменений: главные кнопки действия плоские. Раньше это было решением против лишнего объёма, теперь ещё и тавтология — размытых теней в системе нет. Для явного «без тени» есть shadow-none."
      >
        <div className="flex items-center gap-8">
          <div className="bg-action text-action-fg text-title-l rounded-button-xl flex h-20 items-center px-10 shadow-none">
            Плоская ✓
          </div>
        </div>
      </Section>
    </div>
  ),
};
