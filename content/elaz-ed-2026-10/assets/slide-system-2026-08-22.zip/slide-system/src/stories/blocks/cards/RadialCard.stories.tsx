import type { Meta, StoryObj } from "@storybook/react-vite";
import RadialCard, {
  RADIAL_CARD_COLORS,
  RADIAL_CARD_PAINT,
  radialCardGeometry,
  radialCardValueWidth,
  type RadialCardSegment,
} from "../../../blocks/cards/radialCard";
import { GAUGE_SIZE_RANGE, STACK_MIN_SHARE } from "../../../blocks/gauge";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import { BOARD_SERIES } from "../../../lib/boardPalette";
import { barStops, contrast, runContrast } from "../../../lib/color";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Visitors» — перенос донорского радиального графика.
 *
 * Витрина показывает не столько удачный случай, сколько границы: где число в
 * середине перестаёт помещаться, где сегмент стопки вырождается в просвет, где
 * дуга упирается в потолок и где легенда начинает обрезать названия. Разбор
 * форм и красок — в шапке
 * [`blocks/cards/radialCard.tsx`](../../../blocks/cards/radialCard.tsx),
 * разбор самих дуг — в [`blocks/gauge.tsx`](../../../blocks/gauge.tsx).
 *
 * === Про числа в подписях ===
 *
 * Все размеры и контрасты СЧИТАЮТСЯ прямо здесь — `radialCardGeometry`,
 * `radialCardValueWidth`, `contrast`, `runContrast`, — а не переписаны из
 * шапки блока. Переписанное число живёт своей жизнью: поменяется бюджет
 * карточки или рецепт заливки, а проза останется прежней и будет врать
 * увереннее, чем сам блок.
 *
 * === Про ширину обёртки ===
 *
 * Разборные истории стоят на жёсткой ширине (828 для половинной карточки,
 * 1680 для полной), а не на `max-w-`: сторона поля считается от переданной
 * ширины, и молча сжатый контейнер дал бы картинку, не совпадающую с
 * собственными замерами блока.
 *
 * ⚠️ Чего эта витрина не даёт: `npm run check` обходит только слайды деков.
 * Пока карточка не поставлена в дек, автоматических ворот у неё нет —
 * переполнение здесь ловится замером в режиме 1:1, а не скриптом.
 */

const meta = {
  title: "Карточки/Кольцо и гейдж",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Данные донора  ═══════════════ */

/**
 * Числа со страницы донора: Visitors 925 = 90 + 173 + 187 + 200 + 275.
 *
 * Порядок ПЕРЕВЁРНУТ против донорского. У донора первый элемент ложится на
 * самое внутреннее кольцо, поэтому ряд идёт от меньшего к большему; у стопки
 * колец нет, сегменты идут по дуге от 9 часов, и глаз начинает с первого —
 * значит первым стоит наибольший.
 */
const БРАУЗЕРЫ: RadialCardSegment[] = [
  { label: "Chrome", value: 275 },
  { label: "Safari", value: 200 },
  { label: "Firefox", value: 187 },
  { label: "Edge", value: 173 },
  { label: "Other", value: 90 },
];

const ИТОГ = БРАУЗЕРЫ.reduce((s, b) => s + b.value, 0);

/* ═══════════════  Замеры  ═══════════════ */

const кольцо = radialCardGeometry({ variant: "ring", size: "half" });
const гейдж = radialCardGeometry({ variant: "gauge", size: "half", hasRange: true });
const стопка = radialCardGeometry({ variant: "stacked", size: "half" });
const стопкаПолная = radialCardGeometry({ variant: "stacked", size: "full", width: 1680 });
const кольцоПолное = radialCardGeometry({ variant: "ring", size: "full", width: 1680 });

/** Худшая точка хода заливки против поверхности — тем же рецептом, что рисует дуга */
const дугаК = (paint: string, surface: string) => runContrast(barStops(paint), surface, surface);

const СВЕТЛАЯ_КАРТОЧКА = "#ffffff";
const ТЁМНАЯ_КАРТОЧКА = "#262626";
const ДОРОЖКА = { light: "#ebebeb", dark: "#2f2f2f" };

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Кольцо доли — то, ради чего форма и берётся: одна величина против целого.
 *
 * ⚠️ Здесь видно главное правило блока: число в середине НЕ повторяет число
 * шапки. В шапке итог за период (925 визитов), в середине — доля от плана
 * (63%). Одно и то же число, набранное дважды разным кеглем, читается как
 * ошибка сборки, и блок про такое предупреждает в консоли.
 */
export const Кольцо: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-2">
        Половинная карточка 828 × {CARD_BUDGET}, слот {кольцо.slotW} × {кольцо.slotH}, поле{" "}
        {кольцо.field}
      </h3>
      <p className="text-body-m text-ink-secondary mb-4 max-w-4xl">
        Сторона поля не написана числом, а получена обращением формулы высоты самого блока: у кольца
        поле квадратное, поэтому оно равно высоте слота — {кольцо.field}. Запас в слоте{" "}
        {кольцо.slack.toFixed(0)}. Коробка текста середины {кольцо.centerBox.toFixed(0)} точек:
        «63%» занимает {radialCardValueWidth("63%").toFixed(0)}, «план 1 470» набран body-l и лежит
        строкой ниже.
      </p>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Дуга — опора, а не носитель смысла: длину по окружности человек читает хуже прямой длины,
        поэтому и доля, и знаменатель напечатаны словами. Контраст самой дуги к белой карточке{" "}
        {дугаК(RADIAL_CARD_PAINT, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)}:1 при пороге 3:1 — недобор, и
        держится карточка именно на числах.
      </p>
      <RadialCard
        label="Visitors"
        headline={ИТОГ.toLocaleString("ru-RU")}
        value={ИТОГ}
        total={1470}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        center={{ value: "63%", ratio: "план 1 470" }}
      />
    </div>
  ),
};

/**
 * Полукольцо-гейдж: та же величина, но у шкалы видно начало и конец.
 *
 * Сторона поля здесь упирается не в слот, а в потолок рабочего диапазона
 * `GAUGE_SIZE_RANGE.max`: полукольцо вдвое ниже своей ширины, поэтому слот
 * отдаёт столько высоты, что дуга выросла бы шире, чем форма рассчитана
 * держать. Остаток уходит в центрирование — точные числа считает и печатает
 * сама история.
 */
export const Гейдж: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-2">
        Поле {гейдж.field}
        {гейдж.capped ? ` — зажато потолком ${GAUGE_SIZE_RANGE.max}` : ""}, высота блока{" "}
        {гейдж.blockHeight.toFixed(0)}, запас {гейдж.slack.toFixed(0)}
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Запас {гейдж.slack.toFixed(0)} точек уходит в центрирование по вертикали. Без него он лёг бы
        одним куском снизу, и дуга выглядела бы сдвинутой вверх относительно шапки. Подписи концов
        шкалы — не ось (ось на слайде запрещена правилом dataviz), а два опорных значения, которые
        иначе пришлось бы доставать из знаменателя в уме. Чаша полукольца держит строку шириной{" "}
        {гейдж.centerBox.toFixed(0)}, знаменатель ушёл ПОД дугу — там ему доступна вся ширина блока.
      </p>
      <RadialCard
        variant="gauge"
        label="Visitors"
        headline={ИТОГ.toLocaleString("ru-RU")}
        value={ИТОГ}
        total={1470}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        range={["0", "1 470"]}
        center={{ value: "63%", ratio: "925 визитов из плановых 1 470" }}
      />
    </div>
  ),
};

/**
 * Стопка — то, чем заменён главный вид донора.
 *
 * У донора это пять КОНЦЕНТРИЧЕСКИХ дуг разного радиуса, по одной на браузер.
 * Такую раскладку `blocks/rings.tsx` запрещает первым пунктом своей шапки:
 * при одной и той же доле внешняя дуга длиннее внутренней в 1.468 раза (для
 * трёх колец), то есть рисует на 46.8% больше краски. Здесь все сегменты
 * лежат на ОДНОМ радиусе, и этого искажения нет как класса.
 */
export const Стопка: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-2">
        Поле {стопка.field}, высота блока {стопка.blockHeight.toFixed(1)} при слоте {стопка.slotH}
      </h3>
      <p className="text-body-m text-ink-secondary mb-4 max-w-4xl">
        Легенда — плитки оболочки, а не собственный список блока: у всех семи карточек семейства она
        одна и та же. Плитка {((стопка.slotW - 12 * 4) / 5).toFixed(0)} точек, и бюджетов в ней ДВА:
        величина получает {((стопка.slotW - 12 * 4) / 5 - 40).toFixed(0)} (плитка минус поля), а
        название — {((стопка.slotW - 12 * 4) / 5 - 72).toFixed(0)}, потому что стоит в ряду со
        свотчем 20 и просветом 12. Замер: «Chrome» кеглем body-m занимает 72,9 точки и помещается с
        запасом 3,1 — на этой карточке не обрезано ни одно название. Расхождение с донором названо
        честно: он раскладывает пять плиток на два ряда (3 + 2), у нас — пять равных колонок в один,
        как во всех карточках семейства.
      </p>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        В середине — доля наибольшей категории, а не итог: итог уже стоит в шапке. Наименьшая доля
        здесь {((90 / ИТОГ) * 100).toFixed(1)}% при пороге вырождения{" "}
        {(STACK_MIN_SHARE * 100).toFixed(2)}% — сегмент ещё вдевятеро длиннее просвета между
        сегментами.
      </p>
      <RadialCard
        variant="stacked"
        label="Visitors"
        headline={ИТОГ.toLocaleString("ru-RU")}
        items={БРАУЗЕРЫ}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        center={{ value: "29,7%", ratio: "доля Chrome — наибольшая" }}
      />
    </div>
  ),
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Обе темы рядом через вложенную тему — расхождение видно без переключения
 * тулбара. Здесь смотреть не оттенок, а два разных вопроса: видно ли, ГДЕ
 * дуга, и видно ли, ГДЕ ОНА КОНЧИЛАСЬ.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1704px] gap-12">
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Светлая тема — слабая, и это замерено</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Дуга к белой карточке {дугаК(RADIAL_CARD_PAINT, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)}:1 при пороге
          3:1 — недобор. Дуга к дорожке {дугаК(RADIAL_CARD_PAINT, ДОРОЖКА.light).toFixed(2)}
          :1, то есть граница «дуга кончилась» почти не читается. Сама дорожка к карточке{" "}
          {contrast(ДОРОЖКА.light, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)}:1 — её на проекторе не будет вовсе.
          Всё, что при этом остаётся, — «63%» и «план 1 470» текстом.
        </p>
        <RadialCard
          theme="light"
          label="Visitors"
          headline={ИТОГ.toLocaleString("ru-RU")}
          value={ИТОГ}
          total={1470}
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Last 7 days" }}
          center={{ value: "63%", ratio: "план 1 470" }}
        />
      </div>
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Тёмная — запас втрое</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Та же дуга к карточке #262626 — {дугаК(RADIAL_CARD_PAINT, ТЁМНАЯ_КАРТОЧКА).toFixed(2)}:1,
          к дорожке {дугаК(RADIAL_CARD_PAINT, ДОРОЖКА.dark).toFixed(2)}:1. Порог 3:1 берут оба
          сравнения. Если карточка едет на проектор — брать тёмную тему, и это не вкус, а разница в{" "}
          {(
            дугаК(RADIAL_CARD_PAINT, ТЁМНАЯ_КАРТОЧКА) / дугаК(RADIAL_CARD_PAINT, СВЕТЛАЯ_КАРТОЧКА)
          ).toFixed(1)}{" "}
          раза.
        </p>
        <RadialCard
          theme="dark"
          label="Visitors"
          headline={ИТОГ.toLocaleString("ru-RU")}
          value={ИТОГ}
          total={1470}
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Last 7 days" }}
          center={{ value: "63%", ratio: "план 1 470" }}
        />
      </div>
    </div>
  ),
};

/**
 * Стопка в обеих темах: здесь у краски другая работа — не «видно ли дугу»,
 * а «отличается ли сегмент от соседа». Соседство проверялось донором, не нами
 * (`lib/boardPalette.ts`: дальтонизм для этого набора НЕ проверялся).
 */
export const СтопкаОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1704px] gap-12">
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Светлая</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Пять красок к белой карточке:{" "}
          {RADIAL_CARD_COLORS.map((c) => дугаК(c, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)).join(" · ")}. Порог
          3:1 не берёт ни одна. Величины при этом напечатаны в плитках, и плитка — не украшение:
          квадратик легенды на приглушённой подложке ещё слабее самой дуги.
        </p>
        <RadialCard
          theme="light"
          variant="stacked"
          label="Visitors"
          headline={ИТОГ.toLocaleString("ru-RU")}
          items={БРАУЗЕРЫ}
          period={{ label: "Last 7 days" }}
          center={{ value: "29,7%", ratio: "доля Chrome — наибольшая" }}
        />
      </div>
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Тёмная</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Те же пять к карточке #262626:{" "}
          {RADIAL_CARD_COLORS.map((c) => дугаК(c, ТЁМНАЯ_КАРТОЧКА).toFixed(2)).join(" · ")}. Порог
          берут все пять с запасом. Просвет между сегментами показывает цвет КАРТОЧКИ, а не дорожки:
          у стопки дорожки нет вовсе, сегменты занимают весь разворот.
        </p>
        <RadialCard
          theme="dark"
          variant="stacked"
          label="Visitors"
          headline={ИТОГ.toLocaleString("ru-RU")}
          items={БРАУЗЕРЫ}
          period={{ label: "Last 7 days" }}
          center={{ value: "29,7%", ratio: "доля Chrome — наибольшая" }}
        />
      </div>
    </div>
  ),
};

/* ═══════════════  Крайние случаи  ═══════════════ */

/**
 * Минимум: 4 из 1 200, то есть 0,33%.
 *
 * Чистая пропорция дала бы дугу длиной 3.7 точки при поле 440 — в PDF это
 * ничто, и слайд сказал бы «не начинали», хотя работа началась. У `gauge.tsx`
 * стоит пол `MIN_ARC_LENGTH` = половина толщины дуги: 1.77% полного кольца.
 * То есть дуга ЗАВЫШЕНА впятеро — и ровно поэтому настоящее число стоит в
 * середине, а не выводится из длины.
 */
export const Минимум: Story = {
  render: () => (
    <div className="flex w-[1704px] gap-12">
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">0,33% — сработал пол дуги</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Доля 0,33%, нарисованная длина — 1,77% кольца (пол в половину толщины дуги). Завышение в{" "}
          {(0.0177 / (4 / 1200)).toFixed(1)} раза, и оно сознательное: без пола дуги не было бы
          видно вовсе, а «ничего нет» и «почти ничего нет» — разные утверждения. Настоящее число
          напечатано.
        </p>
        <RadialCard
          label="Заявки на пилот"
          headline="4"
          value={4}
          total={1200}
          period={{ label: "Last 7 days" }}
          center={{ value: "0,3%", ratio: "4 заявки из 1 200 визитов" }}
        />
      </div>
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Ноль — дуги нет совсем</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          При нуле пол не срабатывает: дуга не рисуется. Это правильное поведение — «не начинали» и
          «начали чуть-чуть» должны выглядеть по-разному. Остаётся дорожка, а на светлой карточке
          она {contrast(ДОРОЖКА.light, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)}:1, то есть почти невидима. Всё
          сообщение слайда в этом случае несёт текст середины.
        </p>
        <RadialCard
          label="Заявки на пилот"
          headline="0"
          value={0}
          total={1200}
          period={{ label: "Last 7 days" }}
          center={{ value: "0%", ratio: "ни одной заявки из 1 200 визитов" }}
        />
      </div>
    </div>
  ),
};

/**
 * Потолок — два разных потолка, и путать их нельзя.
 *
 * **Потолок дуги.** Значение больше целого дуга показать не умеет: 128%
 * нарисовались бы вторым витком поверх первого и читались бы как 28%. Дуга
 * зажимается полным разворотом, настоящее число стоит текстом, и подпись
 * ОБЯЗАНА сказать, что потолок превышен. Блок предупреждает в консоли.
 *
 * **Потолок размера.** У гейджа сторона поля упирается в
 * `GAUGE_SIZE_RANGE.max` = {GAUGE_SIZE_RANGE.max}, а не в слот: см. историю
 * «Гейдж».
 */
export const Потолок: Story = {
  render: () => (
    <div className="flex w-[1704px] gap-12">
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">128% — дуга сомкнулась, число говорит правду</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Кольцо замкнуто целиком, и по картинке 128% неотличимы от 100%. Поэтому подпись
          проговаривает перевыполнение словами. В консоли режима разработки — предупреждение с
          обоими числами.
        </p>
        <RadialCard
          label="План продаж"
          headline="1 880"
          value={1880}
          total={1470}
          delta={{ label: "+28,0%", direction: "up" }}
          period={{ label: "Last 30 days" }}
          center={{ value: "128%", ratio: "план 1 470 перевыполнен" }}
        />
      </div>
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">99,9% — дуга НЕ смыкается</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Потолок дуги — полный разворот минус минимально различимая длина: значение меньше целого
          не имеет права сомкнуть кольцо, иначе картинка скажет «готово», когда не готово. Просвет
          виден в 12 часов.
        </p>
        <RadialCard
          label="Миграция данных"
          headline="1 469"
          value={1469}
          total={1470}
          period={{ label: "Last 7 days" }}
          center={{ value: "99,9%", ratio: "остался 1 договор из 1 470" }}
        />
      </div>
    </div>
  ),
};

/**
 * Длинные подписи — три разных места, где длина ломает разное.
 *
 * 1. **Число середины.** Коробка кольца {кольцо.centerBox.toFixed(0)} точек;
 *    «12 400» занимает {radialCardValueWidth("12 400").toFixed(0)} и
 *    переносится на две строки, а перенос растит коробку ВВЕРХ, к дуге. Блок
 *    считает эту ширину сам и предупреждает. Насколько именно «к дуге» —
 *    замерено в самой истории: до дуги остаётся ещё десяток точек, но
 *    заявленный просвет съеден целиком.
 * 2. **Знаменатель.** У кольца он в середине и переносится внутри коробки;
 *    у полукольца — под дугой, где ему доступна вся ширина блока.
 * 3. **Плитки легенды.** Название длиннее плитки обрезается многоточием:
 *    перенос увеличил бы высоту легенды, а она входит в расчёт места под дугу.
 */
export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="flex w-[1704px] flex-col gap-12">
      <div className="flex gap-12">
        <div className="w-[828px]">
          <h3 className="text-title-l text-ink mb-2">Число не помещается — предупреждение</h3>
          <p className="text-body-m text-ink-secondary mb-6">
            «12 400» — {radialCardValueWidth("12 400").toFixed(0)} точек при коробке{" "}
            {кольцо.centerBox.toFixed(0)}. Число уходит на две строки, коробка вырастает до 256 по
            высоте, и её дальний угол оказывается на 165,9 от центра при свободном круге 149,6 и
            внутреннем крае дуги 176 (замер в 1:1). То есть заявленный просвет в 26 точек съеден
            целиком, а до самой дуги остаётся 10,1 — ещё не наложение, но уже без запаса. Ни одна
            автопроверка этого не видит: коробка позиционирована абсолютно, поэтому родитель не
            переполнен, а дуга — не текст, поэтому попарная проверка текстов её не знает. Лечится не
            вёрсткой, а данными: проценты вместо абсолютных, единицы измерения в знаменатель.
          </p>
          <RadialCard
            label="Обращения в поддержку"
            headline="19 800"
            value={12400}
            total={19800}
            period={{ label: "Last 30 days" }}
            center={{ value: "12 400", ratio: "закрыто за квартал из 19 800 обращений" }}
          />
        </div>
        <div className="w-[828px]">
          <h3 className="text-title-l text-ink mb-2">То же число процентами — помещается</h3>
          <p className="text-body-m text-ink-secondary mb-6">
            «63%» — {radialCardValueWidth("63%").toFixed(0)} точек, запас{" "}
            {(кольцо.centerBox - radialCardValueWidth("63%")).toFixed(0)}. Здесь три строки: число,
            знаменатель и подпись, коробка 156 по высоте, дальний угол 131,3 при свободном круге
            149,6 — просвет держится целиком. Рекомендация кольца — подпись не длиннее ДВУХ строк:
            на трёх строках подписи углы коробки просвет уже съедают.
          </p>
          <RadialCard
            label="Обращения в поддержку"
            headline="19 800"
            value={12400}
            total={19800}
            period={{ label: "Last 30 days" }}
            center={{ value: "63%", ratio: "12 400 закрыто", caption: "за квартал" }}
          />
        </div>
      </div>
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">Легенда обрезает названия</h3>
        <p className="text-body-m text-ink-secondary mb-6">
          Пять плиток по {((стопка.slotW - 12 * 4) / 5).toFixed(0)} точек, под текст{" "}
          {((стопка.slotW - 12 * 4) / 5 - 40).toFixed(0)}. Обрезка идёт по `overflow: hidden`, то
          есть текст ТЕРЯЕТСЯ, но на соседа не наезжает. Это не дефект вёрстки, а сигнал сократить
          подпись — либо взять `size="full"`, где плитка становится{" "}
          {((стопкаПолная.slotW - 24 * 4) / 5).toFixed(0)}.
        </p>
        <RadialCard
          variant="stacked"
          label="Источники трафика за квартал по каналам привлечения"
          headline={ИТОГ.toLocaleString("ru-RU")}
          items={[
            { label: "Органический поиск", value: 275 },
            { label: "Прямые заходы", value: 200 },
            { label: "Рекомендации партнёров", value: 187 },
            { label: "Платная реклама", value: 173 },
            { label: "Рассылки и письма", value: 90 },
          ]}
          period={{ label: "Last 30 days" }}
          center={{ value: "29,7%", ratio: "органический поиск — наибольшая доля" }}
        />
      </div>
    </div>
  ),
};

/**
 * Опасный случай: стопка, где две категории вырождаются в просвет.
 *
 * Пола длины у сегментов НЕТ намеренно — растянув маленький, пришлось бы
 * укоротить остальные, то есть исказить сравнение частей, ради которого форма
 * и взята. Цена названа честно: доля меньше {(STACK_MIN_SHARE * 100).toFixed(2)}%
 * становится короче просвета между сегментами и читается как ещё один разрыв.
 *
 * Лечится это данными, а не кодом: такие категории складывают в «прочее»
 * руками. Здесь они оставлены, чтобы предупреждение было на чём увидеть.
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const хвост: RadialCardSegment[] = [
      { label: "Chrome", value: 8400 },
      { label: "Safari", value: 2100 },
      { label: "Firefox", value: 220 },
      { label: "Opera", value: 90 },
      { label: "IE 11", value: 24 },
    ];
    const сумма = хвост.reduce((s, b) => s + b.value, 0);
    return (
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">
          Доли {хвост.map((b) => `${((b.value / сумма) * 100).toFixed(2)}%`).join(" · ")}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-4xl">
          Порог вырождения — {(STACK_MIN_SHARE * 100).toFixed(2)}%: ровно та доля, при которой
          сегмент становится короче просвета между сегментами. Ниже порога здесь{" "}
          {хвост
            .filter((b) => b.value / сумма < STACK_MIN_SHARE)
            .map((b) => `«${b.label}»`)
            .join(", ")}{" "}
          — на дуге их не видно, они читаются как разрывы. В консоли — предупреждение с именами.
        </p>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Величины при этом не потеряны: они стоят в плитках легенды, и плитка — единственный
          носитель, которого вырождение не касается. Правильное лечение — сложить два хвоста в
          «прочее» в самих данных.
        </p>
        <RadialCard
          variant="stacked"
          label="Visitors"
          headline={сумма.toLocaleString("ru-RU")}
          items={хвост}
          delta={{ label: "−1,4%", direction: "down" }}
          period={{ label: "Last 30 days" }}
          center={{
            value: `${((8400 / сумма) * 100).toFixed(1).replace(".", ",")}%`,
            ratio: "доля Chrome — наибольшая",
          }}
        />
      </div>
    );
  },
};

/**
 * Шестая категория: краски пять, категорий больше — хвост складывается.
 *
 * Не отбрасывается и не дорисовывается шестой краской (правило dataviz:
 * «шестой ряд — это не новый цвет: это „прочее“»), а складывается в один
 * приглушённый сегмент. В легенде видно, сколько там оказалось.
 *
 * ⚠️ Складывание считается ДВАЖДЫ — в самой стопке и здесь, для плиток. Повтор
 * сознательный: плитки рисует оболочка, а она про устройство стопки ничего не
 * знает. Расхождение двух списков было бы тихим, и эта история — то место, где
 * его видно.
 */
export const ХвостСложен: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-2">
        Семь категорий, пять красок — шестая и седьмая ушли в «прочее»
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Хвост покрашен приглушённой ролью, а не шестой краской: приглушённое обязано остаться тихим,
        поэтому у него нет и градиента. Плиток легенды шесть, каждая{" "}
        {((стопка.slotW - 12 * 5) / 6).toFixed(0)} точек: величине достаётся{" "}
        {((стопка.slotW - 12 * 5) / 6 - 40).toFixed(0)}, а названию — всего{" "}
        {((стопка.slotW - 12 * 5) / 6 - 72).toFixed(0)} после свотча и просвета. Замер: обрезаны
        «Chrome» на 23,5 точки, «Firefox» на 10,6, «Opera» на 7,5 и «Прочее» на 20,1 — то есть даже
        односложные названия. Блок про такую тесноту предупреждает.
      </p>
      <RadialCard
        variant="stacked"
        label="Visitors"
        headline="1 240"
        items={[
          { label: "Chrome", value: 420 },
          { label: "Safari", value: 300 },
          { label: "Firefox", value: 210 },
          { label: "Edge", value: 150 },
          { label: "Opera", value: 90 },
          { label: "Vivaldi", value: 45 },
          { label: "Brave", value: 25 },
        ]}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        center={{ value: "33,9%", ratio: "доля Chrome — наибольшая" }}
      />
    </div>
  ),
};

/**
 * Полная ширина — показана как ГРАНИЦА, а не как рекомендация.
 *
 * Поле дуги квадратное, а слот во всю рабочую ширину — нет: дуга занимает
 * меньше трети ширины, остальное пусто (точные числа история считает сама).
 * Донорская карточка шириной 448. Полная ширина здесь годится ровно там, где
 * дуга и не должна быть главной, а карточка стоит ради шапки с итогом.
 */
export const ПолнаяШирина: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">
          Кольцо во всю ширину: слот {кольцоПолное.slotW} × {кольцоПолное.slotH}, поле{" "}
          {кольцоПолное.field}
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Дуга занимает {((кольцоПолное.field / кольцоПолное.slotW) * 100).toFixed(0)}% ширины
          слота, {(кольцоПолное.slotW - кольцоПолное.field).toFixed(0)} точек по бокам — пустота.
          Две половинные карточки рядом честнее одной такой.
        </p>
        <RadialCard
          size="full"
          width={1680}
          label="Visitors"
          headline={ИТОГ.toLocaleString("ru-RU")}
          value={ИТОГ}
          total={1470}
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Last 7 days" }}
          center={{ value: "63%", ratio: "план 1 470" }}
        />
      </div>
      <div>
        <h3 className="text-title-l text-ink mb-2">
          Стопка во всю ширину: поле {стопкаПолная.field}, плитка{" "}
          {((стопкаПолная.slotW - 24 * 4) / 5).toFixed(0)}
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Здесь полная ширина работает лучше, но не решает всё: название получает{" "}
          {((стопкаПолная.slotW - 24 * 4) / 5 - 72).toFixed(0)} точек против{" "}
          {((стопка.slotW - 12 * 4) / 5 - 72).toFixed(0)} у половинной. Замер: из пяти длинных
          названий обрезается ОДНО — «Рекомендации партнёров», и на 8,8 точки. На половинной
          карточке те же пять обрезаются все пятеро, от 67,7 до 163,2. Дуга при этом всё равно
          занимает только {((стопкаПолная.field / стопкаПолная.slotW) * 100).toFixed(0)}% ширины.
        </p>
        <RadialCard
          size="full"
          width={1680}
          variant="stacked"
          label="Источники трафика"
          headline={ИТОГ.toLocaleString("ru-RU")}
          items={[
            { label: "Органический поиск", value: 275 },
            { label: "Прямые заходы", value: 200 },
            { label: "Рекомендации партнёров", value: 187 },
            { label: "Платная реклама", value: 173 },
            { label: "Рассылки и письма", value: 90 },
          ]}
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Last 7 days" }}
          center={{ value: "29,7%", ratio: "органический поиск — наибольшая доля" }}
        />
      </div>
    </div>
  ),
};

/* ═══════════════  Краски  ═══════════════ */

/** Донорские краски по порядку и что во что раскрашивается */
export const Краски: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Круг стопки: lime → blue → purple → pink → yellow. Одиночная дуга — blue
      </h3>
      <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
        Порядок донорский и совпадает с воронкой: соседняя карточка того же дека красится так же, и
        расхождение читалось бы как ошибка сборки. Одиночная дуга берёт синюю не по вкусу: из
        донорской восьмёрки это единственная краска, подходящая к порогу 3:1 на светлой карточке.
        Числа ниже — худшая точка хода заливки, а не плоская краска: рецепт `barStops` осветляет
        кверху на 1.8 пункта светлоты, и на светлом фоне это ХУЖЕ плоского значения.
      </p>
      <div className="flex flex-col gap-3">
        {BOARD_SERIES.map((color) => (
          <div key={color} className="flex items-center gap-6">
            <span
              className="shadow-hairline rounded-micro shrink-0"
              style={{ width: 40, height: 40, background: color }}
            />
            <span className="text-body-m text-ink w-32 tabular-nums">{color}</span>
            <span className="text-body-m text-ink-secondary tabular-nums">
              карточка светлая {дугаК(color, СВЕТЛАЯ_КАРТОЧКА).toFixed(2)} · тёмная{" "}
              {дугаК(color, ТЁМНАЯ_КАРТОЧКА).toFixed(2)} · к дорожке светлой{" "}
              {дугаК(color, ДОРОЖКА.light).toFixed(2)} · тёмной{" "}
              {дугаК(color, ДОРОЖКА.dark).toFixed(2)}
            </span>
            <span className="text-body-m text-ink-secondary ml-auto">
              {RADIAL_CARD_COLORS.includes(color as (typeof RADIAL_CARD_COLORS)[number])
                ? "круг стопки"
                : "не используется"}
              {color === RADIAL_CARD_PAINT ? " · одиночная дуга" : ""}
            </span>
          </div>
        ))}
      </div>
    </div>
  ),
};

/* ═══════════════  Как на слайде  ═══════════════ */

/**
 * Две половинные карточки в настоящем ContentSlide.
 *
 * Здесь видно то, чего не показывает голый div: шапка слайда (пилюля,
 * заголовок в ОДНУ строку, лид) забирает 244, подвал резервирует 56, блоку
 * остаётся ровно {CARD_BUDGET} — и карточки занимают его целиком, впритык.
 *
 * ⚠️ «Впритык» здесь не фигура речи. Заголовок в ДВЕ строки съедает ещё 60,
 * доступного становится 544, а карточка остаётся {CARD_BUDGET} — и её низ
 * ложится на подпись презентации. В Storybook это незаметно: подвал
 * спозиционирован абсолютно, из потока выпадает, переполнения контейнера не
 * возникает. Ровно та грабля, что описана в `slide-anatomy.md`. Правило для
 * этой карточки: **заголовок слайда в одну строку, либо `height` считать
 * самому** — как в следующей истории.
 *
 * Раскладка `col-span-6` ×2 — та, ради которой карточка и сделана
 * половинной: 6 колонок по 118 плюс 5 желобов по 24 = 828, ровно `width`.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Витрина"
      title="До плана не хватает трети визитов"
      lead="Слева — доля от плана, справа — из каких браузеров приходят"
      page={1}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <RadialCard
            label="Visitors"
            headline={ИТОГ.toLocaleString("ru-RU")}
            value={ИТОГ}
            total={1470}
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            center={{ value: "63%", ratio: "план 1 470" }}
          />
        </div>
        <div className="col-span-6">
          <RadialCard
            variant="stacked"
            label="Browsers"
            headline={ИТОГ.toLocaleString("ru-RU")}
            items={БРАУЗЕРЫ}
            period={{ label: "Last 7 days" }}
            center={{ value: "29,7%", ratio: "доля Chrome — наибольшая" }}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};

/**
 * Тёмный слайд и заголовок в ДВЕ строки — тот самый случай, который ломает
 * предыдущую историю, но с посчитанной высотой.
 *
 * Арифметика: рабочая область 904 (1080 минус поля 88 сверху и снизу), шапка
 * с двухстрочным заголовком 304, подвал 56. Остаётся 904 − 304 − 56 = 544, и
 * ровно это передано в `height`. Карточка ужимается за счёт дуги: шапка,
 * легенда и поля у неё фиксированные, поэтому сторона поля пересчитывается
 * от нового слота сама — и у кольца, и у стопки. Числа до и после печатает
 * витрина в подписи под слайдом.
 *
 * Тёмная тема здесь не «для разнообразия», а по замеру: краски донора берут
 * порог 3:1 только на тёмной карточке.
 */
export const НаСлайдеТёмном: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Витрина"
      title="Две трети плана взяты, и почти весь трафик приходит из двух браузеров"
      lead="Слева — доля от плана, справа — из каких браузеров приходят"
      page={2}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <RadialCard
            height={544}
            variant="gauge"
            label="Visitors"
            headline={ИТОГ.toLocaleString("ru-RU")}
            value={ИТОГ}
            total={1470}
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            range={["0", "1 470"]}
            center={{ value: "63%", ratio: "925 визитов из плановых 1 470" }}
          />
        </div>
        <div className="col-span-6">
          <RadialCard
            height={544}
            variant="stacked"
            label="Browsers"
            headline={ИТОГ.toLocaleString("ru-RU")}
            items={БРАУЗЕРЫ}
            period={{ label: "Last 7 days" }}
            center={{ value: "29,7%", ratio: "доля Chrome — наибольшая" }}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};
