import type { Meta, StoryObj } from "@storybook/react-vite";
import { BarList } from "../../blocks/barlist";
import { HBarChart } from "../../blocks/chartsParts";

/**
 * Список долей.
 *
 * Перенос «Bar List» из донорского дашборда. Главная секция витрины —
 * сравнение с HBarChart: два блока про одно и то же, и витрина должна
 * показать, где проходит граница между ними, иначе следующий слайд возьмёт
 * тот, что первым попался.
 *
 * Данные выдуманные и НЕ совпадают с числами деков.
 */

const meta = {
  title: "Блоки/Список долей",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const SOURCES = [
  { label: "Поиск", value: 50500, highlight: true },
  { label: "Переходы с сайтов", value: 25900 },
  { label: "Реклама", value: 18300 },
  { label: "Соцсети", value: 9400 },
  { label: "Рассылка", value: 4100 },
];

export const Список: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Типовой случай — справка в колонке</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Заливка каждой строки равна её доле, поэтому список читается как список и как график
        одновременно. Под текстом заливка нейтральная: цвет акцента приходит из палитры графиков и
        может смениться, а текст, читаемость которого зависит от сегодняшнего оттенка, — мина.
        Акцент вынесен туда, где под ним нет текста, — в черту по нижнему краю выделенной строки,
        длиной в ту же долю. Это единственная фигура блока, которая проходит порог 3:1: замер даёт
        4,40:1 к холсту в светлой теме и 4,29:1 в тёмной, тогда как сама нейтральная заливка — 1,26
        и 1,55, то есть на проекторе её нет.
      </p>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Проценты полного списка складываются ровно в 100 — считаются методом наибольших остатков.
        При независимом округлении те же пять источников давали 47 + 24 + 17 + 9 + 4 = 101%.
      </p>
      <div className="w-[720px]">
        <BarList caption="Источники трафика" items={SOURCES} />
      </div>
    </div>
  ),
};

export const ПротивБаров: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Те же данные списком долей</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Занимает 720 точек по ширине — половину рабочей области. Годится, когда список это справка
          рядом с главным блоком слайда.
        </p>
        <div className="w-[720px]">
          <BarList items={SOURCES} />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Те же данные горизонтальными барами</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Бар лежит на чистой дорожке, и длины сравниваются точнее — но блоку нужна вся ширина
          слайда. Годится, когда сравнение долей и есть мысль слайда. Признак выбора простой: на всю
          ширину — бары, в колонку — список.
        </p>
        <HBarChart
          items={SOURCES.map((s) => ({ label: s.label, value: s.value, highlight: s.highlight }))}
        />
      </section>
    </div>
  ),
};

export const НеполноеЦелое: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Показаны не все — доля считается от целого</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Пять источников из тридцати в сумме дают 62%. Если нормировать их до сотни, слайд соврёт:
        читатель поймёт, что видит все источники. Поэтому целое передаётся явно, доли считаются от
        него, а под списком стоит подпись про остаток. Выравнивания суммы до сотни здесь нет и быть
        не должно — каждая доля округляется сама по себе.
      </p>
      <div className="w-[720px]">
        <BarList caption="Топ-5 из 30 источников" total={174000} items={SOURCES} />
      </div>
    </div>
  ),
};

export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Одна строка почти всё</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Хвост вырождается в тонкие полоски — и это верное изображение: доли правда почти нулевые.
          Читаемость держат подписанные проценты, а не длина заливки.
        </p>
        <div className="w-[720px]">
          <BarList
            items={[
              { label: "Прямые заходы", value: 96200, highlight: true },
              { label: "Поиск", value: 2400 },
              { label: "Реклама", value: 800 },
              { label: "Прочее", value: 300 },
            ]}
          />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Длинные названия и восемь строк</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Восемь — потолок по читаемости, а не по высоте: восемь строк меряются в 504 и в бюджет 604
          укладываются, девять дают 568 и тоже, а с подписью над списком девять — уже 612. Поэтому
          блок предупреждает дважды и по разным поводам: про длину списка и, отдельно, про
          посчитанную высоту.
        </p>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Название длиннее колонки строку НЕ поднимает: высота 56 задана жёстко, поэтому подпись в
          две строки занимает 64 и вылезает за строку по 4 сверху и снизу (замер). Порог
          автопроверки — 16, она такое не увидит. Значит подписи надо сокращать, а не надеяться, что
          список подстроится.
        </p>
        <div className="w-[720px]">
          <BarList
            items={[
              {
                label: "Органический поиск по небрендовым запросам",
                value: 41200,
                highlight: true,
              },
              { label: "Органический поиск по бренду", value: 28800 },
              { label: "Контекстная реклама в поиске", value: 19400 },
              { label: "Медийная реклама", value: 12100 },
              { label: "Переходы с отзовиков и каталогов", value: 8600 },
              { label: "Социальные сети", value: 5200 },
              { label: "Почтовые рассылки", value: 3100 },
              { label: "Прочее", value: 1400 },
            ]}
          />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Без абсолютных значений</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Когда абсолютные числа клиенту не нужны или их нельзя показывать, остаются только доли.
          Колонка значений при этом схлопывается, а не остаётся пустой.
        </p>
        <div className="w-[560px]">
          <BarList showValue={false} items={SOURCES} />
        </div>
      </section>
    </div>
  ),
};
