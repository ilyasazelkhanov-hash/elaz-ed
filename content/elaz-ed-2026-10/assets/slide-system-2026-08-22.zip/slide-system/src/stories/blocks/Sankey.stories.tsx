import type { Meta, StoryObj } from "@storybook/react-vite";
import { SankeyFlow } from "../../blocks/sankey";

/**
 * Диаграмма потоков.
 *
 * Форма отвечает на вопрос «куда уходит бюджет / трафик / время»: из чего
 * состоит целое И во что каждая часть превращается. Ни StackedBar, ни
 * ShareRibbon, ни HBarChart оба измерения вместе не показывают.
 *
 * Данные здесь выдуманные и НАМЕРЕННО не совпадают с числами ни одного дека:
 * витрина показывает поведение блока, а не содержание презентации. Числа,
 * совпадающие с деком, рано или поздно начинают жить своей жизнью.
 *
 * Крайние случаи вынесены в отдельные истории и показывают ровно то, что
 * ломается: потолок, выход за потолок, длинные подписи, вырожденный минимум
 * и случай, в котором форму брать НЕ надо.
 */

const meta = {
  title: "Блоки/Поток",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const тыс = (v: number) => `${v.toLocaleString("ru-RU")} тыс`;

/* ── Основной пример: четыре канала, шесть назначений ──────────────────── */

const каналы = [
  { key: "context", label: "Контекст" },
  { key: "social", label: "Соцсети" },
  { key: "partners", label: "Партнёрская сеть" },
  { key: "outdoor", label: "Наружная реклама" },
];

const назначения = [
  { key: "new", label: "Новые клиенты" },
  { key: "repeat", label: "Повторные покупки" },
  { key: "brand", label: "Узнаваемость" },
  { key: "tests", label: "Тесты гипотез" },
  { key: "fee", label: "Агентская комиссия" },
  { key: "craft", label: "Производство макетов" },
];

const бюджет = [
  { from: "context", to: "new", value: 1700 },
  { from: "context", to: "repeat", value: 800 },
  { from: "context", to: "tests", value: 400 },
  { from: "context", to: "fee", value: 300 },
  { from: "social", to: "brand", value: 1100 },
  { from: "social", to: "new", value: 600 },
  { from: "social", to: "repeat", value: 300 },
  { from: "social", to: "craft", value: 400 },
  { from: "partners", to: "new", value: 900 },
  { from: "partners", to: "repeat", value: 700 },
  { from: "partners", to: "fee", value: 200 },
  { from: "outdoor", to: "brand", value: 900 },
  { from: "outdoor", to: "craft", value: 300 },
];

export const Поток: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">SankeyFlow — куда уходит бюджет</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Слева статьи прихода, справа назначения, ширина ленты — величина потока. Цвет кодирует
        ИСТОЧНИК и только его: пять красок CHART_SERIES на пять источников. Приёмники нейтральны, и
        лента переходит от краски источника к их серому — иначе на одном рисунке оказались бы две
        цветовые шкалы и стало бы непонятно, что означает цвет.
      </p>
      <SankeyFlow
        sources={каналы}
        targets={назначения}
        links={бюджет}
        formatValue={тыс}
        totalCaption="рекламного бюджета за квартал"
      />
    </div>
  ),
};

/* ── Потолок: пять источников и семь приёмников ────────────────────────── */

export const Потолок: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Потолок формы — 5 × 7</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Пять источников — это длина CHART_SERIES: шестой источник означал бы шестую краску, а
        палитра по кругу не назначается. Семь приёмников — предел, на котором ленту ещё можно
        проследить глазом. Дальше форма не «становится хуже», она перестаёт работать.
      </p>
      <SankeyFlow
        sources={[
          { key: "context", label: "Контекст" },
          { key: "social", label: "Соцсети" },
          { key: "partners", label: "Партнёрская сеть" },
          { key: "outdoor", label: "Наружная реклама" },
          { key: "market", label: "Витрины" },
        ]}
        targets={[
          { key: "new", label: "Новые клиенты" },
          { key: "repeat", label: "Повторные покупки" },
          { key: "brand", label: "Узнаваемость" },
          { key: "tests", label: "Тесты гипотез" },
          { key: "fee", label: "Агентская комиссия" },
          { key: "craft", label: "Производство" },
          { key: "data", label: "Аналитика" },
        ]}
        links={[
          { from: "context", to: "new", value: 1600 },
          { from: "context", to: "repeat", value: 800 },
          { from: "context", to: "tests", value: 400 },
          { from: "context", to: "fee", value: 150 },
          { from: "context", to: "data", value: 250 },
          { from: "social", to: "brand", value: 1000 },
          { from: "social", to: "new", value: 600 },
          { from: "social", to: "repeat", value: 300 },
          { from: "social", to: "craft", value: 350 },
          { from: "social", to: "data", value: 150 },
          { from: "partners", to: "new", value: 900 },
          { from: "partners", to: "repeat", value: 700 },
          { from: "partners", to: "fee", value: 200 },
          { from: "outdoor", to: "brand", value: 850 },
          { from: "outdoor", to: "craft", value: 250 },
          { from: "outdoor", to: "data", value: 100 },
          { from: "market", to: "new", value: 500 },
          { from: "market", to: "repeat", value: 300 },
          { from: "market", to: "craft", value: 100 },
        ]}
        formatValue={тыс}
        totalCaption="рекламного бюджета за квартал"
      />
    </div>
  ),
};

/* ── За потолком: обрезка со списком отброшенного ──────────────────────── */

export const ЗаПотолком: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Семь источников и девять приёмников</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Узлы сверх потолка отброшены вместе со своими связями, в консоли DEV — список того, что
        выпало, и что в итог их величины НЕ вошли. Обрезка видима: на рисунке пять источников и семь
        приёмников, а не молча «как-то так». Правильный ответ на это предупреждение — свернуть хвост
        в «Прочее» на стороне данных, а не увеличивать потолок.
      </p>
      <SankeyFlow
        sources={[
          { key: "context", label: "Контекст" },
          { key: "social", label: "Соцсети" },
          { key: "partners", label: "Партнёрская сеть" },
          { key: "outdoor", label: "Наружная реклама" },
          { key: "market", label: "Витрины" },
          { key: "mail", label: "Рассылка" },
          { key: "pr", label: "Публикации" },
        ]}
        targets={[
          { key: "new", label: "Новые клиенты" },
          { key: "repeat", label: "Повторные покупки" },
          { key: "brand", label: "Узнаваемость" },
          { key: "tests", label: "Тесты гипотез" },
          { key: "fee", label: "Агентская комиссия" },
          { key: "craft", label: "Производство" },
          { key: "data", label: "Аналитика" },
          { key: "events", label: "Мероприятия" },
          { key: "misc", label: "Прочие расходы" },
        ]}
        links={[
          { from: "context", to: "new", value: 1600 },
          { from: "context", to: "repeat", value: 800 },
          { from: "context", to: "tests", value: 400 },
          { from: "context", to: "data", value: 250 },
          { from: "social", to: "brand", value: 1000 },
          { from: "social", to: "new", value: 600 },
          { from: "social", to: "craft", value: 350 },
          { from: "partners", to: "new", value: 900 },
          { from: "partners", to: "repeat", value: 700 },
          { from: "partners", to: "fee", value: 200 },
          { from: "outdoor", to: "brand", value: 850 },
          { from: "outdoor", to: "craft", value: 250 },
          { from: "market", to: "new", value: 500 },
          { from: "market", to: "repeat", value: 300 },
          { from: "mail", to: "repeat", value: 450 },
          { from: "pr", to: "brand", value: 300 },
          { from: "context", to: "events", value: 200 },
          { from: "social", to: "misc", value: 150 },
        ]}
        formatValue={тыс}
      />
    </div>
  ),
};

/* ── Длинные подписи ───────────────────────────────────────────────────── */

export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Подписи, которые не помещаются в строку</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Название переносится, числа остаются на первой строке. Число строк считается замером ДО
        отрисовки, и из него выводится минимальная высота столбика — поэтому подписи соседних узлов
        не налезают друг на друга, а не «обычно не налезают». Последний приёмник — одно слово
        длиннее колонки: оно рвётся по буквам, как это делает браузер с `break-words`.
      </p>
      <SankeyFlow
        sources={[
          { key: "a", label: "Контекстно-медийная сеть и поисковая реклама" },
          { key: "b", label: "Программатик-закупка в мобильных приложениях" },
          { key: "c", label: "Соцсети" },
        ]}
        targets={[
          { key: "x", label: "Привлечение новых клиентов в основном сегменте" },
          { key: "y", label: "Удержание и повторные покупки постоянных клиентов" },
          { key: "z", label: "Узнаваемость" },
          { key: "w", label: "Внутренняяаналитикаиотчётностьподразделения" },
        ]}
        links={[
          { from: "a", to: "x", value: 1800 },
          { from: "a", to: "y", value: 700 },
          { from: "a", to: "w", value: 200 },
          { from: "b", to: "x", value: 900 },
          { from: "b", to: "z", value: 600 },
          { from: "c", to: "z", value: 800 },
          { from: "c", to: "y", value: 500 },
          { from: "c", to: "w", value: 150 },
        ]}
        formatValue={тыс}
      />
    </div>
  ),
};

/* ── Минимум ───────────────────────────────────────────────────────────── */

export const Минимум: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Один источник — форма вырождается</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Блок это рисует, но так делать не надо: при одном источнике перехода нет, есть только состав
        целого, и на него уже есть StackedBar и ShareRibbon. Sankey берут, когда вопрос про переход
        «из чего во что». История оставлена в витрине именно как отрицательный образец — она
        показывает, что вырожденные данные не ломают геометрию, а не что так можно.
      </p>
      <SankeyFlow
        sources={[{ key: "all", label: "Весь бюджет" }]}
        targets={[
          { key: "new", label: "Новые клиенты" },
          { key: "brand", label: "Узнаваемость" },
        ]}
        links={[
          { from: "all", to: "new", value: 2600 },
          { from: "all", to: "brand", value: 1400 },
        ]}
        formatValue={тыс}
        height={320}
      />
    </div>
  ),
};

/* ── Опасный случай ────────────────────────────────────────────────────── */

export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Пять источников × семь приёмников связаны все со всеми
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Тридцать пять лент на 884 точки ширины. Потолки соблюдены, предупреждений в консоли нет,
        каждое число подписано — и всё равно проследить отдельный поток нельзя. Это не дефект блока,
        а граница самой формы: Sankey читается, когда связей заметно меньше, чем произведение
        колонок, то есть когда у источников РАЗНЫЕ назначения. Если связаны все со всеми — нужна
        таблица или матрица, а не диаграмма потоков.
      </p>
      <SankeyFlow
        sources={[
          { key: "s1", label: "Контекст" },
          { key: "s2", label: "Соцсети" },
          { key: "s3", label: "Партнёры" },
          { key: "s4", label: "Наружная" },
          { key: "s5", label: "Витрины" },
        ]}
        targets={[
          { key: "t1", label: "Новые клиенты" },
          { key: "t2", label: "Повторные" },
          { key: "t3", label: "Узнаваемость" },
          { key: "t4", label: "Тесты" },
          { key: "t5", label: "Комиссия" },
          { key: "t6", label: "Производство" },
          { key: "t7", label: "Аналитика" },
        ]}
        links={["s1", "s2", "s3", "s4", "s5"].flatMap((from, si) =>
          ["t1", "t2", "t3", "t4", "t5", "t6", "t7"].map((to, ti) => ({
            from,
            to,
            /* Величины разные, но одного порядка — именно так и выглядят
               настоящие данные, в которых связаны все со всеми. Формула
               намеренно несимметричная: при симметричной все приёмники
               получались бы одинаковыми, и случай выглядел бы придуманным */
            value: 240 + ((si * 5 + ti * 7 + si * ti) % 6) * 90,
          })),
        )}
        formatValue={тыс}
      />
    </div>
  ),
};
