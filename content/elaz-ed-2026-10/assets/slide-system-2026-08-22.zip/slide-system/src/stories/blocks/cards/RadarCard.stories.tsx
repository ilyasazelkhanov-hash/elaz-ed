import type { Meta, StoryObj } from "@storybook/react-vite";

import RadarCard, {
  RADAR_MAX_SERIES,
  type RadarAxis,
  type RadarSeries,
} from "../../../blocks/cards/radarCard";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Радар» — `blocks/cards/radarCard.tsx`.
 *
 * Донор — система дашбордов. Скриншот
 * заказчика: «Visitors / 1 424 / +5.2%», подпись периода «Jan – Jun 2024»,
 * шестиугольная паутина по месяцам, салатовая фигура с полупрозрачной
 * заливкой.
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`, 64 с каждой стороны), поэтому
 * пара половинных карточек (1680) требует окна от 1808 точек.
 *
 * ⚠️ Замеры делать только в режиме «1:1 — для замеров»: в режиме «вписать в
 * окно» `getBoundingClientRect` возвращает числа после `transform: scale`.
 */

const meta = {
  title: "Карточки/Радар",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

/** Оси донора: шесть месяцев первого полугодия */
const MONTHS: RadarAxis[] = ["January", "February", "March", "April", "May", "June"].map(
  (label) => ({
    key: label,
    label,
  }),
);

/** Значения донора. Их сумма 1 424 — то самое число в шапке скриншота */
const VISITORS = [186, 305, 237, 273, 209, 214];

/* ───────────── площадь фигуры: считаем, а не переписываем ───────────── */

/**
 * Площадь многоугольника по радиусам: ½·sin(2π/n)·Σ rᵢ·rᵢ₊₁.
 *
 * Числа во всех подписях ниже берутся ОТСЮДА, а не выписаны руками:
 * иначе правка данных молча разошлась бы с текстом о них.
 */
const polyArea = (v: readonly number[]) =>
  0.5 *
  Math.sin((2 * Math.PI) / v.length) *
  v.reduce((s, x, i) => s + x * v[(i + 1) % v.length], 0);

const ru = (v: number) => Math.round(v).toLocaleString("ru-RU");

/** Десятичная запятая: в русском тексте точка читается как разделитель разрядов */
const dec = (v: number, digits = 2) => v.toFixed(digits).replace(".", ",");

/* ───────────── подписи под историями ───────────── */

function Note({ children }: { children: React.ReactNode }) {
  return <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">{children}</p>;
}

function Head({ children }: { children: React.ReactNode }) {
  return <h3 className="text-title-l text-ink mb-2">{children}</h3>;
}

/* ═══════════════  типовой случай  ═══════════════ */

/**
 * Скриншот заказчика: те же данные, тот же период, та же салатовая фигура.
 *
 * Отличие от донора одно и оно осознанное: потолок шкалы задан числом
 * (400), а не взят по максимуму данных (305). У донора «максимум = самый
 * высокий месяц», и тогда февраль всегда упирается в внешнее кольцо, каким
 * бы он ни был, — фигура выглядит одинаково при любых данных.
 */
export const Карточка: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>Как на скриншоте — 828 × {CARD_BUDGET}</Head>
      <Note>
        Слот графика {cardChartWidth(828, "half")} ×{" "}
        {cardChartHeight({ size: "half", legend: false })}, легенды нет: ряд один, называет его
        подпись шапки. Замеренный радиус 138, кольца через 34,5. Сумма значений{" "}
        {VISITORS.reduce((a, b) => a + b, 0).toLocaleString("ru-RU")} — это и есть число в шапке.
      </Note>
      <RadarCard
        label="Visitors"
        value="1 424"
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Jan – Jun 2024" }}
        axes={MONTHS}
        series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
        max={400}
        unit="визитов"
      />
    </div>
  ),
};

/**
 * Два ряда — донорский вариант `lines`: заливки нет ни у кого.
 *
 * Здесь же виден главный обман формы, посчитанный на этих самых числах.
 */
export const Сравнение: Story = {
  render: () => {
    const us = [86, 78, 92, 64, 88, 71];
    const them = [57, 52, 61, 43, 59, 47];
    const ratios = us.map((v, i) => v / them[i]);
    return (
      <div className="w-[828px]">
        <Head>Два ряда — и квадратичное искажение в числах</Head>
        <Note>
          По каждой оси мы лучше в {dec(Math.min(...ratios))}–{dec(Math.max(...ratios))} раза.
          Площадь фигуры при этом больше в <b>{dec(polyArea(us) / polyArea(them))} раза</b> (
          {ru(polyArea(us))} против {ru(polyArea(them))}): значение задаёт радиус, а глаз считывает
          площадь, и полтора превращаются в два с четвертью. Ровно поэтому число стоит у каждой
          вершины — числа квадратично не растут. При двух рядах заливки нет: обводка поверх чужой
          заливки даёт 1,7…2,8:1 при пороге 3:1, то есть нижний ряд пропадал бы под верхним. Легенда
          рядов стоит в нижней полосе поля, а не плитками `CardShell`: плитки стоят 124 точки
          высоты, и замер даёт радиус 80 (пол) вместо 138 — фигура втрое меньше по площади. Плитки
          показаны отдельной историей ниже.
        </Note>
        <RadarCard
          label="Оценка клиентов"
          value="79,8"
          delta={{ label: "+6,4 пункта", direction: "up" }}
          period={{ label: "II квартал 2026" }}
          axes={[
            { key: "speed", label: "Скорость" },
            { key: "price", label: "Цена" },
            { key: "support", label: "Поддержка" },
            { key: "ux", label: "Удобство" },
            { key: "quality", label: "Качество" },
            { key: "trust", label: "Доверие" },
          ]}
          series={[
            { key: "us", label: "Мы", values: us, total: "79,8" },
            { key: "market", label: "Рынок", values: them, total: "53,2" },
          ]}
          max={100}
          unit="баллов"
        />
      </div>
    );
  },
};

/* ═══════════════  обе темы  ═══════════════ */

/**
 * Светлая и тёмная РЯДОМ через вложенную тему — расхождение видно без
 * переключения тулбара.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>Светлая карточка</Head>
        <Note>
          ⚠️ Слабое место, принятое заказчиком: обводка #7ccf00 на белой карточке даёт 1,95:1 при
          пороге 3:1, заливка — 1,14:1, обводка к своей же заливке — 1,71:1. Фигура читается
          силуэтом и точками вершин, а не цветом. Сетка `--t-line` здесь 1,19:1 — бледнее донорской
          (1,38), поэтому внешнее кольцо нарисовано вдвое толще остальных.
        </Note>
        <RadarCard
          theme="light"
          label="Visitors"
          value="1 424"
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Jan – Jun 2024" }}
          axes={MONTHS}
          series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
          max={400}
          unit="визитов"
        />
      </div>
      <div className="w-[828px]">
        <Head>Тёмная карточка</Head>
        <Note>
          Те же краски: обводка 7,77:1, обводка к своей заливке 3,84:1 — порог берут обе. Запас
          вчетверо больше светлой темы. Если карточка едет на проектор — брать эту. Сетка в тёмной
          теме 1,13:1, то есть та же подсказка «четверть, половина, три четверти», не более.
        </Note>
        <RadarCard
          theme="dark"
          label="Visitors"
          value="1 424"
          delta={{ label: "+5,2%", direction: "up" }}
          period={{ label: "Jan – Jun 2024" }}
          axes={MONTHS}
          series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
          max={400}
          unit="визитов"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  крайние случаи  ═══════════════ */

/** Нижняя граница: три оси и рекомендованный минимум — пять */
export const Минимум: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>Три оси — треугольник</Head>
        <Note>
          Блок не падает, но формой это уже не является: у треугольника вид целиком задан тремя
          числами, и он читается как значок. Три числа — это `StatTiles`, а не радар.
        </Note>
        <RadarCard
          height={520}
          label="Готовность"
          value="72"
          period={{ label: "Спринт 14" }}
          axes={[
            { key: "a", label: "Дизайн" },
            { key: "b", label: "Разработка" },
            { key: "c", label: "Тесты" },
          ]}
          series={[{ key: "now", label: "Сейчас", values: [88, 74, 54] }]}
          max={100}
          unit="процентов"
        />
      </div>
      <div className="w-[828px]">
        <Head>Пять осей — рекомендованный минимум</Head>
        <Note>
          С пяти осей форма перестаёт быть значком: провал по одному критерию виден как вмятина, а
          не как «фигура другой формы».
        </Note>
        <RadarCard
          height={520}
          label="Оценка команды"
          value="76"
          period={{ label: "Спринт 14" }}
          axes={[
            { key: "a", label: "Скорость" },
            { key: "b", label: "Качество" },
            { key: "c", label: "Процесс" },
            { key: "d", label: "Общение" },
            { key: "e", label: "Планы" },
          ]}
          series={[{ key: "now", label: "Сейчас", values: [88, 74, 54, 91, 73] }]}
          max={100}
          unit="баллов"
        />
      </div>
    </div>
  ),
};

/** Верхняя граница: восемь осей и то, что начинается за ней */
export const Потолок: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>Восемь осей — потолок</Head>
        <Note>
          Диагональные оси попадают в «верхнюю» раскладку подписи (синус 0,707 больше порога 0,25),
          поэтому их подписи стоят над кольцом, а не на его уровне. Радиус подбирается делением
          отрезка пополам так, чтобы поместились ВСЕ восемь боксов.
        </Note>
        <RadarCard
          height={560}
          label="Профиль продукта"
          value="71"
          period={{ label: "Аудит 2026" }}
          axes={[
            "Скорость",
            "Цена",
            "Поддержка",
            "Удобство",
            "Качество",
            "Доверие",
            "Охват",
            "Гибкость",
          ].map((label) => ({ key: label, label }))}
          series={[{ key: "now", label: "Сейчас", values: [86, 62, 78, 91, 68, 74, 55, 52] }]}
          max={100}
          unit="баллов"
        />
      </div>
      <div className="w-[828px]">
        <Head>Двенадцать осей — за потолком</Head>
        <Note>
          Показано, чтобы граница была видна, а не описана. Замер попарных пересечений боксов: при
          восьми осях наложений <b>ноль</b>, при двенадцати — <b>восемь</b> (соседние имена
          перекрываются на 4,1 точки по горизонтали и 14,3 по вертикали, а значение наезжает на имя
          соседа на 23,2). Блок этого не чинит и чинить не может: выбросить ось значит выбросить
          данные. Двенадцать критериев — это таблица.
        </Note>
        <RadarCard
          height={560}
          label="Профиль продукта"
          value="70"
          period={{ label: "Аудит 2026" }}
          axes={Array.from({ length: 12 }, (_, i) => ({
            key: `k${i}`,
            label: `Критерий ${i + 1}`,
          }))}
          series={[
            {
              key: "now",
              label: "Сейчас",
              values: [86, 62, 78, 91, 68, 74, 55, 52, 80, 47, 66, 73],
            },
          ]}
          max={100}
          unit="баллов"
        />
      </div>
    </div>
  ),
};

/** Длинные подписи: они вычитаются из радиуса, а не обрезаются */
export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>Подписи в 14–22 знака</Head>
        <Note>
          Подпись стоит снаружи кольца и вычитает свою ширину из радиуса: чем длиннее имена осей,
          тем меньше фигура — замер даёт радиус 116 против 138 на донорских подписях. Это ЧЕСТНЕЕ
          обрезки: обрезанную подпись замечают уже у клиента.
          <br />
          ⚠️ У длины есть второй, менее очевидный предел. Замер попарных пересечений даёт{" "}
          <b>2 наложения</b>: значения «78» и «68» наезжают на имя соседней оси «Удобство
          интерфейса» на 23,2 точки. Радиусом это НЕ лечится — подписи расставлены по кругу, и
          уменьшение радиуса сближает их ещё сильнее. Лечится коротким именем критерия или меньшим
          числом осей.
        </Note>
        <RadarCard
          height={560}
          label="Оценка по методике"
          value="68"
          period={{ label: "Аудит 2026" }}
          axes={[
            { key: "a", label: "Скорость отклика" },
            { key: "b", label: "Прозрачность цены" },
            { key: "c", label: "Качество поддержки" },
            { key: "d", label: "Удобство интерфейса" },
            { key: "e", label: "Надёжность поставки" },
            { key: "f", label: "Доверие к бренду" },
          ]}
          series={[{ key: "now", label: "Сейчас", values: [86, 62, 78, 91, 68, 74] }]}
          max={100}
          unit="баллов"
        />
      </div>
      <div className="w-[828px]">
        <Head>Подпись, которая не помещается ни при каком радиусе</Head>
        <Note>
          «Оценка вкуса в слепом тесте» шире, чем половина поля. Радиус упирается в пол (80), и
          подпись ВЫЛЕЗАЕТ за границу SVG — у него `overflow: visible` намеренно. Дефект виден
          сразу, а не в PDF у заказчика. Длинная подпись шапки при этом обрезается многоточием — это
          уже `CardShell`.
        </Note>
        <RadarCard
          height={560}
          label="Средневзвешенная оценка по методике сравнительного аудита конкурентов"
          value="68"
          period={{ label: "Аудит 2026" }}
          axes={[
            { key: "a", label: "Оценка вкуса в слепом тесте" },
            { key: "b", label: "Прозрачность ценообразования" },
            { key: "c", label: "Качество поддержки" },
            { key: "d", label: "Удобство интерфейса" },
            { key: "e", label: "Надёжность поставки" },
            { key: "f", label: "Доверие к бренду" },
          ]}
          series={[{ key: "now", label: "Сейчас", values: [86, 62, 78, 91, 68, 74] }]}
          max={100}
          unit="баллов"
        />
      </div>
    </div>
  ),
};

/**
 * Опасный случай — то, на чём радар и ломается.
 *
 * Здесь три беды: изрезанный профиль, у которого форма зависит от порядка
 * осей; вырожденные данные; значения за потолком шкалы.
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const spiky = [95, 30, 90, 28, 92, 25];
    /* Те же шесть чисел, переставленные так, чтобы высокие стояли рядом */
    const grouped = [95, 90, 28, 25, 30, 92];
    const axesOf = (labels: string[]) => labels.map((label) => ({ key: label, label }));
    return (
      <div className="flex flex-col gap-10">
        <div>
          <Head>
            Порядок осей: те же шесть чисел, разница площади{" "}
            {dec((polyArea(grouped) / polyArea(spiky) - 1) * 100, 0)}%
          </Head>
          <Note>
            Слева — чередование, справа — те же значения, переставленные так, чтобы высокие стояли
            рядом. Площадь слева {ru(polyArea(spiky))}, справа {ru(polyArea(grouped))} — больше в{" "}
            <b>{dec(polyArea(grouped) / polyArea(spiky))} раза</b> на ОДНИХ И ТЕХ ЖЕ данных. Причина
            арифметическая: в сумме ½·sin(2π/n)·Σ rᵢ·rᵢ₊₁ участвуют только соседние пары. Перебор
            всех 120 расстановок этих шести чисел даёт разброс от {ru(6632)} до {ru(10401)} — 56,8%;
            на ровном профиле донора тот же перебор даёт всего 3,7%. Вывод: порядок осей выбирается
            один раз и не меняется между слайдами; если он произволен — радар брать нельзя.
          </Note>
          <div className="flex gap-6">
            <div className="w-[828px]">
              <RadarCard
                height={560}
                label="Профиль · через раз"
                value="60"
                period={{ label: "Порядок A" }}
                axes={axesOf(["Ось 1", "Ось 2", "Ось 3", "Ось 4", "Ось 5", "Ось 6"])}
                series={[{ key: "a", label: "Профиль", values: spiky }]}
                max={100}
                unit="баллов"
              />
            </div>
            <div className="w-[828px]">
              <RadarCard
                height={560}
                label="Профиль · высокие рядом"
                value="60"
                period={{ label: "Порядок Б" }}
                axes={axesOf(["Ось 1", "Ось 3", "Ось 4", "Ось 6", "Ось 2", "Ось 5"])}
                series={[{ key: "a", label: "Профиль", values: grouped }]}
                max={100}
                unit="баллов"
              />
            </div>
          </div>
        </div>

        <div className="flex gap-6">
          <div className="w-[828px]">
            <Head>Все нули</Head>
            <Note>
              Фигура схлопывается в точку в центре — и это честная картина данных. Вершины рисуются
              всегда, поэтому профиль виден точкой, а не исчезает с холста: пустой слайд проходит
              все автопроверки, кроме проверки на пустоту.
            </Note>
            <RadarCard
              height={560}
              label="Оценка"
              value="0"
              period={{ label: "Ещё не мерили" }}
              axes={MONTHS}
              series={[{ key: "zero", label: "Нули", values: [0, 0, 0, 0, 0, 0] }]}
              max={100}
              unit="баллов"
            />
          </div>
          <div className="w-[828px]">
            <Head>Значения за потолком шкалы</Head>
            <Note>
              Три значения выше потолка (100) и одно отрицательное. Вершины прижаты к внешнему
              кольцу и к центру, но ЧИСЛА у вершин остаются настоящими, а строка шкалы внизу говорит
              вслух: «значения вне шкалы прижаты к её краю». Молчаливое прижатие превратило бы 140 и
              100 в одинаковые вершины.
            </Note>
            <RadarCard
              height={560}
              label="План против факта"
              value="112"
              delta={{ label: "+12%", direction: "up" }}
              period={{ label: "2026" }}
              axes={MONTHS}
              series={[{ key: "fact", label: "Факт", values: [140, 96, 118, 72, -8, 104] }]}
              max={100}
              unit="процентов"
            />
          </div>
        </div>

        <div className="w-[828px]">
          <Head>Четыре ряда при палитре из трёх</Head>
          <Note>
            Передано четыре ряда, показаны {RADAR_MAX_SERIES}. Четвёртый не берёт цвет по кругу и не
            становится молча двойником первого — он отброшен, и строка шкалы это называет. Причина
            зажима: у наложенных фигур сравниваются ВСЕ пары цветов, а не только соседние.
          </Note>
          <RadarCard
            height={604}
            label="Оценка клиентов"
            value="79,8"
            period={{ label: "II квартал 2026" }}
            axes={MONTHS}
            series={[
              { key: "a", label: "Мы", values: [86, 78, 92, 64, 88, 71] },
              { key: "b", label: "Рынок", values: [57, 52, 61, 43, 59, 47] },
              { key: "c", label: "Лидер", values: [92, 88, 74, 81, 79, 84] },
              { key: "d", label: "Догоняющий", values: [41, 38, 45, 32, 44, 36] },
            ]}
            max={100}
            unit="баллов"
          />
        </div>
      </div>
    );
  },
};

/**
 * Легенда плитками `CardShell` — когда радар стоит в ряду с другими
 * карточками волны и полосы легенд должны совпасть по высоте.
 */
export const ЛегендаПлитками: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>`legendPlacement="inline"` — по умолчанию</Head>
        <Note>
          Слот {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half", legend: false })},
          замеренный радиус <b>138</b>. Легенда занимает нижнюю полосу поля — угол круглой фигуры в
          прямоугольном поле всё равно пуст.
        </Note>
        <RadarCard
          label="Оценка клиентов"
          value="79,8"
          period={{ label: "II квартал 2026" }}
          axes={MONTHS}
          series={[
            { key: "us", label: "Мы", values: [86, 78, 92, 64, 88, 71], total: "79,8" },
            { key: "market", label: "Рынок", values: [57, 52, 61, 43, 59, 47], total: "53,2" },
          ]}
          max={100}
          unit="баллов"
        />
      </div>
      <div className="w-[828px]">
        <Head>`legendPlacement="tiles"` — цена в числах</Head>
        <Note>
          Слот {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half", legend: true })},
          замеренный радиус <b>80</b> — это пол радиуса, дальше блок не ужимается. Площадь фигуры от
          соседней слева — {Math.round((80 / 138) ** 2 * 100)}%, кольца сходятся с 34,5 до 20 точек.
          Брать этот режим только тогда, когда выравнивание с соседними карточками важнее размера
          фигуры.
        </Note>
        <RadarCard
          legendPlacement="tiles"
          label="Оценка клиентов"
          value="79,8"
          period={{ label: "II квартал 2026" }}
          axes={MONTHS}
          series={[
            { key: "us", label: "Мы", values: [86, 78, 92, 64, 88, 71], total: "79,8" },
            { key: "market", label: "Рынок", values: [57, 52, 61, 43, 59, 47], total: "53,2" },
          ]}
          max={100}
          unit="баллов"
        />
      </div>
    </div>
  ),
};

/** Во всю ширину — так делать не надо, и видно почему */
export const ВоВсюШирину: Story = {
  render: () => (
    <div className="w-[1680px]">
      <Head>1680 × {CARD_BUDGET} — радиус тот же, воздуха вдвое больше</Head>
      <Note>
        Слот {cardChartWidth(1680, "full")} × {cardChartHeight({ legend: false })}. Радар круглый,
        поэтому радиус упирается в ВЫСОТУ, а лишняя ширина уходит в пустоту: фигура занимает 244
        точки из 1608. Замеренный радиус здесь <b>122</b> — МЕНЬШЕ, чем 138 на половинной карточке:
        поля при `size="full"` 36 вместо 20, и высоту они отнимают. Эта история — доказательство
        правила «радар ставится половинной карточкой», а не рекомендация.
      </Note>
      <RadarCard
        size="full"
        width={1680}
        label="Visitors"
        value="1 424"
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Jan – Jun 2024" }}
        axes={MONTHS}
        series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
        max={400}
        unit="визитов"
      />
    </div>
  ),
};

/* ═══════════════  как на слайде  ═══════════════ */

/**
 * Карточка внутри `ContentSlide` — единственная проверка, которая
 * подтверждает бюджет 604: в обёртке витрины нет ни шапки слайда, ни
 * подвала, ни холста 1080.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Трафик"
      title="Февраль дал вдвое больше визитов, чем январь"
      page={11}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <RadarCard
            label="Visitors"
            value="1 424"
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Jan – Jun 2024" }}
            axes={MONTHS}
            series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
            max={400}
            unit="визитов"
          />
        </div>
        <div className="col-span-6">
          <RadarCard
            label="Оценка клиентов"
            value="79,8"
            delta={{ label: "+6,4 пункта", direction: "up" }}
            period={{ label: "II квартал 2026" }}
            axes={[
              { key: "speed", label: "Скорость" },
              { key: "price", label: "Цена" },
              { key: "support", label: "Поддержка" },
              { key: "ux", label: "Удобство" },
              { key: "quality", label: "Качество" },
              { key: "trust", label: "Доверие" },
            ]}
            series={[
              { key: "us", label: "Мы", values: [86, 78, 92, 64, 88, 71], total: "79,8" },
              { key: "market", label: "Рынок", values: [57, 52, 61, 43, 59, 47], total: "53,2" },
            ]}
            max={100}
            unit="баллов"
          />
        </div>
      </div>
    </ContentSlide>
  ),
};

/** Тот же слайд в тёмной теме — та, под которую карточка и рассчитана */
export const НаСлайдеТёмном: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Трафик"
      title="Февраль дал вдвое больше визитов, чем январь"
      page={12}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <RadarCard
            label="Visitors"
            value="1 424"
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Jan – Jun 2024" }}
            axes={MONTHS}
            series={[{ key: "desktop", label: "Desktop", values: VISITORS }]}
            max={400}
            unit="визитов"
          />
        </div>
        <div className="col-span-6">
          <RadarCard
            label="Оценка клиентов"
            value="79,8"
            delta={{ label: "+6,4 пункта", direction: "up" }}
            period={{ label: "II квартал 2026" }}
            axes={[
              { key: "speed", label: "Скорость" },
              { key: "price", label: "Цена" },
              { key: "support", label: "Поддержка" },
              { key: "ux", label: "Удобство" },
              { key: "quality", label: "Качество" },
              { key: "trust", label: "Доверие" },
            ]}
            series={
              [
                { key: "us", label: "Мы", values: [86, 78, 92, 64, 88, 71], total: "79,8" },
                { key: "market", label: "Рынок", values: [57, 52, 61, 43, 59, 47], total: "53,2" },
              ] satisfies RadarSeries[]
            }
            max={100}
            unit="баллов"
          />
        </div>
      </div>
    </ContentSlide>
  ),
};
