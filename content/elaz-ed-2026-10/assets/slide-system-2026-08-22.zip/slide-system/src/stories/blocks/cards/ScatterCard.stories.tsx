import type { Meta, StoryObj } from "@storybook/react-vite";
import type { ReactNode } from "react";

import ScatterCard, { type ScatterCardSeries } from "../../../blocks/cards/scatterCard";
import { cardAxisTicks } from "../../../blocks/cards/axis";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Точечная» — `blocks/cards/scatterCard.tsx`.
 *
 * Донор — система дашбордов. Скриншот
 * заказчика: «Revenue per account / 742 / +6.8%», плашка периода «This
 * quarter», оси Sessions × Revenue, три когорты — Starter, Growth, Scale —
 * и плитки со средним по когорте: 270 / 783 / 1 388.
 *
 * ⚠️ ГЛАВНОЕ ОТЛИЧИЕ ОТ ОСТАЛЬНЫХ КАРТОЧЕК ВОЛНЫ: у этой размер по
 * умолчанию — `half`, половина рабочей ширины. У точечной форма облака и
 * есть содержание, а поле 8:1 кладёт облако на бок. Замеры пропорций —
 * в истории «Потолок».
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`, 64 с каждой стороны), поэтому
 * карточка во всю ширину (1680) требует окна от 1808 точек.
 *
 * ⚠️ Замеры делать только в режиме «1:1 — для замеров». В режиме «вписать в
 * окно» `getBoundingClientRect` возвращает числа после `transform: scale`.
 */

const meta = {
  title: "Карточки/Точечная",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

/**
 * Данные донора. Средние по Y подобраны так, чтобы плитки легенды дали
 * ровно донорские 270 / 783 / 1 388 — карточка считает их сама, а не
 * принимает готовыми, и совпадение доказывает, что считает верно.
 *
 * Третья величина (`size`) — число клиентов в точке. У донора она есть
 * («пузырьки при заданном размере»), но чем измерена — на странице не
 * сказано; здесь взято правдоподобное: чем крупнее тариф, тем меньше
 * клиентов, поэтому пузырьки Starter крупные, а Scale — мелкие.
 *
 * Разброс 24…140 — это 5.8:1 по площади, и он выбран НЕ на глаз. Потолок
 * разброса равен (rMax / 8)², то есть зависит от высоты поля, а она у
 * карточки разная (замеры в 1:1):
 *
 *   половинная карточка          rMax 24  → потолок 9.0:1
 *   во всю ширину                rMax 21  → потолок 6.9:1
 *   половинная, ключ своей строкой rMax 20 → потолок 6.3:1
 *
 * 5.8 проходит везде. Что происходит за потолком — в истории «Опасный
 * случай»: мелкие точки упираются в пол радиуса, и их пятна становятся
 * больше своей доли.
 */
const COHORTS: ScatterCardSeries[] = [
  {
    key: "starter",
    label: "Starter",
    points: [
      { x: 8, y: 180, size: 140, label: "SMB · 180" },
      { x: 14, y: 240, size: 124 },
      { x: 21, y: 300, size: 108 },
      { x: 29, y: 360, size: 96 },
    ],
  },
  {
    key: "growth",
    label: "Growth",
    points: [
      { x: 34, y: 620, size: 72 },
      { x: 45, y: 740, size: 60 },
      { x: 52, y: 830, size: 52 },
      { x: 63, y: 940, size: 44 },
    ],
  },
  {
    key: "scale",
    label: "Scale",
    points: [
      { x: 71, y: 1240, size: 34 },
      { x: 80, y: 1350, size: 30 },
      { x: 88, y: 1462, size: 27 },
      { x: 96, y: 1500, size: 24, label: "Enterprise · 1 500" },
    ],
  },
];

/** Тот же набор без третьей величины — донорский вариант `bubble={false}` */
const DOTS: ScatterCardSeries[] = COHORTS.map((s) => ({
  ...s,
  points: s.points.map(({ x, y, label }) => ({ x, y, label })),
}));

/* ───────────── подпись под историей ───────────── */

function Note({ children }: { children: ReactNode }) {
  return <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">{children}</p>;
}

function Head({ children }: { children: ReactNode }) {
  return <h3 className="text-title-l text-ink mb-2">{children}</h3>;
}

/* ═══════════════  типовой случай  ═══════════════ */

/** Скриншот заказчика один в один: те же числа, те же когорты, тот же период */
export const Карточка: Story = {
  render: () => {
    const xs = COHORTS.flatMap((s) => s.points.map((p) => p.x));
    const ys = COHORTS.flatMap((s) => s.points.map((p) => p.y));
    return (
      <div className="w-[828px]">
        <Head>Как на скриншоте — 828 × {CARD_BUDGET}</Head>
        <Note>
          Оси считаются, а не задаются. По X четыре промежутка:{" "}
          {cardAxisTicks(xs, 4).ticks.join(" · ")} — ровно донорские. По Y три:{" "}
          {cardAxisTicks(ys).ticks.join(" · ")} — донор писал 0 / 550 / 1.1K / 1.7K, у нас шаг вышел
          круглее. Средние в плитках карточка считает сама: 270 / 783 / 1 388 совпали со скриншотом.
          Слот графика {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half" })}.
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="742"
          delta={{ label: "+6,8%", direction: "up" }}
          period={{ label: "This quarter" }}
          series={COHORTS}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
    );
  },
};

/** Донорский `bubble={false}`: третьей величины нет, все точки одного размера */
export const БезПузырьков: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>Без третьей величины</Head>
      <Note>
        Пузырьки включаются сами, когда у точек есть `size`. Нет — все точки одного радиуса, и у
        каждой появляется кольцо-просвет цветом карточки: без него две близкие точки одной когорты
        слипаются в восьмёрку, и вместо двух наблюдений читается одно. Суффикс «· avg» в плитках
        тоже пропал — он ставится только вместе с усреднением, а здесь значения переданы готовыми.
      </Note>
      <ScatterCard
        label="Revenue per account"
        value="742"
        delta={{ label: "+6,8%", direction: "up" }}
        period={{ label: "This quarter" }}
        series={DOTS.map((s, i) => ({ ...s, legendValue: ["270", "783", "1 388"][i] }))}
        xTitle="Sessions"
        yTitle="Revenue"
      />
    </div>
  ),
};

/** Замена наведению: две ключевые точки подписаны статически */
export const СПодписямиТочек: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>`marks` — подпись вместо наведения</Head>
      <Note>
        У донора имя записи показывал курсор. В PDF курсора нет, поэтому 1–2 ключевые точки
        подписываются статически. Место ищется по четырём кандидатам — справа, слева, сверху, снизу.
        Подпись принимается, только если её бокс целиком внутри границ (поле построения плюс пустые
        верхнее и правое поля SVG) и не задел ни одного круга. Задеть нельзя не из аккуратности: в
        тёмной теме на салатовой заливке белый текст даёт 1,93:1 при пороге 4,5 — читаемого цвета
        там нет вовсе. Места не нашлось — подпись не рисуется, а в консоли разработки печатается
        предупреждение. Проверено замером: во всех историях в обеих темах ни одна из подписей — ни
        точки, ни оси — не пересекается ни с одним кругом, худший контраст подписи 5,41 в светлой
        теме и 6,00 в тёмной при пороге 4,5.
      </Note>
      <ScatterCard
        label="Revenue per account"
        value="742"
        delta={{ label: "+6,8%", direction: "up" }}
        period={{ label: "This quarter" }}
        series={COHORTS}
        xTitle="Sessions"
        yTitle="Revenue"
        sizeTitle="Accounts"
        marks={[
          { series: "starter", index: 1, label: "SMB · 240" },
          { series: "growth", index: 3, label: "Growth · 940" },
        ]}
      />
    </div>
  ),
};

/* ═══════════════  обе темы  ═══════════════ */

/**
 * Светлая и тёмная РЯДОМ через вложенную тему — расхождение видно без
 * переключения тулбара.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex gap-6">
      <div className="w-[828px]">
        <Head>Светлая карточка</Head>
        <Note>
          ⚠️ Слабое место, принятое заказчиком: при донорской непрозрачности 0,85 заливка не берёт
          порог 3:1 ни у одной когорты — 1,45 у Starter, 2,63 у Growth, 2,37 у Scale. У салата не
          берёт и обводка (1,95). Поэтому когорту называет легенда, а положение читается по сетке.
        </Note>
        <ScatterCard
          theme="light"
          label="Revenue per account"
          value="742"
          delta={{ label: "+6,8%", direction: "up" }}
          period={{ label: "This quarter" }}
          series={COHORTS}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
      <div className="w-[828px]">
        <Head>Тёмная карточка</Head>
        <Note>
          Те же краски дают 7,51 / 3,88 / 4,31 у заливок и 7,77 / 4,02 / 3,67 у обводок — порог
          берут все шесть. Запас вдвое-впятеро больше светлой темы. Если карточка едет на проектор —
          брать эту.
        </Note>
        <ScatterCard
          theme="dark"
          label="Revenue per account"
          value="742"
          delta={{ label: "+6,8%", direction: "up" }}
          period={{ label: "This quarter" }}
          series={COHORTS}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  крайние случаи  ═══════════════ */

/** Минимум: одна когорта, одна точка */
export const МинимумДанных: Story = {
  render: () => (
    <div className="flex flex-col gap-10">
      <div className="w-[828px]">
        <Head>Одна когорта, две точки</Head>
        <Note>
          Легенда из одной плитки выглядит странно, но нужна: цвет сам по себе не называет ничего, а
          среднее по когорте — это число, которого больше нигде на карточке нет. Две точки — нижняя
          граница формы: связь по двум наблюдениям не показывают, показывают «было → стало».
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="270"
          period={{ label: "This quarter" }}
          series={[{ ...COHORTS[0], points: COHORTS[0].points.slice(0, 2) }]}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
      <div className="w-[828px]">
        <Head>Одна точка</Head>
        <Note>
          Не должно ронять блок, но графиком не является: одно наблюдение — это плитка `StatTiles`,
          а не диаграмма связи. Единственный пузырёк при этом получает НАИБОЛЬШИЙ радиус (он же и
          максимум набора), и это честно: площадь кодирует долю от максимума, а он сам себе
          максимум. История нужна, чтобы вырождение было видно здесь, а не на слайде клиента.
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="180"
          period={{ label: "This quarter" }}
          series={[{ ...COHORTS[0], points: COHORTS[0].points.slice(0, 1) }]}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
    </div>
  ),
};

/**
 * Потолок: точек столько, что облако смыкается, и карточка во всю ширину,
 * где пропорции поля ломаются.
 */
export const Потолок: Story = {
  render: () => {
    const dense: ScatterCardSeries[] = COHORTS.map((s, si) => ({
      ...s,
      points: Array.from({ length: 14 }, (_, i) => ({
        x: 6 + si * 30 + i * 2 + (i % 3),
        y: 160 + si * 520 + i * 26 + (i % 4) * 18,
        size: 120 - si * 34 - i * 2,
      })),
    }));
    return (
      <div className="flex flex-col gap-10">
        <div className="w-[828px]">
          <Head>42 точки на половинной карточке</Head>
          <Note>
            Поле {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half" })} за вычетом
            полей даёт пропорцию около 3:1 — донорские 3,09:1. Пузырьки идут в порядке убывания
            радиуса: крупные рисуются первыми и оказываются ПОЗАДИ, иначе мелкий исчезает под
            крупным целиком и наблюдение пропадает из графика.
          </Note>
          <ScatterCard
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={dense}
            xTitle="Sessions"
            yTitle="Revenue"
            sizeTitle="Accounts"
          />
        </div>
        <div className="w-[1680px]">
          <Head>Та же карточка во всю ширину — так делать не надо</Head>
          <Note>
            ⚠️ Поле построения становится примерно 8:1 против донорских 3,09:1. Числа при этом
            верные, а форма связи — нет: одна и та же зависимость на растянутом поле читается как
            более пологая. В консоли разработки на эту историю печатается предупреждение с
            замеренной пропорцией. Лекарство — две половинные карточки рядом, как в истории «На
            слайде».
          </Note>
          <ScatterCard
            size="full"
            width={1680}
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={dense}
            xTitle="Sessions"
            yTitle="Revenue"
            sizeTitle="Accounts"
          />
        </div>
      </div>
    );
  },
};

/** Длинные подписи: лечатся жёлобом, прореживанием и переносом ключа на свою строку */
export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>Рублёвая ось, длинные названия осей, длинная подпись площади</Head>
      <Note>
        Жёлоб слева считается по САМОЙ ШИРОКОЙ подписи тика — здесь это «1 500 000 ₽». Подписи оси X
        прорежены по замеру ширины каждой строки: линия сетки остаётся, пропадает подпись. Подпись
        площади не помещается между названиями осей и уезжает на СВОЮ строку — информация о том, что
        значит пятно, важнее высоты поля построения. Подпись шапки длиннее карточки обрезается
        многоточием — это `CardShell`, а не график.
      </Note>
      <ScatterCard
        label="Выручка на клиента в разрезе тарифных когорт за вычетом возвратов"
        value="1 284 950 ₽"
        delta={{ label: "−31%", direction: "down" }}
        period={{ label: "Последние 12 месяцев" }}
        series={COHORTS.map((s) => ({
          ...s,
          label: `${s.label} — годовой контракт`,
          points: s.points.map((p) => ({ ...p, y: p.y * 1000 })),
        }))}
        xTitle="Сессий на клиента в неделю"
        yTitle="Выручка на клиента"
        sizeTitle="клиентов в точке на конец периода"
        formatY={(v) => `${v.toLocaleString("ru-RU")} ₽`}
        formatX={(v) => `${v} сес.`}
      />
    </div>
  ),
};

/**
 * Опасный случай — то, на чём форма обычно и ломается.
 *
 * Четыре беды подряд: разброс шире, чем площадь способна показать; четвёртая
 * когорта, которой неоткуда взять цвет; данные, сплющенные нулём в домене;
 * и ряд из одних нулей, где шкала вырождается в точку.
 */
export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="flex flex-col gap-10">
      <div className="w-[828px]">
        <Head>Разброс 100:1 — пол радиуса врёт в пользу мелких</Head>
        <Note>
          ⚠️ Площадь кодирует долю: r = R·√(v/v_max). При разбросе шире ~8:1 мелкие значения
          упираются в пол радиуса (8 точек — меньше круг с трёх метров не отличить от точки), и их
          пятна становятся БОЛЬШЕ своей доли. Это осознанный размен на различимость, и он громкий: в
          консоли разработки печатается, сколько точек упёрлось в пол и во сколько раз разброс шире
          возможного. Лечится сворачиванием хвоста в «прочее» или другой формой.
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="742"
          period={{ label: "This quarter" }}
          series={COHORTS.map((s, si) => ({
            ...s,
            points: s.points.map((p, i) => ({ ...p, size: si === 0 ? 900 : 12 - i })),
          }))}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
      <div className="w-[828px]">
        <Head>Четвёртая когорта</Head>
        <Note>
          ⚠️ Показаны первые три, четвёртая ОТБРОШЕНА, и в консоли об этом печатается
          предупреждение. Красить её цветом первой нельзя: получился бы график, который врёт про
          принадлежность точек. На точечной сравниваются все пары цветов сразу, донор ограничился
          тремя когортами, а донорская восьмёрка на различимость пар не проверялась вовсе — это
          записано в шапке `boardPalette.ts`.
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="742"
          period={{ label: "This quarter" }}
          series={[
            ...COHORTS,
            {
              key: "trial",
              label: "Trial",
              points: [
                { x: 4, y: 60 },
                { x: 9, y: 90 },
              ],
            },
          ]}
          xTitle="Sessions"
          yTitle="Revenue"
          sizeTitle="Accounts"
        />
      </div>
      <div className="w-[828px]">
        <Head>Данные, сплющенные нулём в домене</Head>
        <Note>
          ⚠️ Домен карточки включает ноль — как у донора и у соседних карточек волны. Конверсия 3,1
          … 4,4% занимает при этом 12% шкалы: облако сжимается в полоску, и связь по нему прочитать
          нельзя. Карточка это замечает и печатает предупреждение с долей шкалы. Такому набору нужен
          слайдовый `blocks/scatter.tsx` — он считает границы от данных, а не от нуля.
        </Note>
        <ScatterCard
          label="Конверсия по когортам"
          value="3,8%"
          period={{ label: "This quarter" }}
          series={COHORTS.map((s, si) => ({
            ...s,
            points: s.points.map((p, i) => ({ x: p.x, y: 31 + si * 4 + i })),
          }))}
          xTitle="Sessions"
          yTitle="Конверсия"
          formatY={(v) => `${(v / 10).toFixed(1)}%`}
        />
      </div>
      <div className="w-[828px]">
        <Head>Все значения нулевые</Head>
        <Note>
          Домен схлопнулся бы в точку, и шкала дала бы деление на ноль — на слайде это NaN в
          координатах и ПУСТОЙ график, который проходит все автопроверки, кроме проверки на пустоту.
          `cardAxisTicks` подменяет вырожденный домен на [0, 1] явно: все точки ложатся в левый
          нижний угол, и видно, что данных нет.
        </Note>
        <ScatterCard
          label="Revenue per account"
          value="0"
          period={{ label: "This quarter" }}
          series={COHORTS.map((s) => ({
            ...s,
            points: s.points.map(() => ({ x: 0, y: 0 })),
          }))}
          xTitle="Sessions"
          yTitle="Revenue"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  как на слайде  ═══════════════ */

/**
 * Карточка внутри `ContentSlide` — единственная проверка, которая
 * подтверждает бюджет 604. В обёртке витрины он не проверяется никак:
 * там нет ни шапки слайда, ни подвала, ни холста 1080.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Клиентская база"
      title="Выручка на клиента растёт быстрее его активности"
      page={11}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <ScatterCard
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={COHORTS}
            xTitle="Sessions"
            yTitle="Revenue"
            sizeTitle="Accounts"
          />
        </div>
        <div className="col-span-6">
          <ScatterCard
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={DOTS.map((s, i) => ({ ...s, legendValue: ["270", "783", "1 388"][i] }))}
            xTitle="Sessions"
            yTitle="Revenue"
            marks={[{ series: "growth", index: 3, label: "Growth · 940" }]}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};

/** Тот же слайд в тёмной теме — та, под которую карточка и рассчитана */
export const НаСлайдеТёмном: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Клиентская база"
      title="Выручка на клиента растёт быстрее его активности"
      page={12}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <ScatterCard
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={COHORTS}
            xTitle="Sessions"
            yTitle="Revenue"
            sizeTitle="Accounts"
          />
        </div>
        <div className="col-span-6">
          <ScatterCard
            label="Revenue per account"
            value="742"
            delta={{ label: "+6,8%", direction: "up" }}
            period={{ label: "This quarter" }}
            series={DOTS.map((s, i) => ({ ...s, legendValue: ["270", "783", "1 388"][i] }))}
            xTitle="Sessions"
            yTitle="Revenue"
            marks={[{ series: "growth", index: 3, label: "Growth · 940" }]}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};

/**
 * Во всю ширину — показано ради честности, а не как образец: пропорции
 * поля здесь ломаются, см. историю «Потолок».
 */
export const НаСлайдеВоВсюШирину: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Клиентская база"
      title="Крупные клиенты платят больше — но их вчетверо меньше"
      page={13}
      label="Витрина карточек"
    >
      <ScatterCard
        size="full"
        width={1680}
        label="Revenue per account"
        value="742"
        delta={{ label: "+6,8%", direction: "up" }}
        period={{ label: "This quarter" }}
        series={COHORTS}
        xTitle="Sessions"
        yTitle="Revenue"
        sizeTitle="Accounts"
        marks={[{ series: "growth", index: 3, label: "Growth · 940" }]}
      />
    </ContentSlide>
  ),
};
