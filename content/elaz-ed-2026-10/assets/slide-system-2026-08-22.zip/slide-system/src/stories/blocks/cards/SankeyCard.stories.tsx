import type { Meta, StoryObj } from "@storybook/react-vite";
import SankeyCard, {
  type SankeyCardLink,
  type SankeyCardNode,
} from "../../../blocks/cards/sankeyCard";
import {
  BAND_MIN,
  LABEL_GAP,
  LABEL_MAX_SHARE,
  NODE_W,
  RIBBON_MIN,
  SANKEY_CARD_COLORS,
  layoutSankeyCard,
} from "../../../blocks/cards/sankeyLayout";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «поток» — восьмая из донорских карточек.
 *
 * Витрина показывает не столько красивый случай, сколько границы: минимум
 * данных, оба потолка, длинные подписи, статическую изоляцию потока и
 * сочетание, при котором форма перестаёт читаться. Разбор переноса — в шапке
 * [`blocks/cards/sankeyCard.tsx`](../../../blocks/cards/sankeyCard.tsx),
 * вся геометрия и замеры — в
 * [`blocks/cards/sankeyLayout.ts`](../../../blocks/cards/sankeyLayout.ts).
 *
 * === Про числа в подписях ===
 *
 * Все числа СЧИТАЮТСЯ вызовом `layoutSankeyCard` прямо здесь, на тех же
 * данных, что нарисованы рядом. Переписанное руками число живёт своей жизнью:
 * поменяется просвет между узлами или потолок колонки подписей — проза
 * останется прежней и будет врать увереннее, чем сам блок.
 *
 * По той же причине под каждой историей напечатан список ПРЕДУПРЕЖДЕНИЙ,
 * которые блок выдаёт в консоль на этих данных. Предупреждение в консоли
 * видит только тот, кто в этот момент в неё смотрел; на странице его видно
 * всегда.
 *
 * === Про ширину обёртки ===
 *
 * Разборные истории стоят на жёсткой ширине 1680, а не на `max-w-`. Геометрия
 * считается от переданной ширины, и молча сжатый контейнер дал бы картинку,
 * не совпадающую с собственными замерами блока. Витрина добавляет своё поле,
 * поэтому окно нужно от 1808 точек — на узком будет честная горизонтальная
 * прокрутка.
 *
 * ⚠️ Чего эта витрина не даёт: `npm run check` обходит только слайды деков.
 * Пока карточка не поставлена в дек, автоматических ворот у неё нет —
 * переполнение здесь ловится замером в режиме 1:1, а не скриптом.
 */

const meta = {
  title: "Карточки/Поток",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Данные донора  ═══════════════ */

/*
 * Со страницы донора сняты имена узлов, значения источников (32 · 18 · 12 ·
 * 14 · 10 из 86 часов) и доли приёмников (22 · 18 · 13 · 12 · 8 · 14 · 13 %).
 * Самих СВЯЗЕЙ на странице не видно — видны только их толщины, и разведка
 * замерила шесть из девятнадцати. Поэтому матрица ниже достроена так, чтобы
 * суммы по строкам дали донорские часы, а суммы по столбцам — донорские доли
 * ровно, без округления: 18.92 · 15.48 · 11.18 · 10.32 · 6.88 · 12.04 ·
 * 11.18 при итоге 86.
 *
 * То есть выдумана здесь связность, а не итоги: любое число, которое видно
 * на карточке, совпадает с донорским.
 */

const ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "focus", label: "Focus" },
  { key: "meetings", label: "Meetings" },
  { key: "breaks", label: "Breaks" },
  { key: "admin", label: "Admin" },
  { key: "learning", label: "Learning" },
];

const ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "browsing", label: "Browsing" },
  { key: "writing", label: "Writing" },
  { key: "messaging", label: "Messaging" },
  { key: "productivity", label: "Productivity" },
  { key: "email", label: "Email" },
  { key: "calls", label: "Video calls" },
  { key: "other", label: "Everything else" },
];

const СВЯЗИ: SankeyCardLink[] = [
  { from: "focus", to: "writing", value: 13 },
  { from: "focus", to: "productivity", value: 8 },
  { from: "focus", to: "browsing", value: 7 },
  { from: "focus", to: "other", value: 4 },

  { from: "meetings", to: "calls", value: 11 },
  { from: "meetings", to: "messaging", value: 4 },
  { from: "meetings", to: "email", value: 1.5 },
  { from: "meetings", to: "other", value: 1.5 },

  { from: "breaks", to: "browsing", value: 8 },
  { from: "breaks", to: "other", value: 4 },

  { from: "admin", to: "email", value: 5.38 },
  { from: "admin", to: "messaging", value: 5 },
  { from: "admin", to: "productivity", value: 2.32 },
  { from: "admin", to: "browsing", value: 1.3 },

  { from: "learning", to: "browsing", value: 2.62 },
  { from: "learning", to: "writing", value: 2.48 },
  { from: "learning", to: "messaging", value: 2.18 },
  { from: "learning", to: "calls", value: 1.04 },
  { from: "learning", to: "other", value: 1.68 },
];

const часы = (v: number) => `${v.toLocaleString("ru-RU", { maximumFractionDigits: 1 })} ч`;

/* ═══════════════  Замеры для подписей историй  ═══════════════ */

const W = cardChartWidth(1680);
const H = cardChartHeight({ legend: false });

const измерить = (
  sources: readonly SankeyCardNode[],
  targets: readonly SankeyCardNode[],
  links: readonly SankeyCardLink[],
  options: { captions?: boolean; width?: number; half?: boolean; highlight?: string } = {},
) =>
  layoutSankeyCard({
    sources,
    targets,
    links,
    chartWidth: cardChartWidth(options.width ?? 1680, options.half ? "half" : "full"),
    chartHeight: cardChartHeight({ legend: false, size: options.half ? "half" : "full" }),
    hasCaptions: options.captions ?? true,
    formatValue: часы,
    formatShare: (p: number) => (p > 0 && p < 0.5 ? "<1%" : `${Math.round(p)}%`),
    highlight: options.highlight,
  });

const число = (x: number) => x.toFixed(1);
const ряд = (xs: number[]) => xs.map(число).join(" · ");

/**
 * Предупреждения блока, напечатанные на странице.
 *
 * Считаются тем же вызовом, что и геометрия, поэтому разойтись с консолью
 * не могут. Пустой список — тоже результат: он означает, что на этих данных
 * блок молчит, и это видно, а не предполагается.
 */
function Предупреждения({ layout }: { layout: ReturnType<typeof измерить> }) {
  return (
    <div className="mb-10 max-w-5xl">
      <h4 className="text-title-m text-ink mb-2">
        Предупреждений в консоли: {layout.warnings.length}
      </h4>
      {layout.warnings.length ? (
        <ul className="text-body-m text-ink-secondary flex flex-col gap-2">
          {layout.warnings.map((w) => (
            <li key={w} className="flex gap-3">
              <span className="text-ink-tertiary shrink-0">—</span>
              <span>{w}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-body-m text-ink-secondary">
          Блок молчит: пропорция точна, ленты толще {RIBBON_MIN} точек, подписи не обрезаны, полоса
          шире {BAND_MIN}.
        </p>
      )}
    </div>
  );
}

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Донорская карточка один в один, во всю рабочую ширину.
 *
 * Здесь смотреть главное: столбики стоят СВОИМИ долями, минимум высоты не
 * срабатывает ни разу. Ровно это и было целью отказа от донорской двухстрочной
 * подписи — расчёт приведён в шапке блока.
 */
export const Поток: Story = {
  render: () => {
    const L = измерить(ИСТОЧНИКИ, ПРИЁМНИКИ, СВЯЗИ);
    const справедливо = L.sourceValue.map((v) => (v / L.total) * L.barTotal);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Донорские данные, 1680 × {CARD_BUDGET}; поле графика {W} × {H}, полоса потока{" "}
          {число(L.bandW)} × {L.bandH}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Подписи забрали {число(L.fromW)} слева и {число(L.toW)} справа при потолке{" "}
          {число(W * LABEL_MAX_SHARE)} (четверть поля) — то есть на донорских именах потолок и
          близко не срабатывает. Вместе со столбиками {NODE_W} и просветами {LABEL_GAP} колонки
          съедают {число((L.bandX / W) * 100)}% слева и {число(((W - L.bandX - L.bandW) / W) * 100)}
          % справа против донорских 16% и 27%, и на ленты остаётся {число(L.bandW)} —{" "}
          {число((L.bandW / W) * 100)}% ширины против донорских 52%. То есть кегль 24 вместо 13
          подписи не раздул: карточка шире донорской в 2.9 раза, а имена — те же самые. Потолок в
          четверть поля нужен не здесь, а на длинных именах — отдельная история ниже.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Столбики источников: {ряд(L.sourceH)} при «честных» долях {ряд(справедливо)} — совпадают
          до сотых, минимум {число(L.minBar)} на источниках не срабатывает вовсе. Ровно ради этого и
          отвергнута донорская двухстрочная подпись: с ней минимум был бы 46, и четыре источника из
          пяти встали бы одинаковыми (расчёт — в шапке блока). Столбики приёмников: {ряд(L.targetH)}
          ; самый мелкий (Email, 8%) в минимум упирается, и блок про это говорит. Лент{" "}
          {L.ribbons.length}; самая тонкая {число(Math.min(...L.ribbons.map((r) => r.thickest)))},
          самая толстая {число(Math.max(...L.ribbons.map((r) => r.thickest)))}.
        </p>
        <Предупреждения layout={L} />
        <SankeyCard
          label="Tracked time"
          sources={ИСТОЧНИКИ}
          targets={ПРИЁМНИКИ}
          links={СВЯЗИ}
          delta={{ label: "+4,1%", direction: "up" }}
          period={{ label: "This week" }}
          axisLabels={["Tracked time", "Share of tracked time"]}
          formatValue={часы}
        />
      </div>
    );
  },
};

/**
 * Обе темы рядом через вложенную тему — расхождение видно без переключения
 * тулбара, и оно здесь принципиальное.
 *
 * В светлой теме порог 3:1 берёт один столбик из пяти (синий 3.14), в тёмной
 * — все пять (4.83…9.62). Стопка лент в светлой теме плотнее самого слабого
 * столбика уже при двух пересечениях, и прозрачностью это не лечится: причина
 * в том, что жёлтая краска донора на белом почти не видна сама. Полный замер
 * — у `RIBBON_ALPHA` в `sankeyLayout.ts`.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Светлая тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Краски к белой карточке: emerald 1.94 · purple 2.79 · yellow 1.57 · blue 3.14 · pink 2.76.
          Порог берёт одна. Столбики-приёмники — третичный, 3.79, порог берут. Читается карточка за
          счёт подписей у каждого узла, а не за счёт цвета — это принятое заказчиком решение, а не
          недосмотр.
        </p>
        <SankeyCard
          theme="light"
          label="Tracked time"
          sources={ИСТОЧНИКИ}
          targets={ПРИЁМНИКИ}
          links={СВЯЗИ}
          delta={{ label: "+4,1%", direction: "up" }}
          period={{ label: "This week" }}
          axisLabels={["Tracked time", "Share of tracked time"]}
          formatValue={часы}
        />
      </div>
      <div>
        <h3 className="text-title-l text-ink mb-2">Тёмная тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Те же краски к карточке #262626: 7.81 · 5.42 · 9.62 · 4.83 · 5.48 — порог берут все пять с
          запасом, приёмники 3.68. Стопка из пяти лент даёт 4.20 против слабейшего столбика 4.83, то
          есть пересечения остаются тише данных. Если карточка едет на проектор — брать эту тему.
        </p>
        <SankeyCard
          theme="dark"
          label="Tracked time"
          sources={ИСТОЧНИКИ}
          targets={ПРИЁМНИКИ}
          links={СВЯЗИ}
          delta={{ label: "+4,1%", direction: "up" }}
          period={{ label: "This week" }}
          axisLabels={["Tracked time", "Share of tracked time"]}
          formatValue={часы}
        />
      </div>
    </div>
  ),
};

/**
 * Статическая изоляция потока — замена донорскому наведению.
 *
 * У донора один поток можно было проследить, наведя мышь: связанные ленты
 * поднимались с 0.32 до 0.7, все прочие падали до 0.08. В PDF курсора нет,
 * поэтому кадр выбирается заранее — и тогда заголовок слайда обязан
 * формулировать вывод именно про этот поток, иначе непонятно, почему
 * выделен он.
 */
export const Выделение: Story = {
  render: () => {
    const L = измерить(ИСТОЧНИКИ, ПРИЁМНИКИ, СВЯЗИ, { highlight: "admin" });
    const admin = L.ribbons.filter((r) => r.si === 3);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          highlight="admin" — четыре ленты из {L.ribbons.length} в полную силу
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Выделенный источник даёт {admin.length} ленты толщиной {ряд(admin.map((r) => r.thickest))}
          . Замер к карточке: выделенная лента 1.39…2.19 в светлой теме и 3.08…5.47 в тёмной,
          погашенная 1.04…1.09 и 1.12…1.20. В светлой теме абсолютные числа низкие — приём работает
          на разнице, а не на пороге: выделенная плотнее погашенной вдвое в светлой теме и вчетверо
          в тёмной.
        </p>
        <Предупреждения layout={L} />
        <SankeyCard
          label="Tracked time"
          sources={ИСТОЧНИКИ}
          targets={ПРИЁМНИКИ}
          links={СВЯЗИ}
          highlight="admin"
          delta={{ label: "+4,1%", direction: "up" }}
          period={{ label: "This week" }}
          axisLabels={["Tracked time", "Share of tracked time"]}
          formatValue={часы}
        />
      </div>
    );
  },
};

/* ═══════════════  Крайние случаи  ═══════════════ */

const МИНИМУМ_ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "site", label: "Сайт" },
  { key: "ads", label: "Реклама" },
];
const МИНИМУМ_ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "deal", label: "Сделка" },
  { key: "lost", label: "Отказ" },
];
const МИНИМУМ_СВЯЗИ: SankeyCardLink[] = [
  { from: "site", to: "deal", value: 420 },
  { from: "site", to: "lost", value: 980 },
  { from: "ads", to: "deal", value: 260 },
  { from: "ads", to: "lost", value: 1140 },
];

/**
 * Минимум данных: два источника и два приёмника, четыре ленты.
 *
 * Нижняя граница формы. Меньше — это уже не поток: один источник дал бы
 * веер из одной точки, а такой рисунок закрывает `blocks/stages.tsx`, где
 * величина закодирована длиной полосы и читается точнее.
 */
export const МинимумДанных: Story = {
  render: () => {
    const L = измерить(МИНИМУМ_ИСТОЧНИКИ, МИНИМУМ_ПРИЁМНИКИ, МИНИМУМ_СВЯЗИ);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">Два на два — нижняя граница формы</h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Просветов в колонке всего один, поэтому под столбики уходит {число(L.barTotal)} из{" "}
          {L.bandH} — они становятся заметно толще, чем на донорских данных. Столбики источников{" "}
          {ряд(L.sourceH)}, приёмников {ряд(L.targetH)}. Подписи короткие, и колонки сжались до{" "}
          {число(L.fromW)} и {число(L.toW)} — на ленты остаётся {число(L.bandW)}, вдвое больше
          донорского.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Форма ещё читается, но смысла в ней немного: четыре числа — это ряд плиток `StatTiles` или
          пара строк таблицы. Поток берут, когда источников или приёмников больше трёх.
        </p>
        <Предупреждения layout={L} />
        <SankeyCard
          label="Заявки"
          sources={МИНИМУМ_ИСТОЧНИКИ}
          targets={МИНИМУМ_ПРИЁМНИКИ}
          links={МИНИМУМ_СВЯЗИ}
          delta={{ label: "−2,4%", direction: "down" }}
          period={{ label: "Last 30 days" }}
          axisLabels={["Откуда пришли", "Чем закончилось"]}
        />
      </div>
    );
  },
};

/* Семь источников и девять приёмников: оба потолка сразу */
const ПОТОЛОК_ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "s1", label: "Поиск" },
  { key: "s2", label: "Соцсети" },
  { key: "s3", label: "Почта" },
  { key: "s4", label: "Реклама" },
  { key: "s5", label: "Партнёры" },
  { key: "s6", label: "Прямые" },
  { key: "s7", label: "Рефералы" },
];

const ПОТОЛОК_ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "t1", label: "Главная" },
  { key: "t2", label: "Каталог" },
  { key: "t3", label: "Карточка" },
  { key: "t4", label: "Корзина" },
  { key: "t5", label: "Оплата" },
  { key: "t6", label: "Блог" },
  { key: "t7", label: "Поддержка" },
  { key: "t8", label: "Вакансии" },
  { key: "t9", label: "О компании" },
];

const ПОТОЛОК_СВЯЗИ: SankeyCardLink[] = ПОТОЛОК_ИСТОЧНИКИ.flatMap((s, i) =>
  ПОТОЛОК_ПРИЁМНИКИ
    .filter((_, j) => (i + j) % 3 !== 2)
    .map((t, j) => ({
      from: s.key,
      to: t.key,
      value: 400 - i * 40 - j * 25,
    })),
);

/**
 * Потолок: передано семь источников и девять приёмников.
 *
 * Потолков ДВА, и они независимы.
 *
 * **Источники — пять.** Число выведено из палитры, а не назначено: цвет
 * кодирует источник, а по кругу цвета не назначаются (`dataviz.md`). Шестой
 * источник — это не шестая краска, а строка «Прочее» на стороне данных.
 *
 * **Приёмники — семь.** Донорский предел, он же предел читаемости: лент
 * становится до 35 на полосу около 700 точек, и отдельную глазом уже не
 * проследить.
 *
 * Обрезка не молчаливая: лишние узлы отбрасываются вместе со своими связями,
 * и блок печатает, что именно выпало и куда делись их величины. Итог и доли
 * при этом считаются БЕЗ отброшенного — иначе доли не сложились бы в 100%.
 */
export const Потолок: Story = {
  render: () => {
    const L = измерить(ПОТОЛОК_ИСТОЧНИКИ, ПОТОЛОК_ПРИЁМНИКИ, ПОТОЛОК_СВЯЗИ);
    const всего = ПОТОЛОК_СВЯЗИ.reduce((s, l) => s + l.value, 0);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          7 × 9 на входе, {L.keptSources.length} × {L.keptTargets.length} на выходе
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Из {ПОТОЛОК_СВЯЗИ.length} связей нарисовано {L.ribbons.length}. В итог вошло{" "}
          {L.total.toLocaleString("ru-RU")} из {всего.toLocaleString("ru-RU")} — остальное ушло
          вместе с отброшенными узлами, и блок про это говорит явно. Столбики приёмников{" "}
          {ряд(L.targetH)} при минимуме {число(L.minBar)}.
        </p>
        <Предупреждения layout={L} />
        <SankeyCard
          label="Переходы по разделам"
          sources={ПОТОЛОК_ИСТОЧНИКИ}
          targets={ПОТОЛОК_ПРИЁМНИКИ}
          links={ПОТОЛОК_СВЯЗИ}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          axisLabels={["Источник перехода", "Доля от всех переходов"]}
        />
      </div>
    );
  },
};

/* ═══════════════  Длинные подписи и половинная ширина  ═══════════════ */

const ДЛИННЫЕ_ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "a", label: "Контекстная реклама в поиске" },
  { key: "b", label: "Партнёрская сеть и агрегаторы" },
  { key: "c", label: "Прямые заходы" },
];

const ДЛИННЫЕ_ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "x", label: "Оформили подписку на год" },
  { key: "y", label: "Оставили заявку на демонстрацию" },
  { key: "z", label: "Ушли" },
];

const ДЛИННЫЕ_СВЯЗИ: SankeyCardLink[] = [
  { from: "a", to: "x", value: 1200 },
  { from: "a", to: "y", value: 900 },
  { from: "a", to: "z", value: 3400 },
  { from: "b", to: "x", value: 700 },
  { from: "b", to: "y", value: 1500 },
  { from: "b", to: "z", value: 1800 },
  { from: "c", to: "x", value: 400 },
  { from: "c", to: "z", value: 900 },
];

/**
 * Длинные подписи и половинная ширина.
 *
 * Имя узла обрезается многоточием, а не переносится: перенос увеличил бы
 * высоту подписи, а от неё считается минимальная высота столбика — тот самый
 * механизм, который на донорских двух строках съедал пропорцию (расчёт в
 * шапке блока). Обрезка идёт по `overflow: hidden`, то есть текст ТЕРЯЕТСЯ,
 * но на соседа не наезжает.
 *
 * Это не дефект вёрстки, а сигнал сократить подпись: «Подписка», а не
 * «Оформили подписку на год».
 */
export const ДлинныеПодписи: Story = {
  render: () => {
    const L = измерить(ДЛИННЫЕ_ИСТОЧНИКИ, ДЛИННЫЕ_ПРИЁМНИКИ, ДЛИННЫЕ_СВЯЗИ);
    const Половина = измерить(ИСТОЧНИКИ, ПРИЁМНИКИ, СВЯЗИ, { width: 828, half: true });
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">Длинные названия во всю ширину</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Колонка подписи упирается в потолок {число(W * LABEL_MAX_SHARE)} — четверть поля.
            Фактически взято {число(L.fromW)} слева и {число(L.toW)} справа, на ленты остаётся{" "}
            {число(L.bandW)}. Что именно обрезано и на сколько — в списке предупреждений ниже.
          </p>
          <Предупреждения layout={L} />
          <SankeyCard
            label="Регистрации"
            sources={ДЛИННЫЕ_ИСТОЧНИКИ}
            targets={ДЛИННЫЕ_ПРИЁМНИКИ}
            links={ДЛИННЫЕ_СВЯЗИ}
            delta={{ label: "+8,7%", direction: "up" }}
            period={{ label: "Last 30 days" }}
            axisLabels={["Откуда пришли", "Доля от всех регистраций"]}
          />
        </div>
        <div>
          <h3 className="text-title-l text-ink mb-2">Половинная ширина — 828</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Поле графика {cardChartWidth(828, "half")} ×{" "}
            {cardChartHeight({ size: "half", legend: false })}: выше на{" "}
            {cardChartHeight({ size: "half", legend: false }) - H}, потому что поля половинной
            карточки тоньше (20 против 36). Подписи забирают {число(Половина.fromW)} и{" "}
            {число(Половина.toW)}, и на ленты остаётся {число(Половина.bandW)} при пороге {BAND_MIN}
            . Донорские данные сюда влезают, но запаса нет: любое имя длиннее — и полоса уходит под
            порог, о чём блок предупредит.
          </p>
          <Предупреждения layout={Половина} />
          <div className="w-[828px]">
            <SankeyCard
              size="half"
              width={828}
              label="Tracked time"
              sources={ИСТОЧНИКИ}
              targets={ПРИЁМНИКИ}
              links={СВЯЗИ}
              period={{ label: "This week" }}
              axisLabels={["Tracked time", "Share"]}
              formatValue={часы}
            />
          </div>
        </div>
      </div>
    );
  },
};

/* ═══════════════  Опасный случай  ═══════════════ */

const ОПАСНЫЕ_ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "a", label: "Поиск" },
  { key: "b", label: "Соцсети" },
  { key: "c", label: "Почта" },
  { key: "d", label: "Реклама" },
  { key: "e", label: "Прочее" },
];

const ОПАСНЫЕ_ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "t1", label: "Главная" },
  { key: "t2", label: "Каталог" },
  { key: "t3", label: "Карточка" },
  { key: "t4", label: "Корзина" },
  { key: "t5", label: "Оплата" },
  { key: "t6", label: "Блог" },
  { key: "t7", label: "Поддержка" },
];

/* Полная решётка 5 × 7 = 35 лент, и одна связь нарочно ничтожная */
const ОПАСНЫЕ_СВЯЗИ: SankeyCardLink[] = ОПАСНЫЕ_ИСТОЧНИКИ.flatMap((s, i) =>
  ОПАСНЫЕ_ПРИЁМНИКИ.map((t, j) => ({
    from: s.key,
    to: t.key,
    value: i === 4 && j === 6 ? 1 : 300 - i * 45 - j * 20,
  })),
);

/**
 * Опасный случай: полная решётка 5 × 7 — все, кто может, связаны со всеми.
 *
 * Ровно тот случай, о котором предупреждает разведка: 35 лент в полосе около
 * 700 точек. Форма не ломается — она перестаёт отвечать на вопрос. Проследить
 * отдельный поток глазом здесь нельзя: у донора это лечило наведение, а на
 * слайде наведения нет.
 *
 * Лечится не параметрами блока, а данными: свернуть мелкие приёмники в
 * «Прочее», либо выделить один поток через `highlight` и сформулировать
 * заголовок слайда про него, либо взять таблицу — там 35 чисел читаются
 * лучше, чем 35 лент.
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const L = измерить(ОПАСНЫЕ_ИСТОЧНИКИ, ОПАСНЫЕ_ПРИЁМНИКИ, ОПАСНЫЕ_СВЯЗИ);
    const толщины = L.ribbons.map((r) => r.thickest);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          {L.ribbons.length} лент на {число(L.bandW)} точек — предел формы
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Толщины лент от {число(Math.min(...толщины))} до {число(Math.max(...толщины))}. В среднем
          на каждый приёмник приходит {(L.ribbons.length / L.keptTargets.length).toFixed(1)} ленты,
          и в середине полосы они пересекаются все со всеми — именно там замерена стопка, из-за
          которой непрозрачность оставлена донорской 0.32, а не поднята до 0.40.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Отдельно подложена ничтожная связь «Прочее → Поддержка» величиной 1 против соседних сотен:
          она даёт ленту тоньше {RIBBON_MIN} точек, то есть поток, который в данных есть, а на
          слайде не виден. Блок про это говорит — но исправлять должен автор данных, а не блок:
          зажать толщину нельзя, не сломав равенство «сумма лент = высота столбика».
        </p>
        <Предупреждения layout={L} />
        <SankeyCard
          label="Переходы по разделам"
          sources={ОПАСНЫЕ_ИСТОЧНИКИ}
          targets={ОПАСНЫЕ_ПРИЁМНИКИ}
          links={ОПАСНЫЕ_СВЯЗИ}
          delta={{ label: "−12,0%", direction: "down" }}
          period={{ label: "Last 7 days" }}
          axisLabels={["Источник перехода", "Доля от всех переходов"]}
        />
      </div>
    );
  },
};

/* ═══════════════  Краски  ═══════════════ */

/** Донорский круг красок источников — что во что раскрашивается */
export const Краски: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Круг красок: emerald → purple → yellow → blue → pink
      </h3>
      <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
        Порядок снят со скриншота донорского демо (chart-7 · chart-5 · chart-8 · chart-6 · chart-3),
        переставлять его нельзя: соседняя карточка того же дека красится тем же кругом. Пятая краска
        — последняя: шестого источника у этой формы не бывает, потому что не бывает шестой краски.
      </p>
      <div className="flex gap-6">
        {SANKEY_CARD_COLORS.map((color) => (
          <div key={color} className="flex items-center gap-3">
            <span
              className="shadow-hairline rounded-micro"
              style={{ width: 40, height: 40, background: color }}
            />
            <span className="text-body-m text-ink-secondary tabular-nums">{color}</span>
          </div>
        ))}
        <div className="flex items-center gap-3">
          <span
            className="bg-ink-tertiary shadow-hairline rounded-micro"
            style={{ width: 40, height: 40 }}
          />
          <span className="text-body-m text-ink-secondary">приёмник · третичный</span>
        </div>
      </div>
    </div>
  ),
};

/* ═══════════════  Как на слайде  ═══════════════ */

const СЛАЙД_ИСТОЧНИКИ: SankeyCardNode[] = [
  { key: "dev", label: "Разработка" },
  { key: "meet", label: "Встречи" },
  { key: "break", label: "Перерывы" },
  { key: "admin", label: "Администрирование" },
  { key: "learn", label: "Обучение" },
];

const СЛАЙД_ПРИЁМНИКИ: SankeyCardNode[] = [
  { key: "browser", label: "Браузер" },
  { key: "text", label: "Тексты" },
  { key: "chat", label: "Переписка" },
  { key: "tools", label: "Инструменты" },
  { key: "mail", label: "Почта" },
  { key: "calls", label: "Видеозвонки" },
  { key: "rest", label: "Прочее" },
];

/* Та же матрица, что у донора: суммы по строкам и столбцам не меняются */
const СЛАЙД_СВЯЗИ: SankeyCardLink[] = СВЯЗИ.map((l) => ({
  from: { focus: "dev", meetings: "meet", breaks: "break", admin: "admin", learning: "learn" }[
    l.from
  ] as string,
  to: {
    browsing: "browser",
    writing: "text",
    messaging: "chat",
    productivity: "tools",
    email: "mail",
    calls: "calls",
    other: "rest",
  }[l.to] as string,
  value: l.value,
}));

/**
 * Как на слайде: карточка в `ContentSlide` при бюджете 604.
 *
 * ⚠️ 604 — это бюджет при заголовке В ОДНУ СТРОКУ. Замер шапки слайда: поле
 * сверху 88 + пилюля 40 + просвет 24 + заголовок 60 + просвет 24 + лид 32 +
 * отбивка 64 = 332; снизу поле 88 и резерв под подвал 56. Карточка встаёт на
 * 332…936, подвал начинается на 972. Заголовок в две строки означает
 * `height={544}`, иначе низ карточки уедет под подпись — дефект, которого не
 * видит ни одна автопроверка (боксы не пересекаются, холст не превышен).
 *
 * Заголовок формулирует мысль, а не называет тему, и он ПРОВЕРЯЕМ по самой
 * карточке: браузер 22% плюс переписка 13% дают 35% — больше трети.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Как уходит время"
      title="Больше трети недели уходит в браузер и переписку"
      lead="Слева — во что время вкладывали, справа — чем оно оказалось на самом деле."
      page={8}
      label="Демо · карточки дашборда"
    >
      <SankeyCard
        label="Учтённое время"
        sources={СЛАЙД_ИСТОЧНИКИ}
        targets={СЛАЙД_ПРИЁМНИКИ}
        links={СЛАЙД_СВЯЗИ}
        delta={{ label: "+4,1%", direction: "up" }}
        period={{ label: "Эта неделя" }}
        axisLabels={["Учтённое время", "Доля от учтённого времени"]}
        formatValue={часы}
      />
    </ContentSlide>
  ),
};
