import type { Meta, StoryObj } from "@storybook/react-vite";
import { MagicStick, Monitor, Smartphone } from "@solar-icons/react";
import { BarChart, GrowthBars, StatTiles } from "../../blocks/charts";
import { MediaStrip, PhoneFrame } from "../../blocks/media";
import { DarkCTA } from "../../blocks/cta";
import BrowserFrame, { FrameCaption } from "../../blocks/browser";
import { CHART_SERIES, CHART_SERIES_SCATTER } from "../../lib/chartPalette";
import Button from "../../components/Button";

/**
 * Графики, медиа и призывной блок.
 *
 * Палитра графиков проверена валидатором (skill dataviz), а не подобрана:
 * системные акценты iOS её не проходят — оранжевый даёт 2.25:1 на белом,
 * бирюзовый читается серым. Числа прогонов — в src/lib/chartPalette.ts
 */

const meta = {
  title: "Блоки/Данные и медиа",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Заглушки снимков для витрины BrowserFrame.
 *
 * Настоящие снимки чужих сайтов в библиотеке не хранятся: они принадлежат
 * конкретной презентации и живут рядом с её слайдами. Здесь нужен только
 * прямоугольник правильных пропорций, чтобы показать саму рамку, обрезку
 * снизу и подпись — поэтому кадр рисуется SVG прямо в адресе картинки.
 */
function shot(title: string): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="900">
    <rect width="1440" height="900" fill="#f4f4f4"/>
    <rect x="0" y="0" width="1440" height="96" fill="#e5e5e5"/>
    <rect x="48" y="32" width="220" height="32" rx="8" fill="#c8c8c8"/>
    <rect x="48" y="176" width="900" height="64" rx="12" fill="#d4d4d4"/>
    <rect x="48" y="272" width="640" height="28" rx="8" fill="#dedede"/>
    <rect x="48" y="320" width="560" height="28" rx="8" fill="#dedede"/>
    <rect x="48" y="416" width="416" height="300" rx="20" fill="#e0e0e0"/>
    <rect x="512" y="416" width="416" height="300" rx="20" fill="#e0e0e0"/>
    <rect x="976" y="416" width="416" height="300" rx="20" fill="#e0e0e0"/>
    <text x="48" y="820" font-family="sans-serif" font-size="32" fill="#8a8a8a">${title}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const SHOTS = [
  {
    id: "catalog",
    src: shot("Каталог"),
    url: "example.ru/catalog",
    alt: "Страница каталога",
    caption: "В меню — категории, фильтры и подборки",
  },
  {
    id: "rating",
    src: shot("Рейтинг"),
    url: "example.ru/rating",
    alt: "Страница рейтинга",
    caption: "Критерии оценки названы прямо в лиде страницы",
  },
];

const SHOT_DATE = "18.08.2026";

const REVENUE = [
  { label: "I кв.", value: 42 },
  { label: "II кв.", value: 58 },
  { label: "III кв.", value: 71 },
  { label: "IV кв.", value: 124, highlight: true },
];

export const Палитра: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Основной порядок — 5 цветов</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Для форм, где ряды лежат рядом: столбики, стопки, линии. Цвета назначаются в этом порядке
          и никогда по кругу. Шестой ряд — это не новый цвет, а «прочее» или второй график.
        </p>
        <div className="flex gap-4">
          {CHART_SERIES.map((c) => (
            <div key={c} className="flex-1">
              <div className="rounded-tile h-24" style={{ background: c }} />
              <code className="text-caption text-ink-secondary mt-2 block">{c}</code>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Для точечных форм — 3 цвета</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Там, где сравниваются все пары, а не только соседние. Ограничение жёсткое: пятёрка в
          режиме всех пар проваливает проверку — зелёный с оранжевым дают ΔE 4.8 при протанопии,
          зелёный с бирюзовым 13.8 даже при нормальном зрении.
        </p>
        <div className="flex gap-4">
          {CHART_SERIES_SCATTER.map((c) => (
            <div key={c} className="flex-1">
              <div className="rounded-tile h-24" style={{ background: c }} />
              <code className="text-caption text-ink-secondary mt-2 block">{c}</code>
            </div>
          ))}
        </div>
      </section>
    </div>
  ),
};

export const Графики: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-16">
      <section>
        <h3 className="text-title-l text-ink mb-2">Выделение — по умолчанию</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Один столбец в цвете, остальные приглушены. У слайда одна мысль, и обычно она про один
          столбец. Раскрасить все — значит похоронить ту величину, ради которой график и сделан.
        </p>
        <BarChart data={REVENUE} formatValue={(v) => `${v} млн`} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Категории</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Когда столбцы это разные сущности и сравниваются между собой.
        </p>
        <BarChart
          data={[
            { label: "Прямые", value: 38 },
            { label: "Партнёры", value: 52 },
            { label: "Реклама", value: 24 },
            { label: "Органика", value: 61 },
          ]}
          mode="series"
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Форма роста</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Это НЕ график: у полосок нет ни оси, ни подписей, высоты заданы в процентах от максимума.
          Они показывают форму и стоят рядом с крупным числом, которое и есть содержание. Если у
          значений есть числа — ставить график, а не это.
        </p>
        <div className="bg-surface-muted rounded-card max-w-[820px] p-10">
          <p className="text-display-s text-ink tabular-nums">2,4 млн</p>
          <p className="text-body-l text-ink-secondary mt-2">просмотров за 90 дней</p>
          <div className="mt-8">
            <GrowthBars values={[22, 34, 28, 46, 58, 52, 74, 68, 90, 84, 100, 96]} />
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Плитки с числами</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Признак «рост» задаётся отдельно, а не выводится из знака: зелёная стрелка вверх у «было 4
          часа» врала бы — там время упало, и это хорошо.
        </p>
        <StatTiles
          columns={4}
          items={[
            { value: "2,4 млн", label: "просмотров за 90 дней" },
            { value: "38 400", label: "подписчиков", delta: "+12 300 за квартал", up: true },
            { value: "124", label: "ролика", delta: "за 4 месяца" },
            { value: "6 мин", label: "на ролик", delta: "было 4 часа" },
          ]}
        />
      </section>
    </div>
  ),
};

export const Медиа: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-16">
      <section>
        <h3 className="text-title-l text-ink mb-2">Лента обложек</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          В отличие от мобильной версии прокрутки НЕТ: слайд не прокручивают, и то, что не
          поместилось, в PDF просто отрезано. Поэтому ширина обложки считается от числа элементов, а
          не задаётся константой.
        </p>
        <MediaStrip
          available={1680}
          items={[
            { id: "e1", title: "Разбор кейса", meta: "412 тыс. просмотров" },
            { id: "e2", title: "Один инструмент", meta: "180 тыс." },
            { id: "e3", title: "Ошибка новичка", meta: "96 тыс." },
            { id: "e4", title: "За 60 секунд", meta: "1,1 млн" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Рамка телефона</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Полоска острова обязательна: без неё рамка читается просто скруглённым прямоугольником.
          Внутренний радиус равен внешнему минус толщина рамки.
        </p>
        <div className="flex gap-10">
          <PhoneFrame />
          <PhoneFrame />
          <PhoneFrame />
        </div>
      </section>
    </div>
  ),
};

export const Призыв: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <DarkCTA
        cards={[
          { id: "site", label: "Презентация", accent: "#0088ff", Icon: Monitor },
          { id: "app", label: "Дизайн-система", accent: "#5856d6", Icon: Smartphone },
          { id: "custom", label: "Шаблоны", accent: "#008575", Icon: MagicStick },
        ]}
        title="Работаем вместе"
        description="Занимайтесь бизнесом, а мы сделаем так, чтобы каждая презентация выглядела одинаково хорошо."
        accentPhrase="10+ лет опыта"
        action={<Button size="m">Узнать условия</Button>}
      />
    </div>
  ),
};

export const БраузернаяРамка: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">BrowserFrame</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Снимок чужого сайта без обрамления читается как иллюстрация неизвестного происхождения:
        непонятно, макет это, коллаж или действительно страница конкурента. Рамка с адресом и датой
        съёмки отвечает на вопрос «что это и откуда» до того, как его задали.
      </p>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Три кружка светофора сюда намеренно не перенесены: это чужой интерфейс, и рисовать его
        пришлось бы от руки. Вместо них глиф из набора Solar и адрес — форма всё равно опознаётся по
        строке адреса над содержимым. Кадр прижат к ВЕРХУ и обрезается снизу: снимок сделан в окне
        16:10 и целиком на слайд не помещается, а первый экран и есть предмет разбора.
      </p>

      <div className="grid grid-cols-2 gap-6">
        {SHOTS.map((s) => (
          <figure key={s.id}>
            <BrowserFrame src={s.src} url={s.url} alt={s.alt} note={SHOT_DATE} height={300} />
            <FrameCaption>{s.caption}</FrameCaption>
          </figure>
        ))}
      </div>
    </div>
  ),
};
