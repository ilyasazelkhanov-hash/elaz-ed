import type { Meta, StoryObj } from "@storybook/react-vite";
import {
  Bolt,
  ChatRoundDots,
  ClockCircle,
  Gallery,
  Layers,
  MagicStick3,
  Palette,
  Soundwave,
  Star,
  Videocamera,
  Widget,
} from "@solar-icons/react";
import IconSquare, { SQUARE } from "../../components/icons/IconSquare";
import IconStack from "../../components/icons/IconStack";
import GlyphGradient from "../../components/icons/GlyphGradient";
import BrandTile, { BrandFan } from "../../components/BrandTile";
import BrandMark from "../../components/BrandMark";
import { BRAND_PATHS } from "../../components/brandPaths";
import Folder from "../../blocks/Folder";

/**
 * Иконочная система, перенесённая из донорского мобильного проекта.
 *
 * GlyphGradient обязателен НА КАЖДОМ слайде, где есть цветные квадраты:
 * он объявляет `<defs>` с градиентом заливки. Без него глифы теряют ход
 * по светлоте и выглядят плоскими наклейками.
 */

const meta = {
  title: "Блоки/Иконки",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const ACCENTS = ["#0088ff", "#ff8d28", "#5856d6", "#34c759", "#af52de", "#008575"];

export const Квадраты: Story = {
  render: () => (
    <div className="flex flex-col gap-14">
      <GlyphGradient />

      <section>
        <h3 className="text-title-l text-ink mb-6">Цветные — вес Bold</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          На цветной заливке линейные глифы рассыпаются, поэтому вес Bold. Заливка глифа
          градиентная: сверху чистый белый, книзу уходит в полупрозрачный, сквозь который
          просвечивает цвет плитки.
        </p>
        <div className="flex gap-8">
          {[MagicStick3, Palette, Gallery, Star, Bolt, Layers].map((Icon, i) => (
            <IconSquare key={i} Icon={Icon} accent={ACCENTS[i]} ring="var(--t-canvas)" />
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-6">Нейтральные — вес Linear</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Без акцента квадрат берёт цвет поверхности, глиф — цвет текста темы. Контур у него СВОЙ,
          цветом линии: в доноре белый квадрат лежал на серой подложке и читался за счёт разницы с
          ней, а на белом слайде без контура пропадал целиком — оставался висеть один глиф без
          носителя. Третьего веса в системе нет: смесь весов в одном ряду читается как иконки из
          разных наборов.
        </p>
        <div className="flex gap-8">
          {[MagicStick3, Palette, Gallery, Star, Bolt, Layers].map((Icon, i) => (
            <IconSquare key={i} Icon={Icon} ring="var(--t-canvas)" />
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-6">Внутренние детали</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          У части иконок Solar деталь нарисована отдельным путём тем же цветом, что и тело — поверх
          тела она невидима. Слева ClockCircle без поправки: часы превращаются в пустой кружок.
          Справа ChatRoundDots с поправкой — точки видны как прорезь в глифе.
        </p>
        <div className="flex items-center gap-8">
          <IconSquare Icon={ClockCircle} accent="#0088ff" ring="var(--t-canvas)" />
          <IconSquare Icon={ChatRoundDots} accent="#34c759" ring="var(--t-canvas)" />
          <IconSquare Icon={Widget} accent="#af52de" ring="var(--t-canvas)" />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-6">Круги и размеры</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Круг задаётся явно как половина стороны, а НЕ значением 999: такого значения в системе
          нет, а капсульные 400 при стороне больше 400 перестали бы давать круг.
        </p>
        <div className="flex items-center gap-8">
          {[44, 56, 88, 120].map((size) => (
            <IconSquare
              key={size}
              Icon={Soundwave}
              accent="#ff8d28"
              size={size}
              glyph={Math.round(size * 0.45)}
              radius={size / 2}
              ring="var(--t-canvas)"
            />
          ))}
        </div>
      </section>
    </div>
  ),
};

export const Стопки: Story = {
  render: () => (
    <div className="flex flex-col gap-14">
      <GlyphGradient />

      <section>
        <h3 className="text-title-l text-ink mb-6">Три образца одним объектом</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Заход посчитан, а не подобран: при стороне {SQUARE.box}, глифе {SQUARE.glyph} и кольце{" "}
          {SQUARE.ring} потолок захода 19px, взято {SQUARE.overlap} — запас покрывает выступ
          повёрнутого среднего квадрата. Наклонён только средний: наклонить крайние — получится
          веер, а он занят другим приёмом.
        </p>
        <div className="flex gap-16">
          <IconStack>
            {[ChatRoundDots, MagicStick3, Bolt].map((Icon, i) => (
              <IconSquare
                key={i}
                Icon={Icon}
                accent="#0088ff"
                tilt={i === 1 ? SQUARE.tilt : 0}
                ring="var(--t-canvas)"
              />
            ))}
          </IconStack>

          <IconStack>
            {[Gallery, Videocamera, Soundwave].map((Icon, i) => (
              <IconSquare
                key={i}
                Icon={Icon}
                accent="#5856d6"
                tilt={i === 1 ? SQUARE.tilt : 0}
                ring="var(--t-canvas)"
              />
            ))}
          </IconStack>
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-6">Логотипы в квадратах</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Знак бренда получает тот же градиент, что и иконки интерфейса. Раньше он заливался
          сплошным белым — чтобы «не раскрашивать марку», — и рядом с иконками выглядел плоской
          наклейкой на объёмной плитке. Градиент не меняет ни цвет знака, ни форму.
        </p>
        <IconStack>
          {(["claude", "openai", "googlegemini", "cursor"] as const).map((brand, i) => (
            <IconSquare
              key={brand}
              path={BRAND_PATHS[brand]}
              accent={["#d97757", "#0088ff", "#af52de", "#434242"][i]}
              radius={SQUARE.box / 2}
              ring="var(--t-canvas)"
            />
          ))}
        </IconStack>
      </section>
    </div>
  ),
};

export const Бренды: Story = {
  render: () => (
    <div className="flex flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-6">Голый знак</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Монохром, а не фирменные цвета. Шесть знаков из шестнадцати фирменно почти чёрные, и ряд,
          где половина цветная, а половина нет, разваливает строй.
        </p>
        <div className="flex items-center gap-12">
          {(["figma", "react", "typescript", "claude", "github", "vercel"] as const).map((b) => (
            <BrandMark key={b} brand={b} size={64} tone="ink" />
          ))}
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-6">Плитка и веер</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Цвет глифа по правилу: белый везде, где даёт хотя бы 3:1 — порог WCAG для нетекстовой
          графики. У react #61DAFB белый даёт 1.62:1, поэтому там глиф тёмный. Выбор «что
          контрастнее» был бы неверен: он давал бы чёрный мяч Dribbble, хотя у самого Dribbble он
          белый.
        </p>
        <div className="flex items-center gap-12">
          {(["dribbble", "figma", "react", "cloudflare", "docker"] as const).map((b) => (
            <BrandTile key={b} brand={b} size={96} />
          ))}
          <BrandFan brands={["figma", "claude", "cursor"]} />
        </div>
      </section>
    </div>
  ),
};

export const Папка: Story = {
  render: () => (
    <div>
      <h3 className="text-title-l text-ink mb-6">Папка macOS</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Форма и цвета сняты попиксельно с системной иконки, а не нарисованы на глаз. Главная примета
        — плавный скос язычка, вертикальной ступеньки там нет. Передняя стенка ТЕМНЕЕ задней и
        светлеет книзу: обычно рисуют наоборот.
      </p>
      <div className="flex items-end gap-12">
        <Folder size={240} />
        <Folder size={240} depth={0.18}>
          <p className="text-title-m" style={{ color: "#ffffff" }}>
            Материалы
          </p>
          <p className="text-body-m" style={{ color: "rgba(255,255,255,0.78)" }}>
            24 файла
          </p>
        </Folder>
      </div>
    </div>
  ),
};
