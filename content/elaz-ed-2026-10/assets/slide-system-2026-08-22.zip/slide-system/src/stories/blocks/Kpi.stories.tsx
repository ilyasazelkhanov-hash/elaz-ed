import type { Meta, StoryObj } from "@storybook/react-vite";
import { Bag, Box, ChatRoundDots, ClockCircle, UsersGroupRounded } from "@solar-icons/react";
import { KpiRow } from "../../blocks/kpi";

/**
 * Полоса показателей — перенос ряда KPI-карточек с админского дашборда
 * донорский админский дашборд.
 *
 * Блок отвечает на вопрос, на который StatTiles отвечает плохо: «что из
 * четырёх показателей просело». У StatTiles признак изменения двоичный
 * (`up?: boolean`), поэтому падение и отсутствие изменения выглядят там
 * одинаково. Здесь состояний три, и ноль показан нейтрально: ноль не
 * является ростом.
 *
 * Данные здесь демонстрационные и намеренно НЕ совпадают с числами деков:
 * витрина показывает поведение блока, а не содержание презентации.
 * Совпадающие числа рано или поздно начинают жить своей жизнью и
 * расходятся с data/*.
 */

const meta = {
  title: "Блоки/Ряд показателей",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Полоса: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Четыре показателя — штатная раскладка</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Полоса стоит под шапкой слайда и занимает 250px из 604 доступных (замер в 1:1), поэтому
          под ней остаётся место для основного блока. Число набрано headline-l (56) — вровень с
          заголовком слайда, а не крупнее него: полоса это состояние дел, а не сообщение слайда.
          Иконка сверху — опознавательный знак: нужный показатель находят по ней и по подписи, а
          потом читают число.
        </p>
        <KpiRow
          items={[
            {
              Icon: UsersGroupRounded,
              label: "Клиенты",
              value: "9 418",
              change: "+6,2%",
              trend: "up",
            },
            { Icon: Bag, label: "Заказы", value: "1 207", change: "+11,4%", trend: "up" },
            { Icon: Box, label: "Отгружено", value: "863", change: "−3,7%", trend: "down" },
            { Icon: ChatRoundDots, label: "Обращения", value: "274", change: "0,00%" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Три показателя</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Число колонок берётся из числа элементов, отдельного пропа нет: полоса — это один ряд, и
          возможность разложить её в две строки означала бы, что это уже не полоса. При трёх
          элементах карточка становится 544px вместо 402 — числу и плашке просторнее, но кегль не
          меняется, иначе слайды одной презентации перестали бы выглядеть одной системой.
        </p>
        <KpiRow
          items={[
            {
              Icon: UsersGroupRounded,
              label: "Активные аккаунты",
              value: "3 502",
              change: "+4,1%",
              trend: "up",
            },
            {
              Icon: ClockCircle,
              label: "Среднее время ответа",
              value: "2 ч 14 м",
              change: "−18,0%",
              trend: "up",
            },
            {
              Icon: ChatRoundDots,
              label: "Повторные обращения",
              value: "119",
              change: "+9,3%",
              trend: "down",
            },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Два показателя</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Нижняя граница раскладки. Один показатель полосой не бывает — это плитка со Stat, а не
          ряд, поэтому колонок всегда минимум две.
        </p>
        <KpiRow
          items={[
            { Icon: Bag, label: "Оплаченные заказы", value: "612", change: "+2,8%", trend: "up" },
            { Icon: Box, label: "Возвраты", value: "37", change: "+21,6%", trend: "down" },
          ]}
        />
      </section>
    </div>
  ),
};

export const Состояния: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Рост, убыль и ноль рядом</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Три состояния плашки. Ноль — серый и БЕЗ стрелки: стрелка это направление, а у «без
          изменений» направления нет. Тон задаётся явно, а не выводится из знака числа: «−18,0%» у
          времени ответа это падение по знаку и рост по смыслу, и зелёная плашка там честнее
          красной. Забытый тон даёт серую плашку, а не ложный зелёный.
        </p>
        <KpiRow
          items={[
            {
              Icon: UsersGroupRounded,
              label: "Рост",
              value: "4 260",
              change: "+14,8%",
              trend: "up",
            },
            { Icon: Box, label: "Убыль", value: "1 905", change: "−7,2%", trend: "down" },
            {
              Icon: ChatRoundDots,
              label: "Без изменений",
              value: "708",
              change: "0,00%",
              trend: "flat",
            },
            { Icon: Bag, label: "Изменение не указано", value: "152" },
          ]}
        />

        <p className="text-body-m text-ink-secondary mt-10 max-w-4xl">
          Контраст этих трёх плашек замерен, а не оценён на глаз. Плашка лежит НА карточке, поэтому
          считается композит «заливка плашки поверх карточки», а не цвет на холсте. Карточка полосы
          — bg-surface, а не привычная приглушённая подложка, и это следствие замера: на
          приглушённой нейтральная плашка даёт 4,38:1 в светлой теме, а красная — 4,47:1 в тёмной,
          обе ниже порога 4,5. На bg-surface худшая из шести пар — 4,59:1. Обе темы проверять
          обязательно: провалы у пар в разных темах.
        </p>
      </section>
    </div>
  ),
};

export const КрайниеЗначения: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Длинная подпись не роняет ряд чисел</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Подпись во вторую строку есть только у одной карточки. Карточки в ряду тянутся по самой
          высокой, и без специальной меры число под длинной подписью уехало бы вниз — ряд чисел
          читался бы как ошибка вёрстки. Лишняя высота уходит в подпись (flex-1), а строка со
          значением остаётся прижатой к низу карточки. Замер в 1:1: карточка выросла с 250 до 278px,
          но у всех четырёх число стоит на 185px от верха и на 33px от низа — ряд не поехал. У
          обращений падение помечено зелёным намеренно: тон задаёт смысл, а не знак, и меньше
          обращений — это хорошо.
        </p>
        <KpiRow
          items={[
            {
              Icon: UsersGroupRounded,
              label: "Клиенты",
              value: "7 043",
              change: "+5,5%",
              trend: "up",
            },
            {
              Icon: ChatRoundDots,
              label: "Обращения в поддержку за отчётный период",
              value: "512",
              change: "−9,1%",
              trend: "up",
            },
            { Icon: Bag, label: "Заказы", value: "1 388", change: "0,00%" },
            { Icon: Box, label: "Возвраты", value: "44", change: "+1,2%", trend: "down" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Шестизначное число</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Худший случай по ширине: шесть знаков с разрядным пробелом плюс плашка на карточке 402px.
          Замер в 1:1: число 210,56 + плашка 107,59 + просвет 12 при рабочей ширине 338 — остаётся
          5,84px. Помещается, но это и есть потолок, поэтому у строки стоит перенос: плашка уйдёт
          под число, если места действительно не хватит. Перенос портит ритм, но он виден, а вылет
          за карточку в PDF просто обрезается. Числа набраны tabular-nums — иначе разряды в соседних
          карточках стояли бы на разной ширине.
        </p>
        <KpiRow
          items={[
            {
              Icon: UsersGroupRounded,
              label: "Показы",
              value: "184 260",
              change: "+8,4%",
              trend: "up",
            },
            { Icon: Bag, label: "Клики", value: "26 915", change: "+12,7%", trend: "up" },
            { Icon: Box, label: "Заказы", value: "3 074", change: "−2,4%", trend: "down" },
            { Icon: ClockCircle, label: "Время на странице", value: "1 м 06 с", change: "0,00%" },
          ]}
        />
      </section>
    </div>
  ),
};
