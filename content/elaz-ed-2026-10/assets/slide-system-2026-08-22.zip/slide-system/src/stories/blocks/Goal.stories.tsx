import type { Meta, StoryObj } from "@storybook/react-vite";
import { GoalBars, ScoreBreakdown, goalBarsHeight, scoreBreakdownHeight } from "../../blocks/goal";

/**
 * Сравнение с нормой.
 *
 * Два блока одного файла отвечают на один вопрос — «дотянули ли», — и
 * различаются тем, где живёт норма:
 *
 *   GoalBars       одна норма на много замеров: цель одна, дней семь
 *   ScoreBreakdown много норм на один замер: у каждого слагаемого свой потолок
 *
 * Данные здесь демонстрационные и намеренно НЕ совпадают с числами деков:
 * витрина показывает поведение блока, а не содержание презентации.
 * Совпадающие числа рано или поздно начинают жить своей жизнью и
 * расходятся с data/*.
 *
 * Крайние случаи вынесены в отдельные истории и подписаны: они и есть
 * основная работа витрины. Блок, который проверяли только на удобных
 * данных, ломается на первом же клиентском слайде.
 */

const meta = {
  title: "Блоки/Цель и оценка",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const ЦельПоДням: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">GoalBars — столбики с отметкой цели</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Блок сообщает два факта, а не один. Величины показал бы и обычный BarChart; второй факт —
        сколько раз норма взята — в столбиках без линии не читается вовсе, поэтому итоговая строка
        под графиком не опция. Число в ней считается из данных, а не принимается пропсом: принятое
        пропсом разошлось бы с данными молча. Высота блока при значениях по умолчанию —{" "}
        {goalBarsHeight()} при доступных 604.
      </p>
      <GoalBars
        value="8 420"
        caption="заявок в среднем за день"
        period="7–13 июля"
        goal={9000}
        goalLabel="Цель 9 000 заявок"
        data={[
          { label: "Пн", value: 9240 },
          { label: "Вт", value: 7980 },
          { label: "Ср", value: 10410 },
          { label: "Чт", value: 8150 },
          { label: "Пт", value: 9020 },
          { label: "Сб", value: 12300 },
          { label: "Вс", value: 6740 },
        ]}
      />
    </div>
  ),
};

export const ЦельБезШапки: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Тот же блок без крупного числа</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Когда крупное число уже стоит в заголовке слайда, шапка блока его дублирует. Без неё обвязка
        короче на 148 точек, и полю столбиков достаётся до 442 — здесь взято 360. Проверка заодно
        показывает, что блок не разваливается без необязательных частей: высота{" "}
        {goalBarsHeight(360, { head: false })}.
      </p>
      <GoalBars
        height={360}
        goal={92}
        goalLabel="Норма 92%"
        formatValue={(v) => `${v}%`.replace(".", ",")}
        data={[
          { label: "Январь", value: 88 },
          { label: "Февраль", value: 91 },
          { label: "Март", value: 94 },
          { label: "Апрель", value: 96 },
          { label: "Май", value: 93 },
          { label: "Июнь", value: 97 },
        ]}
      />
    </div>
  ),
};

export const ЦельКрайниеСлучаи: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Минимум: цель не взята ни разу, есть ноль</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Итоговая строка меняет формулировку: «взята 0 раз» — это не по-русски, а «не взята ни
          разу» — вывод. Столбик со значением 40 при цели 3 000 занял бы долю в 3 точки и после
          округления пропал бы совсем; минимум в 2 точки не даёт превратить «мало» в «ничего».
          Настоящий ноль при этом остаётся пустым местом — пропуск в ряду это факт.
        </p>
        <GoalBars
          height={220}
          goal={3000}
          goalLabel="Цель 3 000"
          data={[
            { label: "Пн", value: 40 },
            { label: "Вт", value: 0 },
            { label: "Ср", value: 610 },
            { label: "Чт", value: 1240 },
            { label: "Пт", value: 980 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Потолок: цель взята каждый раз</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Все столбики акцентные, линия цели лежит низко — и это правильный рисунок: он сообщает
          «норма пройдена с запасом», а не «график сломан». Запас шкалы 12% над самым высоким
          объектом оставляет линии место, чтобы не слиться с верхней кромкой поля.
        </p>
        <GoalBars
          height={220}
          goal={1200}
          goalLabel="Цель 1 200"
          data={[
            { label: "I кв", value: 1840 },
            { label: "II кв", value: 2110 },
            { label: "III кв", value: 1990 },
            { label: "IV кв", value: 2460 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Опасный случай: цель — это потолок</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          При <code>lowerIsBetter</code> взяты те дни, где значение НИЖЕ нормы. Ровно поэтому взятый
          столбик акцентный, а не зелёный: зелёным пришлось бы красить короткие столбики в блоке про
          инциденты, то есть раскрашивать вывод, а не данные. Направление задано признаком, а не
          выводится из чисел — вывести его из данных невозможно.
        </p>
        <GoalBars
          height={220}
          goal={3}
          lowerIsBetter
          goalLabel="Не больше 3 инцидентов"
          value="21"
          caption="инцидент за неделю"
          period="Дежурство"
          data={[
            { label: "Пн", value: 2 },
            { label: "Вт", value: 5 },
            { label: "Ср", value: 1 },
            { label: "Чт", value: 0 },
            { label: "Пт", value: 8 },
            { label: "Сб", value: 3 },
            { label: "Вс", value: 2 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи и двенадцать столбиков</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Двенадцать — рабочий потолок: тринадцатый даёт колонку около 110 точек, и значение на
          кегле 26 начинает переноситься. Подпись столбика набирается в одну строку; высота строк
          задана как пол, а не жёстко, поэтому перенос делает блок выше, а не кладёт текст поверх
          итоговой строки. Дефект, который видно замером высоты, дешевле спрятанного.
        </p>
        <GoalBars
          height={240}
          goal={140}
          goalLabel="Цель — 140 отгрузок в неделю"
          goalLabelWidth={260}
          data={[
            { label: "нед. 1", value: 118 },
            { label: "нед. 2", value: 132 },
            { label: "нед. 3", value: 147 },
            { label: "нед. 4", value: 151 },
            { label: "нед. 5", value: 139 },
            { label: "нед. 6", value: 162 },
            { label: "нед. 7", value: 144 },
            { label: "нед. 8", value: 128 },
            { label: "нед. 9", value: 155 },
            { label: "нед. 10", value: 149 },
            { label: "нед. 11", value: 173 },
            { label: "нед. 12", value: 168 },
          ]}
        />
      </section>
    </div>
  ),
};

export const ОценкаСоСлагаемыми: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">ScoreBreakdown — оценка и её слагаемые</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Дорожка слагаемого получает ширину, пропорциональную его потолку, а не равную соседним.
        Тогда один потерянный балл выглядит одинаково длинным в любой строке, и хвост дорожки
        читается прямо как «сколько здесь потеряно» — без процентов и без арифметики. У донора
        дорожки одинаковые, и 98%, 97% и 100% в длине неразличимы. Сама оценка считается суммой
        слагаемых: принятая пропсом, она разошлась бы с ними молча. Высота блока —{" "}
        {scoreBreakdownHeight(3)}.
      </p>
      <ScoreBreakdown
        verdict={{ label: "Отлично", tone: "good" }}
        caption="Оценка качества обслуживания за июль"
        parts={[
          { label: "Скорость ответа", points: 49, ceiling: 50 },
          { label: "Полнота решения", points: 29, ceiling: 30 },
          { label: "Повторные обращения", points: 20, ceiling: 20 },
        ]}
      />
    </div>
  ),
};

export const ОценкаКрайниеСлучаи: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Потолок: набрано всё</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Все дорожки залиты целиком, хвостов нет. Разная длина дорожек при этом сохраняется — она
          кодирует цену критерия, а не результат, и выравнивать её нельзя: одинаковые полосы сказали
          бы, что все три критерия стоят одинаково.
        </p>
        <ScoreBreakdown
          verdict={{ label: "Максимум", tone: "good" }}
          parts={[
            { label: "Документы", points: 40, ceiling: 40 },
            { label: "Сроки", points: 35, ceiling: 35 },
            { label: "Приёмка", points: 25, ceiling: 25 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Опасный случай: провал в одном слагаемом</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Ровно то, ради чего блок и заведён. Оценка 41 из 100 сама по себе не говорит, что делать;
          рисунок говорит: два балла потеряно на сроках, а весь критерий приёмки не набран вообще.
          При нулевом слагаемом заливка не рисуется совсем — элемент нулевой ширины в замерах
          неотличим от ошибки вёрстки, а нулевых размеров в этом проекте ищут именно её. Слово
          вердикта задаёт автор: границы полос — знание методики, и выводить «провал» из процента
          значило бы придумать шкалу за неё.
        </p>
        <ScoreBreakdown
          verdict={{ label: "Есть провал", tone: "bad" }}
          caption="Готовность площадки к запуску"
          parts={[
            { label: "Документы", points: 12, ceiling: 50, note: "не хватает актов на 38 баллов" },
            { label: "Сроки", points: 29, ceiling: 30, note: "отставание на два дня" },
            { label: "Приёмка", points: 0, ceiling: 20, note: "не проводилась" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Средняя полоса и длинные подписи</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Жёлтая ступень вердикта — единственное, чем этот набор тонов отличается от пилюли
          изменения в MetricPanel: у изменения середины нет по существу, у оценки она содержательна.
          Пояснение поднимает строку слагаемого с 32 точек до 64, поэтому пять слагаемых с
          пояснениями в бюджет 604 ещё помещаются ({scoreBreakdownHeight(5, { notes: true })}), а
          шесть — уже нет ({scoreBreakdownHeight(6, { notes: true })}). Название, не влезшее в свою
          колонку, переносится и поднимает строку ещё на строку — здесь это видно на первом
          слагаемом.
        </p>
        <ScoreBreakdown
          verdict={{ label: "Приемлемо, с оговорками", tone: "mid" }}
          labelWidth={620}
          parts={[
            {
              label: "Соответствие требованиям информационной безопасности",
              points: 33,
              ceiling: 45,
              note: "не закрыты два пункта регламента доступа",
            },
            {
              label: "Отказоустойчивость и план восстановления",
              points: 27,
              ceiling: 35,
              note: "учения по восстановлению не проводились",
            },
            {
              label: "Обучение сотрудников",
              points: 18,
              ceiling: 20,
              note: "обучены 46 из 50",
            },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Минимум: одно слагаемое и один балл</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Одна строка — вырожденный случай: слагаемых нет, и блок сводится к «набрано столько из
          такого-то». Показан ради проверки, что ширина дорожки при единственном потолке не
          схлопывается, а заливка в один балл из сорока остаётся видимой.
        </p>
        <ScoreBreakdown
          verdict={{ label: "Не пройдено", tone: "bad" }}
          parts={[{ label: "Итоговый чек-лист", points: 1, ceiling: 40 }]}
        />
      </section>
    </div>
  ),
};
