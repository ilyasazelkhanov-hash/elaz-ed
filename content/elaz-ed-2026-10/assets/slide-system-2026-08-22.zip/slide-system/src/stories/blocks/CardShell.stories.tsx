import type { Meta, StoryObj } from "@storybook/react-vite";
import CardShell, {
  CARD_BUDGET,
  LegendTiles,
  cardChartHeight,
  cardChartWidth,
  cardHeaderHeight,
} from "../../blocks/cards/shell";
import { BOARD_CHART, BOARD_SERIES } from "../../lib/boardPalette";

/**
 * Обвязка карточки донорского дашборда.
 *
 * Здесь показана ОБОЛОЧКА: шапка с числом и чипом, подпись периода, слот под
 * график, ряд плиток легенды. Сам график в слот ещё не приехал — на его
 * месте стоит замерочная заглушка, которая печатает свои фактические
 * размеры. Так видно, сколько места форма получит на самом деле, и высоту
 * не придётся подбирать.
 *
 * Числа во всех историях выдуманные — это витрина поведения, а не слайд дека.
 * Тексты взяты из спецификаций донора, чтобы длины строк были правдоподобны.
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`, 64 с каждой стороны), поэтому
 * карточка во всю ширину (1680) требует окна от 1808 точек. На узком окне
 * она вылезет за обёртку — это свойство витрины, а не блока: на слайде
 * 1680 встают ровно в поля.
 *
 * ⚠️ Обе темы проверяются тулбаром «Тема». Две истории внизу показывают
 * светлую и тёмную карточку РЯДОМ через вложенную тему — так расхождение
 * видно без переключения.
 */

const meta = {
  title: "Блоки/Карточка-дашборд",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── замерочная заглушка вместо графика ───────────── */

/**
 * Стоит в слоте графика и печатает свои РЕАЛЬНЫЕ размеры.
 *
 * Пунктирная рамка — не украшение: она показывает границу слота, а слот
 * это и есть предел, за которым содержимое обрезается.
 */
function ChartSlot({ note }: { note?: string }) {
  return (
    <div
      className="border-line text-body-m text-ink-secondary flex h-full w-full flex-col items-center justify-center gap-1 rounded-tile border border-dashed"
      ref={(el) => {
        if (!el || el.dataset.measured) return;
        el.dataset.measured = "1";
        const r = el.getBoundingClientRect();
        const out = el.querySelector("[data-size]");
        if (out) out.textContent = `${Math.round(r.width)} × ${Math.round(r.height)}`;
      }}
    >
      <span className="text-title-m text-ink tabular-nums" data-size>
        —
      </span>
      <span>слот графика, замер после отрисовки</span>
      {note ? <span className="text-ink-tertiary text-body-l">{note}</span> : null}
    </div>
  );
}

const AREA_LEGEND = [
  { label: "Organic", value: "50 500", color: BOARD_SERIES[BOARD_CHART.lime] },
  { label: "Referral", value: "25 900", color: BOARD_SERIES[BOARD_CHART.blue] },
  { label: "Paid", value: "18 300", color: BOARD_SERIES[BOARD_CHART.purple] },
];

const FUNNEL_LEGEND = [
  { label: "Link opened", value: "197", color: BOARD_SERIES[BOARD_CHART.lime] },
  { label: "Started", value: "110", color: BOARD_SERIES[BOARD_CHART.blue] },
  { label: "Completed", value: "77", color: BOARD_SERIES[BOARD_CHART.purple] },
  { label: "Converted", value: "38", color: BOARD_SERIES[BOARD_CHART.pink] },
];

/* ───────────── истории ───────────── */

/** Полный набор: подпись, число, чип, период-плашка, три плитки легенды */
export const Карточка: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Шапка {cardHeaderHeight("m")}, легенда 100, два просвета по 24, поля по 36. Графику остаётся{" "}
        {cardChartHeight()} при ширине {cardChartWidth(1680)} — это{" "}
        {(cardChartWidth(1680) / cardChartHeight()).toFixed(2)}:1 против донорских 2.78:1. Лента
        вдвое площе оригинала; для линий и столбиков честнее половинная ширина, см. следующую
        историю.
      </p>
      <CardShell
        label="Visitors"
        value="94 700"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        legend={AREA_LEGEND}
      >
        <ChartSlot />
      </CardShell>
    </div>
  ),
};

/** Две карточки в колонку — пропорции донора воспроизводятся именно так */
export const ПараВПоловинуШирины: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Две по 828 — ближе к оригиналу</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        828 = шесть колонок по 118 плюс пять желобов по 24. Поле графика{" "}
        {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half" })}, то есть{" "}
        {(cardChartWidth(828, "half") / cardChartHeight({ size: "half" })).toFixed(2)}:1 — донор
        даёт 2.78:1. Поля тоньше (20 вместо 36), радиус на ступень меньше (`rounded-panel` 32 вместо
        `rounded-hero` 48), концентричность сохраняется: 32 − 20 = 12, как и 48 − 36.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <CardShell
            size="half"
            label="Sessions · Conversion 3,7%"
            value="83 200"
            delta={{ label: "+9,4%", direction: "up" }}
            period={{ label: "This year" }}
            legend={[
              { label: "Sessions · итого", value: "83 200", color: BOARD_SERIES[BOARD_CHART.lime] },
              {
                label: "Конверсия · среднее",
                value: "3,7%",
                color: BOARD_SERIES[BOARD_CHART.blue],
              },
            ]}
          >
            <ChartSlot />
          </CardShell>
        </div>
        <div className="w-[828px]">
          <CardShell
            size="half"
            label="Sign-up funnel"
            value="197"
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            legend={FUNNEL_LEGEND}
          >
            <ChartSlot />
          </CardShell>
        </div>
      </div>
    </div>
  ),
};

/** Вторая форма периода: ряд слов вместо сегмент-контрола */
export const ПериодРядомСлов: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">«Weekly / Monthly / Yearly» как подпись</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        У донора это сегмент-контрол с дорожкой и бегунком-таблеткой. Дорожка и подложка убраны:
        именно они делают ряд слов похожим на три кнопки, а нажать в PDF нельзя ни одну. Выбранное —
        основным цветом, остальные — вторичным; тот же приём есть и у самого донора в карточке
        контрибуций. Число здесь `display-s` 72, поэтому шапка выше на 16: {cardHeaderHeight("l")}{" "}
        против {cardHeaderHeight("m")}, а графику остаётся{" "}
        {cardChartHeight({ valueSize: "l", legend: false })} — легенды у этой карточки нет.
      </p>
      <CardShell
        label="Earned so far"
        value="$7 462"
        valueSize="l"
        delta={{ label: "+14,8%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
      >
        <ChartSlot note="легенды нет — слот выше на 124" />
      </CardShell>
    </div>
  ),
};

/** Крайние случаи шапки: длинная подпись, минус, без чипа, без периода */
export const КрайниеСлучаиШапки: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Длинная подпись и длинное число</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Подпись обрезается многоточием, а не переносится: перенос увеличил бы шапку, и график
          уехал бы за бюджет. Число тоже обрезается — но это сигнал, что число не помещается, и
          лечится оно сокращением («1,24 млн»), а не мелким кеглем. Карточка здесь половинная: во
          всю ширину эта же подпись помещается целиком (замер: 848 точек хода строки при 848
          доступных), и обрезка бы не наступила.
        </p>
        <div className="w-[828px]">
          <CardShell
            size="half"
            label="Средний чек в разрезе каналов привлечения за вычетом возвратов и скидок"
            value="1 284 950 900"
            delta={{ label: "−1,8%", direction: "down" }}
            period={{ label: "Последние 90 дней" }}
            height={400}
          >
            <ChartSlot />
          </CardShell>
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Отрицательное изменение</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Цвет плашки задаёт `direction`, а не знак в тексте: подпись может быть «−1,8%», «минус
          треть» или «ниже плана». Красная заливка — роль `error-fill`, текст — `error-fg` (4,70:1 в
          светлой, 4,62:1 в тёмной).
        </p>
        <CardShell
          label="Checkout"
          value="41 800"
          delta={{ label: "−1,8%", direction: "down" }}
          period={{ label: "Last 7 days" }}
          height={400}
        >
          <ChartSlot />
        </CardShell>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Без чипа и без периода</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Оба слота необязательны. Высота шапки при этом не меняется — она считается от кегля числа,
          а не от того, что в неё положили: карточки в одном ряду обязаны иметь одну вертикаль,
          иначе их графики начнутся на разной высоте.
        </p>
        <CardShell label="Active users" value="1 892" height={400}>
          <ChartSlot />
        </CardShell>
      </div>
    </div>
  ),
};

/** Легенда отдельно: 2, 3 и 4 плитки, длинные подписи */
export const Легенда: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-8">
      <div>
        <h3 className="text-title-l text-ink mb-2">Колонки равные при любом числе плиток</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Квадратик указывает на ряд, но величину несёт напечатанное значение: краски донора в
          светлой теме порог 3:1 не берут (салат на белой карточке — 1,53:1, на приглушённой
          подложке — 1,35:1). Поэтому убирать подписи из легенды нельзя.
        </p>
      </div>
      <LegendTiles items={FUNNEL_LEGEND.slice(0, 2)} />
      <LegendTiles items={AREA_LEGEND} />
      <LegendTiles items={FUNNEL_LEGEND} />
      <LegendTiles
        items={[
          {
            label: "Органический трафик из поисковых систем",
            value: "50 500",
            color: BOARD_SERIES[BOARD_CHART.teal],
          },
          { label: "Переходы", value: "25 900", color: BOARD_SERIES[BOARD_CHART.yellow] },
          { label: "Платная реклама", value: "18 300", color: BOARD_SERIES[BOARD_CHART.pink] },
        ]}
      />
    </div>
  ),
};

/** Обе темы рядом — вложенной темой, без переключения тулбара */
export const ОбеТемы: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Светлая и тёмная карточка рядом</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Тема задана самой карточке, поэтому тулбар её не перебивает. Внутри переворачиваются все
        роли: подложка плитки уходит на ступень от карточки в свою сторону, заливка чипа меняет
        значение, волосяной контур квадратика из чёрного становится белым. Краски серий не меняются
        — у донора это краски, а не роли, и в тёмной теме они дают запас контраста втрое больше
        (4,83…12,22 против 1,43…3,14).
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <CardShell
            theme="light"
            size="half"
            height={480}
            label="Visitors"
            value="94 700"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "This year" }}
            legend={AREA_LEGEND}
          >
            <ChartSlot />
          </CardShell>
        </div>
        <div className="w-[828px]">
          <CardShell
            theme="dark"
            size="half"
            height={480}
            label="Visitors"
            value="94 700"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "This year" }}
            legend={AREA_LEGEND}
          >
            <ChartSlot />
          </CardShell>
        </div>
      </div>
    </div>
  ),
};

/** Бюджет высоты — числами, а не на глаз */
export const БюджетВысоты: Story = {
  render: () => {
    const rows = [
      { s: "full", v: "m", l: true, w: 1680 },
      { s: "full", v: "l", l: true, w: 1680 },
      { s: "full", v: "m", l: false, w: 1680 },
      { s: "half", v: "m", l: true, w: 828 },
      { s: "half", v: "l", l: true, w: 828 },
      { s: "half", v: "m", l: false, w: 828 },
    ] as const;

    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">Сколько остаётся графику при бюджете 604</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-4xl">
          Форма графика строится от этих чисел. Слот — `flex-1 min-h-0`: содержимое выше слота
          карточку не растянет, оно обрежется, а в PDF обрезанное пропадает без предупреждения.
        </p>
        <table className="text-body-l text-ink w-full tabular-nums">
          <thead className="text-body-m text-ink-secondary">
            <tr>
              {["размер", "число", "легенда", "шапка", "поле графика", "пропорция"].map((h) => (
                <th key={h} className="border-line border-b py-3 text-left font-normal">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const h = cardChartHeight({ size: r.s, valueSize: r.v, legend: r.l });
              const w = cardChartWidth(r.w, r.s);
              return (
                <tr key={`${r.s}-${r.v}-${r.l}`}>
                  <td className="border-line border-b py-3">
                    {r.s === "full" ? "во всю ширину 1680" : "половина 828"}
                  </td>
                  <td className="border-line border-b py-3">
                    {r.v === "l" ? "display-s 72" : "headline-l 56"}
                  </td>
                  <td className="border-line border-b py-3">{r.l ? "есть" : "нет"}</td>
                  <td className="border-line border-b py-3">{cardHeaderHeight(r.v)}</td>
                  <td className="border-line border-b py-3">
                    {w} × {h}
                  </td>
                  <td className="border-line border-b py-3">{(w / h).toFixed(2)}:1</td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="text-body-m text-ink-secondary mt-8 max-w-4xl">
          Донорское поле графика — 544 × 196, то есть 2.78:1. Ближе всего к нему половинная
          карточка; карточка во всю ширину даёт ленту вдвое площе, и линейные формы на ней теряют
          наклон.
        </p>
      </div>
    );
  },
};
