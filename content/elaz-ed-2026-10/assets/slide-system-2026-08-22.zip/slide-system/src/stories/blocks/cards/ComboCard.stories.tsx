import type { Meta, StoryObj } from "@storybook/react-vite";
import ComboCard, { type ComboPoint } from "../../../blocks/cards/comboCard";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Комбо: столбики по левой оси, линия по правой.
 *
 * ⚠️ Единственный блок системы с ДВУМЯ осями Y. Правило проекта их
 * запрещает («Двойная ось позволяет нарисовать любой вывод выбором
 * масштабов»); карточка перенесена по прямому решению заказчика, принятому
 * после возражения. Разбор — в шапке `src/blocks/cards/comboCard.tsx`,
 * показ обмана — в истории «Опасный случай» внизу.
 *
 * Данные во всех историях демонстрационные. Числа донорские по форме
 * («83 200», «3,7%», ось 0…10,5K и 0…6%), но ряд по месяцам собран здесь и
 * с числами деков намеренно не совпадает.
 *
 * === Про ширину обёртки ===
 *
 * Ширина карточки передаётся блоку ЧИСЛОМ (`width`), а не приходит от
 * контейнера: геометрия SVG считается заранее, чтобы в PDF ничего не
 * подгонялось резиновой вёрсткой. Поэтому обёртки историй — жёсткие
 * `w-[1680px]` и `w-[828px]`, а не `max-w-`: в узком окне честная
 * горизонтальная прокрутка лучше молча сжатого блока с «верными» замерами
 * в подписи.
 *
 * ⚠️ `npm run check` обходит слайды ДЕКОВ, а не витрину. Пока карточка не
 * поставлена в дек, переполнение здесь ловится замером в режиме 1:1, а не
 * скриптом.
 */

const meta = {
  title: "Карточки/Комбо",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Демонстрационные данные  ═══════════════ */

const МЕСЯЦЫ = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/**
 * Сессии и конверсия за год.
 *
 * Суммы проверены счётом, а не переписаны: сессии дают ровно 83 200
 * (максимум 10 400 → потолок левой оси 10,5K), ставки в среднем 3,72 →
 * «3,7%» (максимум 5,2 → потолок правой оси 6%). Обе подписи в шапке и в
 * плитках легенды сходятся с рядом, который нарисован.
 */
const СЕССИИ = [3900, 4400, 5000, 5600, 6100, 6600, 7200, 7600, 8300, 8900, 9200, 10400];
const СТАВКА = [2.4, 2.6, 2.9, 3.1, 3.3, 3.5, 3.8, 4.0, 4.3, 4.6, 4.9, 5.2];

const ГОД: ComboPoint[] = МЕСЯЦЫ.map((label, i) => ({
  label,
  bar: СЕССИИ[i],
  line: СТАВКА[i],
}));

/** Ряды в донорской формулировке: «Sessions · total», «Conversion · average» */
const СТОЛБИКИ = {
  label: "Sessions",
  tileLabel: "Sessions · total",
  tileValue: "83 200",
} as const;

const ЛИНИЯ = {
  label: "Conversion",
  tileLabel: "Conversion · average",
  tileValue: "3,7%",
  max: 6,
} as const;

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Как на скриншоте заказчика: подпись, крупное число, чип, период справа,
 * салатовые капсулы, синяя линия поверх них, две оси, две плитки легенды.
 *
 * Половинная ширина стоит первой не по красоте: поле графика здесь
 * 788 × 224 = 3.52:1 против донорских 544 × 196 = 2.78:1, а полная ширина
 * даёт 5.66:1 — ленту вдвое площе оригинала, на которой наклон линии
 * теряется. Для формы «столбики плюс линия» половина честнее.
 */
export const Карточка: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-2">Половина ширины — 828 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10">
        Слот графика {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half" })}; из него 36
        забирает строка месяцев, 24 — названия рядов над осями, 62 и 35 — жёлоба левой и правой оси.
        Поле построения по замеру в 1:1 — 691 × 244, то есть 2.83:1 против донорских 2.78:1.
      </p>
      <ComboCard
        size="half"
        width={828}
        label="Sessions · Conversion 3,7%"
        value="83 200"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "This year" }}
        data={ГОД}
        bar={СТОЛБИКИ}
        line={ЛИНИЯ}
      />
    </div>
  ),
};

/** Та же карточка во всю рабочую ширину — видно, во что превращается лента */
export const ВоВсюШирину: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Слот {cardChartWidth(1680)} × {cardChartHeight()}, поле построения по замеру 1511 × 212 —
        это 7.13:1 против донорских 2.78:1, лента втрое площе оригинала. Столбики стоят свободнее,
        но линия ложится почти горизонтально: тот же рост ставки читается слабее, чем на половинной
        карточке. Это искажение переноса, а не свойство данных.
      </p>
      <ComboCard
        width={1680}
        label="Sessions · Conversion 3,7%"
        value="83 200"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "This year" }}
        data={ГОД}
        bar={СТОЛБИКИ}
        line={ЛИНИЯ}
      />
    </div>
  ),
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Светлая и тёмная рядом через вложенную тему — расхождение видно без
 * переключения тулбара.
 *
 * ⚠️ Разница здесь не косметическая. Салат `#9ae600` на белой карточке даёт
 * 1.53:1 при пороге 3:1, на тёмной — 9.87:1. Столбики в светлой теме
 * держатся только подписями осей и плитками легенды; если карточка едет на
 * проектор, тёмная тема даёт запас в шесть раз.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1704px] gap-6">
      {(["light", "dark"] as const).map((theme) => (
        <div key={theme} className="w-[828px] shrink-0">
          <h3 className="text-title-l text-ink mb-2">
            {theme === "light" ? "светлая: салат 1.53:1" : "тёмная: салат 9.87:1"}
          </h3>
          <ComboCard
            theme={theme}
            size="half"
            width={828}
            label="Sessions · Conversion 3,7%"
            value="83 200"
            delta={{ label: "+9,4%", direction: "up" }}
            period={{ label: "This year" }}
            data={ГОД}
            bar={СТОЛБИКИ}
            line={ЛИНИЯ}
          />
        </div>
      ))}
    </div>
  ),
};

/* ═══════════════  Крайние случаи  ═══════════════ */

/**
 * Минимум данных: две точки.
 *
 * Проверяется ровно то, что ломается: линия из двух точек — это отрезок
 * (сплайн вырождается корректно, а не в петлю), а ширина столбика упирается
 * в потолок 72 и не расползается на треть поля.
 *
 * ⚠️ Смысловая оговорка, а не техническая: две точки — это не динамика.
 * Линия между двумя месяцами всегда прямая и всегда выглядит убедительно.
 */
export const МинимумДанных: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-10">Две точки: столбик упёрся в потолок 72</h3>
      <ComboCard
        size="half"
        width={828}
        label="Sessions · Conversion 4,1%"
        value="14 800"
        delta={{ label: "+2,1%", direction: "up" }}
        period={{ label: "Q1 → Q2" }}
        data={[
          { label: "Q1", bar: 6800, line: 3.4 },
          { label: "Q2", bar: 8000, line: 4.8 },
        ]}
        bar={{ label: "Sessions", tileLabel: "Sessions · total", tileValue: "14 800" }}
        line={{ label: "Conversion", tileLabel: "Conversion · average", tileValue: "4,1%" }}
      />
    </div>
  ),
};

/**
 * Потолок: 12 точек, миллионы слева, крупное число `display-s` 72 в шапке.
 *
 * Здесь проверяется жёлоб левой оси: он считается от самой длинной подписи
 * («1,5M» — 4 знака), а не задан числом, поэтому подпись не вылезает за
 * край SVG и не обрезается. И проверяется пол столбика: у февраля 4 000
 * при потолке 1,5M это 0.6px, рисуется 6px — «мало», но не «ничего».
 */
export const Потолок: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Миллионы слева, число display-s 72</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Шапка вырастает с {cardChartHeight()} до {cardChartHeight({ valueSize: "l" })} доступной
        графику высоты — 16 точек уходят под более крупное число.
      </p>
      <ComboCard
        width={1680}
        valueSize="l"
        label="Impressions · CTR 1,9%"
        value="8 214 500"
        delta={{ label: "+31,7%", direction: "up" }}
        period={{ label: "Monthly", segments: ["Weekly", "Monthly", "Yearly"] }}
        data={МЕСЯЦЫ.map((label, i) => ({
          label,
          bar: [
            420_000, 4000, 610_000, 720_000, 880_000, 940_000, 1_050_000, 1_180_000, 1_240_000,
            1_320_000, 1_410_000, 1_480_000,
          ][i],
          line: [0.9, 1.1, 1.4, 1.6, 1.7, 1.9, 2.1, 2.2, 2.4, 2.6, 2.8, 3.1][i],
        }))}
        bar={{ label: "Impressions", tileLabel: "Impressions · total", tileValue: "8 214 500" }}
        line={{ label: "CTR", tileLabel: "CTR · average", tileValue: "1,9%" }}
      />
    </div>
  ),
};

/**
 * Длинные подписи: месяцы словами, названия рядов длиннее жёлоба.
 *
 * Подписи по X ПРОРЕЖИВАЮТСЯ: если самая длинная не влезает в шаг, рисуется
 * каждая вторая. Пропущенная подпись читателя не обманывает — слипшаяся
 * каша обманывает. Названия рядов над осями режутся по половине ширины,
 * поэтому налезть друг на друга они не могут по построению.
 */
export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="w-[828px]">
      <h3 className="text-title-l text-ink mb-10">Месяцы словами: показана каждая вторая</h3>
      <ComboCard
        size="half"
        width={828}
        label="Уникальные посетители сайта и доля оформленных заказов"
        value="83 200"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "За календарный год" }}
        data={[
          "Январь",
          "Февраль",
          "Март",
          "Апрель",
          "Май",
          "Июнь",
          "Июль",
          "Август",
          "Сентябрь",
          "Октябрь",
          "Ноябрь",
          "Декабрь",
        ].map((label, i) => ({ label, bar: СЕССИИ[i], line: СТАВКА[i] }))}
        bar={{
          label: "Уникальные посетители сайта за календарный месяц",
          tileLabel: "Посетители · всего за год",
          tileValue: "83 200",
        }}
        line={{
          label: "Доля оформленных заказов от числа посетителей",
          tileLabel: "Конверсия · в среднем",
          tileValue: "3,7%",
          max: 6,
        }}
      />
    </div>
  ),
};

/* ═══════════════  Опасный случай  ═══════════════ */

const ПАДЕНИЕ: ComboPoint[] = [
  { label: "Jan", bar: 10200, line: 2.0 },
  { label: "Feb", bar: 9800, line: 2.2 },
  { label: "Mar", bar: 9400, line: 2.4 },
  { label: "Apr", bar: 9000, line: 2.6 },
  { label: "May", bar: 8600, line: 2.8 },
  { label: "Jun", bar: 8300, line: 3.0 },
  { label: "Jul", bar: 8000, line: 3.2 },
  { label: "Aug", bar: 7700, line: 3.4 },
  { label: "Sep", bar: 7400, line: 3.6 },
  { label: "Oct", bar: 7200, line: 3.7 },
  { label: "Nov", bar: 7000, line: 4.0 },
  { label: "Dec", bar: 6800, line: 4.2 },
];

/**
 * ⚠️ ГЛАВНАЯ ИСТОРИЯ ЭТОГО ФАЙЛА: две карточки, ОДНИ И ТЕ ЖЕ ЧИСЛА,
 * противоположные выводы. Отличается ровно один параметр — потолок правой
 * оси.
 *
 * Слева потолок 6%: линия ставки поднимается на две трети поля и в мае
 * пересекает падающие столбики. Читается «трафик просел, но конверсия его
 * перекрыла».
 *
 * Справа потолок 20%: та же линия лежит в нижней пятой части поля почти
 * горизонтально. Читается «трафик падает, конверсия стоит».
 *
 * Ни одно число не подменено, обе оси начинаются с нуля, обе подписаны —
 * и всё равно картинка говорит то, что выбрал автор. Это и есть цена
 * второй оси Y, и это причина, по которой правило проекта её запрещает.
 *
 * Что делать вместо: два отдельных графика по общей оси X, либо приведение
 * обоих рядов к общей базе («январь = 100»), либо линия как спарклайн без
 * собственной оси. Подробно — в шапке `comboCard.tsx`.
 */
export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="w-[1704px]">
      <h3 className="text-title-l text-ink mb-2">
        Одни и те же данные, два потолка правой оси, противоположные выводы
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Сессии падают с 10 200 до 6 800, ставка растёт с 2,0% до 4,2%. Слева правая ось 0…6%, справа
        0…20%. Больше не отличается ничего.
      </p>
      <div className="flex gap-6">
        {[
          { max: 6, verdict: "«Конверсия перекрыла падение трафика»" },
          { max: 20, verdict: "«Трафик падает, конверсия стоит»" },
        ].map((variant) => (
          <div key={variant.max} className="w-[828px] shrink-0">
            <p className="text-body-m text-ink-secondary mb-4">
              потолок {variant.max}% → {variant.verdict}
            </p>
            <ComboCard
              size="half"
              width={828}
              label="Sessions · Conversion 3,1%"
              value="99 400"
              delta={{ label: "−33,3%", direction: "down" }}
              period={{ label: "This year" }}
              data={ПАДЕНИЕ}
              bar={{ label: "Sessions", tileLabel: "Sessions · total", tileValue: "99 400" }}
              line={{
                label: "Conversion",
                tileLabel: "Conversion · average",
                tileValue: "3,1%",
                max: variant.max,
              }}
            />
          </div>
        ))}
      </div>
    </div>
  ),
};

/* ═══════════════  Как на слайде  ═══════════════ */

/**
 * Карточка в настоящем ContentSlide — проверка бюджета, а не проза.
 *
 * Шапка слайда (пилюля, заголовок в одну строку, лид) забирает 244, подвал
 * резервирует 56, блоку остаётся 604 — ровно `CARD_BUDGET`, и карточка
 * занимает его целиком, без воздуха снизу.
 *
 * ⚠️ Заголовок в ДВЕ строки съедает ещё 60, доступно становится 544, и
 * карточка высотой 604 обрежется снизу — вместе с плитками легенды, то
 * есть с единственным местом, где напечатаны итоги рядов. Заголовок этого
 * слайда держать в одну строку либо задавать `height={544}`.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Витрина"
      title="Конверсия растёт быстрее, чем набирается трафик"
      lead="Столбики — сессии за месяц по левой оси, линия — конверсия по правой"
      page={1}
      label="Витрина карточек"
    >
      <div className="flex h-full gap-6">
        <div className="w-[828px] shrink-0">
          <ComboCard
            size="half"
            width={828}
            label="Sessions · Conversion 3,7%"
            value="83 200"
            delta={{ label: "+9,4%", direction: "up" }}
            period={{ label: "This year" }}
            data={ГОД}
            bar={СТОЛБИКИ}
            line={ЛИНИЯ}
          />
        </div>
        <div className="w-[828px] shrink-0">
          <ComboCard
            size="half"
            width={828}
            label="Signups · Activation 41%"
            value="2 180"
            delta={{ label: "+4,8%", direction: "up" }}
            period={{ label: "This year" }}
            data={МЕСЯЦЫ.map((label, i) => ({
              label,
              bar: [110, 130, 145, 160, 175, 180, 195, 205, 215, 220, 215, 230][i],
              line: [28, 30, 33, 34, 36, 38, 40, 42, 45, 47, 49, 51][i],
            }))}
            bar={{ label: "Signups", tileLabel: "Signups · total", tileValue: "2 180" }}
            line={{
              label: "Activation",
              tileLabel: "Activation · average",
              tileValue: "41%",
              max: 60,
            }}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};
