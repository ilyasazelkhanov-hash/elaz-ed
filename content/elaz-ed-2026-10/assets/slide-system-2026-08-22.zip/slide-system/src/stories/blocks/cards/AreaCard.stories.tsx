import type { Meta, StoryObj } from "@storybook/react-vite";

import AreaCard, { AreaCardPlot, type AreaCardSeries } from "../../../blocks/cards/areaCard";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import { BOARD_CHART, BOARD_SERIES } from "../../../lib/boardPalette";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «площадь» — стопка площадей с шапкой, осями и легендой.
 *
 * Витрина показывает не только красивый случай, а границы: минимум данных,
 * потолок рядов, длинные подписи, кривая против ломаной и сочетание, при
 * котором карточка перестаёт помещаться на слайд.
 *
 * ⚠️ Данные демонстрационные. Первая история воспроизводит скриншот донора
 * (94 700 = 50 500 + 25 900 + 18 300, пик декабря 13 500), потому что по ней
 * сверяют перенос; всё остальное выдумано и с деками намеренно не совпадает.
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`, 64 с каждой стороны), поэтому
 * карточка во всю ширину (1680) требует окна от 1808 точек. На узком окне
 * она вылезет за обёртку — это свойство витрины, а не блока: на слайде 1680
 * встают ровно в поля.
 *
 * === Что смотреть в обеих темах ===
 *
 * Салатовая полоса. В тёмной теме её кромка даёт 6,13…7,77:1, в светлой —
 * 1,62…1,95:1, то есть порог 3:1 не берёт нигде. Это принятая заказчиком цена за
 * «цвета как на скриншоте», числа и разбор — в шапке `blocks/cards/areaCard.tsx`.
 * Практическое следствие: карточка, которая едет на проектор, ставится
 * `theme="dark"`.
 */

const meta = {
  title: "Карточки/Площадь",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Данные донора  ═══════════════ */

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/**
 * Три канала за год.
 *
 * Порядок — донорский и он же правильный для стопки: внизу самый крупный и
 * самый ровный ряд. Только у нижнего ряда прямое основание, все остальные
 * едут на сумме соседей снизу.
 *
 * Суммы совпадают с плитками легенды на скриншоте, пик декабря — 13 500,
 * итог года — 94 700.
 */
const CHANNELS: AreaCardSeries[] = [
  {
    key: "organic",
    label: "Organic",
    values: [2400, 2900, 3300, 3600, 3800, 3700, 4200, 4500, 4800, 5100, 5600, 6600],
  },
  {
    key: "referral",
    label: "Referral",
    values: [1200, 1400, 1500, 1700, 1850, 1800, 2050, 2250, 2450, 2650, 2850, 4200],
  },
  {
    key: "paid",
    label: "Paid",
    values: [800, 900, 1050, 1200, 1350, 1300, 1500, 1650, 1800, 1950, 2100, 2700],
  },
];

/** Подпись деления как на скриншоте: «13.5K». Для русского дека передаётся своя */
const donorTick = (v: number) =>
  v >= 1000 ? `${Math.round(v / 100) / 10}K`.replace(",", ".") : String(v);

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Карточка как на скриншоте: во всю рабочую ширину, три канала, ось донора.
 *
 * `axisTop={13500}` здесь не украшение, а воспроизведение: у донора верхний
 * тик пришпилен к максимуму данных, отсюда его 0 / 4.5K / 9K / 13.5K.
 * Наше общее для волны правило оси даёт другой ответ — следующая история.
 *
 * Число в шапке и значения плиток НЕ выписаны руками: они считаются от тех же
 * данных, что и график. Выписанные руками числа расходятся с графиком при
 * первой же правке данных, и заметить это на слайде некому.
 */
export const Карточка: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Поле построения {cardChartWidth(1680)} × {cardChartHeight()} точек, то есть{" "}
        {(cardChartWidth(1680) / cardChartHeight()).toFixed(2)}:1 против донорских 2,78:1 — лента
        вдвое площе оригинала, наклоны кривых вдвое положе. Для линейных форм честнее половинная
        ширина, см. историю «Пара в половину ширины».
      </p>
      <AreaCard
        label="Visitors"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        series={CHANNELS}
        labels={MONTHS}
        axisTop={13500}
        formatTick={donorTick}
      />
    </div>
  ),
};

/**
 * Та же карточка без `axisTop` — ось по общему правилу волны.
 *
 * `cardAxisTicks` берёт три равных шага и округляет шаг до 1 · 2 · 2,5 · 5
 * своего порядка: 13 500 / 3 = 4 500 → шаг 5 000 → потолок 15 000, подписи
 * 0 / 5K / 10K / 15K. Стопка при этом не достаёт до верхней линии — на
 * скриншоте она её почти касается.
 *
 * Расхождение сознательное: ось, у которой верхний промежуток короче
 * остальных, читается неверно — глаз, привыкший к первым трём шагам,
 * промахивается на высоте точки. Ровный шаг дороже точного совпадения со
 * скриншотом; когда важнее совпадение — `axisTop`.
 */
export const ОсьПоУмолчанию: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Без axisTop: 0 / 5K / 10K / 15K</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Те же данные, что и в первой истории. Разница только в верхнем тике — и в том, сколько
        пустоты остаётся над стопкой: 15 000 против пика 13 500 это 10% высоты поля.
      </p>
      <AreaCard
        label="Visitors"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        series={CHANNELS}
        labels={MONTHS}
      />
    </div>
  ),
};

/* ═══════════════  Половинная ширина  ═══════════════ */

const CHANNELS_LAST_YEAR: AreaCardSeries[] = [
  {
    key: "organic",
    label: "Organic",
    values: [2200, 2350, 2500, 2700, 2900, 2800, 3100, 3300, 3450, 3600, 3800, 4300],
  },
  {
    key: "referral",
    label: "Referral",
    values: [1000, 1100, 1150, 1300, 1400, 1350, 1500, 1650, 1750, 1850, 1950, 2400],
  },
  {
    key: "paid",
    label: "Paid",
    values: [700, 750, 800, 900, 950, 900, 1050, 1150, 1200, 1300, 1400, 1700],
  },
];

/**
 * Две карточки в ряд — пропорции донора воспроизводятся именно так.
 *
 * И вторая работа свойства `axisTop`: обе карточки получают одну шкалу
 * (15 000), поэтому их стопки СРАВНИМЫ по высоте. Без общего потолка каждая
 * карточка растянулась бы на свой максимум, и слабый год выглядел бы как
 * сильный — самая частая ложь пары графиков рядом.
 */
export const ПараВПоловинуШирины: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Две по 828 — ближе к оригиналу</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Поле построения {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half" })}, то есть{" "}
        {(cardChartWidth(828, "half") / cardChartHeight({ size: "half" })).toFixed(2)}:1 — донор
        даёт 2,78:1. Обводка здесь тоньше на точку: она считается долей ширины поля (донорские 2 при
        494) с полом 5 и потолком 8, как линия в `lineCard.tsx`.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <AreaCard
            size="half"
            label="Visitors · 2025"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "This year" }}
            series={CHANNELS}
            labels={MONTHS}
            axisTop={15000}
            formatTick={donorTick}
          />
        </div>
        <div className="w-[828px]">
          <AreaCard
            size="half"
            label="Visitors · 2024"
            delta={{ label: "−3,6%", direction: "down" }}
            period={{ label: "Last year" }}
            series={CHANNELS_LAST_YEAR}
            labels={MONTHS}
            axisTop={15000}
            formatTick={donorTick}
          />
        </div>
      </div>
    </div>
  ),
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Светлая и тёмная карточка рядом, тема задана самой карточке — тулбар её
 * не перебивает.
 *
 * Смотреть надо на НИЖНЮЮ, салатовую полосу. Слева её кромка почти не
 * отделяется ни от белой карточки (1,95:1), ни от хвоста синей полосы над
 * ней (1,62…1,83:1 по длине); справа та же кромка даёт 7,77:1 и 6,13…7,31:1.
 * Это не настройка блока, а цена решения «цвета как на скриншоте», и платится
 * она тёмной темой.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Светлая и тёмная карточка рядом</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Краски серий в обеих темах одинаковы — у донора это краски, а не роли. Переворачиваются
        поверхности: карточка, подложка плитки, сетка, цвет подписей осей. Подписи осей набраны
        вторичным цветом (5,41:1 в светлой, 6,00:1 в тёмной) и лежат вне поля построения, поэтому ни
        в одной точке не попадают на градиент.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <AreaCard
            theme="light"
            size="half"
            height={520}
            label="Visitors"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "This year" }}
            series={CHANNELS}
            labels={MONTHS}
            formatTick={donorTick}
          />
        </div>
        <div className="w-[828px]">
          <AreaCard
            theme="dark"
            size="half"
            height={520}
            label="Visitors"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "This year" }}
            series={CHANNELS}
            labels={MONTHS}
            formatTick={donorTick}
          />
        </div>
      </div>
    </div>
  ),
};

/* ═══════════════  Кривая и ломаная  ═══════════════ */

const QUARTERS = ["I квартал", "II квартал", "III квартал", "IV квартал"];

const QUARTER_SERIES: AreaCardSeries[] = [
  { key: "base", label: "Абонентская плата", values: [4200, 4600, 4400, 6100] },
  { key: "extra", label: "Дополнительные услуги", values: [1400, 1900, 1600, 3200] },
];

/**
 * `shape="smooth"` против `shape="sharp"` на четырёх точках.
 *
 * На двенадцати месяцах монотонная кривая безопасна: она по построению не
 * выходит за значения соседних точек. На четырёх точках безопасность
 * сохраняется, а вот СМЫСЛ рушится: между кварталами нет промежуточных
 * значений, и дуга рисует плавный переход там, где данных попросту нет.
 *
 * Правило: много равномерных точек — кривая, мало точек или неравные шаги —
 * ломаная. Это донорское `shape`, а не наша выдумка.
 */
export const КриваяИЛоманая: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Четыре точки: слева кривая, справа ломаная</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Обе кромки построены по одним и тем же числам. Слева дуга проходит между кварталами так,
        будто величина между ними менялась плавно; справа видно, что известны только четыре
        значения.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <AreaCard
            size="half"
            height={520}
            label="Выручка · сглаженная"
            value="27 400"
            period={{ label: "2025 год" }}
            series={QUARTER_SERIES}
            labels={QUARTERS}
          />
        </div>
        <div className="w-[828px]">
          <AreaCard
            size="half"
            height={520}
            shape="sharp"
            label="Выручка · ломаная"
            value="27 400"
            period={{ label: "2025 год" }}
            series={QUARTER_SERIES}
            labels={QUARTERS}
          />
        </div>
      </div>
    </div>
  ),
};

/* ═══════════════  Крайние случаи  ═══════════════ */

const RU_MONTHS = [
  "Январь",
  "Февраль",
  "Март",
  "Апрель",
  "Май",
  "Июнь",
  "Июль",
  "Август",
  "Сентябрь",
  "Октябрь",
  "Ноябрь",
  "Декабрь",
];

const SIX_SERIES: AreaCardSeries[] = [
  { key: "s1", label: "Поиск", values: [2400, 2600, 2900, 3100, 3300, 3600] },
  { key: "s2", label: "Переходы", values: [1200, 1250, 1400, 1500, 1650, 1800] },
  { key: "s3", label: "Реклама", values: [800, 900, 950, 1100, 1150, 1300] },
  { key: "s4", label: "Рассылка", values: [500, 560, 610, 640, 700, 780] },
  { key: "s5", label: "Партнёры", values: [300, 340, 380, 410, 450, 520] },
  { key: "s6", label: "Прочее", values: [150, 170, 190, 210, 240, 280] },
];

/**
 * Минимум данных, потолок рядов, длинные подписи.
 *
 * ⚠️ Две точки — это нижняя граница формы, а не рекомендация: между двумя
 * точками кривая вырождается в отрезок, и площадь под ней утверждает
 * равномерный переход. Одна точка — уже не график: блок предупредит в
 * консоли, потому что площади между точкой и ничем не существует.
 *
 * ⚠️ Шесть рядов — потолок, и он не про краски, а про толщину полос: шестая
 * полоса на 244 точках высоты получает 15 точек и читается только по легенде.
 * Донор рисует три, и три остаются честным числом для проектора.
 *
 * Длинные подписи оси прореживаются ЗАМЕРОМ, а не по числу знаков: «Сентябрь»
 * шире «Мая» вдвое, и шаг прореживания считается от самой широкой строки.
 */
export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Две точки — нижняя граница формы</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Кривая вырождается в отрезок, поэтому здесь честнее `shape=&quot;sharp&quot;`. Ось,
          легенда и шапка при этом работают как обычно.
        </p>
        <div className="w-[828px]">
          <AreaCard
            size="half"
            height={520}
            shape="sharp"
            label="Пилот"
            period={{ label: "Две недели" }}
            series={[
              { key: "a", label: "Заявки", values: [180, 260] },
              { key: "b", label: "Оплаты", values: [40, 95] },
            ]}
            labels={["Неделя 1", "Неделя 2"]}
          />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок: шесть рядов</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Седьмой ряд блок отбросит и напишет об этом в консоль. Шесть — предел легенды и правила
          «список длиннее 6 пунктов не ставить»; на проекторе честный предел — три-четыре.
        </p>
        <AreaCard
          label="Источники трафика"
          delta={{ label: "+12,0%", direction: "up" }}
          period={{ label: "Полугодие" }}
          series={SIX_SERIES}
          labels={["Янв", "Фев", "Мар", "Апр", "Май", "Июн"]}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи оси и длинные названия рядов</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          На половинной карточке двенадцать русских месяцев не помещаются — часть подписей уходит по
          замеру. Названия рядов в плитках легенды обрезаются многоточием: перенос увеличил бы
          высоту легенды, а она входит в бюджет карточки.
        </p>
        <div className="w-[828px]">
          <AreaCard
            size="half"
            label="Посещаемость по каналам привлечения"
            delta={{ label: "+8,2%", direction: "up" }}
            period={{ label: "Последние 12 месяцев" }}
            series={[
              { ...CHANNELS[0], label: "Органический поиск без брендовых запросов" },
              { ...CHANNELS[1], label: "Переходы с партнёрских площадок" },
              { ...CHANNELS[2], label: "Платная реклама" },
            ]}
            labels={RU_MONTHS}
            formatTick={(v) => v.toLocaleString("ru-RU")}
          />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Без легенды</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Полю построения достаётся {cardChartHeight({ legend: false })} вместо {cardChartHeight()}{" "}
          — на 124 точки больше. ⚠️ Выключать легенду можно только там, где ряды названы иначе
          (например, подписью на самом слайде): краски донора в светлой теме порог 3:1 не берут, и
          без подписей стопка перестаёт быть читаемой.
        </p>
        <AreaCard
          label="Visitors"
          legend={false}
          delta={{ label: "+8,2%", direction: "up" }}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          series={CHANNELS}
          labels={MONTHS}
          formatTick={donorTick}
        />
      </div>
    </div>
  ),
};

/**
 * Опасный случай: почти плоское поле построения.
 *
 * Карточка ужата до 480 точек — столько остаётся, если над ней на слайде
 * стоит ещё один блок. Слоту графика достаётся 160 точек, из них 46 уходят
 * под подписи осей, полю построения остаётся 114: линии сетки встают через
 * 38 точек, и стопка превращается в ленту — наклоны пропадают, разница между
 * рядами читается только по легенде.
 *
 * Блок предупреждает в консоли, когда полю остаётся меньше 120 точек. Порог
 * не запрет — ниже него карточка ещё рисуется, но перестаёт быть графиком.
 */
export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Высота 480: график превращается в ленту</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Лечится не ужиманием, а выбором: либо легенда уходит, либо карточка остаётся единственным
        блоком слайда. Третий выход — половинная ширина: поле построения там уже, и та же высота
        даёт пропорцию ближе к донорской.
      </p>
      <AreaCard
        height={480}
        label="Visitors"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        series={CHANNELS}
        labels={MONTHS}
        formatTick={donorTick}
      />
    </div>
  ),
};

/* ═══════════════  Поле построения без карточки  ═══════════════ */

/**
 * Тот же график в слоте, но без оболочки — как его ставят, когда шапка
 * собирается вручную.
 *
 * Заодно видно, что квадратик легенды и есть единственный указатель на ряд:
 * здесь его нет, и ряды опознаются только по цвету.
 */
export const ТолькоПолеПостроения: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">AreaCardPlot отдельно</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Размеры приходят числами: {cardChartWidth(1680)} × {cardChartHeight()}. Своей высоты у
        графика нет — он рисует ровно то, что ему отдали, и содержимое выше слота обрезается, а не
        растягивает карточку.
      </p>
      <div className="bg-surface rounded-hero p-9">
        <AreaCardPlot
          series={CHANNELS}
          labels={MONTHS}
          width={cardChartWidth(1680)}
          height={cardChartHeight()}
          axisTop={13500}
          formatTick={donorTick}
        />
      </div>
      <div className="mt-6 flex gap-6">
        {CHANNELS.map((s, i) => (
          <span key={s.key} className="text-body-m text-ink-secondary flex items-center gap-3">
            <span
              className="rounded-micro shadow-hairline inline-block"
              style={{
                width: 20,
                height: 20,
                background:
                  BOARD_SERIES[[BOARD_CHART.lime, BOARD_CHART.blue, BOARD_CHART.purple][i]],
              }}
            />
            {s.label}
          </span>
        ))}
      </div>
    </div>
  ),
};

/* ═══════════════  Как на слайде  ═══════════════ */

/**
 * Карточка в настоящем ContentSlide.
 *
 * Здесь видно то, чего не показывает голый div витрины: шапка слайда (пилюля,
 * заголовок в ОДНУ строку, лид) забирает 244, подвал резервирует 56, блоку
 * остаётся 604 — ровно бюджет карточки. Запаса нет: карточка занимает всё.
 *
 * Заголовок формулирует мысль, а не называет тему, — иначе карточка окажется
 * иллюстрацией без утверждения.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Витрина"
      title="Рост посещаемости за год дала органика, а не реклама"
      lead="Три канала привлечения помесячно, высота полосы — вклад канала в общий трафик"
      page={1}
      label="Витрина блоков"
    >
      <AreaCard
        label="Visitors"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        series={CHANNELS}
        labels={MONTHS}
        axisTop={13500}
        formatTick={donorTick}
      />
    </ContentSlide>
  ),
};

/**
 * ⚠️ Заголовок в ДВЕ строки — и бюджета уже нет.
 *
 * Вторая строка заголовка (`headline-l`, 60 точек межстрочного) съедает 60 из
 * 604: блоку остаётся 544. Карточка высотой по умолчанию обрежется снизу — то
 * есть потеряет легенду, а вместе с ней единственную подпись рядов.
 *
 * Лечение — `height={544}`, и оно здесь применено: карточка ужимается сама, а
 * не обрезается. Цена видна в слоте графика — 224 точки по высоте вместо 284.
 *
 * Тёмная тема на этом слайде не для разнообразия: салатовая полоса в светлой
 * теме порог не берёт, и ровно такой слайд — с полной стопкой и легендой —
 * тот случай, когда это заметно.
 */
export const ЗаголовокВДвеСтроки: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Витрина"
      title="Рост посещаемости за год дала органика, а платная реклама осталась на месте"
      lead="Три канала привлечения помесячно, высота полосы — вклад канала в общий трафик"
      page={2}
      label="Витрина блоков"
    >
      <AreaCard
        height={544}
        label="Visitors"
        delta={{ label: "+8,2%", direction: "up" }}
        period={{ label: "This year" }}
        series={CHANNELS}
        labels={MONTHS}
        axisTop={13500}
        formatTick={donorTick}
      />
    </ContentSlide>
  ),
};
