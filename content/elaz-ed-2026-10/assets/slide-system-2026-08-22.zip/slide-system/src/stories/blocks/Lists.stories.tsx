import type { Meta, StoryObj } from "@storybook/react-vite";
import {
  Bolt,
  Code,
  Gallery,
  Pen,
  Ranking,
  Rocket,
  UsersGroupRounded,
  Videocamera,
} from "@solar-icons/react";
import { Checklist, NumberedList, PillRow, Timeline } from "../../blocks/lists";
import { AccentRule, IconRows, IconTiles, PointsRow } from "../../blocks/tiles";
import GlyphGradient from "../../components/icons/GlyphGradient";

/**
 * Блоки перечисления и блоки с иконочным квадратом — из донорского мобильного проекта.
 *
 * Содержимое здесь ДЕМОНСТРАЦИОННОЕ. Донорские данные (уроки курса, аудитория)
 * не переносились: это его предметная область, а не дизайн-система.
 */

const meta = {
  title: "Блоки/Списки",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

const STEPS = [
  { id: "s1", title: "Бриф и сбор материалов", meta: "3 дня", current: false },
  { id: "s2", title: "Структура и сценарий презентации", meta: "5 дней", current: true },
  { id: "s3", title: "Дизайн слайдов", meta: "7 дней", muted: true },
  { id: "s4", title: "Правки и финальная сборка", meta: "3 дня", muted: true },
];

const AUDIENCE = [
  { title: "Отделу продаж", note: "одинаковая презентация у всех менеджеров" },
  { title: "Маркетингу", note: "новый материал за часы, а не за недели" },
  { title: "Основателям", note: "инвесторская презентация без подрядчика" },
];

const TILES = [
  { Icon: Videocamera, accent: "#0088ff", title: "Продажи", note: "коммерческое предложение" },
  { Icon: Ranking, accent: "#ff8d28", title: "Маркетинг", note: "запуск продукта" },
  { Icon: UsersGroupRounded, accent: "#5856d6", title: "HR", note: "презентация для найма" },
  { Icon: Rocket, accent: "#34c759", title: "Инвесторам", note: "раунд и метрики" },
];

const EXTRAS = [
  { Icon: Pen, accent: "#0088ff", title: "Шаблоны слайдов", note: "обложка, разделитель, контент" },
  { Icon: Gallery, accent: "#5856d6", title: "Наборы иконок", note: "Solar и логотипы брендов" },
  { Icon: Bolt, accent: "#af52de", title: "Готовые блоки", note: "списки, графики, ленты медиа" },
  { Icon: Code, accent: "#008575", title: "Выгрузка в PDF", note: "одной командой" },
];

export const Перечисления: Story = {
  render: () => (
    <div className="grid max-w-[1680px] grid-cols-2 gap-16">
      <section>
        <h3 className="text-title-l text-ink mb-2">Галочки</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Читается как «да, это про меня». Для аудитории и для того, что входит в поставку.
        </p>
        <Checklist items={AUDIENCE} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Пилюли</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Только названия. Годится, когда важен охват, а не подробности. Как только к пункту нужна
          вторая строка, пилюли перестают подходить.
        </p>
        <PillRow items={["Продажи", "Маркетинг", "HR", "Инвесторам", "Обучение", "Отчётность"]} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Нумерация</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Номер обещает порядок. Ставить только там, где порядок правда есть.
        </p>
        <NumberedList items={STEPS} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Лента</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Линия говорит, что между шагами есть движение. Рисуется одним элементом на весь список —
          иначе рвётся в промежутках и читается как пунктир.
        </p>
        <Timeline items={STEPS} />
      </section>
    </div>
  ),
};

export const СИконками: Story = {
  name: "С иконками",
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-16">
      <GlyphGradient />

      <section>
        <h3 className="text-title-l text-ink mb-2">Ряд тезисов</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Без подложки — самый тихий вариант. Больше четырёх в ряд не ставить: пятая колонка на
          1680px становится уже 300px, и заголовок начинает переноситься.
        </p>
        <PointsRow items={TILES.slice(0, 3)} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Сетка плиток</h3>
        <p className="text-body-m text-ink-secondary mb-8">Пункты равноправны, порядок не важен.</p>
        <IconTiles items={TILES} columns={4} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Строки</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Пунктов много, у каждого своя роль. Стрелки справа по умолчанию нет: в PDF переходить
          некуда, и стрелка выглядела бы как недоделанный интерфейс.
        </p>
        <IconRows items={EXTRAS} />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Черта слева</h3>
        <p className="text-body-m text-ink-secondary mb-8">
          Ни подложки, ни иконки. Для цитаты и для абзаца, который надо отделить, не превращая в
          карточку.
        </p>
        <AccentRule>
          Мы собрали презентацию за два дня вместо трёх недель — и все слайды оказались в одном
          стиле без единой правки от дизайнера.
        </AccentRule>
      </section>
    </div>
  ),
};
