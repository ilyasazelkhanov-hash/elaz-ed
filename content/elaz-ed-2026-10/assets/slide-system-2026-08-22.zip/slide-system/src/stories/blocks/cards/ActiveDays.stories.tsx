import type { Meta, StoryObj } from "@storybook/react-vite";
import ActiveDaysCard, {
  activeDaysMetrics,
  type ActiveDay,
  type ActiveDaysSeries,
} from "../../../blocks/cards/activeDaysCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Самые активные дни» — донорская карточка активных дней.
 *
 * Месяц как сетка колец: каждый день — кольцо прогресса дневной нормы,
 * номер дня внутри кольца. В шапке итог месяца и подпись месяца.
 *
 * === ⚠️ Что смотреть в первую очередь ===
 *
 * 1. **Сторона кольца.** История «Раскладка» ставит рядом донорскую ячейку
 *    (число НАД кольцами) и вложенную (число ВНУТРИ) с замерами: 61.33
 *    против 101.33. Донорская раскладка тратит на строку числа 40 точек
 *    высоты ячейки, вложенная кладёт число в просвет, который иначе пуст.
 * 2. **Сколько колец.** История «Кольца» показывает 1 · 2 · 3. Три кольца
 *    помещаются, но просвет между дугами падает до 3.07 точки — на
 *    проекторе они сливаются в одну толстую дугу.
 * 3. **Светлая тема.** Из трёх донорских красок порог 3:1 берёт только
 *    внешняя (#f6339a, 3.58). Салат #9ae600 даёт 1.53 — на белой карточке
 *    среднее кольцо почти не видно. Тёмная тема даёт 9.87.
 *
 * Данные историй СГЕНЕРИРОВАНЫ по seed, а не сняты с донора: со скриншота
 * снята только форма компонента. Донорские тут числа в шапке.
 */

const meta = {
  title: "Карточки/Активные дни",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

/** Детерминированный PRNG: одна и та же картинка в Storybook и в PDF */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Месяц: доли дневной нормы по трём кольцам.
 *
 * Будни выше выходных, лёгкая волна по месяцу, редкие дни с полным
 * перевыполнением. Доли считаются независимо по кольцам — у донора они
 * тоже независимы (Move / Exercise / Running).
 */
function buildMonth(seed: number, dayCount = 31, strength = 1): ActiveDay[] {
  const rnd = mulberry32(seed);
  return Array.from({ length: dayCount }, (_, i) => {
    const weekend = i % 7 === 5 || i % 7 === 6;
    const base = (weekend ? 0.34 : 0.62) + 0.24 * Math.sin((i / dayCount) * Math.PI * 2);
    return {
      day: i + 1,
      shares: [
        Math.max(0, Math.min(1.3, (base + rnd() * 0.5) * strength)),
        Math.max(0, Math.min(1.3, (base + rnd() * 0.4 - 0.08) * strength)),
        Math.max(0, Math.min(1.3, (base + rnd() * 0.6 - 0.2) * strength)),
      ],
    };
  });
}

const ТИПОВОЙ = buildMonth(2026);

/** Пусто: нормы не выполнены ни в один день. Проверка «ничего не схлопнулось» */
const МИНИМУМ: ActiveDay[] = Array.from({ length: 31 }, (_, i) => ({
  day: i + 1,
  shares: [0, 0, 0],
}));

/** Потолок: каждый день на норме и выше. Все кольца замкнуты */
const ПОТОЛОК: ActiveDay[] = Array.from({ length: 31 }, (_, i) => ({
  day: i + 1,
  shares: [1, 1.2, 1],
}));

/** Опасный случай: почти нулевые доли — дуга вырождается в точку */
const КРОШКИ: ActiveDay[] = Array.from({ length: 31 }, (_, i) => ({
  day: i + 1,
  shares: [i % 3 === 0 ? 0 : 0.012, 0.006, 0],
}));

const КОЛЬЦА: ActiveDaysSeries[] = [
  { label: "Move", value: "816 kcal" },
  { label: "Exercise", value: "1h 41m" },
  { label: "Running", value: "5,2 км" },
];

/** Итог месяца с суффиксом донора: «32 459 total steps» одной строкой шапки */
const ИТОГ = (
  <>
    32 459 <span className="text-body-l text-ink-secondary">шагов</span>
  </>
);

const М = activeDaysMetrics;

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Как это ставится на слайд: одно кольцо, номер внутри, месяц в шапке.
 */
export const Карточка: Story = {
  render: () => {
    const m = М({ dayCount: 31 });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Слот графика {m.slotWidth} × {m.slotHeight}. Колонок {m.columns} × {m.rows} строк —
          подобрано перебором по критерию «крупнейшее кольцо», а не взято у донора (у него 7 в
          строке, и это не календарь: дни идут подряд, без выравнивания по дням недели). Ячейка{" "}
          {m.cellWidth.toFixed(2)} × {m.cellHeight.toFixed(2)} при просвете {m.gap}. КОЛЬЦО{" "}
          {m.ring.toFixed(2)} — это ×{(m.ring / 28).toFixed(2)} к донорскому 28. Обводка{" "}
          {m.stroke.toFixed(2)}, просвет внутри {m.hole.toFixed(1)}, номер дня набран кеглем{" "}
          {m.dayFontSize}. На экране 2.5 м с четырёх метров кольцо — 13,2 см и 1,89°, номер — 4,7 см
          и 40′ (для сравнения `body-l` 24px — 27′).
        </p>
        <ActiveDaysCard
          label="Most active days"
          value={ИТОГ}
          delta={{ label: "+12,4%", direction: "up" }}
          month="Январь"
          days={ТИПОВОЙ}
          selected={17}
        />
      </div>
    );
  },
};

/* ═══════════════  Раскладка ячейки  ═══════════════ */

/**
 * ⚠️ Донорская ячейка против вложенного номера — на одних данных.
 */
export const Раскладка: Story = {
  render: () => {
    const a = М({ dayCount: 31, layout: "inset" });
    const b = М({ dayCount: 31, layout: "stacked" });
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            `layout="inset"` — номер ВНУТРИ кольца: {a.ring.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Так просил заказчик и так кольцо крупнее всего: высота ячейки {a.cellHeight.toFixed(2)}{" "}
            уходит на кольцо целиком, минус {a.cellInset} рамки с полем сверху и снизу. Номер стоит
            в просвете {a.hole.toFixed(1)}, который иначе пуст, и набран кеглем {a.dayFontSize} —
            выбран замером: диагональ чернил «31» при {a.dayFontSize} равна 50,9 при разрешённых 82%
            просвета (64,7). Кегль 44 тоже влез бы (61,9), но занял бы 78% — число упёрлось бы в
            дугу.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            layout="inset"
            selected={17}
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            `layout="stacked"` — донорская: номер НАД кольцами, {b.ring.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Ровно как замерено у донора: колонка «число сверху, кольца снизу». Цена на нашем
            носителе видна числом: строка числа (32) и просвет под ней (8) забирают 40 точек из{" "}
            {b.cellHeight.toFixed(2)} высоты ячейки, и кольцу остаётся {b.ring.toFixed(2)} вместо{" "}
            {a.ring.toFixed(2)} — то есть {(100 - (b.ring / a.ring) * 100).toFixed(0)}% стороны
            потеряно. Раскладка нужна там, где колец больше двух: в просвет трёх колец номер не
            помещается ни одним кеглем шкалы.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            layout="stacked"
            selected={17}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Кольца  ═══════════════ */

/**
 * ⚠️ Сколько колец выдерживает ячейка — и чем платит светлая тема.
 */
export const Кольца: Story = {
  render: () => {
    const one = М({ dayCount: 31, rings: 1 });
    const twoBare = М({ dayCount: 31, rings: 2 });
    const two = М({ dayCount: 31, rings: 2, legend: true });
    const three = М({ dayCount: 31, rings: 3, legend: true });
    const gap3 = three.radii[0] - three.radii[1] - three.stroke;
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Одно кольцо — просвет {one.hole.toFixed(1)}, номер {one.dayFontSize}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Легенда не нужна: что за величина, сказано в шапке карточки. Кольцо{" "}
            {one.ring.toFixed(2)} — втрое крупнее донорского.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            series={[КОЛЬЦА[0]]}
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            ⚠️ Два кольца — легенда обязательна, и она уводит раскладку в `{two.layout}`
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Легенда здесь не украшение: в светлой теме салат #9ae600 даёт к белой карточке 1,53:1
            при пороге 3:1 — какое кольцо чьё, по цвету не определить, только по подписи. А легенда
            забирает у слота 124 точки (плитка 100 + просвет 24), и дальше всё решено арифметикой:
            без легенды кольцо было бы {twoBare.ring.toFixed(2)} с просветом{" "}
            {twoBare.hole.toFixed(1)} и номером {twoBare.dayFontSize} внутри, а с легендой кольцо{" "}
            {two.ring.toFixed(2)}, просвет {two.hole.toFixed(1)} — туда не влезает даже кегль 20
            (диагональ чернил 25,2 при разрешённых {(two.hole * 0.82).toFixed(1)}). Блок сам ушёл на
            донорскую раскладку. Отсюда правило: одно кольцо — `inset` без легенды, два и три —
            `stacked` с легендой.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            series={КОЛЬЦА.slice(0, 2)}
            legend
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            Три кольца — раскладка сама ушла в `{three.layout}`
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Просвет внутри третьего кольца — {three.hole.toFixed(1)} точки, а самый мелкий
            разрешённый кегль (20) даёт диагональ чернил 25,2. Номер не помещается, поэтому блок
            перешёл на донорскую раскладку и сказал об этом в метриках — молчаливой подмены нет.
            Кольцо {three.ring.toFixed(2)}, обводка {three.stroke.toFixed(2)}, ЧИСТЫЙ ПРОСВЕТ между
            соседними дугами {gap3.toFixed(2)} — на экране 2,5 м это 0,4 см, с четырёх метров 3,4′.
            Три дуги на таком просвете на проекторе сольются: три кольца — граница возможного, а не
            рабочий режим.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            series={КОЛЬЦА}
            legend
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Колонки  ═══════════════ */

/**
 * Подобранные 11 колонок против донорских 7.
 */
export const Колонки: Story = {
  render: () => {
    const auto = М({ dayCount: 31 });
    const seven = М({ dayCount: 31, columns: 7 });
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Подбор: {auto.columns} × {auto.rows}, кольцо {auto.ring.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Квадратная ячейка требует отношения строк к колонкам {auto.slotHeight} /{" "}
            {auto.slotWidth} = 0,254, откуда c² ≥ 31 / 0,254 и c ≥ 11,06. Перебор даёт то же: 11 →{" "}
            {auto.ring.toFixed(2)}, 12 → {М({ dayCount: 31, columns: 12 }).ring.toFixed(2)}, 13 →{" "}
            {М({ dayCount: 31, columns: 13 }).ring.toFixed(2)}, 8 →{" "}
            {М({ dayCount: 31, columns: 8 }).ring.toFixed(2)}.
          </p>
          <ActiveDaysCard label="Most active days" value={ИТОГ} month="Январь" days={ТИПОВОЙ} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            Донорские 7 × {seven.rows}: кольцо {seven.ring.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Ячейка {seven.cellWidth.toFixed(2)} × {seven.cellHeight.toFixed(2)} — широкая и низкая,
            кольцо ограничивает ВЫСОТА, и половина ширины уходит в пустые поля. Потеря{" "}
            {(100 - (seven.ring / auto.ring) * 100).toFixed(0)}% стороны кольца. ⚠️ И вторая беда:
            семь в строке читается как календарь, которым сетка не является — 1-е число встаёт в
            первую колонку независимо от дня недели. Если слайду нужен календарь, это другой блок.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value={ИТОГ}
            month="Январь"
            days={ТИПОВОЙ}
            columns={7}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Светлая и тёмная карточка — вложенной темой, без переключения тулбара.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <p className="text-body-m text-ink-secondary max-w-4xl">
        Краски колец одинаковы в обеих темах — это краски донора, а не роли. Контраст к своей
        карточке: внешнее #f6339a — 3,58 в светлой и 4,22 в тёмной; среднее #9ae600 — 1,53 и 9,87;
        внутреннее #00bcff — 2,18 и 6,95. То есть в светлой теме порог 3:1 берёт одно кольцо из
        трёх. Это записанное решение заказчика («цвета как на скриншотах»), а не недосмотр — но
        карточку с несколькими кольцами на проектор правильнее везти тёмной. Трек в обеих темах
        декоративен: 1,08…1,47 к своей поверхности.
      </p>
      {(["light", "dark"] as const).map((theme) => (
        <ActiveDaysCard
          key={theme}
          theme={theme}
          label="Most active days"
          value={ИТОГ}
          delta={{ label: "+12,4%", direction: "up" }}
          month="Январь"
          days={ТИПОВОЙ}
          series={КОЛЬЦА.slice(0, 2)}
          legend
          selected={17}
        />
      ))}
    </div>
  ),
};

/* ═══════════════  Крайние случаи  ═══════════════ */

/**
 * Минимум, потолок, длинные подписи, вырожденная дуга и месяц из 28 дней.
 */
export const КрайниеСлучаи: Story = {
  render: () => {
    const half3 = М({ size: "half", dayCount: 31, rings: 3, legend: true });
    const feb = М({ dayCount: 28 });
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">Минимум — норма не выполнена ни разу</h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Все доли нулевые. Дуга не рисуется вовсе — остаются трек и номер. Это и есть проверка
            «ничего не схлопнулось в ноль»: сетка на месте, ячейки прежнего размера, номера
            читаются. ⚠️ И это же показывает, чего стоит донорский трек: при 16% непрозрачности
            пустой месяц выглядит просто рядом чисел.
          </p>
          <ActiveDaysCard label="Most active days" value="0" month="Январь" days={МИНИМУМ} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Потолок — норма выполнена и перевыполнена</h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Кольца замкнуты. ⚠️ Доля 1,2 нарисована как 1,0: дуга длиннее окружности легла бы на
            саму себя, и «перевыполнено на 20%» неотличимо от «ровно норма». Если перевыполнение
            существенно — оно должно быть напечатано числом, а не показано кольцом.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value="61 320"
            delta={{ label: "+96%", direction: "up" }}
            month="Январь"
            days={ПОТОЛОК}
            series={КОЛЬЦА.slice(0, 2)}
            legend
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Вырожденная дуга — доли около нуля</h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Доли 1,2% и 0,6%. Круглые концы обводки удлиняют дугу на толщину обводки с каждой
            стороны, поэтому 1,2% окружности (3,3 точки при {М({ dayCount: 31 }).stroke.toFixed(2)}{" "}
            толщины) выглядит как короткий штрих, а не как ничто. Ровный ноль не рисуется совсем —
            иначе он дал бы ТОЧКУ и день без активности читался бы как день с крошечной.
          </p>
          <ActiveDaysCard label="Most active days" value="412" month="Январь" days={КРОШКИ} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Длинные подписи</h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Подпись серии и плитки легенды обрезаются многоточием, а не переносятся: перенос увёл бы
            сетку за бюджет. Плашка месяца не сжимается (`shrink-0`) — она подпись, рвать её нельзя.
          </p>
          <ActiveDaysCard
            label="Активность по дням месяца с учётом тренировок, прогулок и подъёмов по лестнице"
            value="1 284 950"
            delta={{ label: "−1,8%", direction: "down" }}
            month="Ноябрь 2026"
            days={ТИПОВОЙ}
            series={[
              { label: "Расход энергии за сутки, килокалории", value: "816 kcal" },
              { label: "Продолжительность тренировок", value: "1h 41m" },
            ]}
            legend
            selected={3}
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            Февраль: {feb.columns} × {feb.rows}, кольцо {feb.ring.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            28 дней вместо 31 — подбор колонок пересчитывается, а не подгоняет пустые ячейки: сетка
            заполнена целиком.
          </p>
          <ActiveDaysCard
            label="Most active days"
            value="29 118"
            month="Февраль"
            days={ТИПОВОЙ.slice(0, 28)}
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            ⚠️ Опасный случай: половина ширины, три кольца, легенда
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Самое мелкое сочетание из всех настроек: слот {half3.slotWidth} × {half3.slotHeight},
            ячейка {half3.cellWidth.toFixed(2)} × {half3.cellHeight.toFixed(2)}, кольцо{" "}
            {half3.ring.toFixed(2)} при обводке {half3.stroke.toFixed(2)}. Само КОЛЬЦО порог «~40
            точек» держит — оно всё ещё в 1,7 раза крупнее донорского 28. Ниже порога уходит другое:
            ЧИСТЫЙ ПРОСВЕТ между соседними дугами —{" "}
            {(half3.radii[0] - half3.radii[1] - half3.stroke).toFixed(2)} точки, то есть 0,32 см на
            экране 2,5 м и 2,7′ с четырёх метров. Три дуги сольются в одну толстую, и карточка
            скажет не то, что в данных. Лечится тремя способами: убрать легенду, оставить одно
            кольцо или взять полную ширину.
          </p>
          <div className="w-[828px]">
            <ActiveDaysCard
              size="half"
              label="Most active days"
              value="32 459"
              month="Январь"
              days={ТИПОВОЙ}
              series={КОЛЬЦА}
              legend
            />
          </div>
        </div>
      </div>
    );
  },
};

/* ═══════════════  Половинная карточка  ═══════════════ */

/**
 * Половина рабочей ширины — две такие карточки встают рядом.
 */
export const ПоловиннаяКарточка: Story = {
  render: () => {
    const m = М({ size: "half", dayCount: 31 });
    return (
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">
          828 точек: {m.columns} × {m.rows}, кольцо {m.ring.toFixed(2)}
        </h3>
        <p className="text-body-m text-ink-secondary mb-10">
          Слот {m.slotWidth} × {m.slotHeight}, ячейка {m.cellWidth.toFixed(2)} ×{" "}
          {m.cellHeight.toFixed(2)}, просвет {m.gap}, номер кеглем {m.dayFontSize}. Кольцо всё ещё
          вдвое крупнее донорского (28) — при одном кольце половина ширины работает.
        </p>
        <ActiveDaysCard
          size="half"
          label="Most active days"
          value="32 459"
          delta={{ label: "+12,4%", direction: "up" }}
          month="Январь"
          days={ТИПОВОЙ}
          selected={17}
        />
      </div>
    );
  },
};

/* ═══════════════  На слайде  ═══════════════ */

/**
 * Карточка внутри ContentSlide — проверка бюджета 604.
 *
 * Шапка слайда (пилюля, заголовок в одну строку, лид) забирает 244, подвал
 * резервирует 56, блоку остаётся ровно 604. Карточка задана высотой, а не
 * содержимым: сетка обязана поместиться в остаток.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Активность"
      title="Норму дня закрыли 23 раза из 31"
      lead="Кольцо — доля дневной нормы шагов, номер внутри кольца — число месяца"
      page={11}
      label="Витрина карточек"
    >
      <ActiveDaysCard
        label="Most active days"
        value={ИТОГ}
        delta={{ label: "+12,4%", direction: "up" }}
        month="Январь"
        days={ТИПОВОЙ}
        selected={17}
      />
    </ContentSlide>
  ),
};

/**
 * То же на тёмном слайде — так эту карточку правильно везти на проектор.
 *
 * Здесь два кольца с легендой: в тёмной теме обе краски берут порог с
 * запасом (4,22 и 9,87 против 3,58 и 1,53 в светлой).
 */
export const НаТёмномСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Активность"
      title="Норму дня закрыли 23 раза из 31"
      lead="Внешнее кольцо — расход энергии, внутреннее — время тренировки"
      page={12}
      label="Витрина карточек"
    >
      <ActiveDaysCard
        label="Most active days"
        value={ИТОГ}
        delta={{ label: "+12,4%", direction: "up" }}
        month="Январь"
        days={ТИПОВОЙ}
        series={КОЛЬЦА.slice(0, 2)}
        legend
        selected={17}
      />
    </ContentSlide>
  ),
};
