import type { Meta, StoryObj } from "@storybook/react-vite";
import { CapacityBars, FactRow } from "../../blocks/facts";
import { StatTiles } from "../../blocks/charts";
import Card from "../../components/Card";

/**
 * Строка фактов и столбики с потолком.
 *
 * Оба приёма сняты с донорского админского дашборда,
 * где стоят внутри панели показателя: строка фактов — её подвалом, стаканы —
 * фоном столбиков графика. Перенесены отношения и механика, а не пиксели:
 * донорская подпись 12px на слайде не существует как размер.
 *
 * Данные демонстрационные и намеренно НЕ совпадают с числами реальных деков:
 * витрина показывает поведение блока, а не содержание презентации.
 * Совпадающие числа рано или поздно начинают жить своей жизнью и расходятся
 * с data/*.
 */

const meta = {
  title: "Блоки/Строка фактов",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const ТриЧетыреПять: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">FactRow — три ячейки</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Нижняя рамка формы. Две величины на разделителе читаются не как ряд, а как
          противопоставление — пару честнее написать словами. Значение набрано headline-s (36): это
          ровно половина главного числа панели (display-s 72), поэтому подвал ему не спорит.
        </p>
        <FactRow
          items={[
            { value: "9 млрд", label: "Токенов всего" },
            { value: "562,7 млн", label: "Пиковый месяц" },
            { value: "62 дня", label: "Длинная серия" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Четыре ячейки — раскладка донора</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Разделитель — левая граница соседа, а не отдельный элемент: так он всегда во всю высоту
          строки. Поля у линии — 24, тот же желоб, что у сетки слайда, поэтому между текстами
          соседних ячеек получается ровно 48.
        </p>
        <FactRow
          items={[
            { value: "9 млрд", label: "Токенов всего" },
            { value: "562,7 млн", label: "Пиковый месяц" },
            { value: "12 ч 54 мин", label: "Самая долгая задача" },
            { value: "62 дня", label: "Длинная серия" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Пять ячеек — верхняя рамка</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Шестая ячейка на ширине 1680 дала бы 280 точек, из которых 48 съедают поля у разделителей:
          на подпись остаётся 232, и она начинает переноситься. В режиме разработки блок
          предупреждает об этом в консоли.
        </p>
        <FactRow
          items={[
            { value: "9 млрд", label: "Токенов всего" },
            { value: "562,7 млн", label: "Пиковый месяц" },
            { value: "12 ч 54 мин", label: "Долгая задача" },
            { value: "62 дня", label: "Длинная серия" },
            { value: "31", label: "Активных проекта" },
          ]}
        />
      </section>
    </div>
  ),
};

export const ВКарточкеИНаХолсте: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Подвалом внутри панели показателя</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Ровно то место, где приём стоит у донора. Заливки у ячеек нет намеренно: приглушённая
          плитка на приглушённой подложке даёт 1.00:1 — плитки исчезли бы. Черта сверху (rule)
          отделяет факты от графика, без неё они читаются как его подписи. Панель собрана под бюджет
          содержательного слайда: замер даёт 597 при потолке 604, поэтому её можно ставить на слайд
          как есть.
        </p>
        <Card surface="muted" className="max-w-[820px]">
          <p className="text-body-m text-ink-secondary">Вклад за год</p>
          <p className="text-display-s text-ink mt-2 tabular-nums">18 240</p>
          <div className="mt-8">
            <CapacityBars
              height={200}
              capacity={40}
              data={[
                { label: "Апрель", value: 31 },
                { label: "Май", value: 26 },
                { label: "Июнь", value: 38 },
                { label: "Июль", value: 17 },
              ]}
            />
          </div>
          <div className="mt-8">
            <FactRow
              rule
              items={[
                { value: "9 млрд", label: "Токенов всего" },
                { value: "562,7 млн", label: "Пиковый месяц" },
                { value: "62 дня", label: "Длинная серия" },
              ]}
            />
          </div>
        </Card>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Сам по себе на холсте</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Тот же блок без карточки и без черты: на холсте строку и так ничто не подпирает. Токены
          одни и те же — ink для значения, ink-secondary для подписи, line для разделителя, —
          поэтому поверхность блоку безразлична.
        </p>
        <FactRow
          items={[
            { value: "9 млрд", label: "Токенов всего" },
            { value: "562,7 млн", label: "Пиковый месяц" },
            { value: "12 ч 54 мин", label: "Долгая задача" },
            { value: "62 дня", label: "Длинная серия" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Чем это не StatTiles</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Сверху плитки, снизу строка — с одними и теми же величинами. Плитки заявляют, строка
          дополняет: 72 против 36 и подложка против её отсутствия. Если факты и есть содержание
          слайда, ставить надо верхнее; строка нужна там, где главное число уже есть и оно чужое.
        </p>
        <StatTiles
          columns={3}
          items={[
            { value: "9 млрд", label: "Токенов всего" },
            { value: "562,7 млн", label: "Пиковый месяц" },
            { value: "62 дня", label: "Длинная серия" },
          ]}
        />
        <div className="mt-10">
          <FactRow
            items={[
              { value: "9 млрд", label: "Токенов всего" },
              { value: "562,7 млн", label: "Пиковый месяц" },
              { value: "62 дня", label: "Длинная серия" },
            ]}
          />
        </div>
      </section>
    </div>
  ),
};

export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Подписи в две строки</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Ячейки тянутся по самой высокой, поэтому разделители остаются одной длины, а значения — на
        одной линии. Строка вырастает с 76 до 104 точек: перенос подписи стоит 28, ровно одну строку
        body-m.
      </p>
      <FactRow
        items={[
          { value: "9 млрд", label: "Обработано токенов за всё время работы" },
          { value: "562,7 млн", label: "Пик" },
          { value: "12 ч 54 мин", label: "Самая долгая непрерывная задача" },
          { value: "62 дня", label: "Серия" },
        ]}
      />
    </div>
  ),
};

export const СтаканыЗаполнение: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">CapacityBars — близко к потолку</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Потолок приходит из данных, а не из максимума выборки, поэтому «почти полно» видно без
          чтения оси. Стакан нарисован контуром, а не серой заливкой. ⚠️ Довод, которым это
          объяснялось («донорская заливка даёт у границы „налито ↔ пусто“ 2,79:1 при пороге 3:1»),
          снят с белого холста и краски #0088ff прежней системы и сегодня не работает: на токенах
          скина board та же граница даёт 3,16:1 в светлой теме и 3,56:1 в тёмной, то есть порог
          берёт. Контур остаётся потому, что даёт больший запас — 3,54:1 к светлому холсту и 4,55:1
          к тёмному, — а не потому, что заливка проваливается. Разбор — в шапке blocks/facts.tsx.
        </p>
        <CapacityBars
          capacity={120}
          ceilingLabel="потолок — 120 мест в группе"
          data={[
            { label: "Понедельник", value: 112 },
            { label: "Вторник", value: 104 },
            { label: "Среда", value: 118 },
            { label: "Четверг", value: 97 },
            { label: "Пятница", value: 109 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Далеко от потолка</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Те же столбцы в BarChart выглядели бы ровно так же, как предыдущий ряд: там высота
          считается от максимума В ДАННЫХ, и самый высокий столбец всегда упирается в верх области.
          Здесь видно, что занята пятая часть ёмкости, — это и есть весь приём.
        </p>
        <CapacityBars
          capacity={120}
          ceilingLabel="потолок — 120 мест в группе"
          data={[
            { label: "Понедельник", value: 26 },
            { label: "Вторник", value: 19 },
            { label: "Среда", value: 31 },
            { label: "Четверг", value: 14 },
            { label: "Пятница", value: 22 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Ровно потолок и превышение</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Ровно потолок — заливка занимает стакан целиком, до стенок и до верхней грани: сосуд
          полон. Превышение — заливка дальше не растёт, а по верхней грани встаёт поперечная метка
          цветом ink (тот же приём, что у отметки нормы в Meter). Растить столбик за стакан нельзя:
          потолок, который можно перерасти, перестаёт быть потолком, а пересчёт масштаба под выброс
          молча сожмёт все остальные столбцы. Метка нейтральная, а не красная: перевыполненный план
          и превышенная норма часов — одна форма и разные выводы, и делать вывод за автора слайда
          блок не должен.
        </p>
        <CapacityBars
          capacity={40}
          ceilingLabel="потолок — 40 часов в неделю"
          data={[
            { label: "Проектирование", value: 40 },
            { label: "Вёрстка", value: 47 },
            { label: "Ревью", value: 12 },
            { label: "Правки", value: 40 },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Свой потолок у каждого столбца</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Когда ёмкость у столбцов разная, сравниваются уже не величины, а доли: 18 из 24 занято
          сильнее, чем 30 из 60, хотя число меньше. Читать такой ряд как сравнение величин нельзя —
          подпись потолка поэтому обязательна.
        </p>
        <CapacityBars
          capacity={24}
          height={280}
          ceilingLabel="у каждой команды своя норма: 24, 60, 24 и 36 часов"
          data={[
            { label: "Аналитика", value: 18 },
            { label: "Разработка", value: 30, capacity: 60 },
            { label: "Дизайн", value: 23 },
            { label: "Поддержка", value: 9, capacity: 36 },
          ]}
        />
      </section>
    </div>
  ),
};
