import type { Meta, StoryObj } from "@storybook/react-vite";
import { Stars } from "@solar-icons/react";

import AiImageCard, {
  MAX_FRAMES,
  MAX_GALLERY,
  aiImageGeometry,
  packGallery,
  type AiGalleryTile,
  type AiImageFrame,
} from "../../../blocks/cards/aiImageCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Генерация картинок» — `blocks/cards/aiImageCard.tsx`.
 *
 * Донор — система дашбордов. Это не
 * график, а кусок интерфейса: лента переписки, кадр генерации с обратным
 * отсчётом, справа masonry-архив прошлых генераций. На слайде он становится
 * СТАТИЧНЫМ МАКЕТОМ — тем же, чем бывает скриншот продукта.
 *
 * === Картинок в репозитории нет ===
 *
 * Ни одна история ниже не подставляет `src`. Это не недоделка витрины: блок
 * обязан работать на заглушках, потому что заказчик приносит снимки позже,
 * а вёрстка слайда к этому моменту уже согласована. Заглушка держит габарит
 * — тот же приём, что у `MediaCover` (`blocks/media.tsx`) и `CoverCard`
 * (`blocks/entity.tsx`). Подстановка `src` не двигает ничего: `<img>`
 * ложится в тот же прямоугольник с `object-cover`.
 *
 * === Про числа в подписях ===
 *
 * Все размеры под историями СЧИТАЮТСЯ вызовом `aiImageGeometry` и
 * `packGallery` на тех же данных, что нарисованы рядом. Переписанное руками
 * число живёт своей жизнью: поменяется доля галереи — проза останется
 * прежней и будет врать увереннее самого блока.
 *
 * ⚠️ Витрина добавляет своё поле, поэтому карточка во всю ширину (1680)
 * требует окна от 1808 точек. На узком окне она вылезет за обёртку — это
 * свойство витрины, а не блока.
 *
 * ⚠️ Замеры делать только в режиме «1:1 — для замеров». В режиме «вписать
 * в окно» `getBoundingClientRect` возвращает числа после `transform: scale`.
 */

const meta = {
  title: "Карточки/Генерация картинок",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные донора ───────────── */

/** Запрос со страницы донора, 118 знаков */
const PROMPT =
  "Create a vintage editorial illustration of Lionel Messi dribbling in Argentina's home kit against a blue background.";

/**
 * Пара кадров: ожидание и результат.
 *
 * Донор показывает ОДИН кадр, который проходит оба состояния во времени.
 * Пара — компенсация анимации, предложенная самой разведкой: «показать ДВА
 * кадра рядом — слева ожидание с конкретной цифрой отсчёта и рябью, справа
 * готовое изображение».
 */
const PAIR: AiImageFrame[] = [
  {
    state: "pending",
    caption: "12-я секунда: рябь и отсчёт",
    note: "Generating image",
    timer: "12s",
  },
  {
    state: "ready",
    caption: "14-я секунда: кадр проявлен",
    note: "Vintage editorial Messi",
  },
];

/**
 * Та же пара для ПОЛОВИННОЙ карточки.
 *
 * Тексты короче не для красоты, а по замеру. Кадр половинной карточки —
 * 204 точки; строка состояния получает 204 − 20 − 20 = 164 минус место
 * под счётчик, то есть 123 точки. В них кеглем 18 не влезает даже
 * донорская «Generating image»: её замеренная ширина 144.5, обрезка на
 * 25.8 точки. Поэтому здесь «Generating» — и это не придирка витрины, а
 * находка: на половинной карточке собственная строка донора не помещается.
 *
 * Подпись ПОД кадром получает все 204 точки, то есть кеглем 20 около 21
 * знака: «12-я секунда: отсчёт» (187.5) входит, «12-я секунда: рябь и
 * отсчёт» (250.3) — уже нет. Обрезать её нельзя: именно она объясняет,
 * чем один кадр пары отличается от другого.
 */
const HALF_PAIR: AiImageFrame[] = [
  { state: "pending", caption: "12-я секунда: отсчёт", note: "Generating", timer: "12s" },
  { state: "ready", caption: "14-я секунда: готово", note: "Messi, cobalt" },
];

/**
 * Шесть плиток архива.
 *
 * ⚠️ Порядок НЕ случайный: раскладка идёт по исходному порядку (алгоритм
 * разобран в `packGallery`), и от порядка зависит, войдут ли все плитки.
 * Здесь они выстроены от высокой к низкой — при таком порядке жадная
 * укладка даёт колонки 360 / 365 / 334 из отведённых 368 и не теряет ни
 * одной. Тот же набор в обратном порядке потерял бы две.
 *
 * Пропорции — донорские: 3:4 (замеренный на странице `aspect-ratio 449/600`
 * это 0.748), 4:5, 1:1 и три горизонтальных, которых у донора нет, но без
 * которых шесть плиток в 368 точек не укладываются — см. «Потолок».
 */
const GALLERY: AiGalleryTile[] = [
  { caption: "Botanical poster, pressed leaves", ratio: 0.75 },
  { caption: "Vintage editorial Messi, Argentina kit", ratio: 0.8 },
  { caption: "Character set, flat icons", ratio: 1 },
  { caption: "City scene at dusk", ratio: 4 / 3 },
  { caption: "ZARA storefront, editorial", ratio: 1.5 },
  { caption: "Studio portrait, warm key", ratio: 16 / 9 },
];

/* ───────────── подписи под историями ───────────── */

function Head({ children }: { children: React.ReactNode }) {
  return <h3 className="text-title-l text-ink mb-2">{children}</h3>;
}

function Note({ children }: { children: React.ReactNode }) {
  return <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">{children}</p>;
}

/** Числа раскладки, посчитанные тем же кодом, что рисует блок */
function geomLine(args: Parameters<typeof aiImageGeometry>[0]) {
  const g = aiImageGeometry(args);
  return `слот ${g.slotW}×${g.slotH} · кадр ${g.frameW}×${g.frameH} · запрос ${g.promptW} · ${
    g.galleryW ? `панель ${g.galleryW}, плитка ${g.tileW}, masonry ${g.masonryH}` : "без панели"
  }`;
}

/* ═══════════════  типовой случай  ═══════════════ */

/**
 * Полная карточка: запрос слева, пара кадров, архив справа.
 * Ровно та композиция, ради которой донор и разбирался.
 */
export const Карточка: Story = {
  render: () => {
    const g = aiImageGeometry({ gallery: true });
    const packed = packGallery(
      GALLERY.map((t) => t.ratio),
      3,
      g.tileW,
      g.masonryH,
    );

    return (
      <div className="w-[1680px]">
        <Head>Как у донора — 1680 × {CARD_BUDGET}</Head>
        <Note>
          {geomLine({ gallery: true })}. Кадр вышел ×{(g.frameW / 200).toFixed(2)} к донорским
          200×250, плитка ×{(g.tileW / 131).toFixed(2)} к донорским 131 — а не «минимум втрое», как
          советует разведка: 750 точек высоты не помещаются в бюджет блока {CARD_BUDGET}. Колонки
          masonry вышли {packed.heights.join(" / ")} из {g.masonryH}, потеряно плиток:{" "}
          {packed.dropped.length}.
        </Note>
        <AiImageCard
          label="Image generation"
          value="128 кадров"
          delta={{ label: "+34 за неделю", direction: "up" }}
          period={{ label: "Fable 5", icon: Stars }}
          prompt={PROMPT}
          frames={PAIR}
          gallery={GALLERY}
          galleryNote="6 из 128"
        />
      </div>
    );
  },
};

/**
 * Половинная карточка: запрос сверху, галереи нет.
 * Так карточка встаёт в колонку `col-span-6` рядом с другой.
 */
export const Половинная: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>828 × {CARD_BUDGET} — запрос над кадрами</Head>
      <Note>
        {geomLine({ size: "half" })}. Запрос переезжает наверх и обрезается по двум строкам: сбоку
        ему осталась бы колонка в 340 точек при вдвое меньшей высоте. Кадр при этом падает до{" "}
        {aiImageGeometry({ size: "half" }).frameW} точек — блок предупреждает об этом в консоль,
        потому что донорский кадр 200 при вчетверо меньшем носителе.
      </Note>
      <AiImageCard
        size="half"
        label="Image generation"
        value="128 кадров"
        period={{ label: "Fable 5", icon: Stars }}
        prompt={PROMPT}
        frames={HALF_PAIR}
      />
    </div>
  ),
};

/* ═══════════════  обе темы  ═══════════════ */

/**
 * Одна и та же карточка в двух темах.
 *
 * Тёмная — та, с которой снимался донор. Смотреть надо обе: заглушка,
 * вуаль и зерно ведут себя в них по-разному, и слабое место у каждой своё.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-16">
      <div>
        <Head>Светлая</Head>
        <Note>
          Глиф заглушки набран `--t-ink-tertiary`: замер к подложке кадра даёт 3,33:1 (#838383 на
          #f0f0f0) при пороге 3:1 для нетекстовой графики. Зерно `.plate-grain` на светлой подложке
          едва заметно — это и правильно: рябь у донора шла по тёмному #262626, на белом та же
          непрозрачность выглядела бы грязью.
        </Note>
        <AiImageCard
          label="Image generation"
          value="128 кадров"
          period={{ label: "Fable 5", icon: Stars }}
          prompt={PROMPT}
          frames={PAIR}
          gallery={GALLERY}
          galleryNote="6 из 128"
        />
      </div>

      <div>
        <Head>Тёмная — как снимался донор</Head>
        <Note>
          Те же данные, `theme="dark"`. Глиф заглушки — 4,14:1 (#7d7d7d на #1c1c1c). Вуаль под
          подписью на тёмной заглушке даёт 18,9…19,3:1 против 5,7…10,4:1 на белой картинке: вуаль
          посчитана по худшему случаю, то есть по белому небу в кадре, а не по нашей серой заглушке.
        </Note>
        <AiImageCard
          theme="dark"
          label="Image generation"
          value="128 кадров"
          period={{ label: "Fable 5", icon: Stars }}
          prompt={PROMPT}
          frames={PAIR}
          gallery={GALLERY}
          galleryNote="6 из 128"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  крайние случаи  ═══════════════ */

/** Один кадр, без архива — минимум, при котором карточка ещё о чём-то говорит */
export const МинимумДанных: Story = {
  render: () => (
    <div className="w-[828px]">
      <Head>Один готовый кадр</Head>
      <Note>
        {geomLine({ size: "half", frames: 1 })}. Пары нет — значит нет и противопоставления
        «ожидание → результат»: остаётся просто картинка с подписью. Это законный случай (слайд про
        результат, а не про процесс), но приём донора при нём не переносится вовсе.
      </Note>
      <AiImageCard
        size="half"
        label="Image generation"
        value="1 кадр"
        prompt={PROMPT}
        frames={[HALF_PAIR[1]]}
      />
    </div>
  ),
};

/** Оба потолка: {MAX_FRAMES} кадра и {MAX_GALLERY} плиток */
export const Потолок: Story = {
  render: () => {
    const three = aiImageGeometry({ frames: 3 });
    const g = aiImageGeometry({ gallery: true });
    const nine = packGallery(
      Array.from({ length: MAX_GALLERY }, (_, i) => [0.75, 0.8, 1][i % 3]),
      3,
      g.tileW,
      g.masonryH,
    );

    return (
      <div className="flex w-[1680px] flex-col gap-16">
        <div>
          <Head>
            {MAX_FRAMES} кадра — потолок пары. {three.frameW}×{three.frameH} каждый
          </Head>
          <Note>
            Третий кадр ещё уточняет ленту («запрос → 6 с → 14 с»), четвёртый превратил бы её в
            ленту кадров, и читатель начнёт искать различия там, где их нет. Архива рядом уже не
            будет: три кадра занимают {three.framesW} из {three.slotW} точек, галерее остаётся{" "}
            {three.slotW - three.framesW} — меньше одной донорской панели.
          </Note>
          <AiImageCard
            label="Image generation"
            value="128 кадров"
            period={{ label: "Fable 5", icon: Stars }}
            prompt={PROMPT}
            frames={[
              { state: "pending", caption: "6-я секунда", note: "Generating image", timer: "6s" },
              { state: "pending", caption: "12-я секунда", note: "Generating image", timer: "12s" },
              { state: "ready", caption: "14-я секунда: готово", note: "Vintage editorial Messi" },
            ]}
          />
        </div>

        <div>
          <Head>Потолок архива — шесть плиток, а не девять</Head>
          <Note>
            Разведка предлагает 3×3. Замер говорит, что при донорских пропорциях девять не влезают:
            masonry отведено {g.masonryH} точек, плитка {g.tileW}, и вертикальная плитка 3:4
            занимает {Math.round(g.tileW / 0.75)} — по две на колонку и всё. Проверка на девяти
            вертикальных плитках: колонки {nine.heights.join(" / ")}, потеряно {nine.dropped.length}
            . Поэтому набор по умолчанию — шесть, и три из них горизонтальные. Девять помещаются,
            только если ВСЕ горизонтальные (высота ≤ {Math.floor((g.masonryH - 24) / 3)}) — то есть
            ценой отказа от донорской вертикальной сетки.
          </Note>
          <AiImageCard
            label="Image generation"
            value="128 кадров"
            period={{ label: "Fable 5", icon: Stars }}
            prompt={PROMPT}
            frames={PAIR}
            gallery={GALLERY}
            galleryNote="6 из 128"
          />
        </div>
      </div>
    );
  },
};

/** Длинный запрос, длинные подписи, подписи на плитках */
export const ДлинныеПодписи: Story = {
  render: () => {
    const g = aiImageGeometry({ gallery: true });

    return (
      <div className="w-[1680px]">
        <Head>Запрос в 470 знаков, подписи на плитках включены</Head>
        <Note>
          Запрос обрезается по шести строкам, подпись кадра и строка на вуали — по одной. Обрезка не
          украшение: слот карточки фиксирован, и лишняя строка не растянула бы карточку, а выдавила
          бы кадры за нижний край, где в PDF их отрежет. Подписи на плитках при ширине {g.tileW}{" "}
          входят примерно на {Math.floor((g.tileW - 24) / 7.65)} знаков кеглем 18 — блок
          предупреждает, сколько подписей из шести обрежется, и отдельно про вуаль: на самой низкой
          плитке (104 точки) затемнение занимает 69% высоты и читается уже как заливка.
        </Note>
        <AiImageCard
          label="Image generation · Fable 5 · подписи включены"
          value="128 кадров"
          delta={{ label: "+34 за неделю", direction: "up" }}
          period={{ label: "Fable 5", icon: Stars }}
          prompt={`${PROMPT} Use grainy offset print texture, muted ochre and cobalt, hand-set condensed grotesque headline, torn paper edges, and a subtle halftone pattern across the entire composition, as if scanned from a 1974 sports weekly printed on cheap uncoated stock.`}
          frames={[
            {
              state: "pending",
              caption: "12-я секунда: рябь по канвасу и обратный отсчёт до готовности",
              note: "Generating image — resolving composition and palette",
              timer: "12s",
            },
            {
              state: "ready",
              caption: "14-я секунда: кадр проявлен радиальной маской с растушёванным краем",
              note: "Vintage editorial Messi, Argentina home kit, cobalt background",
            },
          ]}
          gallery={GALLERY}
          tileCaptions
          galleryNote="6 из 128"
        />
      </div>
    );
  },
};

/**
 * Опасный случай: набор, на котором блок перестаёт работать.
 *
 * Каждое из четырёх нарушений здесь даёт предупреждение в консоль. Смысл
 * истории — показать, как выглядит нарушение НА ЭКРАНЕ: предупреждение
 * видит только тот, кто в этот момент смотрел в консоль.
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const g = aiImageGeometry({ frames: 3, gallery: true });
    const twelve = packGallery(
      Array.from({ length: MAX_GALLERY }, (_, i) => [0.75, 0.8, 0.667][i % 3]),
      3,
      g.tileW,
      g.masonryH,
    );

    return (
      <div className="w-[1680px]">
        <Head>Три кадра рядом с архивом + оба кадра готовы + 12 плиток</Head>
        <Note>
          Что сломано. (1) Три кадра и панель архива вместе оставляют запросу {g.promptW} точек —
          пузырь вытягивается в столбик по слову. (2) Оба видимых кадра в состоянии «готово»: пара
          перестаёт быть «до и после» и читается как две разные картинки. (3) Плиток передано 12 при
          потолке {MAX_GALLERY}; из оставшихся девяти вертикальных укладываются не все — колонки{" "}
          {twelve.heights.join(" / ")} из {g.masonryH}, потеряно {twelve.dropped.length}. Плитка,
          которой не хватило места, не рисуется вовсе: обрезанная наполовину читается как брак
          печати, отсутствующая — как более короткая колонка. Замер подтверждает и (1): колонка
          запроса переполнена по ширине на 12 точек — одни поля пузыря (24 + 24) шире отведённых ему{" "}
          {g.promptW}. Это единственная история набора, где замер находит переполнение, и находит он
          ровно то, о чём предупреждает блок.
        </Note>
        <AiImageCard
          label="Image generation"
          value="128 кадров"
          period={{ label: "Fable 5", icon: Stars }}
          prompt={PROMPT}
          frames={[
            { state: "ready", caption: "Готово", note: "Messi, cobalt background" },
            { state: "ready", caption: "Готово", note: "Messi, ochre background" },
            { state: "ready", caption: "Готово", timer: "14s", note: "Messi, mint background" },
          ]}
          gallery={[
            ...GALLERY,
            { caption: "Portrait, cold key", ratio: 0.75 },
            { caption: "Botanical study II", ratio: 0.8 },
            { caption: "Character set II", ratio: 0.667 },
            { caption: "Storefront II", ratio: 0.75 },
            { caption: "City scene II", ratio: 0.8 },
            { caption: "Portrait III", ratio: 0.667 },
          ]}
          galleryNote="12 из 128"
        />
      </div>
    );
  },
};

/* ═══════════════  как на слайде  ═══════════════ */

/**
 * Карточка внутри `ContentSlide` — единственная проверка, которая
 * подтверждает бюджет {CARD_BUDGET}. В обёртке витрины он не проверяется
 * никак: там нет ни шапки слайда, ни подвала, ни холста 1080.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Генерация"
      title="Кадр рождается за 14 секунд — и сразу уходит в архив"
      page={11}
      label="Витрина карточек"
    >
      <AiImageCard
        label="Image generation"
        value="128 кадров"
        delta={{ label: "+34 за неделю", direction: "up" }}
        period={{ label: "Fable 5", icon: Stars }}
        prompt={PROMPT}
        frames={PAIR}
        gallery={GALLERY}
        galleryNote="6 из 128"
      />
    </ContentSlide>
  ),
};

/** Тот же слайд в тёмной теме — той, с которой снимался донор */
export const НаСлайдеТёмном: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Генерация"
      title="Кадр рождается за 14 секунд — и сразу уходит в архив"
      page={12}
      label="Витрина карточек"
    >
      <AiImageCard
        label="Image generation"
        value="128 кадров"
        delta={{ label: "+34 за неделю", direction: "up" }}
        period={{ label: "Fable 5", icon: Stars }}
        prompt={PROMPT}
        frames={PAIR}
        gallery={GALLERY}
        galleryNote="6 из 128"
      />
    </ContentSlide>
  ),
};

/** Две половинные карточки в колонках `col-span-6` — процесс и результат */
export const НаСлайдеПара: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Генерация"
      title="Один запрос — два варианта за четырнадцать секунд"
      page={13}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <AiImageCard
            size="half"
            label="Image generation"
            value="14 s"
            period={{ label: "Fable 5", icon: Stars }}
            prompt={PROMPT}
            frames={HALF_PAIR}
          />
        </div>
        <div className="col-span-6">
          <AiImageCard
            size="half"
            label="Image generation"
            value="2 варианта"
            period={{ label: "Fable 5", icon: Stars }}
            prompt="Same scene, ochre background, heavier halftone, condensed headline set in all caps."
            frames={[
              { state: "ready", caption: "Вариант A", note: "Cobalt" },
              { state: "ready", caption: "Вариант B", note: "Ochre" },
            ]}
          />
        </div>
      </div>
    </ContentSlide>
  ),
};
