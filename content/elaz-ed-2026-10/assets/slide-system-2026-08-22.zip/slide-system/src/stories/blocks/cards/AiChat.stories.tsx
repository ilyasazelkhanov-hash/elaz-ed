import type { Meta, StoryObj } from "@storybook/react-vite";
import { BranchingPathsUp, CpuBolt, Widget } from "@solar-icons/react";
import AiChatCard, {
  CODE_MAX_LINES,
  COMPOSER_HEIGHT,
  MAX_LINES,
  MAX_MESSAGES,
  PLAN_MAX_STEPS,
  SEND_STOPS,
  codeCardHeight,
  layoutAiChat,
  planCardHeight,
  type ChatComposer,
  type ChatMessage,
} from "../../../blocks/cards/aiChatCard";
import { CARD_BUDGET, cardChartHeight } from "../../../blocks/cards/shell";
import { BOARD_HEAT } from "../../../lib/boardPalette";
import { contrast, runContrast } from "../../../lib/color";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «переписка с агентом» — перенос донорского переписки.
 *
 * Витрина показывает не столько красивый случай, сколько ГРАНИЦЫ: минимум,
 * потолок числа реплик, потолок длины одной реплики, длинные подписи
 * и сочетание, при котором лента перестаёт помещаться. Разбор переноса —
 * в шапке [`blocks/cards/aiChatCard.tsx`](../../../blocks/cards/aiChatCard.tsx).
 *
 * === Про числа в подписях ===
 *
 * Все числа СЧИТАЮТСЯ вызовом `layoutAiChat` прямо здесь, на тех же данных,
 * что нарисованы рядом. Переписанное руками число живёт своей жизнью:
 * поменяется просвет между рядами или высота карточки кода — проза останется
 * прежней и будет врать увереннее, чем сам блок.
 *
 * По той же причине под каждой историей напечатан список ПРЕДУПРЕЖДЕНИЙ,
 * которые блок выдаёт в консоль на этих данных. Предупреждение в консоли
 * видит только тот, кто в этот момент в неё смотрел; на странице его видно
 * всегда.
 *
 * === Про ширину обёртки ===
 *
 * Разборные истории стоят на жёсткой ширине 1680, а не на `max-w-`.
 * Геометрия считается от переданной ширины, и молча сжатый контейнер дал бы
 * картинку, не совпадающую с собственными замерами блока. Витрина добавляет
 * своё поле, поэтому окно нужно от 1808 точек — на узком будет честная
 * горизонтальная прокрутка.
 *
 * ⚠️ Чего эта витрина не даёт: `npm run check` обходит только слайды деков.
 * Пока карточка не поставлена в дек, автоматических ворот у неё нет —
 * переполнение здесь ловится замером в режиме 1:1, а не скриптом.
 */

const meta = {
  title: "Карточки/Переписка",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Тексты донора  ═══════════════ */

/*
 * Всё, кроме строк кода, снято со страницы донора дословно (раздел «Тексты
 * со страницы» в спецификации разведки). Код на странице виден кусками —
 * четыре строки ниже написаны так, чтобы имя файла, бейдж языка и счётчик
 * диффа («TSX», «theme-toggle.tsx», «+56 −14») остались донорскими.
 */

const ЗАПРОС =
  "update our color tokens for dark mode and add a reusable theme toggle to the registry, run lint and a production build when you're done.";

const ОТВЕТ =
  "Done — the semantic dark-mode tokens and reusable theme toggle are wired. The toggle updates the root theme from one place and persists the selection.";

const КОД_3 = ["export function ThemeToggle() {", "  const { theme, setTheme } = useTheme()", "}"];

const КОД_4 = [
  "export function ThemeToggle() {",
  "  const { theme, setTheme } = useTheme()",
  '  return <Switch checked={theme === "dark"} onChange={setTheme} />',
  "}",
];

const КОД_5 = [
  "export function ThemeToggle() {",
  "  const { theme, setTheme } = useTheme()",
  '  const next = theme === "dark" ? "light" : "dark"',
  '  return <Switch checked={theme === "dark"} onChange={() => setTheme(next)} />',
  "}",
];

const ШАГИ = [
  { label: "Read project files", state: "done" as const },
  { label: "Update and install light mode tokens", state: "done" as const },
  { label: "Implement dark mode tokens", state: "done" as const },
  { label: "Add reusable registered theme toggle", state: "active" as const },
  { label: "Run registry, lint and production build", state: "todo" as const },
];

const КОМПОЗЕР: ChatComposer = {
  placeholder: "Ask me anything",
  model: "Fable 5",
  status: [
    { label: "main", icon: BranchingPathsUp },
    { label: "project-sea", icon: Widget },
    { label: "Agent", icon: CpuBolt },
  ],
};

/* Типовая лента: донорский запрос, донорский ответ, карточка кода в 3 строки */
const ЛЕНТА: ChatMessage[] = [
  { role: "user", text: ЗАПРОС },
  {
    role: "assistant",
    text: ОТВЕТ,
    code: {
      language: "TSX",
      file: "theme-toggle.tsx",
      diff: { added: 56, removed: 14 },
      lines: КОД_3,
    },
  },
];

/* ═══════════════  Замеры для подписей историй  ═══════════════ */

const измерить = (
  messages: readonly ChatMessage[],
  options: { composer?: ChatComposer; width?: number; half?: boolean; height?: number } = {},
) =>
  layoutAiChat({
    messages,
    composer: options.composer,
    width: options.width ?? 1680,
    height: options.height ?? CARD_BUDGET,
    size: options.half ? "half" : "full",
  });

const ряд = (xs: number[]) => xs.join(" · ");

/**
 * Предупреждения блока, напечатанные на странице.
 *
 * Считаются тем же вызовом, что и геометрия, поэтому разойтись с консолью
 * не могут. Пустой список — тоже результат: он означает, что на этих данных
 * блок молчит, и это видно, а не предполагается.
 */
function Предупреждения({ layout }: { layout: ReturnType<typeof измерить> }) {
  return (
    <div className="mb-10 max-w-5xl">
      <h4 className="text-title-m text-ink mb-2">
        Предупреждений в консоли: {layout.warnings.length}
      </h4>
      {layout.warnings.length ? (
        <ul className="text-body-m text-ink-secondary flex flex-col gap-2">
          {layout.warnings.map((w) => (
            <li key={w} className="flex gap-3">
              <span className="text-ink-tertiary shrink-0">—</span>
              <span>{w}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-body-m text-ink-secondary">
          Блок молчит: лента {layout.threadHeight} точек при поле {layout.available}, реплик не
          больше {MAX_MESSAGES}, ни одна не длиннее {MAX_LINES} строк, строки кода в поле{" "}
          {Math.round(layout.codeWidth)} помещаются.
        </p>
      )}
    </div>
  );
}

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Донорская переписка во всю рабочую ширину, без композера.
 *
 * Здесь смотреть главное: сколько от донора вообще помещается. Замер:
 * донорский запрос встаёт в две строки, донорский ответ — в две, и на
 * карточку кода остаётся место под четыре строки. Взяты три — четвёртая
 * помещается, но съедает запас с 34 точек до 6, а пятая уже не влезает.
 * Числа обеих границ — в истории «Потолок длины».
 */
export const Переписка: Story = {
  render: () => {
    const L = измерить(ЛЕНТА);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          1680 × {CARD_BUDGET}; поле ленты {L.contentWidth} × {L.available}, лента {L.threadHeight}{" "}
          — запас {L.available - L.threadHeight}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Колонка содержимого {L.columnWidth} (лента минус аватар 44 и просвет 20), потолок пузыря{" "}
          {L.bubbleMax} — ровно половина ленты, как у донора. Донорский запрос ({ЗАПРОС.length}{" "}
          знаков) встал в {L.rows[0].lines} строк{L.rows[0].lines === 1 ? "у" : ""}, пузырь{" "}
          {L.rows[0].height}; донорский ответ ({ОТВЕТ.length} знаков) — в {L.rows[1].lines} строк
          {L.rows[1].lines === 1 ? "у" : ""} на всю колонку, {L.rows[1].parts.text} точек. Карточка
          кода {L.rows[1].parts.code} = 90 + 28 × {КОД_3.length}, поле кода{" "}
          {Math.round(L.codeWidth)}.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Высоты рядов: {ряд(L.rows.map((r) => r.height))} плюс просвет 24 между ними. Слот карточки{" "}
          {cardChartHeight({ legend: false })}, композера нет — ленте достаётся весь слот. Замер в
          браузере совпал с расчётом до точки: ряды в вёрстке {ряд(L.rows.map((r) => r.height))},
          лента {L.threadHeight}.
        </p>
        <Предупреждения layout={L} />
        <AiChatCard
          label="Остаток контекста"
          value="57%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={ЛЕНТА}
          userInitial="M"
        />
      </div>
    );
  },
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Обе темы рядом через вложенную тему — расхождение видно без переключения
 * тулбара, и оно здесь про разделение панелей, а не про текст.
 *
 * Текст проходит везде с запасом: реплика пользователя 16.61 в светлой
 * и 12.83 в тёмной, ответ 19.80 и 14.50, подписи 18 на приглушённой
 * подложке 4.75 и 6.76 при пороге 4.5.
 *
 * А вот КРОМКИ в светлой теме почти нет: приглушённая подложка к карточке
 * 1.14, обводка `line` к приглушённой 1.05. Карточка кода и пузырь
 * держатся на разнице заливок, которой на проекторе с засветкой может
 * не хватить. Это не дефект переноса: светлый скин донора весь лежит между
 * #ffffff и #ebebeb, и плитки легенды в `shell.tsx` стоят на той же разнице.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Светлая тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Пузырь `fill-strong` #ebebeb на карточке #ffffff — 1.19. Карточка кода `surface-muted`
          #f0f0f0 — 1.14, её обводка `line` #ebebeb к своей заливке — 1.05. Аватар ассистента чёрный
          с белым глифом: 19.80 и 19.80.
        </p>
        <AiChatCard
          theme="light"
          label="Остаток контекста"
          value="57%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={ЛЕНТА}
          userInitial="M"
        />
      </div>
      <div>
        <h3 className="text-title-l text-ink mb-2">Тёмная тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Те же роли на карточке #262626: пузырь #2f2f2f — 1.13, но он СВЕТЛЕЕ карточки, как у
          донора (#262626 на #171717); карточка кода #1c1c1c темнее, обводка к ней 1.27. Аватар
          белый с тёмным глифом: 14.50 и 17.95. Если переписка едет на проектор — брать эту тему.
        </p>
        <AiChatCard
          theme="dark"
          label="Остаток контекста"
          value="57%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={ЛЕНТА}
          userInitial="M"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  Минимум  ═══════════════ */

const МИНИМУМ: ChatMessage[] = [
  { role: "user", text: "Собери прод-сборку и прогони линтер." },
  { role: "assistant", text: "Готово: линтер чист, сборка 1,8 МБ." },
];

/**
 * Минимум данных: две однострочные реплики.
 *
 * Нижняя граница ряда — не строка текста, а аватар: однострочный ответ
 * ассистента даёт 32 точки текста, но ряд равен 44. Из этого и посчитан
 * потолок числа реплик в шапке блока.
 */
export const Минимум: Story = {
  render: () => {
    const L = измерить(МИНИМУМ);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Две реплики: {ряд(L.rows.map((r) => r.height))} — лента {L.threadHeight} из {L.available}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Пузырь пользователя в одну строку — 64 (32 строка + 32 поля), ответ ассистента — 32
          текста, но ряд {L.rows[1].height}: ниже аватара ряд не бывает. Лента прижата книзу, как у
          донора, поэтому пустое место копится сверху — под шапкой карточки, а не между репликами.
        </p>
        <Предупреждения layout={L} />
        <AiChatCard
          label="Остаток контекста"
          value="82%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={МИНИМУМ}
        />
      </div>
    );
  },
};

/* ═══════════════  Потолок числа реплик  ═══════════════ */

const КОРОТКИЕ: ChatMessage[] = [
  { role: "user", text: "Где упал прод-билд?" },
  { role: "assistant", text: "На шаге типов: два импорта из удалённого модуля." },
  { role: "user", text: "Почини и перезапусти." },
  { role: "assistant", text: "Импорты переписаны, сборка зелёная." },
  { role: "user", text: "Отправь в ветку релиза." },
];

const ШЕСТЬ: ChatMessage[] = [
  ...КОРОТКИЕ,
  { role: "assistant", text: "Отправил: release/2026-08, проверки прошли." },
];

/**
 * Потолок ЧИСЛА реплик — и почему у него два значения.
 *
 * `MAX_MESSAGES` = 6 посчитан по самому дешёвому ряду (однострочный ответ
 * ассистента, 44): 44·6 + 24·5 = 384 из 408. Но в живом диалоге реплики
 * чередуются, а пузырь пользователя стоит 64, и тогда потолок падает
 * до пяти. Обе цифры честные, просто про разные ленты — поэтому настоящие
 * ворота не потолок, а `overflow`.
 */
export const ПотолокЧисла: Story = {
  render: () => {
    const L5 = измерить(КОРОТКИЕ);
    const L6 = измерить(ШЕСТЬ);
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Пять чередующихся реплик: {L5.threadHeight} из {L5.available} — запас{" "}
            {L5.available - L5.threadHeight}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Ряды {ряд(L5.rows.map((r) => r.height))}: три пузыря по 64 и два ответа по 44, плюс
            четыре просвета по 24.
          </p>
          <Предупреждения layout={L5} />
          <AiChatCard
            label="Остаток контекста"
            value="41%"
            period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
            messages={КОРОТКИЕ}
          />
        </div>
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Шестая реплика: {L6.threadHeight} из {L6.available} — переполнение {L6.overflow}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Ряд 44 плюс просвет 24 — и лента выходит за поле. Смотреть здесь надо на ВЕРХ: он
            остался на месте. Прижатие книзу при переполнении отключается, иначе верх ушёл бы в
            минус и пропал бы молча — ровно та грабля, из-за которой в проекте появилось `safe`
            центрирование. Обрезается низ, и это видно.
          </p>
          <Предупреждения layout={L6} />
          <AiChatCard
            label="Остаток контекста"
            value="38%"
            period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
            messages={ШЕСТЬ}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Потолок длины реплики  ═══════════════ */

const ДЛИННАЯ =
  "прогони полный аудит дизайн-системы: собери все места, где кегль задан числом вместо токена, все инлайновые тени и все цвета мимо ролей, разложи по файлам и приложи к каждому месту ссылку на строку, а потом предложи порядок починки от самого дешёвого к самому дорогому.";

const ЛЕНТА_4: ChatMessage[] = [
  { role: "user", text: ЗАПРОС },
  {
    role: "assistant",
    text: ОТВЕТ,
    code: {
      language: "TSX",
      file: "theme-toggle.tsx",
      diff: { added: 56, removed: 14 },
      lines: КОД_4,
    },
  },
];

const ЛЕНТА_5: ChatMessage[] = [
  { role: "user", text: ЗАПРОС },
  {
    role: "assistant",
    text: ОТВЕТ,
    code: {
      language: "TSX",
      file: "theme-toggle.tsx",
      diff: { added: 56, removed: 14 },
      lines: КОД_5,
    },
  },
];

const ПЕРЕГРУЗ: ChatMessage[] = [
  { role: "user", text: ДЛИННАЯ },
  {
    role: "assistant",
    meta: "Обдумывал 12,4 с",
    text: ОТВЕТ,
    code: {
      language: "TSX",
      file: "theme-toggle.tsx",
      diff: { added: 56, removed: 14 },
      lines: КОД_4,
    },
  },
];

/**
 * Потолок ДЛИНЫ одной реплики, и почему длинную реплику нельзя обрезать.
 *
 * Первый блок — донорская лента с карточкой кода в пять строк вместо трёх.
 * Одна строка кода стоит 28 точек, и двух хватает, чтобы лента вышла за поле.
 * Второй блок — реплика в пять строк плюс мета-подпись и карточка кода:
 * тут не хватает уже больше сотни.
 *
 * ⚠️ Обратить внимание: текст НЕ обрезан многоточием ни там, ни там.
 * Молчаливая обрезка поставила бы на клиентский слайд утверждение, которого
 * никто не писал, — «…» вместо второй половины требования. Блок вместо
 * этого говорит, на сколько точек он не влез, и решение принимает человек:
 * сократить текст, убрать вложение или отдать переписке два слайда.
 */
export const ПотолокДлины: Story = {
  render: () => {
    const L4 = измерить(ЛЕНТА_4);
    const L5 = измерить(ЛЕНТА_5);
    const LP = измерить(ПЕРЕГРУЗ);
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Пятая строка кода: {L5.threadHeight} из {L5.available} — переполнение {L5.overflow}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Карточка кода растёт на 28 точек за строку: {codeCardHeight(3)} · {codeCardHeight(4)} ·{" "}
            {codeCardHeight(5)}. При донорской реплике в {L5.rows[0].lines} строки лента{" "}
            {L4.threadHeight} на четырёх строках (запас {L4.available - L4.threadHeight}) и{" "}
            {L5.threadHeight} на пяти. То есть объявленный потолок {CODE_MAX_LINES} строк (
            {codeCardHeight(CODE_MAX_LINES)} точек) достижим только у реплики покороче — и это ровно
            тот случай, когда потолок-константа врёт, а `overflow` говорит правду.
          </p>
          <Предупреждения layout={L5} />
          <AiChatCard
            label="Остаток контекста"
            value="57%"
            period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
            messages={ЛЕНТА_5}
            userInitial="M"
          />
        </div>
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Реплика в {LP.rows[0].lines} строк: {LP.threadHeight} из {LP.available} — переполнение{" "}
            {LP.overflow}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Пузырь {LP.rows[0].height} при потолке {MAX_LINES} строк. Ряд ответа {LP.rows[1].height}
            : мета {LP.rows[1].parts.meta} + текст {LP.rows[1].parts.text} + просвет 16 + код{" "}
            {LP.rows[1].parts.code}. Текст цел — обрезан низ карточки кода, и это видно на картинке.
          </p>
          <Предупреждения layout={LP} />
          <AiChatCard
            label="Остаток контекста"
            value="57%"
            period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
            messages={ПЕРЕГРУЗ}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  План: кадр «работа идёт»  ═══════════════ */

const С_ПЛАНОМ: ChatMessage[] = [
  { role: "user", text: "Обнови токены тёмной темы и добавь переключатель." },
  {
    role: "assistant",
    plan: { title: "Осталось 2 шага из 5", steps: ШАГИ.slice(0, 4) },
  },
];

const С_ПЛАНОМ_5: ChatMessage[] = [
  { role: "user", text: "Обнови токены тёмной темы и добавь переключатель." },
  { role: "assistant", plan: { title: "Осталось 2 шага из 5", steps: ШАГИ } },
];

/**
 * Замена донорской анимации: один кадр, в котором видно, что работа идёт.
 *
 * У донора счётчик «N steps left» перещёлкивается прокруткой строк, шаги
 * отмечаются по очереди, рядом крутится спиннер. В PDF остаётся один кадр —
 * значит кадр надо выбрать: часть шагов с галочками, один в контуре, счётчик
 * с конкретным числом. Спиннер не переносится: застывший спиннер сообщает
 * «загрузка сломалась», а не «идёт работа».
 *
 * Донорских шагов пять, и пятый в бюджет уже не влезает — второй блок это
 * показывает числом.
 */
export const План: Story = {
  render: () => {
    const L = измерить(С_ПЛАНОМ);
    const L5 = измерить(С_ПЛАНОМ_5);
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Четыре шага: карточка плана {planCardHeight(4)}, лента {L.threadHeight} из {L.available}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Высота плана — 82 + 48 × шагов: поля 40, заголовок 32, просвет 16, ряды по 40 через 8 и
            две обводки. Три шага с галочками, один в контуре — это и есть «работа идёт». Контур
            акцентный, 4.60 в светлой теме и 6.45 в тёмной; кружок ожидающего шага третичный, 3.33 и
            4.14 при пороге 3 для нетекстовой графики.
          </p>
          <Предупреждения layout={L} />
          <AiChatCard
            label="Осталось шагов"
            value="2"
            period={{ label: "Plan", segments: ["Ask", "Agent", "Plan"] }}
            messages={С_ПЛАНОМ}
          />
        </div>
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Пятый шаг: {planCardHeight(PLAN_MAX_STEPS)}, лента {L5.threadHeight} из {L5.available} —
            переполнение {L5.overflow}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Донорские пять шагов вместе с однострочной репликой пользователя дают {L5.threadHeight}{" "}
            — на {L5.overflow} больше поля. Отсюда практический вывод: донорский план целиком
            помещается только БЕЗ реплики над ним, то есть слайд должен быть про план, а не про
            диалог.
          </p>
          <Предупреждения layout={L5} />
          <AiChatCard
            label="Осталось шагов"
            value="2"
            period={{ label: "Plan", segments: ["Ask", "Agent", "Plan"] }}
            messages={С_ПЛАНОМ_5}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Композер  ═══════════════ */

const С_КОМПОЗЕРОМ: ChatMessage[] = [
  { role: "user", text: "Проверь, что тёмная тема переключается во всех блоках." },
  {
    role: "assistant",
    meta: "Обдумывал 12,4 с",
    text: "Проверил: переключаются все, кроме карточки кода — у неё заливка была прописана числом.",
  },
];

/** Контраст к четырём поверхностям скина: обе карточки и оба холста */
const ПОВЕРХНОСТИ = [
  { label: "карточка светлая #ffffff", hex: "#ffffff" },
  { label: "холст светлый #f7f7f7", hex: "#f7f7f7" },
  { label: "карточка тёмная #262626", hex: "#262626" },
  { label: "холст тёмный #121212", hex: "#121212" },
];

/**
 * Композер и его цена.
 *
 * Композер — единственный «орган управления», который переносится, и это не
 * исключение из правила слайда, а другой случай: он опознавательный знак
 * продукта, как строка адреса в мокапе браузера. Поле ввода — подпись, а не
 * поле: курсора в PDF нет, мигать нечему. Бегущая градиентная обводка донора
 * не переносится — застывший сегмент дуги читается как дефект печати.
 *
 * Цена измерима: 80 капсула + 12 просвет + 32 строка состояния + 24 отбивка
 * от ленты. Это ровно карточка кода в четыре строки.
 *
 * Ниже — замер градиента кнопки отправки. Проверяется не пара концов,
 * а ВЕСЬ ход: `runContrast` из `lib/color.ts` сканирует 101 точку. Класс
 * дефекта «на одном конце проходит, на другом нет» уже стоил слайда
 * в `blocks/layers.tsx`.
 */
export const Композер: Story = {
  render: () => {
    const L = измерить(С_КОМПОЗЕРОМ, { composer: КОМПОЗЕР });
    const слот = cardChartHeight({ legend: false });
    const глифХудший = runContrast(SEND_STOPS, "#ffffff", "#ffffff");
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Композер стоит {COMPOSER_HEIGHT + 24} точек: поле ленты {L.available} вместо {слот}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Лента {L.threadHeight} из {L.available}, запас {L.available - L.threadHeight}. Карточка
          кода в три строки ({codeCardHeight(3)}) сюда уже не встанет — выбирать приходится одно:
          либо композер, либо вложение в ответе.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Капсула 80 — это `rounded-button-xl` системы: радиус 40, ровно половина высоты. Донорские
          52 при окне 1440 после ×1.333 дают 69,3, и ближайшая ступень кнопок вверх — 80. Внутри
          круглые кнопки 56 плюс поля 12 сходятся в те же 80.
        </p>

        <h4 className="text-title-m text-ink mt-8 mb-2">
          Градиент кнопки отправки: {BOARD_HEAT[5]} → {BOARD_HEAT[6]}
        </h4>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Белый глиф вдоль всего хода: верх {contrast(BOARD_HEAT[5], "#ffffff").toFixed(2)}, низ{" "}
          {contrast(BOARD_HEAT[6], "#ffffff").toFixed(2)}, худшая из 101 точки —{" "}
          {глифХудший.toFixed(2)}. Порог для нетекстовой графики 3, берётся везде.
        </p>
        <ul className="text-body-m text-ink-secondary mb-10 flex flex-col gap-2">
          {ПОВЕРХНОСТИ.map((s) => {
            const верх = contrast(BOARD_HEAT[5], s.hex);
            const низ = contrast(BOARD_HEAT[6], s.hex);
            const худший = runContrast(SEND_STOPS, s.hex, s.hex);
            return (
              <li key={s.hex} className="flex gap-3">
                <span className="text-ink-tertiary shrink-0">—</span>
                <span>
                  сама кнопка к «{s.label}»: верх {верх.toFixed(2)}, низ {низ.toFixed(2)}, худшая
                  точка хода {худший.toFixed(2)}
                  {худший < 3 ? " — порог 3 НЕ берётся, кнопку держит белый глиф внутри" : ""}
                </span>
              </li>
            );
          })}
        </ul>

        <Предупреждения layout={L} />
        <AiChatCard
          label="Остаток контекста"
          value="57%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={С_КОМПОЗЕРОМ}
          composer={КОМПОЗЕР}
        />
      </div>
    );
  },
};

/* ═══════════════  Длинные подписи  ═══════════════ */

const ДЛИННЫЕ: ChatMessage[] = [
  { role: "user", text: "Покажи, что осталось." },
  {
    role: "assistant",
    meta: "Обдумывал 12,4 секунды, прочитал 48 файлов проекта, включая все манифесты деков, правила вёрстки, витрины токенов и обе темы, сверил каждое найденное место со шкалой типографики и отдельно проверил, что ни один кегль не задан числом мимо токена",
    plan: {
      title:
        "Осталось два шага из пяти, оба про сборку: прогон реестра компонентов со всеми историями и прод-сборка с проверкой типов, линтером и выгрузкой в PDF на проверку заказчику",
      steps: [
        {
          label:
            "Перечитать все файлы проекта, включая манифесты деков, правила вёрстки, витрины токенов и обе темы, и составить список мест, где кегль, цвет или радиус заданы прямым значением вместо токена системы",
          state: "done",
        },
        { label: "Обновить токены светлой темы", state: "active" },
      ],
    },
  },
];

const ДЛИННЫЙ_КОД: ChatMessage[] = [
  { role: "user", text: "Покажи диф." },
  {
    role: "assistant",
    code: {
      language: "TSX",
      file: "components/theme/registry/reusable-theme-toggle-with-persistence.tsx",
      diff: { added: 156, removed: 23 },
      lines: [
        'export const ThemeToggle = withPersistence(function ThemeToggle({ storageKey = "board-theme", defaultTheme = "system" }: ThemeToggleProps) {',
        "  const { theme, setTheme } = useTheme()",
        "}",
      ],
    },
  },
];

/**
 * Длинные подписи: где блок обрезает, а где предупреждает.
 *
 * Правило разное, и разница не в вежливости, а в том, что за текст.
 *
 * | Что | Поведение | Почему |
 * | --- | --- | --- |
 * | Реплика | переносится целиком, при переполнении предупреждение | это ВЫСКАЗЫВАНИЕ, обрезать нельзя |
 * | Мета, заголовок плана, подпись шага | ряд фиксированной высоты, `truncate` + предупреждение | это ЯРЛЫК, и ряд под него посчитан |
 * | Имя файла в карточке кода | `truncate` | ярлык |
 * | Строка кода | НЕ переносится, предупреждение с числами | перенос кода меняет его смысл |
 *
 * То есть многоточие допустимо только там, где текст служебный и его ряд
 * заранее одной высоты. Реплика в этот список не входит никогда.
 */
export const ДлинныеПодписи: Story = {
  render: () => {
    const L = измерить(ДЛИННЫЕ);
    const LK = измерить(ДЛИННЫЙ_КОД);
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">Ярлыки: обрезаются, но со словами</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Мета, заголовок плана и подпись шага стоят в рядах фиксированной высоты (24, 32, 40) —
            под них место посчитано, и вторая строка туда не влезет физически. Поэтому здесь
            `truncate`, но КАЖДЫЙ случай уходит в предупреждение: обрезанный ярлык должен быть
            замечен, а не пережит.
          </p>
          <Предупреждения layout={L} />
          <AiChatCard
            label="Осталось шагов"
            value="2"
            period={{ label: "Plan", segments: ["Ask", "Agent", "Plan"] }}
            messages={ДЛИННЫЕ}
          />
        </div>
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Строка кода шире поля {Math.round(LK.codeWidth)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Строка кода не переносится: перенос по ширине контейнера меняет вид кода, а на слайде
            выглядит как ошибка. Значит длинная строка уходит за правый край — и блок говорит, на
            сколько именно. Лечится это в данных (сократить строку), а не в вёрстке.
          </p>
          <Предупреждения layout={LK} />
          <AiChatCard
            label="Изменений в ветке"
            value="12"
            period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
            messages={ДЛИННЫЙ_КОД}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Опасный случай  ═══════════════ */

/**
 * Опасный случай: та же переписка в ПОЛОВИНУ ширины.
 *
 * Для линий и столбиков половина карточки — лекарство: поле 788 × 316 даёт
 * пропорцию 2.49:1, почти донорскую, а полная ширина — 5.66:1 (разбор
 * в шапке `shell.tsx`). Для переписки всё наоборот, и это ровно то же
 * правило с другой стороны: переписка — форма СПИСОЧНАЯ, ей нужна длина
 * строки, а не пропорция поля.
 *
 * Числа ниже показывают цену: колонка содержимого падает почти вдвое,
 * донорский запрос разъезжается на вдвое большее число строк, а поле кода
 * перестаёт держать даже короткую строку.
 *
 * Вывод для слайда: переписка ставится во всю рабочую ширину. Если рядом
 * нужна вторая карточка — это два слайда, а не два столбца.
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const Lfull = измерить(ЛЕНТА);
    const Lhalf = измерить(ЛЕНТА, { half: true, width: 828 });
    return (
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">
          Половина ширины: колонка {Lhalf.columnWidth} вместо {Lfull.columnWidth}, пузырь{" "}
          {Lhalf.bubbleMax} вместо {Lfull.bubbleMax}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Донорский запрос: {Lhalf.rows[0].lines} строк вместо {Lfull.rows[0].lines}, пузырь{" "}
          {Lhalf.rows[0].height} вместо {Lfull.rows[0].height}. Донорский ответ:{" "}
          {Lhalf.rows[1].lines} строк вместо {Lfull.rows[1].lines}. Поле ленты {Lhalf.available}{" "}
          (половинная карточка выше по слоту: поля 20 вместо 36), лента {Lhalf.threadHeight} —
          переполнение {Lhalf.overflow}. Поле кода {Math.round(Lhalf.codeWidth)} против{" "}
          {Math.round(Lfull.codeWidth)}.
        </p>
        <Предупреждения layout={Lhalf} />
        <AiChatCard
          size="half"
          width={828}
          label="Остаток контекста"
          value="57%"
          period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
          messages={ЛЕНТА}
          userInitial="M"
        />
      </div>
    );
  },
};

/* ═══════════════  Как на слайде  ═══════════════ */

const СЛАЙД: ChatMessage[] = [
  {
    role: "user",
    text: "Обнови токены тёмной темы и добавь переиспользуемый переключатель, потом прогони линтер и прод-сборку.",
  },
  {
    role: "assistant",
    text: "Готово: семантические токены тёмной темы и переключатель собраны. Переключатель меняет тему из одного места и запоминает выбор.",
    code: {
      language: "TSX",
      file: "theme-toggle.tsx",
      diff: { added: 56, removed: 14 },
      lines: КОД_3,
    },
  },
];

/**
 * Как на слайде: карточка в `ContentSlide` при бюджете 604.
 *
 * ⚠️ 604 — это бюджет при заголовке В ОДНУ СТРОКУ. Замер шапки слайда: поле
 * сверху 88 + пилюля 40 + просвет 24 + заголовок 60 + просвет 24 + лид 32 +
 * отбивка 64 = 332; снизу поле 88 и резерв под подвал 56. Карточка встаёт на
 * 332…936, подвал начинается на 972. Заголовок в две строки означает
 * `height={544}`, иначе низ карточки уедет под подпись — дефект, которого не
 * видит ни одна автопроверка (боксы не пересекаются, холст не превышен).
 *
 * Заголовок формулирует мысль и ПРОВЕРЯЕМ по самой карточке: одна реплика
 * пользователя, один ответ, 56 добавленных строк и 14 убранных.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Как это выглядит в работе"
      title="Одна фраза заказчика — и правка уже в ветке"
      lead="Слева агент, справа человек: между запросом и готовым файлом ничего больше нет."
      page={9}
      label="Демо · карточки дашборда"
    >
      <AiChatCard
        label="Остаток контекста"
        value="57%"
        period={{ label: "Agent", segments: ["Ask", "Agent", "Plan"] }}
        messages={СЛАЙД}
      />
    </ContentSlide>
  ),
};
