import { useEffect, useRef, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import AgentThinkingCard, {
  AgentStatusLine,
  agentCardGeometry,
  agentMessageHeight,
  agentMessagesHeight,
  type AgentMessage,
} from "../../../blocks/cards/agentThinkingCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * «Индикатор работы» — перенос донорского индикатора обдумывания.
 *
 * === Читать до того, как оценивать историю ===
 *
 * У донора это анимированный индикатор: бегущий по буквам блик, мерцающие
 * искры, комета на восьмёрке, тикающий таймер. В PDF не остаётся ничего из
 * перечисленного. Поэтому перенесена СТРОКА СОСТОЯНИЯ — значок, подпись,
 * зафиксированная длительность, — а не индикатор. Полный разбор, что именно
 * потеряно и почему ни один кадр анимации не заморожен, — в шапке
 * `blocks/cards/agentThinkingCard.tsx`.
 *
 * Строка сама по себе — 36 точек высотой. Самостоятельным блоком на холсте
 * 1920×1080 она быть не может, поэтому едет на слайд внутри мокапа панели
 * ассистента: слайд показывает продукт, а не измеряет величину.
 *
 * ⚠️ Замеры делать в 1:1. Истории без `slide: true` витрина не масштабирует,
 * поэтому в них `getBoundingClientRect` честен; истории «Как на слайде»
 * масштабируются — для их замеров переключить тулбар «Масштаб» на «1:1».
 */

const meta = {
  title: "Карточки/Индикатор работы",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

/**
 * Реплика пользователя — донорская, из превью-чата страницы индикатора обдумывания:
 * «Redesign the pricing page hero and tighten the CTA copy». Переведена, а не
 * выдумана: это единственный текст переписки, который у донора есть.
 */
const ПЕРЕПИСКА: AgentMessage[] = [
  {
    from: "user",
    text: "Пересобери первый экран страницы тарифов и подтяни текст призыва — сейчас он длиннее кнопки и не помещается на телефоне.",
  },
  {
    from: "agent",
    text: "Понял. Смотрю текущий макет, тексты призыва в трёх тарифах и то, как первый экран ведёт себя на ширине 390.",
  },
  { from: "user", text: "Заодно проверь, что заголовок не переносится на двух строках." },
];

const ЛИНИИ_ПЕРЕПИСКИ = [2, 2, 1];

/* ───────────── линейка ───────────── */

/**
 * Оборачивает карточку и печатает её ФАКТИЧЕСКИЕ размеры плюс худшее
 * переполнение внутри неё. Пороги те же, что в `layout-verification.md`:
 * 16 по высоте (ниже — выносные элементы шрифта) и 4 по ширине. Считаются
 * только контейнеры, иначе каждая строка текста даёт ложное срабатывание.
 *
 * ⚠️ ТРЕТЬЯ МЕРКА — «вверх», и она добавлена не для полноты.
 *
 * `scrollHeight − clientHeight` видит переполнение ТОЛЬКО ВНИЗ. Лента реплик
 * прижата книзу (`justify-end`), поэтому лишняя реплика уходит ВВЕРХ, и обе
 * привычные мерки остаются нулями: замер на опасном случае № 2 дал
 * `scrollHeight − clientHeight = 0` при 184 точках содержимого, вылезшего
 * над лентой, и 84 точках, вылезших за верхний край самой карточки.
 *
 * Это ровно тот класс дефекта, про который предупреждает
 * `.claude/rules/layout-verification.md`: зелёный результат негодного
 * инструмента хуже отсутствия проверки. Мерка «вверх» считает, насколько
 * верх первого потомка выше верха своего контейнера.
 */
function Линейка({ children }: { children: React.ReactNode }) {
  const box = useRef<HTMLDivElement>(null);
  const [итог, setИтог] = useState("замер после отрисовки");

  useEffect(() => {
    const el = box.current;
    const card = el?.firstElementChild as HTMLElement | null;
    if (!card) return;
    const id = requestAnimationFrame(() => {
      const r = card.getBoundingClientRect();
      const boxes = [card, ...card.querySelectorAll("*")].filter((e) => e.children.length);
      const dy = Math.max(...boxes.map((e) => e.scrollHeight - e.clientHeight));
      const dx = Math.max(...boxes.map((e) => e.scrollWidth - e.clientWidth));
      /* Переполнение ВВЕРХ: scrollHeight его не видит, см. шапку линейки */
      const up = Math.max(
        0,
        ...boxes.map((e) => {
          const top = e.getBoundingClientRect().top;
          const kids = [...e.children].filter(
            (k) => getComputedStyle(k).position !== "absolute",
          ) as HTMLElement[];
          return Math.max(0, ...kids.map((k) => top - k.getBoundingClientRect().top));
        }),
      );
      const scaled = card.closest(".slide-canvas");
      setИтог(
        `${Math.round(r.width)} × ${Math.round(r.height)} · ` +
          `переполнение по высоте ${dy} (порог 16), по ширине ${dx} (порог 4), ` +
          `вверх ${Math.round(up)} (порог 0)` +
          (scaled ? " · холст масштабирован, мерить в 1:1" : ""),
      );
    });
    return () => cancelAnimationFrame(id);
  });

  return (
    <div ref={box}>
      {children}
      <p className="text-body-m text-ink-secondary mt-4 tabular-nums">{итог}</p>
    </div>
  );
}

/* ───────────── строка отдельно ───────────── */

/**
 * Сама строка состояния — то, во что превратился донорский индикатор.
 *
 * Здесь видно главное: работу обозначает СЛОВО, а не рисунок. Значок
 * называет участника, длительность — цену ожидания. Ни точек-волны, ни
 * кометы, ни многоточия.
 *
 * Замеры подписей (WCAG; кегль подписи 30 — крупный, порог 3, но взят
 * строгий 4.5, потому что длительность рядом набрана кеглем 24):
 *
 *   подпись `ink-secondary` на карточке    светлая 5.41   тёмная 6.00
 *   подпись `accent-fg` на карточке        светлая 5.25   тёмная 5.73
 *   подпись `success-fg` на карточке       светлая 5.48   тёмная 6.82
 *   подпись `error-fg` на карточке         светлая 5.72   тёмная 5.42
 *   длительность `ink-tertiary` на карточке светлая 3.79  тёмная 3.68
 *
 * Длительность — единственное место, где взят третичный цвет, и кегль у неё
 * ровно 24: порог системы, ниже которого третичный запрещён.
 */
export const Строка: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Три состояния</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Состояний три, а не одно, и это не расширение донора за компанию. Статичный кадр процесса
          честен только тогда, когда состояние названо: если «работает» — единственно возможное
          значение, то подпись со значком превращаются в украшение, а слайд получает вечно висящий
          индикатор.
        </p>
        <div className="bg-surface rounded-hero flex flex-col gap-6 p-9">
          <AgentStatusLine state="work" duration="7,0 с" />
          <AgentStatusLine state="done" duration="12,4 с" />
          <AgentStatusLine state="fail" label="Не удалось прочитать макет" duration="3,1 с" />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Тон и градиент подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Донорский «shimmer» — блик, бегущий по буквам. Неподвижный кадр этого блика существовать
          может, а вот донорский рецепт цвета — нет: концы градиента у него залиты тоном с
          непрозрачностью 0.55, и это 2.24 на белой карточке при пороге 3. У бегущего блика слабый
          конец не задерживался на букве, у застывшего — остаётся навсегда. Поэтому ход градиента
          взят между двумя ролями текста, вторичной и основной: худшая точка 5.41 на карточке и 4.75
          на композере, то есть не хуже обычной вторичной подписи.
        </p>
        <div className="bg-surface rounded-hero flex flex-col gap-6 p-9">
          <AgentStatusLine state="work" duration="7,0 с" />
          <AgentStatusLine state="work" duration="7,0 с" gradient />
          <AgentStatusLine state="work" tone="accent" duration="7,0 с" />
          <AgentStatusLine
            state="work"
            tone="accent"
            gradient
            label="Акцент + градиент: градиент игнорируется"
            duration="7,0 с"
          />
          <AgentStatusLine
            state="work"
            gradient
            label="Сверяю тексты призыва в трёх тарифах с гайдлайном"
            duration="7,0 с"
          />
        </div>
        <p className="text-body-l text-ink mt-6 max-w-5xl">
          ⚠️ Смотреть на вторую и последнюю строки — и не соглашаться с градиентом заранее. Осмотр в
          обеих темах: на короткой подписи «Работает над ответом» (304 точки) яркая середина
          приходится ровно на одно слово, и это читается как случайно выделенное «над», а не как
          приём. На длинной подписи (740 точек) переход растянут и накрывает два-три слова — мягче,
          но сутью не отличается: неподвижный градиент на тексте всё равно читается как выделение
          середины фразы, а не как след блика. Поэтому градиент оставлен опцией и выключен по
          умолчанию; ставить его на клиентский слайд стоит только если заказчик прямо просит след
          донорского «shimmer» и согласен с тем, как это выглядит без движения.
        </p>
      </div>
    </div>
  ),
};

/* ───────────── типовой случай ───────────── */

/**
 * Типовой случай — мокап панели во всю рабочую ширину.
 *
 * Ответа ассистента после последней реплики нет, и это не пропуск: он и не
 * должен был появиться, состояние «работает» ровно про это. Строка стоит
 * там же, где у донора, — между перепиской и композером.
 */
export const Карточка: Story = {
  render: () => <КарточкаВид />,
};

function КарточкаВид() {
  const g = agentCardGeometry();
  const занято = agentMessagesHeight(ЛИНИИ_ПЕРЕПИСКИ);
  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Внутри полей {g.inner}: шапка {g.chrome}, просвет {g.rowGap}, переписка {g.conversation},
        просвет {g.rowGap}, строка состояния {g.status}, просвет {g.statusGap}, композер{" "}
        {g.composer}. Три реплики ({ЛИНИИ_ПЕРЕПИСКИ.join(" + ")} строки) занимают {занято} из{" "}
        {g.conversation} — остаётся {g.conversation - занято}. Пузырь шире 76% ширины панели не
        растёт: реплика во всю ширину перестаёт читаться как реплика.
      </p>
      <Линейка>
        <AgentThinkingCard
          title="Ассистент"
          caption="Страница тарифов · черновик 4"
          messages={ПЕРЕПИСКА}
          duration="7,0 с"
        />
      </Линейка>
      <p className="text-body-l text-ink mt-8 max-w-5xl">
        Что здесь НЕ нарисовано и почему: бегущий блик подписи, мерцающие искры, комета на
        восьмёрке, точки-волна, тикающий таймер, курсор в поле ввода. Всё это в PDF мертво, а
        застывший кадр любого из них читается как зависший интерфейс, а не как идущая работа. Кнопка
        отправки оставлена: в отличие от шеврона у подписи периода в `shell.tsx`, она ничего не
        прячет — это часть изображаемого композера, а не обещание выпадающего списка.
      </p>
    </div>
  );
}

/* ───────────── обе темы ───────────── */

/**
 * Обе темы рядом — вложенной темой, без переключения тулбара.
 *
 * Смотреть надо на три вещи: пузырь пользователя (роль `action`
 * переворачивается — чёрный в светлой, белый в тёмной), подложку композера
 * и длительность третичным цветом.
 *
 * Замеры на подложке композера `surface-muted`:
 *
 *   подсказка `ink-tertiary` 24     светлая 3.33   тёмная 4.14
 *   подпись градиентом, худшая точка светлая 4.75   тёмная 6.76
 *
 * Подсказка в светлой теме — 3.33 при пороге 3 для кегля 24. Запас
 * маленький, и это осознанно: подсказка в поле ввода обязана быть тише
 * настоящего текста, а тише вторичного в системе только третичный. Ставить
 * её мельче 24 нельзя — там третичный запрещён вовсе.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div className="bg-canvas rounded-hero p-9" data-theme="light">
        <h3 className="text-title-l text-ink mb-6">Светлая</h3>
        <AgentThinkingCard
          theme="light"
          title="Ассистент"
          caption="Страница тарифов · черновик 4"
          messages={ПЕРЕПИСКА}
          duration="7,0 с"
        />
      </div>
      <div className="bg-canvas rounded-hero p-9" data-theme="dark">
        <h3 className="text-title-l text-ink mb-6">Тёмная</h3>
        <AgentThinkingCard
          theme="dark"
          title="Ассистент"
          caption="Страница тарифов · черновик 4"
          messages={ПЕРЕПИСКА}
          duration="7,0 с"
        />
      </div>
    </div>
  ),
};

/* ───────────── половина ширины ───────────── */

/**
 * Две панели рядом — `size="half"`, колонка 828.
 *
 * Половина здесь работает лучше, чем у графиков: у ленты реплик нет
 * пропорции, которую можно испортить, а узкая колонка ближе к настоящей
 * панели ассистента, чем полоса в 1680 точек. Цена — реплики переносятся
 * чаще, поэтому потолок переписки ниже.
 */
export const Половина: Story = {
  render: () => <ПоловинаВид />,
};

function ПоловинаВид() {
  const g = agentCardGeometry({ size: "half" });
  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Две колонки по 828</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Переписке остаётся {g.conversation} — на {g.conversation - agentCardGeometry().conversation}{" "}
        больше, чем во всю ширину: поле карточки меньше на 16 сверху и снизу. Слева — работа идёт,
        справа — она закончилась; вторая панель показывает, что строка состояния не привязана к
        одному значению.
      </p>
      <div className="slide-grid">
        <div className="col-span-6">
          <Линейка>
            <AgentThinkingCard
              size="half"
              title="Ассистент"
              messages={[ПЕРЕПИСКА[0], ПЕРЕПИСКА[1]]}
              duration="7,0 с"
            />
          </Линейка>
        </div>
        <div className="col-span-6">
          <Линейка>
            <AgentThinkingCard
              size="half"
              title="Ассистент"
              messages={[
                ПЕРЕПИСКА[0],
                { from: "agent", text: "Готово: первый экран пересобран, призыв — 24 знака." },
              ]}
              state="done"
              duration="12,4 с"
            />
          </Линейка>
        </div>
      </div>
    </div>
  );
}

/* ───────────── крайние случаи ───────────── */

/**
 * Крайние случаи: минимум, потолок, длинные подписи, опасный случай.
 *
 * ⚠️ Последняя карточка раздела переполняется НАМЕРЕННО — это и есть
 * опасный случай. Линейка под ней обязана показать число больше порога 16;
 * если она показывает ноль, сломана линейка, а не карточка.
 */
export const КрайниеСлучаи: Story = {
  render: () => <КрайниеСлучаиВид />,
};

function КрайниеСлучаиВид() {
  const g = agentCardGeometry();
  const без = agentCardGeometry({ chrome: false });
  const потолок = agentMessagesHeight(ЛИНИИ_ПЕРЕПИСКИ);
  const перебор = agentMessagesHeight([...ЛИНИИ_ПЕРЕПИСКИ, 2, 2]);

  return (
    <div className="flex w-[1680px] flex-col gap-16">
      <div>
        <h3 className="text-title-l text-ink mb-2">Минимум: только строка и поле ввода</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Ни шапки, ни переписки, ни длительности — панель только что открыта. Переписке достаётся{" "}
          {без.conversation} пустых точек, и это не схлопывание: лента держит остаток высоты, а
          композер остаётся прижат книзу. Высота карточки взята 320, чтобы пустота не занимала
          пол-экрана витрины.
        </p>
        <Линейка>
          <AgentThinkingCard height={320} />
        </Линейка>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">
          Потолок переписки: {потолок} из {g.conversation}
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Три реплики в {ЛИНИИ_ПЕРЕПИСКИ.join(" + ")} строки — предел для полной ширины с шапкой.
          Четвёртая двухстрочная добавила бы {agentMessageHeight(2) + 16} и вывела бы ленту за
          остаток. Считать это надо заранее — `agentCardGeometry` и `agentMessagesHeight`, — а не
          узнавать на показе.
        </p>
        <Линейка>
          <AgentThinkingCard
            title="Ассистент"
            caption="Страница тарифов · черновик 4"
            messages={ПЕРЕПИСКА}
            duration="7,0 с"
          />
        </Линейка>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Подпись состояния, подпись шапки и текст-подсказка обрезаются многоточием, а не
          переносятся: строка состояния имеет фиксированную высоту 36, и вторая строка вытолкнула бы
          композер. Длительность не обрезается никогда — она справа и с `shrink-0`, иначе первым
          пропало бы число, а не текст.
        </p>
        <Линейка>
          <AgentThinkingCard
            title="Ассистент"
            caption="Страница тарифов, черновик 4, ветка эксперимента с годовой подпиской и скидкой за два места"
            messages={[ПЕРЕПИСКА[0]]}
            label="Сверяю тексты призыва в трёх тарифах с гайдлайном и проверяю длину строки на ширине 390"
            duration="128,7 с"
            placeholder="Опишите задачу: что поменять, где посмотреть исходники, к какому сроку нужен черновик"
          />
        </Линейка>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Опасный случай № 1: подпись обещает движение</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Слева — то, чего в этом компоненте быть не должно, справа — как правильно. Многоточие
          «Думает…» — такое же обещание анимации, как пунктир, точки-волна или застывшая комета
          спиннера: в живом интерфейсе точки набегают, в PDF они просто висят, и строка читается как
          зависшая. Компонент это НЕ запрещает технически — подпись задаёт слайд, — поэтому запрет
          записан здесь.
        </p>
        <div className="bg-surface rounded-hero grid grid-cols-2 gap-6 p-9">
          <div className="flex flex-col gap-4">
            <span className="text-body-m text-error-fg">✗ так нельзя</span>
            <AgentStatusLine label="Думает…" />
            <AgentStatusLine label="Загрузка · · ·" />
          </div>
          <div className="flex flex-col gap-4">
            <span className="text-body-m text-success-fg">✓ так правильно</span>
            <AgentStatusLine label="Работает над ответом" duration="7,0 с" />
            <AgentStatusLine label="Читает 14 файлов проекта" duration="7,0 с" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">
          Опасный случай № 2: реплик больше, чем влезает
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Пять реплик занимают {перебор} при остатке {g.conversation} — перебор{" "}
          {перебор - g.conversation}. Лента не прокручивается и не сжимает пузыри, а лишнее уходит
          ВВЕРХ: реплики наезжают на шапку мокапа и вылезают за верхний край карточки. Замер: 184
          точки над лентой, 84 за кромкой карточки.
          <br />
          ⚠️ И вот главное, ради чего этот случай стоит в витрине: привычная мерка переполнения его
          НЕ ВИДИТ. `scrollHeight − clientHeight` у ленты равен нулю, потому что содержимое вылезло
          вверх, а не вниз. Поэтому линейка считает третье число — «вверх», — и только оно здесь
          отличается от нуля. Лечится как всегда: меньше содержимого или больше высоты, а не мельче
          кегль.
        </p>
        <Линейка>
          <AgentThinkingCard
            title="Ассистент"
            caption="Страница тарифов · черновик 4"
            messages={[
              ...ПЕРЕПИСКА,
              {
                from: "agent",
                text: "Проверил: заголовок на 390 переносится на две строки, потому что в нём 38 знаков против 31 помещающихся.",
              },
              {
                from: "user",
                text: "Тогда сократи заголовок и покажи два варианта — с ценой в подзаголовке и без неё.",
              },
            ]}
            duration="7,0 с"
          />
        </Линейка>
      </div>
    </div>
  );
}

/* ───────────── геометрия ───────────── */

/**
 * Раскладка числами — чтобы её сверяли, а не оценивали на глаз.
 *
 * Все ряды, кроме переписки, фиксированы, поэтому переписке достаётся точный
 * остаток. Таблицу считает тот же `agentCardGeometry`, по которому строится
 * сама карточка, — разойтись с ней она не может.
 */
export const Геометрия: Story = {
  render: () => {
    const rows = [
      { size: "full", chrome: true, height: CARD_BUDGET },
      { size: "full", chrome: false, height: CARD_BUDGET },
      { size: "half", chrome: true, height: CARD_BUDGET },
      { size: "half", chrome: false, height: CARD_BUDGET },
      { size: "full", chrome: true, height: 544 },
      { size: "half", chrome: true, height: 320 },
    ] as const;

    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">Что получится при разной высоте</h3>
        <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
          Столбец «переписка» — единственный, который меняется: остальные ряды заданы кеглями и
          полями системы. Строка «544» — случай слайда с заголовком в две строки; «320» — компактная
          панель без переписки.
        </p>
        <table className="text-body-l text-ink w-full tabular-nums">
          <thead className="text-body-m text-ink-secondary">
            <tr>
              {[
                "карточка",
                "высота",
                "поле",
                "внутри",
                "шапка",
                "переписка",
                "строка",
                "композер",
                "реплик по 2 строки",
              ].map((h) => (
                <th key={h} className="border-line border-b py-3 text-left font-normal">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const g = agentCardGeometry(r);
              let n = 0;
              while (agentMessagesHeight(Array<number>(n + 1).fill(2)) <= g.conversation) n++;
              return (
                <tr key={`${r.size}-${r.chrome}-${r.height}`}>
                  <td className="border-line border-b py-3">
                    {r.size === "full" ? "1680 полная" : "828 половина"}
                  </td>
                  <td className="border-line border-b py-3">{r.height}</td>
                  <td className="border-line border-b py-3">{g.pad}</td>
                  <td className="border-line border-b py-3">{g.inner}</td>
                  <td className="border-line border-b py-3">{g.chrome || "нет"}</td>
                  <td className="border-line border-b py-3">{g.conversation}</td>
                  <td className="border-line border-b py-3">{g.status}</td>
                  <td className="border-line border-b py-3">{g.composer}</td>
                  <td className="border-line border-b py-3">{n}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  },
};

/* ═══════════════  На слайде  ═══════════════ */

/**
 * Мокап внутри ContentSlide — проверка бюджета 604.
 *
 * Шапка слайда (пилюля, заголовок в одну строку, лид) забирает 244, подвал
 * резервирует 56, блоку остаётся ровно 604. Карточка берёт весь бюджет.
 *
 * Заголовок формулирует мысль, а не называет тему: мысль здесь — «ассистент
 * показывает, чем занят», и мокап её доказывает. Аналитического смысла у
 * блока нет и приписывать его нельзя: он ничего не измеряет.
 *
 * ⚠️ Заголовок в ДВЕ строки съедает ещё 60 — тогда `height={544}`, и при
 * этой высоте переписке остаётся 236 вместо 296. Три реплики (288) туда уже
 * не влезут, надо снимать одну. Проверено дважды: сначала в истории «Обе
 * темы» высота была срезана до 520 «чтобы витрина была компактнее», и лента
 * вылезла на 76 точек вверх — молча, потому что привычная мерка переполнения
 * смотрит только вниз. Высоту вернули на бюджет.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Продукт"
      title="Ассистент говорит, чем занят, и сколько это уже длится"
      lead="Строка состояния стоит над полем ввода: значок, подпись, время работы"
      page={12}
      label="Витрина карточек"
    >
      <AgentThinkingCard
        title="Ассистент"
        caption="Страница тарифов · черновик 4"
        messages={ПЕРЕПИСКА}
        duration="7,0 с"
      />
    </ContentSlide>
  ),
};

/**
 * То же на тёмном слайде: панель берёт тему слайда, своей не задаёт.
 *
 * Пузырь пользователя здесь белый — роль `action` перевёрнута темой. Это
 * тот случай, ради которого роль вообще перевёрнута: чёрный пузырь на
 * тёмной панели был бы дырой.
 */
export const НаТёмномСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Продукт"
      title="Ассистент говорит, чем занят, и сколько это уже длится"
      lead="Та же панель в тёмной теме: пузырь пользователя переворачивается вместе с ролью действия"
      page={13}
      label="Витрина карточек"
    >
      <AgentThinkingCard
        title="Ассистент"
        caption="Страница тарифов · черновик 4"
        messages={ПЕРЕПИСКА}
        duration="7,0 с"
      />
    </ContentSlide>
  ),
};
