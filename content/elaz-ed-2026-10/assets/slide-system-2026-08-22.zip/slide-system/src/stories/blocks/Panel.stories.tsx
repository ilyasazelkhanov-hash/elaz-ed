import type { Meta, StoryObj } from "@storybook/react-vite";
import { BarChart } from "../../blocks/charts";
import { HeatLattice } from "../../blocks/lattice";
import { DeltaPill, MetricPanel, metricPanelSlot } from "../../blocks/panel";

/**
 * Панель показателя.
 *
 * Приём перенесён из админского дашборда: показатель, его изменение и его
 * график лежат в ОДНОЙ карточке и читаются как один объект, а не как три
 * соседа. До сих пор в проекте график стоял на слайде голым — число «сколько
 * всего» уезжало в заголовок слайда, то есть на другой смысловой уровень.
 *
 * Данные здесь демонстрационные и намеренно НЕ совпадают с числами реальных
 * деков: витрина показывает поведение блока, а не содержание презентации.
 * Совпадающие числа рано или поздно начинают жить своей жизнью и расходятся
 * с data/*.
 *
 * === Что смотреть в обеих темах ===
 *
 * Панель по умолчанию белая (surface) с волосяным контуром. В скине board
 * заливка и контур работают в обеих темах, но разница заливок очень мала:
 * surface #ffffff против холста #f7f7f7 — это 1.07:1 в светлой, #262626
 * против #121212 — 1.24:1 в тёмной. Контур (--t-line) добавляет 1.19:1
 * и 1.13:1 к своей карточке. Всё это ниже порога 3:1 для нетекстовой
 * графики — так устроен донор, зафиксировано в themes.css.
 *
 * (До скина board surface и canvas в светлой теме были ОБА #ffffff, и
 * контур оставался единственным признаком панели. Теперь признака два,
 * но оба слабые.)
 */
const meta = {
  title: "Блоки/Панель показателя",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* Демонстрационные ряды. Числа выдуманные, ни к какому деку не относятся */

const REVENUE = [
  { label: "Янв", value: 318 },
  { label: "Фев", value: 342 },
  { label: "Мар", value: 361 },
  { label: "Апр", value: 402 },
  { label: "Май", value: 455 },
  { label: "Июн", value: 493, highlight: true },
];

const MONTHS = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"];

export const ТриНаполнения: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Со столбиками</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Полная панель: подпись показателя, подпись выбранного периода справа, крупное число с
          пилюлей изменения в одну строку и график во всю ширину карточки. Высота графика не
          подобрана, а посчитана: metricPanelSlot(«l») даёт 377 — это 604 доступных минус 227
          обвязки панели, — а у BarChart собственная обвязка ещё 70, отсюда height 307. Замер
          собранной панели: 603,5 при бюджете 604.
        </p>
        <MetricPanel
          label="Выручка"
          period="Помесячно"
          value="2 946 800 ₽"
          delta={{ value: "+11,4%", tone: "good" }}
        >
          <BarChart
            data={REVENUE}
            height={metricPanelSlot("l") - 70}
            formatValue={(v) => `${v} тыс.`}
          />
        </MetricPanel>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">С тепловой решёткой</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Тот же слот принимает любой блок проекта. Решётке передан тот же бюджет 377 — она сама
          вычитает из него свою строку заголовков и строку подписи шкалы. Ячейки внутри панели
          выходят на ~5 точек выше своей ширины: HeatLattice считает сторону от полной рабочей
          ширины слайда (1680), а в панели у неё на 64 точки меньше — на поля карточки. Это
          оговорено в шапке самой решётки и на чтение не влияет.
        </p>
        <MetricPanel
          label="Дни с релизами"
          period="12 месяцев"
          value="184 дня"
          delta={{ value: "+23 дня", tone: "good" }}
        >
          <HeatLattice
            budgetHeight={metricPanelSlot("l")}
            columns={MONTHS}
            rows={[
              { label: "Платформа", values: [4, 6, 5, 9, 7, 11, 8, 6, 12, 10, 7, 5] },
              { label: "Мобильное", values: [2, 3, 1, 4, 6, 5, 3, 2, 7, 6, 4, 3] },
              { label: "Интеграции", values: [1, 0, 2, 3, 2, 4, 5, 3, 6, 4, 2, null] },
            ]}
          />
        </MetricPanel>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">С пустым слотом</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Без содержимого панель не оставляет висящего снизу воздуха: отбивка под слот задана на
          самом слоте, а не на строке с числом. Так панель годится и как крупная плитка показателя —
          например, рядом с панелью, у которой график есть.
        </p>
        <div className="grid grid-cols-2 gap-6">
          <MetricPanel
            label="Средний чек"
            period="Квартал"
            value="4 180 ₽"
            delta={{ value: "+2,6%", tone: "good" }}
          />
          <MetricPanel label="Активных договоров" period="Квартал" value="1 207" />
        </div>
      </section>
    </div>
  ),
};

export const ВРяду: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Две в ряд — размер «l»</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Панель шириной 828: число остаётся в display-s (72). Обе панели держат одну высоту — не
          потому, что так вышло, а потому, что шапке задан пол в 40 точек: панель без подписи
          периода иначе получила бы шапку на 8 точек ниже, и числа встали бы на разной высоте.
        </p>
        <div className="grid grid-cols-2 gap-6">
          <MetricPanel
            label="Выручка"
            period="Помесячно"
            value="2 946 800 ₽"
            delta={{ value: "+11,4%", tone: "good" }}
          >
            <BarChart data={REVENUE} height={200} formatValue={(v) => `${v} тыс.`} />
          </MetricPanel>
          <MetricPanel label="Новые клиенты" value="1 207" delta={{ value: "+8,1%", tone: "good" }}>
            <BarChart
              mode="series"
              data={[
                { label: "Прямые", value: 512 },
                { label: "Партнёры", value: 348 },
                { label: "Реклама", value: 221 },
                { label: "Прочее", value: 126 },
              ]}
              height={200}
            />
          </MetricPanel>
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Три в ряд — размер «m»</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Панель шириной 544. Число уходит на ступень ниже, в headline-l (56), подпись — в body-m
          (20). Отношение числа к подписи при этом сохраняется: 2,80 против 2,77 у размера «l».
          Оставить display-s означало бы получить перенос длинного числа на вторую строку — и
          разъехавшиеся по высоте панели.
        </p>
        <div className="grid grid-cols-3 gap-6">
          <MetricPanel
            size="m"
            label="Заказы"
            period="Неделя"
            value="1 394"
            delta={{ value: "+4,2%", tone: "good" }}
          >
            <BarChart
              data={[
                { label: "Пн", value: 182 },
                { label: "Вт", value: 214 },
                { label: "Ср", value: 196 },
                { label: "Чт", value: 235 },
                { label: "Пт", value: 268, highlight: true },
              ]}
              height={150}
            />
          </MetricPanel>
          <MetricPanel
            size="m"
            label="Возвраты"
            period="Неделя"
            value="38"
            delta={{ value: "−1,9%", tone: "good" }}
          >
            <BarChart
              data={[
                { label: "Пн", value: 9 },
                { label: "Вт", value: 7 },
                { label: "Ср", value: 8 },
                { label: "Чт", value: 6 },
                { label: "Пт", value: 8 },
              ]}
              height={150}
            />
          </MetricPanel>
          <MetricPanel
            size="m"
            label="Отказы оплаты"
            period="Неделя"
            value="52"
            delta={{ value: "+6,7%", tone: "bad" }}
          >
            <BarChart
              data={[
                { label: "Пн", value: 8 },
                { label: "Вт", value: 9 },
                { label: "Ср", value: 11 },
                { label: "Чт", value: 10 },
                { label: "Пт", value: 14, highlight: true },
              ]}
              height={150}
            />
          </MetricPanel>
        </div>
      </section>
    </div>
  ),
};

export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Знак и оценка — разные вещи</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Цвет пилюли задаётся признаком tone, а не знаком числа. Слева минус означает хорошую
          новость — время ответа упало; справа плюс означает плохую — отток вырос. Вывести цвет из
          знака значит время от времени красить хорошую новость красным, причём молча.
        </p>
        <div className="grid grid-cols-3 gap-6">
          <MetricPanel
            size="m"
            label="Время первого ответа"
            period="Месяц"
            value="1 ч 12 мин"
            delta={{ value: "−38,0%", tone: "good" }}
          />
          <MetricPanel
            size="m"
            label="Отток"
            period="Месяц"
            value="3,4%"
            delta={{ value: "+0,9 п.п.", tone: "bad" }}
          />
          <MetricPanel
            size="m"
            label="Доля повторных покупок"
            period="Месяц"
            value="41,8%"
            delta={{ value: "0,00%", tone: "flat" }}
          />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Длинная подпись показателя</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Подпись не обрезается — потерянный на клиентском слайде текст не восстановить. Цена в том,
          что перенос на вторую строку опускает число: замер средней панели против соседних даёт
          шапку 56 вместо 40 и число на 16 точек ниже. Лечится КОРОТКОЙ подписью, а не уменьшением
          кегля — мельче body-m на слайде уже не читают.
        </p>
        <div className="grid grid-cols-3 gap-6">
          <MetricPanel
            size="m"
            label="Заказы"
            period="Год"
            value="14 592"
            delta={{ value: "+3,1%", tone: "good" }}
          />
          <MetricPanel
            size="m"
            label="Регулярная выручка по корпоративному тарифу"
            period="Год"
            value="8 940 ₽"
            delta={{ value: "+12,5%", tone: "good" }}
          />
          <MetricPanel
            size="m"
            label="Обращения"
            period="Год"
            value="708"
            delta={{ value: "−2,1%", tone: "good" }}
          />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Число и пилюля не помещаются в строку</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Четыре панели в ряд — 402 точки на панель, 336 внутри полей. Замер первой: число «1 284
          590 ₽» занимает 307, просвет 16, пилюля 89 — вместе 412, то есть на 76 больше, чем есть.
          Пилюля уходит на вторую строку. Соседние панели тянутся за ней — сетка равняет их по самой
          высокой, — и весь ряд вырастает со 181 до 234. Это выбрано намеренно: рост высоты виден
          сразу, а вылет вбок в PDF молча ложится на соседнюю колонку. Лечится приведением величины
          к тысячам или миллионам в самих данных.
        </p>
        <div className="grid grid-cols-4 gap-6">
          <MetricPanel
            size="m"
            label="Оборот за год"
            period="2026"
            value="1 284 590 ₽"
            delta={{ value: "+11,4%", tone: "good" }}
          />
          <MetricPanel size="m" label="Пользователи" period="2026" value="9 348" />
          <MetricPanel
            size="m"
            label="Средняя сессия"
            period="2026"
            value="12 мин"
            delta={{ value: "+1,2%", tone: "good" }}
          />
          <MetricPanel
            size="m"
            label="Оценка"
            period="2026"
            value="4,7"
            delta={{ value: "0,0", tone: "flat" }}
          />
        </div>
      </section>
    </div>
  ),
};

export const Пилюля: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">DeltaPill — общая пилюля изменения</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Та же пилюля стоит и в панели показателя, и в ряду KPI-плиток. Три состояния: рост в нужную
        сторону — зелёные роли success, в ненужную — красные error, отсутствие изменения —
        нейтральная заливка и вторичный текст. Ноль перекрашивается принудительно: подпись «0,00%» с
        зелёной заливкой утверждает рост, которого нет, и это неверный факт, а не оформление. Если
        tone при этом передан не flat, в разработке пишется предупреждение — тихая подмена того, что
        написал автор, тоже дефект.
      </p>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Замеры контраста на поверхности панели (порог AA 4.5 при кегле 18): светлая тема — 5.22
        зелёная, 5.42 красная, 4.61 нейтральная; тёмная — 5.51, 5.02, 6.94. На приглушённой подложке
        те же пилюли дают 4.36 (нейтральная, светлая) и 4.48 (красная, тёмная) — поэтому панель по
        умолчанию белая, а не приглушённая.
      </p>
      <div className="border-line bg-surface rounded-panel flex flex-wrap items-center gap-6 border p-8">
        <DeltaPill value="+14,8%" tone="good" />
        <DeltaPill value="−2,1%" tone="bad" />
        <DeltaPill value="0,00%" tone="flat" />
        <DeltaPill value="−38,0%" tone="good" />
        <DeltaPill value="+0,9 п.п." tone="bad" />
        <DeltaPill value="0 дней" tone="flat" />
      </div>
    </div>
  ),
};
