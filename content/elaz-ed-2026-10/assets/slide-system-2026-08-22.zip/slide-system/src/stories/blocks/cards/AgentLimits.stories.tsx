import type { Meta, StoryObj } from "@storybook/react-vite";
import AgentLimitsCard, {
  AGENT_LIMITS_COLORS,
  AGENT_LIMITS_PLAN_COLOR,
  agentLimitsHeight,
  barHeight,
  layoutAgentLimits,
  segmentGap,
  shareTone,
  type AgentLimitRow,
  type AgentLimitsSegment,
} from "../../../blocks/cards/agentLimitsCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import { contrast } from "../../../lib/color";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «расход и лимиты» — девятая из донорских карточек.
 *
 * Разбор переноса, все решения и отказы — в шапке
 * [`blocks/cards/agentLimitsCard.tsx`](../../../blocks/cards/agentLimitsCard.tsx).
 * Спецификация разведки — во внутреннем разборе.
 *
 * === Про числа в подписях ===
 *
 * Все числа СЧИТАЮТСЯ вызовом `layoutAgentLimits` прямо здесь, на тех же
 * данных, что нарисованы рядом. Переписанное руками число живёт своей жизнью:
 * поменяется просвет или потолок — проза останется прежней и будет врать
 * увереннее, чем сам блок.
 *
 * Контрасты тоже считаются, а не переписаны: функция `contrast` из
 * `lib/color.ts` — та самая, которой мерили палитру.
 *
 * === Про ширину обёртки ===
 *
 * Разборные истории стоят на жёсткой ширине 1680, а не на `max-w-`. Геометрия
 * считается от переданной ширины, и молча сжатый контейнер дал бы картинку,
 * не совпадающую с собственными замерами блока. Витрина добавляет своё поле,
 * поэтому окно нужно от 1808 точек — на узком будет честная горизонтальная
 * прокрутка.
 *
 * ⚠️ Чего эта витрина не даёт: `npm run check` обходит только слайды деков.
 * Пока карточка не поставлена в дек, автоматических ворот у неё нет —
 * переполнение здесь ловится замером в режиме 1:1, а не скриптом.
 */

const meta = {
  title: "Карточки/Расход и лимиты",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ═══════════════  Данные донора  ═══════════════ */

/*
 * Со страницы донора сняты все до одного числа: потолок 1M, семь статей
 * расхода (520k · 96k · 68k · 54k · 42k · 24k · 16k, сумма 820k = 82%), две
 * отложенные (69.9k и 16.1k), свободное место 180k и три лимита плана
 * (38% · 3% · 5%). Ничего не достроено и не округлено.
 */
const МАКСИМУМ = 1_000_000;

const СТАТЬИ: AgentLimitsSegment[] = [
  { key: "messages", label: "Messages", value: 520_000 },
  { key: "system-tools", label: "System tools", value: 96_000 },
  { key: "mcp-tools", label: "MCP tools", value: 68_000 },
  { key: "skills", label: "Skills", value: 54_000 },
  { key: "system-prompt", label: "System prompt", value: 42_000 },
  { key: "memory", label: "Memory files", value: 24_000 },
  { key: "agents", label: "Custom agents", value: 16_000 },
  { key: "mcp-deferred", label: "MCP tools (deferred)", value: 69_900, deferred: true },
  { key: "sys-deferred", label: "System tools (deferred)", value: 16_100, deferred: true },
];

const ЛИМИТЫ: AgentLimitRow[] = [
  { key: "5h", label: "5-hour limit", used: 0.38, resets: "Resets in 2 hr 46 min" },
  { key: "week-all", label: "Weekly · all models", used: 0.03, resets: "Resets Tue 3:00 PM" },
  { key: "week-pro", label: "Weekly · Pro", used: 0.05, resets: "Resets Tue 3:00 PM" },
];

/** Донорский формат величины: «520k», «69,9k» */
const токены = (v: number) =>
  v >= 1_000_000
    ? `${(v / 1_000_000).toLocaleString("ru-RU", { maximumFractionDigits: 1 })}M`
    : `${(v / 1000).toLocaleString("ru-RU", { maximumFractionDigits: 1 })}k`;

/* ═══════════════  Служебное  ═══════════════ */

const число = (x: number) => (Number.isInteger(x) ? String(x) : x.toFixed(1));
const ряд = (xs: number[]) => xs.map(число).join(" · ");

const измерить = (input: Parameters<typeof layoutAgentLimits>[0]) => layoutAgentLimits(input);

/**
 * Предупреждения блока, напечатанные на странице.
 *
 * Считаются тем же вызовом, что и геометрия, поэтому разойтись с консолью не
 * могут. Пустой список — тоже результат: он означает, что на этих данных блок
 * молчит, и это видно, а не предполагается.
 */
function Предупреждения({ layout }: { layout: ReturnType<typeof измерить> }) {
  return (
    <div className="mb-10 max-w-5xl">
      <h4 className="text-title-m text-ink mb-2">
        Предупреждений в консоли: {layout.warnings.length}
      </h4>
      {layout.warnings.length ? (
        <ul className="text-body-m text-ink-secondary flex flex-col gap-2">
          {layout.warnings.map((w) => (
            <li key={w} className="flex gap-3">
              <span className="text-ink-tertiary shrink-0">—</span>
              <span>{w}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-body-m text-ink-secondary">
          Блок молчит: заливка помещается в полосу, сегменты толще двух зазоров, строк расшифровки и
          лимитов не больше потолка, красок хватает на все статьи.
        </p>
      )}
    </div>
  );
}

/* ═══════════════  Поверхности и композит для замеров контраста  ═══════════ */

const ПОВЕРХНОСТИ = {
  светлаяКарточка: "#ffffff",
  светлыйХолст: "#f7f7f7",
  тёмнаяКарточка: "#262626",
  тёмныйХолст: "#121212",
} as const;

/**
 * Композит полупрозрачной заливки на своей подложке.
 *
 * ⚠️ Нужен потому, что статусные заливки тёмной темы — `rgba(…, 0.18)`, а
 * `contrast` работает с непрозрачными цветами. Считать контраст к самому
 * `rgba` нельзя: получится контраст к цвету, которого на экране нет.
 */
function сплав(hex: string, alpha: number, base: string) {
  const p = (s: string, i: number) => parseInt(s.slice(1 + i * 2, 3 + i * 2), 16);
  const mix = (i: number) => Math.round(p(hex, i) * alpha + p(base, i) * (1 - alpha));
  return `#${[0, 1, 2].map((i) => mix(i).toString(16).padStart(2, "0")).join("")}`;
}

function ТаблицаКонтраста({
  rows,
  порог,
}: {
  rows: readonly { что: string; краска: string; фон: string; подпись: string }[];
  порог: number;
}) {
  return (
    <table className="text-body-m text-ink-secondary w-full max-w-5xl table-fixed">
      <thead>
        <tr className="text-ink">
          <th className="w-[44%] py-2 text-left font-normal">Что на что</th>
          <th className="w-[18%] py-2 text-left font-normal">Краска</th>
          <th className="w-[18%] py-2 text-left font-normal">Фон</th>
          <th className="w-[10%] py-2 text-right font-normal tabular-nums">Замер</th>
          <th className="w-[10%] py-2 text-right font-normal">Порог {порог}</th>
        </tr>
      </thead>
      <tbody>
        {rows.map((r) => {
          const c = contrast(r.краска, r.фон);
          return (
            <tr key={r.что} className="border-line border-t">
              <td className="text-ink py-2">{r.что}</td>
              <td className="py-2 tabular-nums">{r.краска}</td>
              <td className="py-2 tabular-nums">{r.подпись}</td>
              <td className="py-2 text-right tabular-nums">{c.toFixed(2)}</td>
              <td className={`py-2 text-right ${c >= порог ? "text-success-fg" : "text-error-fg"}`}>
                {c >= порог ? "берёт" : "не берёт"}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Донорские данные один в один, режим `breakdown` — то есть раскрытое
 * состояние донора, разрезанное на две колонки.
 *
 * Здесь смотреть главное: полоса несёт и общий процент (длина заливки), и
 * состав (семь кусков), а величину каждого куска несёт напечатанная строка
 * слева. Именно так и должно быть — краски донора в светлой теме порог 3:1
 * не берут, разбор в шапке `lib/boardPalette.ts`.
 */
export const Расшифровка: Story = {
  render: () => {
    const L = измерить({
      segments: СТАТЬИ,
      max: МАКСИМУМ,
      limits: ЛИМИТЫ,
      mode: "breakdown",
      hasFree: true,
    });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Донорские данные, 1680 × {CARD_BUDGET}; внутри {L.innerW} × {L.slotH}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Полоса {L.innerW} × {L.barH}, отношение {число(L.innerW / L.barH)}:1 против донорских 69:1
          — толщина посчитана долей ширины, а не масштабированием шестёрки (разбор в шапке блока).
          Заливка {число(L.filledPx)} плюс {L.parts.length - 1} зазоров по {L.gap} ={" "}
          {число(L.filledPx + L.gapsPx)}; хвост дорожки {число(L.tailPx)}. Сегменты:{" "}
          {ряд(L.parts.map((p) => p.px))}.
        </p>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Колонки: расшифровка {L.leftW}, разделитель 1, лимиты {L.rightW} — делёж 7 к 5, как в
          сетке слайда. Строк расшифровки {L.rows.length} при потолке {L.rowsFit} (высота колонки{" "}
          {L.bodyH}, строка {28}, просвет {8}) — донорские десять помещаются ровно. Лимитов{" "}
          {ЛИМИТЫ.length} при потолке {L.limitCap}; полоса лимита {L.limitBarH}, потому что колонка{" "}
          {L.rightW} узкая и толщина упирается в пол {12}.
        </p>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          mode="breakdown"
          label="Context window"
          segments={СТАТЬИ}
          max={МАКСИМУМ}
          limits={ЛИМИТЫ}
          limitsTitle="Plan usage limits"
          limitsMeta="Max (5×)"
          freeLabel="Free space"
          formatValue={токены}
        />
      </div>
    );
  },
};

/* ═══════════════  Свёрнутое состояние  ═══════════════ */

/**
 * Донорское СВЁРНУТОЕ состояние — режим `compact`.
 *
 * ⚠️ Его место — половинная ширина, и это замер, а не вкус. Донорская
 * свёрнутая карточка 448 × 247 — это 1.81:1. Наша половинная 828 × 604 даёт
 * 1.37:1, полная 1680 × 604 — 2.78:1. То есть в половину карточка садится
 * почти донорской пропорцией, а во всю ширину растягивается вдвое.
 *
 * Практическое следствие важнее пропорции: во всю ширину полоса лимита
 * становится 24 точки и блок лимита 68, поэтому в бюджет влезает три лимита;
 * в половину полоса 12, блок 56 — влезает четыре, и остаётся запас.
 */
export const Свёрнутая: Story = {
  render: () => {
    const Половина = измерить({
      segments: СТАТЬИ,
      max: МАКСИМУМ,
      limits: ЛИМИТЫ,
      mode: "compact",
      size: "half",
      width: 828,
    });
    const Полная = измерить({
      segments: СТАТЬИ,
      max: МАКСИМУМ,
      limits: ЛИМИТЫ,
      mode: "compact",
    });
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Две половинных карточки в ряд — 828 × {CARD_BUDGET}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Внутри {Половина.innerW} × {Половина.slotH}. Полоса контекста {Половина.barH}, полосы
            лимитов {Половина.limitBarH}, зазор сегментов {Половина.gap}. Занято {Половина.contentH}{" "}
            из {Половина.slotH} — остаётся {Половина.slotH - Половина.contentH}. Плиток легенды
            здесь нет, и не потому что не влезли, а потому что в карточке есть лимиты плана: с ними
            легенда выключена по умолчанию, иначе две соседние карточки с разным числом лимитов
            оказались бы одна с легендой, другая без. Потолок лимитов {Половина.limitCap}. Пустая
            полоса внизу — цена того, что карточка растянута на весь бюджет 604; на слайде вместо
            этого берут `agentLimitsHeight` и центрируют, см. историю «На слайде, свёрнутая».
          </p>
          <Предупреждения layout={Половина} />
          <div className="flex gap-6">
            <div className="w-[828px]">
              <AgentLimitsCard
                mode="compact"
                size="half"
                width={828}
                label="Context window"
                segments={СТАТЬИ}
                max={МАКСИМУМ}
                limits={ЛИМИТЫ}
                limitsTitle="Plan usage limits"
                limitsMeta="Max (5×)"
                formatValue={токены}
              />
            </div>
            <div className="w-[828px]">
              <AgentLimitsCard
                mode="compact"
                size="half"
                width={828}
                label="Бюджет производства"
                segments={[
                  { key: "a", label: "Съёмка", value: 2_400_000 },
                  { key: "b", label: "Постпродакшн", value: 1_150_000 },
                  { key: "c", label: "Реквизит", value: 420_000 },
                  { key: "d", label: "Логистика", value: 260_000 },
                ]}
                max={6_000_000}
                limits={[
                  { key: "q", label: "Квартальный", used: 0.71, resets: "сброс 1 июля" },
                  { key: "y", label: "Годовой", used: 0.24, resets: "сброс 1 января" },
                ]}
                limitsTitle="Лимиты договора"
                limitsMeta="Рамочный"
                period={{ label: "II квартал" }}
                total="6 млн ₽"
                formatValue={(v) => `${(v / 1_000_000).toLocaleString("ru-RU")} млн`}
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Та же карточка во всю ширину — 1680</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Полоса лимита здесь {Полная.limitBarH} вместо {Половина.limitBarH}, блок лимита{" "}
            {Полная.limitBlock} вместо {Половина.limitBlock}; занято {Полная.contentH} из{" "}
            {Полная.slotH}, потолок лимитов {Полная.limitCap}. Форма не ломается, но карточка
            становится лентой: три коротких подписи растянуты на 1608 точек, а справа от каждой
            подписи — 1200 точек пустоты до процента. Во всю ширину честнее ставить `breakdown`.
          </p>
          <Предупреждения layout={Полная} />
          <AgentLimitsCard
            mode="compact"
            label="Context window"
            segments={СТАТЬИ}
            max={МАКСИМУМ}
            limits={ЛИМИТЫ}
            limitsTitle="Plan usage limits"
            limitsMeta="Max (5×)"
            formatValue={токены}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Только полоса  ═══════════════ */

/**
 * Полоса без лимитов плана: плитки легенды включаются САМИ.
 *
 * Правило двусоставное: лимитов нет И плитки помещаются (нужно 124 точки).
 * Вторая половина правила появилась после замера — с лимитами две соседние
 * половинных карточки получались одна с легендой, другая без, потому что у
 * них разное число лимитов. Разбор в шапке блока. Продавить решение в обе
 * стороны можно свойством `legend`.
 *
 * Высота здесь — `agentLimitsHeight`, а не бюджет: без лимитов содержимого на
 * 604 точки нет, и карточка во весь бюджет висела бы пустой наполовину.
 */
export const ТолькоПолоса: Story = {
  render: () => {
    const СТАТЬИ_5 = СТАТЬИ.filter((s) => !s.deferred).slice(0, 5);
    const вход = { segments: СТАТЬИ_5, max: МАКСИМУМ, mode: "compact" as const };
    const H = agentLimitsHeight(вход);
    const L = измерить({ ...вход, height: H });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Пять статей, без лимитов; высота по содержимому — {H} вместо {CARD_BUDGET}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Плитки легенды включены: {L.showLegend ? "да" : "нет"}. Слот под полосу {L.slotH} при
          полосе {L.barH} — ровно столько и нужно. Плитка легенды несёт и величину, и долю, потому
          что цвет сам по себе величину не несёт: замеры — в истории «Контраст».
        </p>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          label="Context window"
          segments={СТАТЬИ_5}
          max={МАКСИМУМ}
          height={H}
          period={{ label: "Сейчас" }}
          formatValue={токены}
        />
      </div>
    );
  },
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Обе темы рядом через вложенную тему — расхождение видно без переключения
 * тулбара, и оно здесь принципиальное.
 *
 * В светлой теме порог 3:1 берёт одна краска из семи (синяя, 3.14), в тёмной
 * — все семь (4.83…9.62). То есть сегментированная полоса в светлой теме
 * работает как ФОРМА (длина заливки и границы кусков), а не как цветовой код.
 * Если карточка едет на проектор — брать тёмную тему: запас втрое.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      {(["light", "dark"] as const).map((theme) => (
        <div key={theme}>
          <h3 className="text-title-l text-ink mb-2">
            {theme === "light" ? "Светлая тема" : "Тёмная тема"}
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            {theme === "light"
              ? "Дорожка #ebebeb на белой карточке — 1.19:1: она видна как форма, а не как цвет, и это нормально, потому что она фон, а не данные. Зазоры между сегментами показывают её же."
              : "Дорожка #2f2f2f на карточке #262626 — 1.13:1. Донорский трек #262626 здесь совпал бы с карточкой ровно (1.00) и полоса пропала бы целиком; поэтому взят наш --t-fill-strong, разбор в BOARD_TIER_ZERO."}
          </p>
          <AgentLimitsCard
            theme={theme}
            mode="breakdown"
            label="Context window"
            segments={СТАТЬИ}
            max={МАКСИМУМ}
            limits={ЛИМИТЫ}
            limitsTitle="Plan usage limits"
            limitsMeta="Max (5×)"
            freeLabel="Free space"
            formatValue={токены}
          />
        </div>
      ))}
    </div>
  ),
};

/* ═══════════════  Контраст  ═══════════════ */

/**
 * Замеры контраста — считаются функцией `contrast` из `lib/color.ts` прямо
 * здесь, а не переписаны из чужого отчёта.
 *
 * ⚠️ Градиентов в этой карточке НЕТ ни одного — ни в полосе, ни в чипе, ни в
 * дорожке (разведка отметила это прямо: «Градиентов нет ни одного, тени
 * нет»). Поэтому мерить «в нескольких точках по длине» здесь нечего: заливка
 * каждого сегмента постоянна, и одного замера на сегмент достаточно. Взамен
 * меряется то, что для сегментированной полосы важнее — СОСЕДНИЕ пары: куски
 * стоят встык через просвет в 4 точки, и если два соседа неразличимы, полоса
 * читается как один длинный сегмент.
 */
export const Контраст: Story = {
  render: () => {
    const пары = AGENT_LIMITS_COLORS.slice(0, -1).map((c, i) => ({
      что: `Сегмент ${i + 1} рядом с ${i + 2}`,
      краска: c,
      фон: AGENT_LIMITS_COLORS[i + 1],
      подпись: AGENT_LIMITS_COLORS[i + 1],
    }));

    const наКарточке = (фон: string, подпись: string) =>
      AGENT_LIMITS_COLORS.map((c, i) => ({
        что: `Сегмент ${i + 1}`,
        краска: c,
        фон,
        подпись,
      }));

    const чипы = [
      {
        что: "Чип, нейтральный — светлая",
        краска: "#0a0a0a",
        фон: "#f5f5f5",
        подпись: "bg-fill #f5f5f5",
      },
      {
        что: "Чип, нейтральный — тёмная",
        краска: "#fafafa",
        фон: "#1f1f1f",
        подпись: "bg-fill #1f1f1f",
      },
      {
        что: "Чип, тревога — светлая",
        краска: "#8a6100",
        фон: "#fff3c4",
        подпись: "warning-fill",
      },
      {
        что: "Чип, тревога — тёмная",
        краска: "#ffd60a",
        фон: сплав("#ffd60a", 0.18, ПОВЕРХНОСТИ.тёмнаяКарточка),
        подпись: `сплав ${сплав("#ffd60a", 0.18, ПОВЕРХНОСТИ.тёмнаяКарточка)}`,
      },
      {
        что: "Чип, опасность — светлая",
        краска: "#c81e28",
        фон: "#ffe2e4",
        подпись: "error-fill",
      },
      {
        что: "Чип, опасность — тёмная",
        краска: "#ff6b60",
        фон: сплав("#fb2c36", 0.18, ПОВЕРХНОСТИ.тёмнаяКарточка),
        подпись: `сплав ${сплав("#fb2c36", 0.18, ПОВЕРХНОСТИ.тёмнаяКарточка)}`,
      },
    ];

    const подписи = [
      {
        что: "Название статьи, кегль 20 — светлая",
        краска: "#0a0a0a",
        фон: ПОВЕРХНОСТИ.светлаяКарточка,
        подпись: "карточка #ffffff",
      },
      {
        что: "Величина и время сброса, кегль 20 — светлая",
        краска: "#6a6a6a",
        фон: ПОВЕРХНОСТИ.светлаяКарточка,
        подпись: "карточка #ffffff",
      },
      {
        что: "Название статьи, кегль 20 — тёмная",
        краска: "#fafafa",
        фон: ПОВЕРХНОСТИ.тёмнаяКарточка,
        подпись: "карточка #262626",
      },
      {
        что: "Величина и время сброса, кегль 20 — тёмная",
        краска: "#a3a3a3",
        фон: ПОВЕРХНОСТИ.тёмнаяКарточка,
        подпись: "карточка #262626",
      },
    ];

    const служебные = [
      {
        что: "Образец отложенной статьи — светлая",
        краска: "#838383",
        фон: ПОВЕРХНОСТИ.светлаяКарточка,
        подпись: "карточка #ffffff",
      },
      {
        что: "Образец отложенной статьи — тёмная",
        краска: "#7d7d7d",
        фон: ПОВЕРХНОСТИ.тёмнаяКарточка,
        подпись: "карточка #262626",
      },
      {
        что: "Дорожка полосы — светлая",
        краска: "#ebebeb",
        фон: ПОВЕРХНОСТИ.светлаяКарточка,
        подпись: "карточка #ffffff",
      },
      {
        что: "Дорожка полосы — тёмная",
        краска: "#2f2f2f",
        фон: ПОВЕРХНОСТИ.тёмнаяКарточка,
        подпись: "карточка #262626",
      },
    ];

    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            Текст карточки на своей подложке — порог 4.5 (кегль 20 мельче 24)
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Весь текст карточки набран кеглями 20 и 26, то есть мельче 24, — значит порог строгий,
            4.5. Третичного цвета в карточке нет ни в одном месте, хотя у донора время сброса
            набрано именно им: третичный в светлой теме даёт 3.27 и на кегле 20 порог не берёт
            (`design-tokens.md`).
          </p>
          <ТаблицаКонтраста rows={подписи} порог={4.5} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            Дорожка и образцы — порог 3 (нетекстовая графика)
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            ⚠️ Дорожке порог не предъявляется вовсе: она ФОН полосы, а не данные, и обязана быть
            тише заливки — 1.19 и 1.13 здесь не дефект, а требование. Она стоит в таблице, чтобы
            видно было, насколько она тише. Образец отложенной статьи — графика, ему 3:1
            предъявляется, и он его берёт в обеих темах.
          </p>
          <ТаблицаКонтраста rows={служебные} порог={3} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Чип доли на своей заливке — порог 4.5</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Чип набран `text-body-l` 24, то есть формально проходит по порогу 3:1 для крупного
            текста. Здесь предъявлен строгий 4.5 — потому что 24 это ровно граница, а на проекторе с
            засветкой запас нужен. Тёмные заливки полупрозрачные, поэтому замер идёт к СПЛАВУ с
            карточкой, а не к самому rgba: цвета rgba на экране не существует.
          </p>
          <ТаблицаКонтраста rows={чипы} порог={4.5} />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            Сегменты на карточке — порог 3 (нетекстовая графика)
          </h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Слева светлая карточка, справа тёмная. Это решение заказчика, а не недосмотр: краски
            донора берутся как есть, а величину несёт напечатанная строка. Разбор — в шапке
            `lib/boardPalette.ts`.
          </p>
          <div className="flex gap-10">
            <ТаблицаКонтраста
              rows={наКарточке(ПОВЕРХНОСТИ.светлаяКарточка, "карточка #ffffff")}
              порог={3}
            />
            <ТаблицаКонтраста
              rows={наКарточке(ПОВЕРХНОСТИ.тёмнаяКарточка, "карточка #262626")}
              порог={3}
            />
          </div>
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">Соседние сегменты друг с другом — порог 3</h3>
          <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
            Порядок красок донорский и переставлять его нельзя, поэтому таблица — не приговор, а
            предупреждение: пары ниже порога различаются просветом в {segmentGap(barHeight(1608))}{" "}
            точки, а не цветом. Просвет здесь несёт границу, ровно как у донора, где он всего 1
            точка при полосе 6.
          </p>
          <ТаблицаКонтраста rows={пары} порог={3} />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Пороги чипа  ═══════════════ */

/**
 * Три тона чипа общей доли.
 *
 * Тон считается от порогов, а не задаётся руками — иначе «96% бюджета съедено»
 * можно было бы покрасить нейтрально и слайд перестал бы предупреждать. По
 * умолчанию тревога с 75%, опасность с 90%; на клиентском слайде эти числа
 * задаёт предметная область, поэтому они свойства блока.
 */
export const Пороги: Story = {
  render: () => {
    const случаи = [
      { доля: 0.42, подпись: "42% — нейтральный" },
      { доля: 0.82, подпись: "82% — тревога, донорский случай" },
      { доля: 0.96, подпись: "96% — опасность" },
    ];
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        {случаи.map(({ доля, подпись }) => {
          const статьи: AgentLimitsSegment[] = [
            { key: "a", label: "Сообщения", value: доля * 0.63 * МАКСИМУМ },
            { key: "b", label: "Инструменты", value: доля * 0.2 * МАКСИМУМ },
            { key: "c", label: "Навыки", value: доля * 0.1 * МАКСИМУМ },
            { key: "d", label: "Память", value: доля * 0.07 * МАКСИМУМ },
          ];
          const вход = { segments: статьи, max: МАКСИМУМ, mode: "compact" as const };
          const H = agentLimitsHeight(вход);
          return (
            <div key={подпись}>
              <h3 className="text-title-l text-ink mb-2">
                {подпись} → тон «{shareTone(доля, 0.75, 0.9)}»
              </h3>
              <AgentLimitsCard
                label="Контекстное окно"
                segments={статьи}
                max={МАКСИМУМ}
                height={H}
                formatValue={токены}
              />
            </div>
          );
        })}
      </div>
    );
  },
};

/* ═══════════════  Крайние случаи  ═══════════════ */

/**
 * Минимум данных: одна статья, один лимит.
 *
 * Нижняя граница формы. С одной статьёй сегментированная полоса перестаёт
 * быть сегментированной — остаётся обычный индикатор заполнения, и это
 * честно: одна величина это `Meter` или плитка с числом, а не карточка
 * дашборда. Смотреть здесь надо на то, что ничего не схлопнулось в ноль:
 * полоса, чип, лимит и хвост дорожки на месте.
 */
export const МинимумДанных: Story = {
  render: () => {
    const статьи: AgentLimitsSegment[] = [{ key: "one", label: "Сообщения", value: 180_000 }];
    const лимиты: AgentLimitRow[] = [
      { key: "5h", label: "Пятичасовой", used: 0.04, resets: "через 4 ч 10 мин" },
    ];
    const вход = {
      segments: статьи,
      max: МАКСИМУМ,
      limits: лимиты,
      mode: "compact" as const,
      size: "half" as const,
      width: 828,
    };
    const H = agentLimitsHeight(вход);
    const L = измерить({ ...вход, height: H });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Одна статья 18%, один лимит 4%; высота по содержимому {H}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Сегмент {число(L.parts[0].px)} при полосе {L.innerW} — 18% ширины, зазоров нет вовсе
          (сегмент один). Полоса лимита при доле 0.04 занимает {число(0.04 * L.innerW)} точек — это{" "}
          {число((0.04 * L.innerW) / L.limitBarH)} её толщин, то есть капсула ещё читается как
          капсула, а не как точка. Хвост дорожки {число(L.tailPx)}.
        </p>
        <Предупреждения layout={L} />
        <div className="w-[828px]">
          <AgentLimitsCard
            size="half"
            width={828}
            height={H}
            label="Контекстное окно"
            segments={статьи}
            max={МАКСИМУМ}
            limits={лимиты}
            limitsTitle="Лимиты плана"
            limitsMeta="Max (5×)"
            formatValue={токены}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Потолок  ═══════════════ */

const МНОГО_СТАТЕЙ: AgentLimitsSegment[] = Array.from({ length: 11 }, (_, i) => ({
  key: `s${i}`,
  label: `Статья расхода № ${i + 1}`,
  value: Math.round((90_000 - i * 7000) * 1),
}));

const МНОГО_ЛИМИТОВ: AgentLimitRow[] = Array.from({ length: 6 }, (_, i) => ({
  key: `l${i}`,
  label: `Лимит № ${i + 1}`,
  used: 0.7 - i * 0.1,
  resets: `сброс через ${i + 1} ч`,
}));

/**
 * Потолок: одиннадцать статей и шесть лимитов при семи красках круга.
 *
 * Потолков ЧЕТЫРЕ, и они независимы.
 *
 * **Красок семь.** Восьмая статья — это не восьмая краска, а строка «прочее»
 * (`dataviz.md`, запрет «цвета не назначаются по кругу»). Блок про повтор
 * говорит, но НЕ обрезает: сегмент в полосе всё равно занимает свою долю, и
 * молча выкинуть его значило бы соврать про сумму.
 *
 * **Строк расшифровки — сколько влезло в колонку**, считается от её высоты.
 *
 * **Лимитов — сколько влезло**, и число зависит от ШИРИНЫ: в узкой колонке
 * полоса тоньше, блок ниже, влезает больше.
 *
 * **Тонкие сегменты.** Всё, что тоньше двух зазоров, на полосе не видно.
 *
 * Обрезка не молчаливая: лишнее отбрасывается, и блок печатает, что именно.
 */
export const Потолок: Story = {
  render: () => {
    const L = измерить({
      segments: МНОГО_СТАТЕЙ,
      max: МАКСИМУМ,
      limits: МНОГО_ЛИМИТОВ,
      mode: "breakdown",
      hasFree: true,
    });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          11 статей и 6 лимитов на входе; нарисовано {Math.min(L.rows.length, L.rowsFit)} строк и{" "}
          {Math.min(МНОГО_ЛИМИТОВ.length, L.limitCap)} лимитов
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Красок {AGENT_LIMITS_COLORS.length}, статей {L.parts.length} — восьмая и далее повторяют
          круг, и на полосе появляются два одинаково синих куска не рядом. Это ровно тот случай,
          когда данные надо сворачивать, а не блок чинить.
        </p>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          mode="breakdown"
          label="Расход по статьям"
          segments={МНОГО_СТАТЕЙ}
          max={МАКСИМУМ}
          limits={МНОГО_ЛИМИТОВ}
          limitsTitle="Лимиты плана"
          limitsMeta="Расширенный"
          freeLabel="Свободно"
          formatValue={токены}
        />
      </div>
    );
  },
};

/* ═══════════════  Длинные подписи  ═══════════════ */

const ДЛИННЫЕ: AgentLimitsSegment[] = [
  { key: "a", label: "Переписка с клиентом и согласования по договору", value: 460_000 },
  { key: "b", label: "Системные инструменты платформы и их описания", value: 190_000 },
  { key: "c", label: "Файлы долговременной памяти проекта", value: 90_000 },
  { key: "d", label: "Пользовательские подагенты", value: 40_000 },
  {
    key: "e",
    label: "Инструменты MCP, загруженные отложенно",
    value: 120_000,
    deferred: true,
  },
];

const ДЛИННЫЕ_ЛИМИТЫ: AgentLimitRow[] = [
  {
    key: "a",
    label: "Пятичасовое окно по всем моделям сразу",
    used: 0.38,
    resets: "сброс через 2 ч 46 мин",
  },
  {
    key: "b",
    label: "Недельный лимит, все модели",
    used: 0.03,
    resets: "сброс во вторник в 15:00",
  },
];

/**
 * Длинные подписи в обеих колонках.
 *
 * Название обрезается многоточием, а не переносится: перенос увеличил бы
 * высоту строки, а от неё считается потолок числа строк — и вместо одной
 * обрезанной подписи со слайда пропала бы целая статья. Обрезка идёт по
 * `overflow: hidden`, то есть текст ТЕРЯЕТСЯ, но на соседа не наезжает.
 *
 * Числовые колонки при этом не сжимаются: их ширины ЗАМЕРЕНЫ по самой длинной
 * строке колонки тем же шрифтом и трекингом, какими они рисуются. Поэтому
 * длинное название съедает место у себя, а не у величины.
 *
 * Это не дефект вёрстки, а сигнал сократить подпись: «Переписка», а не
 * «Переписка с клиентом и согласования по договору».
 */
export const ДлинныеПодписи: Story = {
  render: () => {
    const вход = {
      segments: ДЛИННЫЕ,
      max: МАКСИМУМ,
      limits: ДЛИННЫЕ_ЛИМИТЫ,
      mode: "breakdown" as const,
      hasFree: true,
    };
    const H = agentLimitsHeight(вход);
    const L = измерить({ ...вход, height: H });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Колонка расшифровки {L.leftW}, колонка лимитов {L.rightW}; высота по содержимому {H}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Отложенная статья 120k стоит серым образцом и с длинным тире вместо доли: в полосу и в
          сумму она не входит, поэтому доли у неё нет — а «0,0%» было бы неправдой. Донорская пара
          цветов «отложено / свободно» у нас схлопнулась бы в один квадратик, разбор в шапке блока.
        </p>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          mode="breakdown"
          label="Контекстное окно"
          segments={ДЛИННЫЕ}
          max={МАКСИМУМ}
          height={H}
          limits={ДЛИННЫЕ_ЛИМИТЫ}
          limitsTitle="Лимиты тарифного плана"
          limitsMeta="Максимальный (5×)"
          freeLabel="Свободно"
          formatValue={токены}
        />
      </div>
    );
  },
};

/* ═══════════════  Опасный случай  ═══════════════ */

const ОПАСНЫЕ: AgentLimitsSegment[] = [
  { key: "a", label: "Сообщения", value: 700_000 },
  { key: "b", label: "Системные инструменты", value: 150_000 },
  { key: "c", label: "Навыки", value: 60_000 },
  { key: "d", label: "Память", value: 40_000 },
  { key: "e", label: "Подагенты", value: 20_000 },
  { key: "f", label: "Служебное", value: 5_000 },
  { key: "g", label: "Хвост", value: 300 },
];

/**
 * Опасный случай: 97.5% расхода и сегмент, который тоньше просвета.
 *
 * Смотреть здесь два дефекта сразу.
 *
 * **Хвост дорожки почти исчез.** При 97.5% заливки на хвост остаётся два
 * десятка точек, и полоса читается как «заполнено целиком» — то есть теряет
 * разницу между 97 и 100. Это предел формы: выше 95% индикатор перестаёт
 * отвечать на вопрос «сколько осталось», и вместо полосы нужна цифра.
 *
 * **Сегмент 300 из миллиона** даёт полкирпича ширины — его на полосе нет, но
 * в сумме он есть. Блок про это говорит; чинить должен автор данных, свернув
 * мелочь в «прочее»: зажать ширину нельзя, не сломав равенство «сумма
 * сегментов = длина заливки».
 */
export const ОпасныйСлучай: Story = {
  render: () => {
    const вход = {
      segments: ОПАСНЫЕ,
      max: МАКСИМУМ,
      mode: "breakdown" as const,
      hasFree: true,
    };
    const H = agentLimitsHeight(вход);
    const L = измерить({ ...вход, height: H });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          {число(L.share * 100)}% расхода; хвост дорожки {число(L.tailPx)} из {L.innerW}
        </h3>
        <p className="text-body-m text-ink-secondary mb-4 max-w-5xl">
          Сегменты: {ряд(L.parts.map((p) => p.px))}. Порог видимости — два зазора, то есть{" "}
          {L.gap * 2} точек. Чип опасный: доля {число(L.share * 100)}% выше порога 90%.
        </p>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          mode="breakdown"
          label="Контекстное окно"
          segments={ОПАСНЫЕ}
          max={МАКСИМУМ}
          height={H}
          freeLabel="Свободно"
          formatValue={токены}
        />
      </div>
    );
  },
};

/**
 * Перебор потолка: статей больше, чем ресурса.
 *
 * Полоса зажимается по 100%, а доли остаются честными и в сумме дают больше
 * ста. Расхождение намеренное: растянуть полосу за край карточки нельзя, а
 * подогнать доли под сто значило бы скрыть перерасход — ровно то, ради чего
 * слайд и делается.
 */
export const Перерасход: Story = {
  render: () => {
    const статьи: AgentLimitsSegment[] = [
      { key: "a", label: "Съёмка", value: 3_800_000 },
      { key: "b", label: "Постпродакшн", value: 2_100_000 },
      { key: "c", label: "Реквизит", value: 900_000 },
    ];
    const вход = { segments: статьи, max: 6_000_000, mode: "breakdown" as const };
    const H = agentLimitsHeight(вход);
    const L = измерить({ ...вход, height: H });
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">
          Сумма 6,8 млн при потолке 6 млн — {число(L.share * 100)}%
        </h3>
        <Предупреждения layout={L} />
        <AgentLimitsCard
          mode="breakdown"
          label="Бюджет производства"
          segments={статьи}
          max={6_000_000}
          height={H}
          period={{ label: "II квартал" }}
          formatValue={(v) => `${(v / 1_000_000).toLocaleString("ru-RU")} млн`}
        />
      </div>
    );
  },
};

/* ═══════════════  Краски  ═══════════════ */

/** Донорский круг красок — что во что раскрашивается */
export const Краски: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Круг сегментов: blue → purple → pink → yellow → emerald → sky → teal
      </h3>
      <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
        Порядок снят со страницы донорского демо (chart-6 · chart-5 · chart-3 · chart-8 · chart-7 ·
        chart-4 · chart-1) и переставлять его нельзя: соседняя карточка того же дека красится тем же
        кругом. Восьмая краска донора, салат chart-2, в этот круг не входит — у донора её здесь нет.
      </p>
      <div className="flex flex-wrap gap-6">
        {AGENT_LIMITS_COLORS.map((color, i) => (
          <div key={color} className="flex items-center gap-3">
            <span
              className="rounded-micro shadow-hairline"
              style={{ width: 40, height: 40, background: color }}
            />
            <span className="text-body-m text-ink-secondary tabular-nums">
              {i + 1}. {color}
            </span>
          </div>
        ))}
        <div className="flex items-center gap-3">
          <span
            className="rounded-micro shadow-hairline"
            style={{ width: 40, height: 40, background: AGENT_LIMITS_PLAN_COLOR }}
          />
          <span className="text-body-m text-ink-secondary">лимиты плана — все одной</span>
        </div>
        <div className="flex items-center gap-3">
          <span
            className="bg-fill-strong rounded-micro shadow-hairline"
            style={{ width: 40, height: 40 }}
          />
          <span className="text-body-m text-ink-secondary">дорожка и «свободно»</span>
        </div>
        <div className="flex items-center gap-3">
          <span
            className="bg-ink-tertiary rounded-micro shadow-hairline"
            style={{ width: 40, height: 40 }}
          />
          <span className="text-body-m text-ink-secondary">отложенная статья</span>
        </div>
      </div>
    </div>
  ),
};

/* ═══════════════  Как на слайде  ═══════════════ */

const СЛАЙД_СТАТЬИ: AgentLimitsSegment[] = [
  { key: "prod", label: "Производство", value: 2_400_000 },
  { key: "post", label: "Постпродакшн", value: 1_150_000 },
  { key: "media", label: "Размещение", value: 620_000 },
  { key: "props", label: "Реквизит и площадки", value: 420_000 },
  { key: "logistics", label: "Логистика", value: 260_000 },
  { key: "legal", label: "Права и лицензии", value: 150_000 },
];

const СЛАЙД_ЛИМИТЫ: AgentLimitRow[] = [
  { key: "q", label: "Квартальный", used: 0.83, resets: "сброс 1 июля" },
  { key: "y", label: "Годовой", used: 0.31, resets: "сброс 1 января" },
  { key: "extra", label: "Резерв на непредвиденное", used: 0.12, resets: "без сброса" },
];

/**
 * Как на слайде: карточка в `ContentSlide` при бюджете 604.
 *
 * ⚠️ 604 — это бюджет при заголовке В ОДНУ СТРОКУ. Замер шапки слайда: поле
 * сверху 88 + пилюля 40 + просвет 24 + заголовок 60 + просвет 24 + лид 32 +
 * отбивка 64 = 332; снизу поле 88 и резерв под подвал 56. Карточка встаёт на
 * 332…936, подвал начинается на 972. Заголовок в две строки означает
 * `height={544}`, иначе низ карточки уедет под подпись — дефект, которого не
 * видит ни одна автопроверка (боксы не пересекаются, холст не превышен).
 *
 * Заголовок формулирует мысль, а не называет тему, и он ПРОВЕРЯЕМ по самой
 * карточке: производство и постпродакшн дают 3,55 млн из освоенных 5,00 млн
 * — ровно 71,0%. Освоено 5 из 7 млн договора.
 *
 * ⚠️ Заголовок сокращён до 36 знаков НЕ из вкуса. Первая редакция («Больше
 * двух третей освоенного ушло на съёмку и монтаж», 52 знака) вставала в две
 * строки, шапка слайда вырастала на 60 точек, и карточка в 604 уезжала за
 * нижнее поле: замер дал низ карточки на 996 при потолке содержимого 992.
 * Потолок заголовка в одну строку — ~46 знаков (`slide-anatomy.md`). Второй
 * выход — оставить длинный заголовок и передать `height={544}`.
 */
const СЛАЙД_ВХОД = {
  segments: СЛАЙД_СТАТЬИ,
  max: 7_000_000,
  limits: СЛАЙД_ЛИМИТЫ,
  mode: "breakdown" as const,
  hasFree: true,
};

/**
 * ⚠️ Высота — `agentLimitsHeight`, а не бюджет 604.
 *
 * Замер: содержимому нужно 508 точек (шапка 100 + просвет 24 + полоса 24 +
 * просвет 24 + колонка лимитов 264 + поля 72), то есть в полном бюджете внизу
 * карточки остаётся 96 точек пустоты. Пустая полоса в четверть высоты
 * читается как незакрытая карточка, а не как воздух.
 *
 * Раз карточка ниже бюджета, её надо ЦЕНТРИРОВАТЬ по рабочей области —
 * `content-center` на сетке слайда (`slide-anatomy.md`), иначе она
 * прижимается к верху и под ней висит пустота в 96 точек уже на слайде.
 */
const слайдКарточка = (theme?: "light" | "dark") => (
  <div className="slide-grid h-full content-center">
    <div className="col-span-12">
      <AgentLimitsCard
        mode="breakdown"
        theme={theme}
        label="Освоено по договору"
        segments={СЛАЙД_СТАТЬИ}
        max={7_000_000}
        height={agentLimitsHeight(СЛАЙД_ВХОД)}
        limits={СЛАЙД_ЛИМИТЫ}
        limitsTitle="Лимиты договора"
        limitsMeta="Рамочный, 7 млн"
        freeLabel="Не распределено"
        period={{ label: "II квартал" }}
        formatValue={(v) =>
          `${(v / 1_000_000).toLocaleString("ru-RU", { maximumFractionDigits: 2 })} млн`
        }
      />
    </div>
  </div>
);

export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Бюджет кампании"
      title="Съёмка и монтаж съели 71% освоенного"
      lead="Слева — во что вложены деньги, справа — где мы относительно лимитов договора."
      page={9}
      label="Демо · карточки дашборда"
    >
      {слайдКарточка()}
    </ContentSlide>
  ),
};

/**
 * Тот же слайд в тёмной теме — и это не «для разнообразия».
 *
 * Краски донора в светлой теме порог 3:1 берёт одна из семи, в тёмной — все
 * семь (замеры в истории «Контраст»). Если слайд едет на проектор, тёмная
 * тема даёт запас втрое; светлая остаётся для печати и экрана.
 *
 * ⚠️ Тёмный содержательный слайд читается как начало нового раздела
 * (`themes.md`). Ставить его в середину рассказа можно только вместе с
 * соседними: либо весь блок про бюджет тёмный, либо весь светлый.
 */
export const НаСлайдеТёмная: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Бюджет кампании"
      title="Съёмка и монтаж съели 71% освоенного"
      lead="Слева — во что вложены деньги, справа — где мы относительно лимитов договора."
      page={10}
      label="Демо · карточки дашборда"
    >
      {слайдКарточка()}
    </ContentSlide>
  ),
};

/**
 * Свёрнутый режим на слайде: две половинных карточки в ряд.
 *
 * Это второй законный способ поставить блок на слайд — и единственный, при
 * котором карточка держит донорскую пропорцию (1.37:1 против донорских
 * 1.81:1; полная даёт 2.78:1). Цена — состав расхода на слайде не подписан:
 * в половинную карточку с лимитами плитки легенды не влезают, не хватает 9
 * точек. Полоса тогда отвечает только за общий процент, и он напечатан.
 */
const ПОДДЕРЖКА: AgentLimitsSegment[] = [
  { key: "a", label: "Сопровождение", value: 640_000 },
  { key: "b", label: "Доработки", value: 380_000 },
  { key: "c", label: "Обучение", value: 120_000 },
];

const ПОДДЕРЖКА_ЛИМИТЫ: AgentLimitRow[] = [
  { key: "q", label: "Квартальный", used: 0.29, resets: "сброс 1 июля" },
  { key: "y", label: "Годовой", used: 0.11, resets: "сброс 1 января" },
];

const млн = (v: number) =>
  `${(v / 1_000_000).toLocaleString("ru-RU", { maximumFractionDigits: 2 })} млн`;

export const НаСлайдеСвёрнутая: Story = {
  parameters: { slide: true },
  render: () => {
    /*
     * ⚠️ Высота у обеих карточек ОДНА — наибольшая из двух естественных.
     * Слева три лимита, справа два, и по содержимому карточки вышли бы
     * разной высоты: 380 и 324. Разновысокие карточки в ряду читаются как
     * ошибка вёрстки, даже когда данных в них правда разное количество
     * (`slide-anatomy.md`).
     */
    const общая = Math.max(
      agentLimitsHeight({
        segments: СЛАЙД_СТАТЬИ,
        max: 7_000_000,
        limits: СЛАЙД_ЛИМИТЫ,
        mode: "compact",
        size: "half",
        width: 828,
      }),
      agentLimitsHeight({
        segments: ПОДДЕРЖКА,
        max: 4_000_000,
        limits: ПОДДЕРЖКА_ЛИМИТЫ,
        mode: "compact",
        size: "half",
        width: 828,
      }),
    );
    return (
      <ContentSlide
        eyebrow="Бюджет кампании"
        title="Квартальный лимит выбран на 83%"
        lead="Два договора рядом: слева кампания, справа поддержка."
        page={11}
        label="Демо · карточки дашборда"
      >
        <div className="slide-grid h-full content-center">
          <div className="col-span-6">
            <AgentLimitsCard
              size="half"
              width={828}
              height={общая}
              label="Кампания"
              segments={СЛАЙД_СТАТЬИ}
              max={7_000_000}
              limits={СЛАЙД_ЛИМИТЫ}
              limitsTitle="Лимиты договора"
              limitsMeta="Рамочный"
              formatValue={млн}
            />
          </div>
          <div className="col-span-6">
            <AgentLimitsCard
              size="half"
              width={828}
              height={общая}
              label="Поддержка"
              segments={ПОДДЕРЖКА}
              max={4_000_000}
              limits={ПОДДЕРЖКА_ЛИМИТЫ}
              limitsTitle="Лимиты договора"
              limitsMeta="Рамочный"
              formatValue={млн}
            />
          </div>
        </div>
      </ContentSlide>
    );
  },
};
