import type { Meta, StoryObj } from "@storybook/react-vite";
import ContributionsCard, {
  contributionsMetrics,
  type ContributionFact,
  type ContributionMonth,
  type ContributionWeek,
} from "../../../blocks/cards/contributionsCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Вклад за год» — донорский календаря вклада.
 *
 * Тепловая сетка года в стиле GitHub: колонка — неделя, строка — день
 * недели, густота заливки — интенсивность. Вокруг сетки итог года с чипом
 * изменения, четыре сводных числа и подписи месяцев.
 *
 * === ⚠️ Что смотреть в первую очередь ===
 *
 * 1. **Сторона клетки.** История «Колонки» показывает 53 и 26 колонок рядом
 *    с замерами. Полный год даёт клетку 22.49 — она видна как пятно, но
 *    ступень на ней с четырёх метров не читается.
 * 2. **Нижняя ступень лестницы.** История «Лестница» ставит рядом донорские
 *    пять ступеней и сокращённые четыре на данных, где почти все дни —
 *    единицы. У донорской лестницы «был вклад» бледнее, чем «не было».
 * 3. **Тёмная тема даёт запас.** Ступени в ней слабее по числам, но и фон
 *    ниже; на проекторе тёмный слайд с этой карточкой выигрывает.
 *
 * Данные историй СГЕНЕРИРОВАНЫ по seed, а не сняты с донора: со скриншота
 * снималось распределение ступеней (tier0 65 · tier1 74 · tier2 56 · tier3 37
 * · tier4 16 · tier5 11 из 259 клеток), а не значения дней. Форма года здесь
 * правдоподобная, но выдуманная — донорские тут только числа в шапке.
 */

const meta = {
  title: "Карточки/Вклад за год",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── генератор года ───────────── */

/** Детерминированный PRNG: одна и та же картинка в Storybook и в PDF */
function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const MONTH_LABELS = [
  "Jan",
  "Feb",
  "Mar",
  "Apr",
  "May",
  "Jun",
  "Jul",
  "Aug",
  "Sep",
  "Oct",
  "Nov",
  "Dec",
];

const DAY = 86400000;

/**
 * Год как колонки-недели.
 *
 * Сетка начинается с ВОСКРЕСЕНЬЯ, предшествующего 1 января, и кончается
 * субботой после 31 декабря — как у GitHub и у донора. Отсюда 53 колонки,
 * а не 52: 365 дней плюс хвосты не делятся на семь. Дни вне года —
 * `null`, они не рисуются вовсе.
 */
function buildYear(
  year: number,
  value: (date: Date, rnd: () => number) => number,
): { weeks: ContributionWeek[]; months: ContributionMonth[] } {
  const rnd = mulberry32(year);
  const first = new Date(Date.UTC(year, 0, 1));
  const start = new Date(first.getTime() - first.getUTCDay() * DAY);
  const last = new Date(Date.UTC(year, 11, 31));
  // +1, а не ceil от разницы: 2023 год начинается с воскресенья, разница
  // делится на семь нацело, и ceil дал бы на колонку меньше, чем нужно
  const columns = Math.floor((last.getTime() - start.getTime()) / DAY / 7) + 1;

  const weeks: (number | null)[][] = Array.from({ length: columns }, () =>
    Array.from({ length: 7 }, () => null),
  );

  for (let t = first.getTime(); t <= last.getTime(); t += DAY) {
    const date = new Date(t);
    const offset = Math.round((t - start.getTime()) / DAY);
    weeks[Math.floor(offset / 7)][offset % 7] = value(date, rnd);
  }

  const months = MONTH_LABELS.map((label, m) => ({
    label,
    week: Math.floor((Date.UTC(year, m, 1) - start.getTime()) / DAY / 7),
  }));

  return { weeks, months };
}

/**
 * Правдоподобная форма года: будни плотнее выходных, сезонная волна,
 * распределение значений со смещением вниз (степень 1.5 — редкие большие
 * дни, много малых).
 *
 * Ступени посчитаны, а не обещаны. Замер по этим данным (365 дней, потолок
 * 12): 111 · 82 · 47 · 51 · 35 · 39, то есть 30% · 22% · 13% · 14% · 10% ·
 * 11%. Донорский скриншот (259 клеток): 25% · 29% · 22% · 14% · 6% · 4% —
 * он ниже по верхним ступеням. Данные близкие, но НЕ донорские: со
 * скриншота снималось распределение, а не значения дней.
 */
const ТИПОВОЙ = buildYear(2025, (date, rnd) => {
  const weekend = date.getUTCDay() === 0 || date.getUTCDay() === 6;
  const season = 0.86 + 0.14 * Math.sin(((date.getUTCMonth() + 1) / 12) * Math.PI * 2);
  if (rnd() > (weekend ? 0.55 : 0.92) * season) return 0;
  return Math.max(1, Math.ceil(12 * Math.pow(rnd(), 1.5)));
});

/** Почти пусто: активность только в марте, и по одному вкладу в день */
const МИНИМУМ = buildYear(2024, (date, rnd) => (date.getUTCMonth() === 2 && rnd() > 0.55 ? 1 : 0));

/** Потолок: каждый день на максимуме шкалы, сетка сплошная */
const ПОТОЛОК = buildYear(2023, () => 23);

/** Опасный случай: почти все дни — ОДИН вклад, то есть первая ступень */
const ЕДИНИЦЫ = buildYear(2022, (_, rnd) => (rnd() > 0.25 ? 1 : 0));

const ФАКТЫ: ContributionFact[] = [
  { value: "9B", label: "Lifetime tokens" },
  { value: "562.7M", label: "Peak tokens" },
  { value: "12h 54m", label: "Longest task" },
  { value: "62 days", label: "Top streak" },
];

const ПЕРИОДЫ = ["Weekly", "Monthly", "Yearly"];

/** Сводит соседние недели по две: 53 колонки → 27 */
function поДвеНедели(weeks: readonly ContributionWeek[]): ContributionWeek[] {
  const out: ContributionWeek[] = [];
  for (let i = 0; i < weeks.length; i += 2) {
    const a = weeks[i];
    const b = weeks[i + 1];
    out.push(
      Array.from({ length: 7 }, (_, d) => {
        const x = a?.[d] ?? null;
        const y = b?.[d] ?? null;
        return x === null && y === null ? null : (x ?? 0) + (y ?? 0);
      }),
    );
  }
  return out;
}

const МЕТРИКА = (columns: number, extra: Parameters<typeof contributionsMetrics>[0] = {}) =>
  contributionsMetrics({ columns, ...extra });

/* ═══════════════  Типовой случай  ═══════════════ */

/**
 * Как на скриншоте: год целиком, пять ступеней донора, четыре сводных числа.
 */
export const Карточка: Story = {
  render: () => {
    const m = МЕТРИКА(ТИПОВОЙ.weeks.length);
    return (
      <div className="w-[1680px]">
        <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Слот графика {m.slotWidth} × {m.slotHeight}. Внутри: плитки фактов 100, просвет 24, строка
          «Activity» 32, просвет 12, сетка {m.gridHeight.toFixed(0)}, просвет 8, месяцы 24. Колонок{" "}
          {m.columns} — полный год от воскресенья до субботы, 52 не хватает. Клетка{" "}
          {m.cellWidth.toFixed(2)} × {m.cellHeight.toFixed(2)} при просвете {m.gap}. Это 1.17%
          ширины кадра: на экране 2.5 м — 2.9 см, с четырёх метров 0.42°, примерно как знак
          `body-l`. Пятно видно; ступень на нём — нет, см. историю «Лестница».
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="$7 462"
          delta={{ label: "+14,8%", direction: "up" }}
          facts={ФАКТЫ}
          period="Weekly"
          periods={ПЕРИОДЫ}
          weeks={ТИПОВОЙ.weeks}
          months={ТИПОВОЙ.months}
        />
      </div>
    );
  },
};

/* ═══════════════  Колонки  ═══════════════ */

/**
 * Полный год против «по две недели» — чем платим за подробность.
 */
export const Колонки: Story = {
  render: () => {
    const сжатые = поДвеНедели(ТИПОВОЙ.weeks);
    const a = МЕТРИКА(ТИПОВОЙ.weeks.length);
    const b = МЕТРИКА(сжатые.length);
    return (
      <div className="flex w-[1680px] flex-col gap-10">
        <div>
          <h3 className="text-title-l text-ink mb-2">
            {a.columns} колонок: клетка {a.cellWidth.toFixed(2)} × {a.cellHeight.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Клетка квадратная, и ограничитель здесь ШИРИНА: колонка даёт{" "}
            {((a.slotWidth - (a.columns - 1) * a.gap) / a.columns).toFixed(2)}, а полоса высотой{" "}
            {a.bandHeight} дала бы {((a.bandHeight - 6 * a.gap) / 7).toFixed(2)}. Берётся меньшее,
            поэтому сетка ({a.gridHeight.toFixed(2)}) на {(a.bandHeight - a.gridHeight).toFixed(2)}{" "}
            ниже полосы и центруется в ней.
          </p>
          <ContributionsCard
            label="Contributions this year"
            value="$7 462"
            delta={{ label: "+14,8%", direction: "up" }}
            facts={ФАКТЫ}
            period="Weekly"
            periods={ПЕРИОДЫ}
            weeks={ТИПОВОЙ.weeks}
            months={ТИПОВОЙ.months}
          />
        </div>

        <div>
          <h3 className="text-title-l text-ink mb-2">
            {b.columns} колонок по две недели: клетка {b.cellWidth.toFixed(2)} ×{" "}
            {b.cellHeight.toFixed(2)}
          </h3>
          <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
            Теперь ограничитель — ВЫСОТА: колонка дала бы{" "}
            {((b.slotWidth - (b.columns - 1) * b.gap) / b.columns).toFixed(2)}, но полоса разрешает
            только {((b.bandHeight - 6 * b.gap) / 7).toFixed(2)}. Ширина пятна выросла вдвое:{" "}
            {b.cellWidth.toFixed(2)} против {a.cellWidth.toFixed(2)}. Клетка перестаёт быть
            квадратом и становится кирпичом (отношение {(b.cellWidth / b.cellHeight).toFixed(2)}:1),
            зато лента остаётся во всю ширину, а ступень различима. Цена: отдельный день пропал —
            клетка теперь сумма двух недель по этому дню недели, и слайд обязан это сказать словами,
            иначе зритель прочтёт двухнедельную сумму как дневную.
          </p>
          <ContributionsCard
            label="Contributions this year"
            value="$7 462"
            delta={{ label: "+14,8%", direction: "up" }}
            facts={ФАКТЫ}
            period="Monthly"
            periods={ПЕРИОДЫ}
            weeks={сжатые}
            months={ТИПОВОЙ.months.map((m) => ({ ...m, week: Math.floor(m.week / 2) }))}
          />
        </div>
      </div>
    );
  },
};

/* ═══════════════  Лестница  ═══════════════ */

/**
 * Опасный случай: год из единиц. Донорская лестница против сокращённой.
 */
export const Лестница: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">
          Пять ступеней донора — «был вклад» бледнее нуля
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Почти все дни здесь — один вклад, то есть первая ступень. Замер к белой карточке: нулевая
          ступень #d4d4d4 даёт 1,48:1, первая #ddd6ff — 1,39:1. Лестница идёт ВНИЗ на первом шаге, а
          друг от друга ступени отличаются в 1,07 раза. В тёмной теме то же: 1,13 против 1,01, шаг
          1,14. На проекторе год активности выглядит пустым годом.
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="341"
          facts={ФАКТЫ}
          period="Weekly"
          periods={ПЕРИОДЫ}
          weeks={ЕДИНИЦЫ.weeks}
          months={ЕДИНИЦЫ.months}
          max={8}
        />
      </div>
      <div>
        <h3 className="text-title-l text-ink mb-2">
          `scale="readable"` — четыре ступени, нижняя отброшена
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Те же данные, тот же потолок. Первая ступень теперь #a684ff — 2,85:1 к карточке, шаг от
          нуля 1,92 раза (в тёмной теме 1,65:1 и 1,46). Лестница монотонна: «был вклад» темнее, чем
          «не было». Ступеней стало четыре — на слайде это не потеря: пять градаций с четырёх метров
          всё равно не различаются.
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="341"
          facts={ФАКТЫ}
          period="Weekly"
          periods={ПЕРИОДЫ}
          weeks={ЕДИНИЦЫ.weeks}
          months={ЕДИНИЦЫ.months}
          max={8}
          scale="readable"
        />
      </div>
    </div>
  ),
};

/* ═══════════════  Обе темы  ═══════════════ */

/**
 * Светлая и тёмная карточка — вложенной темой, без переключения тулбара.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <p className="text-body-m text-ink-secondary max-w-4xl">
        Лестниц ДВЕ, и это не инверсия одной: светлая идёт violet 200→700 (бледный → глухой), тёмная
        950→500 (почти чёрный → яркий). Направление разное намеренно — рост активности обязан
        увеличивать контраст с фоном, а на тёмном фоне «сильнее» значит «светлее». Нулевая ступень в
        тёмной теме взята НАША (#2f2f2f): донорская #262626 совпадает с цветом нашей карточки и
        исчезла бы совсем.
      </p>
      {(["light", "dark"] as const).map((theme) => (
        <ContributionsCard
          key={theme}
          theme={theme}
          label="Contributions this year"
          value="$7 462"
          delta={{ label: "+14,8%", direction: "up" }}
          facts={ФАКТЫ}
          period="Weekly"
          periods={ПЕРИОДЫ}
          weeks={ТИПОВОЙ.weeks}
          months={ТИПОВОЙ.months}
        />
      ))}
    </div>
  ),
};

/* ═══════════════  Крайние случаи  ═══════════════ */

/**
 * Минимум данных, потолок, длинные подписи, карточка без обвязки.
 */
export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Минимум данных — активность одного месяца</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Год почти пустой: вклады только в марте и по одному в день. Сетка не схлопывается и не
          меняет шаг — колонки на месте, месяцы подписаны, пустой год виден как пустой. Это и есть
          проверка «ничего не схлопнулось в ноль»: при потолке 1 все ненулевые дни попадают на
          верхнюю ступень.
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="17"
          facts={ФАКТЫ.slice(0, 2)}
          weeks={МИНИМУМ.weeks}
          months={МИНИМУМ.months}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок — каждый день на максимуме</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Сплошная заливка верхней ступенью. Клетки не сливаются в одно поле: их разделяет просвет{" "}
          {МЕТРИКА(ПОТОЛОК.weeks.length).gap} — те же 35% стороны, что и у донора. Хвосты первой и
          последней недели остались пустыми — там дней года нет, и они не рисуются вовсе, а не
          красятся нулевой ступенью.
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="8 395"
          delta={{ label: "+240%", direction: "up" }}
          facts={ФАКТЫ}
          period="Yearly"
          periods={ПЕРИОДЫ}
          weeks={ПОТОЛОК.weeks}
          months={ПОТОЛОК.months}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Подписи фактов и строка «Activity» обрезаются многоточием, а не переносятся: перенос
          увеличил бы ряд, и сетка ушла бы за бюджет. Обрезка — сигнал сократить текст, а не
          уменьшить кегль. Ряд периодов не сжимается (`shrink-0`): он подпись, и рвать её нельзя.
        </p>
        <ContributionsCard
          label="Вклад участников за календарный год с учётом ревью и правок"
          value="1 284 950"
          delta={{ label: "−1,8%", direction: "down" }}
          activityLabel="Активность по дням года, включая выходные и праздники"
          facts={[
            { value: "9 000 000 000", label: "Токенов израсходовано за всё время работы" },
            { value: "562.7M", label: "Пиковое потребление за сутки" },
            { value: "12h 54m", label: "Самая длинная непрерывная задача" },
            { value: "62 days", label: "Наибольшая серия дней подряд" },
          ]}
          period="Понедельно"
          periods={["Понедельно", "Помесячно", "Погодно"]}
          weeks={ТИПОВОЙ.weeks}
          months={ТИПОВОЙ.months}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">
          Без фактов и без месяцев — сетке остаётся больше
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-4xl">
          Без ряда фактов полоса под сетку вырастает со {МЕТРИКА(ТИПОВОЙ.weeks.length).bandHeight}{" "}
          до {МЕТРИКА(ТИПОВОЙ.weeks.length, { facts: false }).bandHeight}, и клетка становится{" "}
          {МЕТРИКА(ТИПОВОЙ.weeks.length, { facts: false }).cellHeight.toFixed(2)} — тут её уже
          ограничивает ширина колонки, а не бюджет, поэтому сетка ниже полосы и центруется в ней.
          Месяцы без сетки бессмысленны, но сетка без месяцев работает: год читается формой.
        </p>
        <ContributionsCard
          label="Contributions this year"
          value="$7 462"
          delta={{ label: "+14,8%", direction: "up" }}
          weeks={ТИПОВОЙ.weeks}
        />
      </div>
    </div>
  ),
};

/* ═══════════════  Половинная карточка  ═══════════════ */

/**
 * ⚠️ Половина ширины воспроизводит донора буквально — и показывает, почему
 * так на слайде нельзя.
 */
export const ПоловиннаяКарточка: Story = {
  render: () => {
    const m = МЕТРИКА(ТИПОВОЙ.weeks.length, { size: "half" });
    return (
      <div className="w-[828px]">
        <h3 className="text-title-l text-ink mb-2">
          828 точек: клетка {m.cellWidth.toFixed(2)} × {m.cellHeight.toFixed(2)}
        </h3>
        <p className="text-body-m text-ink-secondary mb-10">
          Это ровно донорская клетка (10,97 при карточке 582) — и ровно то, чего на слайде быть не
          должно: {m.cellWidth.toFixed(2)} из 1920 — это 0,58% кадра, на экране 2,5 м — 1,5 см, с
          четырёх метров 0,21°. Вдвое мельче нижнего кегля шкалы. Ограничитель здесь ШИРИНА: по
          высоте полоса дала бы {((m.bandHeight - 6 * m.gap) / 7).toFixed(2)}, поэтому сетка (
          {m.gridHeight.toFixed(0)}) ниже полосы ({m.bandHeight}) и центруется в ней. Годный выход
          для половины — сводить недели: 27 колонок дают клетку{" "}
          {МЕТРИКА(27, { size: "half" }).cellWidth.toFixed(2)}.
        </p>
        <ContributionsCard
          size="half"
          label="Contributions"
          value="$7 462"
          delta={{ label: "+14,8%", direction: "up" }}
          facts={ФАКТЫ.slice(0, 2)}
          period="Weekly"
          periods={ПЕРИОДЫ}
          weeks={ТИПОВОЙ.weeks}
          months={ТИПОВОЙ.months}
        />
      </div>
    );
  },
};

/* ═══════════════  На слайде  ═══════════════ */

/**
 * Карточка внутри ContentSlide — проверка бюджета 604.
 *
 * Шапка слайда (пилюля, заголовок в одну строку, лид) забирает 244, подвал
 * резервирует 56, блоку остаётся ровно {CARD_BUDGET}. Карточка задана
 * высотой, а не содержимым: сетка обязана поместиться в остаток.
 *
 * ⚠️ Заголовок в ДВЕ строки съедает ещё 60 — тогда `height={544}`, и клетка
 * станет ниже на 8,6.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Активность"
      title="Год не проседает: рабочих дней без вклада — четверть"
      lead="Колонка — неделя, строка — день недели, густота — число вкладов за день"
      page={9}
      label="Витрина карточек"
    >
      <ContributionsCard
        label="Contributions this year"
        value="$7 462"
        delta={{ label: "+14,8%", direction: "up" }}
        facts={ФАКТЫ}
        period="Weekly"
        periods={ПЕРИОДЫ}
        weeks={ТИПОВОЙ.weeks}
        months={ТИПОВОЙ.months}
      />
    </ContentSlide>
  ),
};

/**
 * То же на тёмном слайде — так эту карточку правильно везти на проектор.
 *
 * Ступени в тёмной теме дают меньшие числа контраста (1,65…3,44 против
 * 2,85…7,30), но фон под ними тоже тёмный, а засветка проектора бьёт по
 * светлым слайдам сильнее: белая карточка на экране становится серой, и
 * бледные ступени пропадают первыми.
 */
export const НаТёмномСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Активность"
      title="Год не проседает: рабочих дней без вклада — четверть"
      lead="Колонка — неделя, строка — день недели, густота — число вкладов за день"
      page={10}
      label="Витрина карточек"
    >
      <ContributionsCard
        label="Contributions this year"
        value="$7 462"
        delta={{ label: "+14,8%", direction: "up" }}
        facts={ФАКТЫ}
        period="Weekly"
        periods={ПЕРИОДЫ}
        weeks={ТИПОВОЙ.weeks}
        months={ТИПОВОЙ.months}
        scale="readable"
      />
    </ContentSlide>
  ),
};
