import type { Meta, StoryObj } from "@storybook/react-vite";

import LineCard, { type LinePoint } from "../../../blocks/cards/lineCard";
import { cardAxisTicks } from "../../../blocks/cards/axis";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Линия» — `blocks/cards/lineCard.tsx`.
 *
 * Донор — система дашбордов. Скриншот
 * заказчика: «Revenue / $18 240 / +9.4%», сегмент-контрол Weekly / Monthly /
 * Yearly, одна сглаженная салатовая линия, под ней градиентная площадь,
 * ось `$0 / $2K / $4K / $6K`, месяцы Jan…Dec, легенды нет.
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`, 64 с каждой стороны), поэтому
 * карточка во всю ширину (1680) требует окна от 1808 точек. На узком окне
 * она вылезет за обёртку — это свойство витрины, а не блока: на слайде
 * 1680 встают ровно в поля.
 *
 * ⚠️ Замеры делать только в режиме «1:1 — для замеров». В режиме «вписать в
 * окно» `getBoundingClientRect` возвращает числа после `transform: scale`.
 */

const meta = {
  title: "Карточки/Линия",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

/**
 * Данные донора, снятые разведкой ПО КООРДИНАТАМ пути (ноль на y=191,
 * 32.692px на 1000). Это ряд Weekly с донорской страницы.
 *
 * Максимум 5200 → шаг `niceStep(5200/3)` = 2000 → тики 0 / 2K / 4K / 6K.
 * Ровно то, что на скриншоте заказчика: `$0 / $2K / $4K / $6K`.
 */
const REVENUE: LinePoint[] = [
  1400, 1900, 2600, 2300, 3400, 3100, 2700, 3800, 4600, 4200, 3600, 5200,
].map((value, i) => ({ label: MONTHS[i], value }));

/**
 * Доллар — свойство данных, а не формы, поэтому знак приходит форматом слайда.
 *
 * Минус ставится ПЕРЕД знаком валюты («−$2K»), а не между ним и числом
 * («$-2K»): второе читается как часть суммы. И это настоящий минус U+2212,
 * а не дефис — у дефиса другая ширина и другая высота над базовой линией.
 */
const usd = (v: number) => {
  const a = Math.abs(v);
  const body = a >= 1000 ? `$${a / 1000}K` : `$${a}`;
  return v < 0 ? `−${body}` : body;
};

/* ───────────── подпись под историей ───────────── */

function Note({ children }: { children: React.ReactNode }) {
  return <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">{children}</p>;
}

function Head({ children }: { children: React.ReactNode }) {
  return <h3 className="text-title-l text-ink mb-2">{children}</h3>;
}

/* ═══════════════  типовой случай  ═══════════════ */

/** Скриншот заказчика один в один: те же данные, те же тики, тот же период */
export const Карточка: Story = {
  render: () => (
    <div className="w-[1680px]">
      <Head>Как на скриншоте — 1680 × {CARD_BUDGET}</Head>
      <Note>
        Данные донора. Ось считается, а не задаётся: максимум 5200, шаг{" "}
        {cardAxisTicks(REVENUE.map((p) => p.value)).step}, тики{" "}
        {cardAxisTicks(REVENUE.map((p) => p.value))
          .ticks.map(usd)
          .join(" / ")}{" "}
        — совпало со скриншотом. Слот графика {cardChartWidth(1680)} ×{" "}
        {cardChartHeight({ legend: false })}, легенды нет: ряд один, называет его подпись в шапке.
      </Note>
      <LineCard
        label="Revenue"
        value="$18 240"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        points={REVENUE}
        formatTick={usd}
      />
    </div>
  ),
};

/** Замена наведению: точка и её значение напечатаны */
export const СМаркером: Story = {
  render: () => (
    <div className="w-[1680px]">
      <Head>Точка вместо наведения</Head>
      <Note>
        У донора значение точки появлялось по курсору и уносило подпись шапки. В PDF курсора нет,
        поэтому точка ставится статически и подписывается. Подпись набрана `--t-ink`, а не
        вторичным: в тёмной теме вторичный на верхнем краю площади даёт 2,47:1 при пороге 4,5 —
        замер по пяти точкам вдоль градиента приведён в шапке `lineCard.tsx`. Кольцо вокруг точки —
        цветом фона карточки: контраст линии к своей же площади 1,65:1, цветом точка от неё не
        отделяется.
      </Note>
      <LineCard
        label="Revenue"
        value="$18 240"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        points={REVENUE}
        formatTick={usd}
        marker={{ index: 11, label: "Dec · $5 200" }}
      />
    </div>
  ),
};

/** Ломаная — для данных, где промежуток читать как интерполяцию нельзя */
export const Ломаная: Story = {
  render: () => (
    <div className="w-[1680px]">
      <Head>`shape="sharp"` — те же точки, прямые сегменты</Head>
      <Note>
        Сглаживание — это утверждение, что между точками величина менялась плавно. Для месяцев
        выручки правда, для замеров раз в квартал или для категорий — нет. Кривая здесь монотонная
        (Фрич — Карлсон), а не Catmull-Rom: обычный сплайн перелетает через опорные точки и у
        площади уводит кромку ниже нуля, то есть закрашивает отрицательную массу.
      </Note>
      <LineCard
        label="Revenue"
        value="$18 240"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        points={REVENUE}
        shape="sharp"
        formatTick={usd}
      />
    </div>
  ),
};

/* ═══════════════  обе темы  ═══════════════ */

/**
 * Светлая и тёмная РЯДОМ через вложенную тему — расхождение видно без
 * переключения тулбара.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-8">
      <div>
        <Head>Светлая карточка</Head>
        <Note>
          ⚠️ Слабое место, принятое заказчиком: линия #7ccf00 на белой карточке даёт 1,95:1 при
          пороге 3:1, площадь — 1,18:1. Салат виден как «что-то светло-зелёное», а не как величина.
          Поэтому ось и число обязательны — они и есть содержание.
        </Note>
        <LineCard
          theme="light"
          height={420}
          label="Revenue"
          value="$18 240"
          delta={{ label: "+9,4%", direction: "up" }}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={REVENUE}
          formatTick={usd}
        />
      </div>
      <div>
        <Head>Тёмная карточка</Head>
        <Note>
          Те же краски дают 7,77:1 у линии и 2,43:1 у верха площади. Запас вчетверо больше светлой
          темы. Если карточка едет на проектор — брать эту.
        </Note>
        <LineCard
          theme="dark"
          height={420}
          label="Revenue"
          value="$18 240"
          delta={{ label: "+9,4%", direction: "up" }}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={REVENUE}
          formatTick={usd}
        />
      </div>
    </div>
  ),
};

/* ═══════════════  крайние случаи  ═══════════════ */

/** Две точки — меньше линия не бывает */
export const МинимумДанных: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <Head>Две точки</Head>
        <Note>
          Линия из двух точек — это стрелка «было → стало», и на слайде она честнее, чем те же два
          числа в графике из двенадцати. Прореживание оси здесь не срабатывает: обе подписи
          помещаются, крайние прижаты к краям SVG якорем, а не отступом.
        </Note>
        <LineCard
          height={380}
          label="Revenue"
          value="$5 200"
          delta={{ label: "+271%", direction: "up" }}
          period={{ label: "Yearly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={[
            { label: "Jan", value: 1400 },
            { label: "Dec", value: 5200 },
          ]}
          formatTick={usd}
          marker={{ index: 1, label: "$5 200" }}
        />
      </div>
      <div>
        <Head>Одна точка</Head>
        <Note>
          Не должно ронять блок, но и графиком не является: одно число — это плитка `StatTiles`, а
          не линия. Точка встаёт по центру поля, линия вырождается в неё же. История нужна, чтобы
          вырождение было видно, а не вылезло на слайде клиента.
        </Note>
        <LineCard
          height={380}
          label="Revenue"
          value="$1 400"
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={[{ label: "Jan", value: 1400 }]}
          formatTick={usd}
          marker={{ index: 0, label: "$1 400" }}
        />
      </div>
    </div>
  ),
};

/** Потолок: столько подписей, что ось приходится прореживать */
export const Потолок: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <Head>52 недели во всю ширину</Head>
        <Note>
          Подписи прорежены по ЗАМЕРУ ширины каждой строки, а не по фиксированному шагу: жадный
          проход слева с бронью на последнюю подпись. Последняя точка — та, ради которой график и
          смотрят, поэтому она не может быть выброшена жадностью. Сама линия при этом рисует все 52
          точки: прореживается подпись, а не данные.
        </Note>
        <LineCard
          height={440}
          label="Sessions"
          value="126 400"
          delta={{ label: "+18,2%", direction: "up" }}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={Array.from({ length: 52 }, (_, i) => ({
            label: `W${i + 1}`,
            /* Ряд держится выше нуля намеренно: здесь проверяется прореживание
               подписей, а отрицательные значения — отдельная история ниже */
            value: 1600 + Math.round(900 * Math.sin(i / 5)) + i * 55,
          }))}
        />
      </div>
      <div>
        <Head>Половина ширины: 828, те же 12 месяцев</Head>
        <Note>
          Поле {cardChartWidth(828, "half")} × {cardChartHeight({ size: "half", legend: false })} —
          это{" "}
          {(cardChartWidth(828, "half") / cardChartHeight({ size: "half", legend: false })).toFixed(
            2,
          )}
          :1 против донорских 2,64:1. Толщина линии считается от ширины поля (доля донора 0,506%),
          но упирается в пол 5 — толщину линий системы: 3,6px на проекторе были бы волоском.
        </Note>
        <div className="flex gap-6">
          <div className="w-[828px]">
            <LineCard
              size="half"
              width={828}
              height={440}
              label="Revenue"
              value="$18 240"
              delta={{ label: "+9,4%", direction: "up" }}
              period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
              points={REVENUE}
              formatTick={usd}
            />
          </div>
          <div className="w-[828px]">
            <LineCard
              size="half"
              width={828}
              height={440}
              label="Sessions"
              value="83 200"
              delta={{ label: "−3,2%", direction: "down" }}
              period={{ label: "Monthly", segments: ["Weekly", "Monthly", "Yearly"] }}
              points={REVENUE.map((p) => ({ ...p, value: Math.round(p.value * 1.7) }))}
              series="blue"
            />
          </div>
        </div>
      </div>
    </div>
  ),
};

/** Длинные подписи: они лечатся жёлобом и якорем, а не мелким кеглем */
export const ДлинныеПодписи: Story = {
  render: () => (
    <div className="w-[1680px]">
      <Head>Длинная подпись шапки, широкие тики, длинные месяцы</Head>
      <Note>
        Жёлоб слева считается по САМОЙ ШИРОКОЙ подписи тика — здесь это «1 500 000 ₽», и поле
        построения ужимается ровно на её ширину: замер даёт жёлоб 123 против 52 у долларовой оси.
        Поле справа — половина последней подписи оси. Оба крайних якоря переставляются на край SVG,
        если центрованная подпись за него выходит: без этого горизонтальная проверка переполнения
        (порог 4px) сработала бы уже на выгрузке. Подпись шапки здесь помещается целиком — во всю
        ширину места хватает; многоточие `CardShell` включается на половинной карточке.
      </Note>
      <LineCard
        label="Средний чек в разрезе каналов привлечения за вычетом возвратов, скидок и бонусов"
        value="1 284 950"
        delta={{ label: "ниже плана на треть", direction: "down" }}
        period={{ label: "Последние 12 месяцев" }}
        points={[
          "Январь",
          "Февраль",
          "Март",
          "Апрель",
          "Май",
          "Июнь",
          "Июль",
          "Август",
          "Сентябрь",
          "Октябрь",
          "Ноябрь",
          "Декабрь",
        ].map((label, i) => ({ label, value: REVENUE[i].value * 247 }))}
        formatTick={(v) => `${v.toLocaleString("ru-RU")} ₽`}
        marker={{ index: 11, label: "Декабрь · 1 284 400 ₽" }}
      />
    </div>
  ),
};

/**
 * Опасный случай — то, на чём график обычно и ломается.
 *
 * Три беды в одном месте: плоский ряд (домен схлопывается, шкала делит на
 * ноль), нули по всему ряду и отрицательные значения (площадь обязана уйти
 * ПОД нулевую линию, а не быть обрезанной по низу поля).
 */
export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <Head>Ряд из одних нулей</Head>
        <Note>
          Домен схлопнулся бы в точку, и шкала дала бы деление на ноль — на слайде это NaN в
          атрибуте `d` и ПУСТОЙ график, который проходит все автопроверки, кроме проверки на
          пустоту. Поэтому вырожденный домен подменяется на [0, 1] явно: линия ложится на нулевую,
          тики 0 и 1.
        </Note>
        <LineCard
          height={360}
          label="Revenue"
          value="$0"
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={MONTHS.map((label) => ({ label, value: 0 }))}
          formatTick={usd}
        />
      </div>
      <div>
        <Head>Плоский ненулевой ряд</Head>
        <Note>
          Значение одно и то же во всех точках. Ноль в домене жёсткий, поэтому линия встаёт на своей
          высоте, а не в середине поля: у площади масса обязана быть пропорциональна величине, иначе
          ряд, который больше соседнего в полтора раза, рисуется втрое жирнее.
        </Note>
        <LineCard
          height={360}
          label="Revenue"
          value="$3 400"
          delta={{ label: "0,0%", direction: "up" }}
          period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={MONTHS.map((label) => ({ label, value: 3400 }))}
          formatTick={usd}
        />
      </div>
      <div>
        <Head>Отрицательные значения</Head>
        <Note>
          Площадь замыкается по НУЛЕВОЙ линии, а не по низу поля, поэтому убыток закрашивается вниз,
          а не обрезается. Ось при этом включает отрицательные тики. ⚠️ Градиент площади остаётся
          единым сверху вниз — у части под нулём он почти прозрачен, и убыток читается силуэтом
          линии, а не массой. Если убыток — мысль слайда, честнее расходящиеся столбики
          (`blocks/deltas.tsx`), а не эта карточка.
        </Note>
        <LineCard
          height={400}
          label="Operating result"
          value="−$1 900"
          delta={{ label: "−212%", direction: "down" }}
          period={{ label: "Monthly", segments: ["Weekly", "Monthly", "Yearly"] }}
          points={[1400, 900, -600, -1200, 400, 1100, -300, -1900, -800, 600, 1500, 2400].map(
            (value, i) => ({ label: MONTHS[i], value }),
          )}
          formatTick={usd}
        />
      </div>
    </div>
  ),
};

/* ═══════════════  как на слайде  ═══════════════ */

/**
 * Карточка внутри `ContentSlide` — единственная проверка, которая
 * подтверждает бюджет 604. В обёртке витрины он не проверяется никак:
 * там нет ни шапки слайда, ни подвала, ни холста 1080.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Выручка"
      title="Декабрь закрыли на $5 200 — вчетверо больше января"
      page={7}
      label="Витрина карточек"
    >
      <LineCard
        label="Revenue"
        value="$18 240"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        points={REVENUE}
        formatTick={usd}
        marker={{ index: 11, label: "Dec · $5 200" }}
      />
    </ContentSlide>
  ),
};

/** Тот же слайд в тёмной теме — та, под которую карточка и рассчитана */
export const НаСлайдеТёмном: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Выручка"
      title="Декабрь закрыли на $5 200 — вчетверо больше января"
      page={8}
      label="Витрина карточек"
    >
      <LineCard
        label="Revenue"
        value="$18 240"
        delta={{ label: "+9,4%", direction: "up" }}
        period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
        points={REVENUE}
        formatTick={usd}
        marker={{ index: 11, label: "Dec · $5 200" }}
      />
    </ContentSlide>
  ),
};

/** Две половинные на одном слайде — пропорции ближе к донорским */
export const НаСлайдеПара: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Выручка"
      title="Выручка растёт быстрее трафика — растёт средний чек"
      page={9}
      label="Витрина карточек"
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-6">
          <LineCard
            size="half"
            width={828}
            height={548}
            label="Revenue"
            value="$18 240"
            delta={{ label: "+9,4%", direction: "up" }}
            period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
            points={REVENUE}
            formatTick={usd}
          />
        </div>
        <div className="col-span-6">
          <LineCard
            size="half"
            width={828}
            height={548}
            label="Sessions"
            value="31 000"
            delta={{ label: "+2,1%", direction: "up" }}
            period={{ label: "Weekly", segments: ["Weekly", "Monthly", "Yearly"] }}
            points={REVENUE.map((p) => ({ ...p, value: 1700 + p.value }))}
            series="blue"
          />
        </div>
      </div>
    </ContentSlide>
  ),
};
