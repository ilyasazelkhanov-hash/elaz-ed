import type { Meta, StoryObj } from "@storybook/react-vite";
import { DivergingBars, SplitVerdict, TransitionRows } from "../../blocks/deltas";
import { ShareRibbon } from "../../blocks/share";
import { MergeFlow } from "../../blocks/flow";
import { RoadmapBars } from "../../blocks/roadmap";

/**
 * Блоки изменения и структуры.
 *
 * Все шесть добавлены под реальный аудит, и каждый отвечает на вопрос,
 * на который прежние формы отвечали плохо:
 *
 *   DivergingBars — «показатели разошлись» вместо «один больше другого»
 *   TransitionRows — «перешло из одного состояния в другое»
 *   SplitVerdict  — «у одной вещи две противоположные оценки»
 *   ShareRibbon   — «целое держится на первых нескольких частях»
 *   MergeFlow     — «две страницы надо свести в одну»
 *   RoadmapBars   — «задачи идут ОДНОВРЕМЕННО, а не очередью»
 *
 * Данные здесь демонстрационные и намеренно НЕ совпадают с числами дека:
 * витрина показывает поведение блока, а не содержание презентации.
 * Совпадающие числа рано или поздно начинают жить своей жизнью и
 * расходятся с data/*.
 */

const meta = {
  title: "Блоки/Изменение и структура",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Расхождение: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">DivergingBars — показатели разошлись</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Нулевая линия посередине делает вывод формой. Высота считается от наибольшего по модулю
          изменения, поэтому маленькое изменение и выглядит маленьким — масштаб, подобранный под
          вывод, на клиентском слайде недопустим.
        </p>
        <DivergingBars
          height={360}
          items={[
            { label: "Клики", value: "4 618", delta: 55.9, note: "последние 28 дней" },
            { label: "Показы", value: "200 847", delta: -7.8, note: "последние 28 дней" },
          ]}
        />
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Тот же блок при сопоставимых величинах</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Когда изменения близки по модулю, оба столбца заметны. Это проверка на то, что масштаб не
          привязан к знаку.
        </p>
        <DivergingBars
          height={300}
          items={[
            { label: "Небрендовые клики", value: "1 240", delta: 18.4 },
            { label: "Брендовые клики", value: "3 378", delta: -21.2 },
          ]}
        />
      </section>
    </div>
  ),
};

export const БылоСтало: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">TransitionRows</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Стрелка между значениями делает связь формой: пара читается за один взгляд, а не собирается
        в голове из трёх ячеек таблицы. «Было» набрано третичным цветом — это разрешено ровно
        потому, что кегль здесь 44px, а третичный допустим от 24px.
      </p>
      <TransitionRows
        items={[
          { label: "CTR", from: "1,36%", to: "2,30%", note: "сниппеты стали работать лучше" },
          { label: "Средняя позиция", from: "7,66", to: "7,31", note: "небольшое улучшение" },
          { label: "Страниц в индексе", from: "19", to: "27", note: "индекс расширялся" },
        ]}
      />
    </div>
  ),
};

export const ДвеОценки: Story = {
  render: () => (
    <div className="max-w-[1200px]">
      <h3 className="text-title-l text-ink mb-2">SplitVerdict</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Для вывода-противоречия: по одному признаку хорошо, по другому плохо. Два отдельных числа
        рядом читаются как два независимых факта — общая рамка делает из них одно наблюдение.
      </p>
      <SplitVerdict
        title="Страница рейтинга"
        good={{
          caption: "Позиция уже хорошая",
          value: "4,81",
          note: "поиск показывает страницу высоко",
        }}
        bad={{
          caption: "А клика не происходит",
          value: "0,97%",
          note: "сниппет не отвечает на запрос",
        }}
      />
    </div>
  ),
};

export const ЛентаДолей: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">ShareRibbon</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Скоба складывает первые сегменты за зрителя и подписывает результат. Это другой вывод, чем у
        обычной полосы состава: не «из чего состоит целое», а «насколько целое держится на
        нескольких первых частях».
      </p>
      <ShareRibbon
        groupCount={3}
        groupLabel="93,0% кликов дают три страницы"
        items={[
          { label: "/catalog/coffee-machines", value: 44.5, caption: "5 420 кликов" },
          { label: "Главная /", value: 33.8, caption: "4 119 кликов" },
          { label: "/catalog/grinders", value: 14.6, caption: "1 775 кликов" },
          { label: "/rating", value: 1.5, caption: "185 кликов" },
          { label: "Остальные страницы", value: 5.5, caption: "671 клик" },
        ]}
      />
    </div>
  ),
};

export const Склейка: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">MergeFlow</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Ветки сходятся слева направо, к результату. Обратное направление читалось бы как разделение,
        то есть как противоположная рекомендация. Пунктирная ветка — та страница, которая перестаёт
        существовать самостоятельно.
      </p>
      <MergeFlow
        pairs={[
          {
            topic: "Кофемашины",
            intent: "обзор · сравнение · цена",
            keep: { url: "/catalog/coffee-machines", result: "5 420 кликов" },
            merge: { url: "/blog/coffee-machines-…", result: "9 кликов" },
            outcome: "Основная страница темы: /catalog/coffee-machines",
          },
        ]}
      />
    </div>
  ),
};

export const ПланНаНеделях: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">RoadmapBars</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Главное, что даёт шкала и не даёт таблица, — видно, что задачи идут одновременно. В столбце
        «1–2, 2–4, 3–6» это не читается, и план понимают как очередь на двенадцать недель подряд.
        Полосы одного тона: цвет здесь не различает задачи, их различает строка.
      </p>
      <RoadmapBars
        weeks={12}
        labelWidth={560}
        tasks={[
          {
            from: 1,
            to: 2,
            title: "Зафиксировать базовую аналитику",
            done: "Понятна точка старта",
          },
          {
            from: 1,
            to: 2,
            title: "Очистить индексируемую структуру",
            done: "Робот не тратит обход на мусор",
          },
          {
            from: 3,
            to: 6,
            title: "Переписать приоритетные страницы",
            done: "Методика, автор, дата",
          },
          {
            from: 6,
            to: 12,
            title: "Расширить полезную семантику",
            done: "Растёт доля кликов вне лидеров",
          },
        ]}
      />
    </div>
  ),
};
