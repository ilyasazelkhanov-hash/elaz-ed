import { useLayoutEffect, useRef, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import HeatmapCard, {
  HEAT_ACCENT,
  HEAT_FLOOR,
  HEAT_LEGEND_STOPS,
  heatFill,
  heatmapGeometry,
  type HeatmapRow,
} from "../../../blocks/cards/heatmapCard";
import { CARD_BUDGET } from "../../../blocks/cards/shell";
import { BOARD_CHART, BOARD_SERIES } from "../../../lib/boardPalette";
import { contrast } from "../../../lib/color";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка-дашборд «тепловая карта»: день × час.
 *
 * Перенос седьмого донорского скриншота. Переносится не форма графика,
 * а карточка целиком: шапка с числом и чипом, подпись периода, матрица,
 * легенда шкалы «Less … More».
 *
 * === Чем это отличается от `Блоки/Тепловая решётка` ===
 *
 * Там — БЛОК во всю ширину слайда, 6–12 колонок × 3–5 строк, и в каждой
 * клетке НАПЕЧАТАНО ЧИСЛО. Здесь — СОДЕРЖИМОЕ КАРТОЧКИ: матрица 7×12 и
 * крупнее, клетка 40 точек высотой, цифр в клетках нет вовсе, а точное
 * значение заменено печатной подписью пика. Разбор по трём осям — в шапке
 * `src/blocks/cards/heatmapCard.tsx`.
 *
 * Одной строкой: нужны числа — «Тепловая решётка»; нужна карточка
 * дашборда с крупным итогом и мелкой матрицей — эта.
 *
 * === Про числа в историях ===
 *
 * Матрица выдумана, но СВЯЗНА: число в шапке считается суммой самих клеток,
 * а подпись пика — поиском максимума по тем же данным. Ни одно производное
 * число здесь не переписано руками — иначе оно разъедется с матрицей при
 * первой правке, и на слайде этого никто не заметит.
 *
 * ⚠️ Витрина добавляет своё поле (`p-16`), поэтому карточка во всю ширину
 * (1680) требует окна от 1808 точек. На узком окне она вылезет за обёртку —
 * это свойство витрины, а не блока.
 *
 * ⚠️ Замеры делать в режиме тулбара «1:1 — для замеров». В режиме «вписать
 * в окно» холст сжат трансформацией, и `getBoundingClientRect` врёт.
 */

const meta = {
  title: "Карточки/Тепловая карта",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные ───────────── */

/** Часы через два: 12 колонок, как на скриншоте донора */
const HOURS = ["00", "02", "04", "06", "08", "10", "12", "14", "16", "18", "20", "22"];

/** Активность по дням недели. Будни с дневным пиком, выходные ровнее */
const WEEK: HeatmapRow[] = [
  { label: "Mon", values: [3, 2, 2, 4, 12, 26, 31, 28, 22, 14, 7, 4] },
  { label: "Tue", values: [4, 2, 3, 6, 15, 29, 34, 33, 25, 16, 8, 5] },
  { label: "Wed", values: [3, 3, 4, 7, 17, 31, 36, 35, 27, 18, 9, 5] },
  { label: "Thu", values: [5, 3, 4, 8, 19, 34, 41, 38, 44, 20, 10, 6] },
  { label: "Fri", values: [4, 3, 5, 9, 18, 30, 35, 32, 26, 19, 12, 8] },
  { label: "Sat", values: [7, 5, 4, 5, 9, 14, 18, 20, 19, 17, 13, 9] },
  { label: "Sun", values: [6, 4, 3, 4, 8, 12, 15, 17, 16, 14, 11, 8] },
];

/** Итог считается ИЗ матрицы, а не переписывается со скриншота донора */
function total(rows: HeatmapRow[]) {
  return rows.reduce((sum, row) => sum + row.values.reduce((s: number, v) => s + (v ?? 0), 0), 0);
}

/** Разделитель разрядов — неразрывный пробел, как везде в системе */
function ru(n: number) {
  return n.toLocaleString("ru-RU").replace(/ /g, " ");
}

/** Часы 00…23: 24 колонки, полное разрешение суток */
const HOURS_24 = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));

/** Те же дни, но по часам: интерполяция соседних значений двухчасовой сетки */
const WEEK_24: HeatmapRow[] = WEEK.map((row) => ({
  label: row.label,
  values: row.values.flatMap((v, i) => {
    const next = row.values[i + 1] ?? v;
    return [v as number, Math.round(((v as number) + (next as number)) / 2)];
  }),
}));

/** Данные для потолка: 12 строк по 24 часа */
const MONTH_24: HeatmapRow[] = Array.from({ length: 12 }, (_, w) => ({
  label: `W${w + 1}`,
  values: HOURS_24.map((_, h) => {
    const day = Math.max(0, 20 - Math.abs(h - 14) * 2);
    return Math.round(day * (1 + ((w % 5) - 2) / 10));
  }),
}));

/* ───────────── замерочная обвязка ───────────── */

/** Печатает фактические числа расчёта — чтобы высоту не подбирать на глаз */
function Geometry({
  size,
  cardWidth,
  rows,
  columns,
  height = CARD_BUDGET,
}: {
  size: "full" | "half";
  cardWidth: number;
  rows: number;
  columns: number;
  height?: number;
}) {
  const g = heatmapGeometry({ cardWidth, size, rows, columns, height });
  return (
    <p className="text-body-m text-ink-secondary mb-8 max-w-5xl tabular-nums">
      Карточка {cardWidth} × {height}. Слот {g.slot}, матрица {g.matrix}, занято {g.used}. Клетка{" "}
      {g.cellWidth.toFixed(1)} × {g.cellHeight} — это {g.ratio.toFixed(2)}:1 при донорских 1.32:1.
      Подписи колонок {g.labelStep === 1 ? "все" : "через одну"}.
    </p>
  );
}

/* ───────────── истории ───────────── */

/** Типовой случай: 7×12 во всю рабочую ширину */
export const Карточка: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <Geometry size="full" cardWidth={1680} rows={7} columns={12} />
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Клетка вышла втрое шире своей высоты — матрица читается полосками, а не полем. Это не дефект
        вёрстки, а следствие ширины: 12 делений на 1608 точек. Донорская пропорция возвращается
        двумя способами, оба ниже — половинная карточка и 24 колонки вместо 12.
      </p>
      <HeatmapCard
        label="Active users"
        value={ru(total(WEEK))}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        columns={HOURS}
        rows={WEEK}
      />
    </div>
  ),
};

/** Половинная карточка — пропорция клетки почти донорская */
export const ПоловиннаяШирина: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Две по 828 — ближе к оригиналу</h3>
      <Geometry size="half" cardWidth={828} rows={7} columns={12} />
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Поля тоньше (20 вместо 36), радиус на ступень меньше (`rounded-panel` 32 вместо
        `rounded-hero` 48), клетка почти квадратная. Справа — второй акцент: рампа строится от любой
        краски донора, формула та же.
      </p>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        ⚠️ Цена смены акцента — числом. Верхняя ступень синей рампы даёт на белой карточке 3,76:1,
        изумрудной (`emerald-400` #00d492) — 1,94:1. То есть у правой карточки порог 3:1 не берёт
        ДАЖЕ пик: в светлой теме это карта «где гуще», а не «сколько именно», и подпись пика
        становится не украшением, а единственным способом прочесть величину. В тёмной теме тот же
        изумруд даёт 7,81:1 и проблемы нет. Замеры красок — в шапке `lib/boardPalette.ts`.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            label="Active users"
            value={ru(total(WEEK))}
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            columns={HOURS}
            rows={WEEK}
          />
        </div>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            accent={BOARD_SERIES[BOARD_CHART.emerald]}
            label="Revenue by hour"
            value={`$${ru(total(WEEK) * 7)}`}
            delta={{ label: "+11,8%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            columns={HOURS}
            rows={WEEK}
            formatValue={(v) => `$${ru(v * 7)}`}
          />
        </div>
      </div>
    </div>
  ),
};

/** 24 колонки: полная ширина честна там, где делений много */
export const ПолноеРазрешениеСуток: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">24 колонки во всю ширину</h3>
      <Geometry size="full" cardWidth={1680} rows={7} columns={24} />
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Клетка 55 × 40 — 1.38:1, то есть донорская пропорция. Шаг колонки 63 точки, подписи
        помещаются все. Вывод для слайда: карточку во всю ширину надо кормить мелким делением (часы,
        дни месяца, недели года), а не растягивать двенадцать колонок.
      </p>
      <HeatmapCard
        label="Active users"
        value={ru(total(WEEK_24))}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        columns={HOURS_24}
        rows={WEEK_24}
      />
    </div>
  ),
};

/** Обе темы рядом — вложенной темой, без переключения тулбара */
export const ОбеТемы: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Светлая и тёмная карточка рядом</h3>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Тема задана самой карточке, поэтому тулбар её не перебивает. Рампа переворачивается сама:
        `color-mix` подмешивает акцент в токен трека (`--t-fill-strong` — #ebebeb в светлой, #2f2f2f
        в тёмной), и та же формула даёт светлую рампу на белой карточке и тёмно-синюю на тёмной. Хук
        определения темы этому блоку не нужен, потому что цифр в клетках нет.
      </p>
      <div className="flex gap-6">
        <div className="w-[828px]">
          <HeatmapCard
            theme="light"
            size="half"
            cardWidth={828}
            label="Active users"
            value={ru(total(WEEK))}
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            columns={HOURS}
            rows={WEEK}
          />
        </div>
        <div className="w-[828px]">
          <HeatmapCard
            theme="dark"
            size="half"
            cardWidth={828}
            label="Active users"
            value={ru(total(WEEK))}
            delta={{ label: "+5,2%", direction: "up" }}
            period={{ label: "Last 7 days" }}
            columns={HOURS}
            rows={WEEK}
          />
        </div>
      </div>
    </div>
  ),
};

/* ───────────── замер контраста ───────────── */

/**
 * Вычисленный цвет → hex.
 *
 * ⚠️ Два синтаксиса, и разница не косметическая. Замер в Chromium:
 * обычная заливка приходит как `rgb(255, 255, 255)` — каналы 0…255,
 * а результат `color-mix(in srgb, …)` как `color(srgb 0.74 0.82 0.94)` —
 * каналы 0…1. Разбор «взять все числа» на втором даёт почти чёрный
 * вместо голубого, и таблица контраста ниже печатала бы правдоподобную
 * чушь. Поймано замером, а не рассуждением.
 */
function toHex(color: string) {
  const m = color.match(/\d+(\.\d+)?/g);
  if (!m || m.length < 3) return "#000000";
  const scale = color.startsWith("color(") ? 255 : 1;
  return `#${m
    .slice(0, 3)
    .map((v) =>
      Math.round(Number(v) * scale)
        .toString(16)
        .padStart(2, "0"),
    )
    .join("")}`;
}

interface Probe {
  theme: string;
  what: string;
  fill: string;
  over: string;
  ratio: number;
  /** Порог WCAG: 4.5 для текста мельче 24, 3 для крупного текста и графики */
  need: number;
  /** Ниже порога — но так и задумано: нижний конец непрерывной шкалы */
  ramp: boolean;
}

/** Полупрозрачный цвет складывается с тем, что под ним, иначе замер врёт */
function flatten(color: string, over: string) {
  const m = color.match(/[\d.]+/g) ?? [];
  const alpha = m.length > 3 ? Number(m[3]) : 1;
  if (alpha >= 1) return toHex(color);
  const fg = toHex(color);
  const bg = toHex(over);
  const ch = (i: number) => {
    const f = parseInt(fg.slice(1 + i * 2, 3 + i * 2), 16);
    const b = parseInt(bg.slice(1 + i * 2, 3 + i * 2), 16);
    return Math.round(f * alpha + b * (1 - alpha));
  };
  return `#${[0, 1, 2].map((i) => ch(i).toString(16).padStart(2, "0")).join("")}`;
}

/** Данные пробника: рампа от 0 до потолка плюс оба состояния вне шкалы */
const PROBE_ROWS: HeatmapRow[] = [
  { label: "рампа", values: [0, 10, 25, 50, 75, 100] },
  { label: "нет данных", values: [null, null, null, null, null, null] },
  { label: "ниже нуля", values: [-5, -5, -5, -5, -5, -5] },
];

const PROBE_COLUMNS = ["0%", "10%", "25%", "50%", "75%", "100%"];

/**
 * Снимает ФАКТИЧЕСКИЕ цвета из браузера и считает контраст.
 *
 * Меряется НАСТОЯЩАЯ карточка, а не образцы, собранные теми же классами
 * рядом: образец — это копия, а копия расходится с оригиналом молча.
 * Поэтому пробник рендерит `HeatmapCard` в обеих темах и читает у неё
 * вычисленные стили.
 *
 * Формулу `color-mix` вычисляет браузер: единственный честный способ узнать
 * цвет клетки — прочитать вычисленный стиль, а не пересчитать смесь в уме.
 */
function ContrastTable() {
  const ref = useRef<HTMLDivElement>(null);
  const [rows, setRows] = useState<Probe[]>([]);

  useLayoutEffect(() => {
    const root = ref.current;
    if (!root) return;
    const out: Probe[] = [];

    for (const theme of ["light", "dark"] as const) {
      const card = root.querySelector<HTMLElement>(`[data-probe="${theme}"] .bg-surface`);
      if (!card) continue;
      const surface = toHex(getComputedStyle(card).backgroundColor);

      const grid = card.querySelector<HTMLElement>("[style*='grid-template-columns']");
      if (!grid) continue;

      const push = (what: string, raw: string, need: number, ramp = false) => {
        const fill = flatten(raw, surface);
        out.push({ theme, what, fill, over: surface, ratio: contrast(fill, surface), need, ramp });
      };

      // клетки рампы: доля растёт слева направо, шесть точек по длине
      grid.querySelectorAll<HTMLElement>("[style*='color-mix']").forEach((cell, i) => {
        push(`клетка ${PROBE_COLUMNS[i]} шкалы`, getComputedStyle(cell).backgroundColor, 3, true);
      });

      const empty = grid.querySelector<HTMLElement>(".bg-fill");
      if (empty) {
        const cs = getComputedStyle(empty);
        push("клетка «нет данных»", cs.backgroundColor, 3, true);
        push("её контур", cs.borderTopColor, 3);
      }

      const negative = grid.querySelector<HTMLElement>(".bg-error");
      if (negative) push("клетка «ниже нуля»", getComputedStyle(negative).backgroundColor, 3);

      // легенда шкалы лежит вне сетки — те же пять точек донора
      const swatches = [...card.querySelectorAll<HTMLElement>("[style*='color-mix']")].filter(
        (el) => !grid.contains(el),
      );
      swatches.forEach((swatch, i) => {
        const percent = Math.round(HEAT_FLOOR + (100 - HEAT_FLOOR) * (HEAT_LEGEND_STOPS[i] ?? 0));
        push(`квадратик легенды ${percent}%`, getComputedStyle(swatch).backgroundColor, 3, true);
      });

      // подписи: кегль 18, значит порог 4.5
      const texts = [...card.querySelectorAll<HTMLElement>("span")].filter(
        (s) => !s.children.length && s.textContent?.trim(),
      );
      const byText = (needle: string) => texts.find((t) => t.textContent?.includes(needle));
      const label = byText("рампа");
      if (label) push("подпись строки, 18px", getComputedStyle(label).color, 4.5);
      const column = byText("50%");
      if (column) push("подпись колонки, 18px", getComputedStyle(column).color, 4.5);
      const less = byText("Less");
      if (less) push("слово Less, 18px", getComputedStyle(less).color, 4.5);
      const note = byText("Красным");
      if (note) push("строка под матрицей, 18px", getComputedStyle(note).color, 4.5);
      const value = byText("100");
      if (value) push("число шапки, 56px", getComputedStyle(value).color, 3);
    }

    setRows(out);
  }, []);

  return (
    <div ref={ref}>
      <div className="mb-10 flex gap-6">
        {(["light", "dark"] as const).map((theme) => (
          <div key={theme} data-probe={theme} className="w-[828px]">
            <HeatmapCard
              theme={theme}
              size="half"
              cardWidth={828}
              height={400}
              rowLabelWidth={160}
              max={100}
              label="Пробник рампы"
              value="100"
              period={{ label: theme === "light" ? "светлая" : "тёмная" }}
              columns={PROBE_COLUMNS}
              rows={PROBE_ROWS}
            />
          </div>
        ))}
      </div>

      <table className="text-body-m text-ink w-full max-w-5xl tabular-nums">
        <thead className="text-ink-secondary">
          <tr>
            {["тема", "что", "цвет", "на чём", "контраст", "порог"].map((h) => (
              <th key={h} className="border-line border-b py-2 text-left font-normal">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              <td className="border-line border-b py-2">{r.theme}</td>
              <td className="border-line border-b py-2">{r.what}</td>
              <td className="border-line border-b py-2">{r.fill}</td>
              <td className="border-line border-b py-2">{r.over}</td>
              <td className="border-line border-b py-2">{r.ratio.toFixed(2)}</td>
              <td className="border-line border-b py-2">
                {r.ratio >= r.need
                  ? r.need
                  : r.ramp
                    ? `${r.need} — не берёт, так и задумано`
                    : `${r.need} — НЕ БЕРЁТ`}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/** Контраст замером: подписи на карточке и клетки по всей длине рампы */
export const Контраст: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Замер, а не расчёт в уме</h3>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Рампа проверяется в шести точках по длине, а не в одной: у непрерывной шкалы нижний конец
        ОБЯЗАН таять в фоне, иначе «почти ноль» и «половина» станут неразличимы. Порог 3:1
        предъявляется клетке с заметной величиной — примерно с середины шкалы, — а не каждой клетке
        подряд. Пол доли поднят с донорских {8} до {HEAT_FLOOR}% именно поэтому: при 8% нижняя
        ступень на проекторе с засветкой пропадала совсем. Акцент — {HEAT_ACCENT}.
      </p>
      <ContrastTable />
    </div>
  ),
};

/** Крайние случаи: минимум данных, потолок, длинные подписи, пустые клетки */
export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">Минимум данных: 2 × 3</h3>
        <Geometry size="half" cardWidth={828} rows={2} columns={3} height={400} />
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Клетка не бывает выше своей ширины — иначе матрица вытягивается в столбики. Здесь
          ограничение сработало: по высоте помещалось бы больше, но клетка остановилась на ширине.
          Остаток ушёл НАД строку шкалы, а не под неё. На таких данных карточка не нужна вовсе:
          шесть чисел честнее напечатать.
        </p>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            height={400}
            label="Пилот"
            value="3"
            period={{ label: "Три дня" }}
            columns={["Утро", "День", "Вечер"]}
            rows={[
              { label: "Пн", values: [1, 3, 2] },
              { label: "Вт", values: [2, 1, 3] },
            ]}
          />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок: 12 строк × 24 колонки = 288 клеток</h3>
        <Geometry size="full" cardWidth={1680} rows={12} columns={24} />
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Клетка сжалась до 22 точек, подписи колонок печатаются все (шаг 63). Пол клетки — 16: если
          бы расчёт дал меньше, матрица вышла бы за слот и `npm run check` увидел бы переполнение.
          Это предел формы, а не рекомендация: на показе с четырёх метров такая матрица читается
          пятном, а не полем.
        </p>
        <HeatmapCard
          label="Заявки"
          value={ru(total(MONTH_24))}
          delta={{ label: "+2,4%", direction: "up" }}
          period={{ label: "Last 12 weeks" }}
          columns={HOURS_24}
          rows={MONTH_24}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи и пустые клетки</h3>
        <Geometry size="full" cardWidth={1680} rows={4} columns={6} />
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Колонка подписей расширена до 320 — при ней длинные названия помещаются целиком (замер: ни
          одной обрезанной строки). Что бывает без этого, показывает вторая карточка: там колонка
          осталась по умолчанию 88, и от «Азиатско-Тихоокеанского региона» остаётся «Ази…». Обрезка
          — механизм защиты, а не решение: подпись, от которой остались три буквы, бесполезна, и
          лечится это шириной колонки или короткими названиями в данных. Подпись строки обрезается
          многоточием, а не переносится — перенос увеличил бы строку, и матрица уехала бы за слот.
          Клетки без данных (`null`) — нейтральная заливка `bg-fill` с контуром третичным (замер:
          сама заливка даёт к карточке 1,09:1, контур — 3,79:1 в светлой теме и 3,68:1 в тёмной; без
          контура клетка исчезала бы совсем). Синего в ней нет вовсе, поэтому с рампой не спутать.
          Ноль — это НЕ «нет данных»: он рисуется нижней ступенью рампы, то есть голубым. Сравнить
          можно в строке APAC: первая клетка ноль, вторая пустая.
        </p>
        <HeatmapCard
          rowLabelWidth={320}
          label="Revenue by region"
          value={ru(963)}
          delta={{ label: "+11,8%", direction: "up" }}
          period={{ label: "H1 2024" }}
          max={80}
          columns={["Jan", "Feb", "Mar", "Apr", "May", "Jun"]}
          rows={[
            { label: "Европа, Ближний Восток и Африка", values: [42, 48, 55, 61, 70, 74] },
            { label: "Северная и Южная Америка", values: [38, 40, 47, 52, 58, 66] },
            { label: "Азиатско-Тихоокеанский регион", values: [0, null, 29, 36, 41, 49] },
            { label: "Латинская Америка", values: [12, 14, null, 19, 24, 27] },
          ]}
        />

        <p className="text-body-m text-ink-secondary mt-8 mb-6 max-w-5xl">
          Та же карточка с колонкой подписей по умолчанию — 88 точек.
        </p>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            height={400}
            label="Revenue by region"
            value={ru(963)}
            period={{ label: "H1 2024" }}
            max={80}
            columns={["Jan", "Feb", "Mar", "Apr", "May", "Jun"]}
            rows={[
              { label: "Европа, Ближний Восток и Африка", values: [42, 48, 55, 61, 70, 74] },
              { label: "Северная и Южная Америка", values: [38, 40, 47, 52, 58, 66] },
              { label: "Азиатско-Тихоокеанский регион", values: [0, null, 29, 36, 41, 49] },
              { label: "Латинская Америка", values: [12, 14, null, 19, 24, 27] },
            ]}
          />
        </div>
      </div>
    </div>
  ),
};

/** Опасный случай: отрицательные, ровная матрица, потолок ниже данных */
export const ОпасныйСлучай: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">Отрицательные значения</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Шкала однонаправленная: один тон, гуще — больше, ноль на краю. Места под −18 на ней нет, а
          сказать «минус» здесь нечем — цифр в клетках не бывает. Молча покрасить −18 бледной
          клеткой значит соврать: падение стало бы неотличимо от роста на единицу. Поэтому такие
          клетки получают краску ВНЕ рампы — `bg-error` #ff3b30 (3,55:1 к белой карточке, 4,27:1 к
          тёмной), в синей шкале не встречается ни на одной ступени. Строка под матрицей заявляет об
          этом словами и вытесняет подпись пика: пик среди величин, часть которых вне шкалы, — это
          полуправда. ⚠️ Первым сюда просился `bg-error-fill`, заливка чипа, — и замер её отверг: в
          тёмной теме это rgba(251,44,54,0.18), на карточке #262626 она складывается в 1,2:1, то
          есть клетка-ошибка была бы почти невидима ровно там, где обязана кричать. Правильная форма
          для величин, расходящихся от нуля, — `DivergingBars` в `src/blocks/deltas.tsx`.
        </p>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            height={400}
            label="Прирост подписчиков"
            value="−214"
            delta={{ label: "−9,1%", direction: "down" }}
            period={{ label: "Last 7 days" }}
            columns={["Пн", "Вт", "Ср", "Чт", "Пт"]}
            rows={[
              { label: "Утро", values: [12, 8, -18, 4, 9] },
              { label: "День", values: [22, 19, -6, 17, 21] },
              { label: "Вечер", values: [31, 28, 12, 26, 30] },
            ]}
          />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Ровная матрица: все значения равны</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Потолок шкалы равен каждому значению, доля везде 1, вся матрица закрашена верхней
          ступенью. Формально верно, содержательно пусто: тепловая карта показывает НЕРАВНОМЕРНОСТЬ,
          и там, где её нет, форма не нужна — нужна одна цифра. Блок этого не запрещает и запретить
          не может (данные законные), но выглядеть должно именно так — заметно.
        </p>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            height={400}
            label="Смены"
            value="60"
            period={{ label: "Неделя" }}
            columns={["Пн", "Вт", "Ср", "Чт", "Пт"]}
            rows={[
              { label: "Утро", values: [4, 4, 4, 4, 4] },
              { label: "День", values: [4, 4, 4, 4, 4] },
              { label: "Вечер", values: [4, 4, 4, 4, 4] },
            ]}
          />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок задан ниже данных</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          `max={40}` при значениях до 44: всё, что выше потолка, прижимается к 100% и становится
          неразличимым между собой. Приём законный — так две соседние карточки приводятся к общей
          шкале, — но у него есть цена, и она видна: три клетки верхнего конца слились в одну
          густоту. Подпись пика при этом продолжает называть НАСТОЯЩЕЕ значение 44, а не потолок.
        </p>
        <div className="w-[828px]">
          <HeatmapCard
            size="half"
            cardWidth={828}
            height={400}
            max={40}
            label="Active users"
            value={ru(total(WEEK))}
            period={{ label: "Last 7 days" }}
            columns={HOURS}
            rows={WEEK}
          />
        </div>
      </div>
    </div>
  ),
};

/**
 * Как на слайде: карточка в ContentSlide при бюджете 604.
 *
 * ⚠️ 604 — это бюджет при заголовке В ОДНУ СТРОКУ. Замер шапки слайда:
 * поле сверху 88 + пилюля 40 + просвет 24 + заголовок 60 + просвет 24 +
 * лид 32 + отбивка 64 = 332, снизу поле 88 и резерв под подвал 56. Карточка
 * встаёт на 332…936, подвал начинается на 972 — просвет 36.
 *
 * Первая версия этой истории имела заголовок в ДВЕ строки, и замер поймал
 * то, чего не видит проверка переполнения: карточка вставала на 392…996,
 * то есть её нижний край уезжал ПОД строку подвала (972). Текст на текст
 * при этом не наезжал — между легендой шкалы и подписью оставалось 12
 * точек, — поэтому ни одна проверка не сработала бы: холст (1080) не
 * превышен, боксы строк не пересекаются. Видно это только глазом и только
 * замером «низ карточки против верха подвала». Лечится не уменьшением
 * кегля, а вторым числом: заголовок в две строки означает `height={544}`.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Аудитория"
      title="Пик активности — четверг после обеда"
      lead="Каждая клетка — час недели; чем гуще синий, тем больше одновременных пользователей."
      page={7}
      label="Демо · карточки дашборда"
    >
      <HeatmapCard
        label="Active users"
        value={ru(total(WEEK_24))}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        columns={HOURS_24}
        rows={WEEK_24}
      />
    </ContentSlide>
  ),
};

/**
 * Тот же слайд с заголовком в ДВЕ строки — и с высотой 544 вместо 604.
 *
 * 60 точек второй строки заголовка вычитаются из бюджета блока, иначе
 * карточка уезжает под подвал. Клетка при этом сжимается с 40 до 31
 * (замер печатается самой историей выше), матрица остаётся читаемой.
 * Тёмная тема заодно — вторая тема проверяется на месте, а не в витрине.
 */
export const НаСлайдеДваЗаголовка: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Аудитория"
      title="Пик активности приходится на четверг после обеда — рассылку надо ставить туда"
      lead="Каждая клетка — час недели; чем гуще синий, тем больше одновременных пользователей."
      page={7}
      label="Демо · карточки дашборда"
    >
      <HeatmapCard
        height={544}
        label="Active users"
        value={ru(total(WEEK_24))}
        delta={{ label: "+5,2%", direction: "up" }}
        period={{ label: "Last 7 days" }}
        columns={HOURS_24}
        rows={WEEK_24}
      />
    </ContentSlide>
  ),
};

/** Легенда шкалы отдельно: пять точек донора и их доли */
export const ЛегендаШкалы: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Less … More — пять точек, доли 0 / ¼ / ½ / ¾ / 1
      </h3>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Легенда — не украшение: она единственное, что объясняет шкалу, когда наведения нет. Доли
        донорские, а вот доля подмешивания на нижней точке поднята с 8% до {HEAT_FLOOR}%. Ниже — те
        же пять точек с подписанными процентами.
      </p>
      <div className="bg-surface rounded-panel flex items-end gap-6 p-9">
        {HEAT_LEGEND_STOPS.map((stop) => (
          <div key={stop} className="flex flex-col items-center gap-3">
            <span
              className="rounded-micro"
              style={{ width: 88, height: 88, background: heatFill(stop) }}
            />
            <span className="text-label text-ink-secondary tabular-nums">
              {Math.round(HEAT_FLOOR + (100 - HEAT_FLOOR) * stop)}%
            </span>
          </div>
        ))}
      </div>
    </div>
  ),
};
