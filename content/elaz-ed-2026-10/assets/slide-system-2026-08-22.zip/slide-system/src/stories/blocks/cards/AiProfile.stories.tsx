import { useEffect, useRef, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";

import AiProfileCard, {
  AI_PROFILE_BAR_COLOR,
  AI_PROFILE_SPANS,
  aiProfileGeometry,
  spanWidth,
  type AiProfileAgents,
  type AiProfileContributions,
  type AiProfileTokens,
} from "../../../blocks/cards/aiProfileCard";
import AiIdentityCard, {
  COVER_MIN,
  aiIdentityGeometry,
  type AiIdentity,
} from "../../../blocks/cards/aiProfileIdentity";
import { useRemeasureOnFont } from "../../../blocks/cards/axis";
import { contributionsMetrics } from "../../../blocks/cards/contributionsCard";
import { earningsGeometry } from "../../../blocks/cards/earningsCard";
import { CARD_BUDGET, cardChartHeight, cardChartWidth } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * «Профиль вклада» — донорский профиля.
 *
 * Донор — вертикальная стопка трёх карточек: личность с обложкой и
 * цифрами, столбики агентов за 30 дней, линия расхода токенов. Стопка
 * меряется в 1208 точек при бюджете слайда 604, поэтому она разложена в
 * две колонки и разбита на два слайда: «кто и сколько» и «динамика».
 * Обоснование числами — в шапке `blocks/cards/aiProfileCard.tsx`.
 *
 * === Что здесь смотреть в первую очередь ===
 *
 * 1. **Пропорция обложки.** У донора банер 4.12:1. У нас обложка получает
 *    ОСТАТОК высоты, поэтому её пропорция зависит от того, сколько строк в
 *    карточке: от 1.24:1 у пустой до 3.02:1 у полной. История «Крайние
 *    случаи» ставит оба края рядом.
 * 2. **Клетка тепловой карты.** Разведка донора требует 26–30 точек, иначе
 *    решётка на проекторе сливается в шум. В колонке col-span-8 при 38
 *    колонках донора выходит 24.32 — недобор. Лечится данными: 30 колонок
 *    дают 30.86.
 * 3. **Светлая тема здесь РАБОТАЕТ.** Это единственная пара карточек
 *    донора с фиолетовыми красками: столбик к треку 3.46 против 1.29 у
 *    салатовых карточек, линия к карточке 4.12 против 1.95.
 *
 * === Данные ===
 *
 * Числа и подписи — донорские, со страницы: «$7,462 / +14.8%», плитки
 * «9B · 562.7M · 12h 54m · 62 days», «32 agents», «667.7M tokens / +9.4%».
 * Ряды по дням донор не публикует, поэтому они СЧИТАЮТСЯ формулой от
 * индекса дня — детерминированно, а не случайно. Случайные числа здесь
 * запрещены: две выгрузки PDF дали бы два разных файла, и слайд
 * «поменялся» бы сам собой между отправками клиенту.
 *
 * ⚠️ Замеры делать в 1:1. Истории без `slide: true` витрина не
 * масштабирует, поэтому в них `getBoundingClientRect` честен; история
 * «Как на слайде» масштабируется — для её замеров переключить тулбар
 * «Масштаб» на «1:1 — для замеров».
 */

const meta = {
  title: "Карточки/Профиль вклада",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── детерминированные данные ───────────── */

/**
 * Псевдослучайное, но ВОСПРОИЗВОДИМОЕ число из индекса: дробная часть
 * синуса. Одно и то же при каждом рендере, в каждой сборке и в каждой
 * выгрузке — именно это здесь и требуется.
 */
function шум(i: number, seed = 1) {
  const x = Math.sin((i + 1) * 12.9898 * seed) * 43758.5453;
  return x - Math.floor(x);
}

/** Недели тепловой карты: 38 колонок донора по семь дней */
const НЕДЕЛИ = Array.from({ length: 38 }, (_, w) =>
  Array.from({ length: 7 }, (_, d) => {
    const i = w * 7 + d;
    const n = шум(i);
    /* Выходные тише будней, каждый шестой день — простой. Ноль и «дня нет»
       различаются: null стоит только в хвостах, ноль — это «работал, но
       ничего не сделал» */
    if (n < 0.18) return 0;
    const выходной = d === 5 || d === 6;
    return Math.round(n * (выходной ? 6 : 22));
  }),
);

/* Хвосты: первая неделя началась в среду, последняя оборвана на пятнице */
const ГОД: (number | null)[][] = НЕДЕЛИ.map((week, w) =>
  week.map((value, d) => {
    if (w === 0 && d < 2) return null;
    if (w === 37 && d > 4) return null;
    return value;
  }),
);

const МЕСЯЦЫ = [
  { label: "Jun", week: 0 },
  { label: "Jul", week: 3 },
  { label: "Aug", week: 7 },
  { label: "Sep", week: 12 },
  { label: "Oct", week: 16 },
  { label: "Nov", week: 21 },
  { label: "Dec", week: 25 },
  { label: "Jan", week: 30 },
  { label: "Feb", week: 34 },
];

/** Столбики агентов: 30 дней декабря, подпись — номер дня */
const ДНИ = Array.from({ length: 30 }, (_, i) => {
  const n = шум(i, 3);
  return { label: String(i + 1), value: n < 0.2 ? 0 : Math.round(1 + n * 5) };
});

/** Точки линии токенов: тот же месяц, миллионы токенов */
const ТОКЕНЫ = Array.from({ length: 30 }, (_, i) => ({
  label: String(i + 1),
  value: Math.round(120 + шум(i, 7) * 380 + i * 9),
}));

const ПИК_ТОКЕНОВ = ТОКЕНЫ.reduce((best, p, i) => (p.value > ТОКЕНЫ[best].value ? i : best), 0);
const ПИК_АГЕНТОВ = ДНИ.reduce((best, b, i) => (b.value > ДНИ[best].value ? i : best), 0);

const ЛИЧНОСТЬ: AiIdentity = {
  name: "Mertcan Esmergül",
  handle: "@sitenley",
  badge: "PRO",
  caption: "hi@example.com",
  facts: [
    { value: "9B", label: "Lifetime tokens" },
    { value: "562.7M", label: "Peak tokens" },
    { value: "12h 54m", label: "Longest task" },
    { value: "62 days", label: "Top streak" },
  ],
};

const ВКЛАД: AiProfileContributions = {
  label: "Contributions this year",
  value: "$7 462",
  delta: { label: "+14,8%", direction: "up" },
  period: "Yearly",
  periods: ["Weekly", "Monthly", "Yearly"],
  weeks: ГОД,
  months: МЕСЯЦЫ,
};

const АГЕНТЫ: AiProfileAgents = {
  label: "Agents",
  value: "32 agents",
  period: { label: "December" },
  bars: ДНИ,
  highlight: ПИК_АГЕНТОВ,
  legend: [
    {
      label: `Пик · ${ПИК_АГЕНТОВ + 1} декабря`,
      value: `${ДНИ[ПИК_АГЕНТОВ].value} агентов`,
      color: AI_PROFILE_BAR_COLOR,
    },
    {
      label: "Дней простоя",
      value: String(ДНИ.filter((d) => d.value === 0).length),
      color: "var(--t-fill-strong)",
    },
  ],
};

const ТОКЕНЫ_КАРТОЧКА: AiProfileTokens = {
  label: "Tokens",
  value: "667.7M tokens",
  delta: { label: "+9,4%", direction: "up" },
  period: { label: "December" },
  points: ТОКЕНЫ,
  marker: { index: ПИК_ТОКЕНОВ, label: `${ТОКЕНЫ[ПИК_ТОКЕНОВ].value}M` },
  formatTick: (v) => `${v}M`,
};

/* ───────────── линейка ───────────── */

/**
 * Оборачивает блок и печатает его ФАКТИЧЕСКИЕ размеры плюс худшее
 * переполнение внутри.
 *
 * Пороги — из `.claude/rules/layout-verification.md`: 16 по высоте (ниже
 * это выносные элементы шрифта, а не переполнение) и 4 по ширине.
 * Считаются только контейнеры (`children.length`), иначе каждая строка
 * текста даёт ложное срабатывание. Заодно проверяется, что ничего не
 * схлопнулось в ноль: ищется самый маленький ненулевой элемент.
 */
function Линейка({ children }: { children: React.ReactNode }) {
  const box = useRef<HTMLDivElement>(null);
  const [итог, setИтог] = useState("замер после отрисовки");

  useEffect(() => {
    const el = box.current;
    const block = el?.firstElementChild as HTMLElement | null;
    if (!block) return;
    const id = requestAnimationFrame(() => {
      const r = block.getBoundingClientRect();
      const все = [block, ...block.querySelectorAll("*")] as HTMLElement[];
      const боксы = все.filter((e) => e.children.length);
      const dy = Math.max(...боксы.map((e) => e.scrollHeight - e.clientHeight));
      const dx = Math.max(...боксы.map((e) => e.scrollWidth - e.clientWidth));
      const нули = все.filter((e) => {
        const b = e.getBoundingClientRect();
        return b.width < 1 || b.height < 1;
      }).length;
      const scaled = block.closest(".slide-canvas");
      setИтог(
        `${Math.round(r.width)} × ${Math.round(r.height)} · ` +
          `переполнение по высоте ${dy} (порог 16), по ширине ${dx} (порог 4) · ` +
          `схлопнутых в ноль элементов ${нули}` +
          (scaled ? " · холст масштабирован, мерить в 1:1" : ""),
      );
    });
    return () => cancelAnimationFrame(id);
  });

  return (
    <div ref={box}>
      {children}
      <p className="text-body-m text-ink-secondary mt-4 tabular-nums">{итог}</p>
    </div>
  );
}

/* ───────────── истории ───────────── */

/**
 * Часть «кто и сколько»: личность слева, вклад за год справа.
 *
 * Это первый из двух слайдов донорской стопки. Плитки статов стоят в
 * карточке личности, а не рядом с тепловой картой, — у донора они в той же
 * карточке, что имя, и при узком экране он сам раскладывает их 2×2.
 */
export const Профиль: Story = {
  render: () => <ПрофильВид />,
};

function ПрофильВид() {
  const g = aiProfileGeometry({ part: "profile" });
  const identity = aiIdentityGeometry({
    width: g.widths.identity,
    handle: true,
    caption: true,
    facts: 4,
  });
  const heat = contributionsMetrics({
    cardWidth: g.widths.contributions,
    size: "half",
    columns: 38,
    facts: false,
  });

  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Две колонки {g.widths.identity} + {g.widths.contributions} при бюджете {CARD_BUDGET}
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Карточка личности: содержимое занимает {identity.content}, обложке остаётся {identity.cover}{" "}
        — пропорция {identity.coverRatio.toFixed(2)}:1 при донорских 4.12:1. Чем больше строк в
        карточке, тем ближе обложка к донорскому банеру, а не наоборот. Тепловая карта: слот{" "}
        {heat.slotWidth} × {heat.slotHeight}, полоса {heat.bandHeight}, клетка{" "}
        {heat.cellWidth.toFixed(2)} с просветом {heat.gap} — разведка донора требует 26–30, то есть
        недобор {(26 - heat.cellWidth).toFixed(2)}. Лечится числом колонок: при 30 колонках вместо
        38 клетка становится{" "}
        {contributionsMetrics({
          cardWidth: g.widths.contributions,
          size: "half",
          columns: 30,
          facts: false,
        }).cellHeight.toFixed(2)}
        . Клетку ограничивает ШИРИНА, а не высота: сетка занимает {heat.gridHeight.toFixed(0)} из
        полосы {heat.bandHeight.toFixed(0)}, то есть{" "}
        {((heat.bandHeight - heat.gridHeight) / 2).toFixed(0)} точек пустого места сверху и столько
        же снизу — карточка `ContributionsCard` центрует сетку в полосе. Это плата за то, что плитки
        статов стоят в карточке личности: верни их сюда, и полоса сожмётся до{" "}
        {contributionsMetrics({
          cardWidth: g.widths.contributions,
          size: "half",
          columns: 38,
          facts: true,
        }).bandHeight.toFixed(0)}
        , зато обложке слева останется 440 вместо {identity.cover} и банер станет почти квадратом
        (1.24:1 против {identity.coverRatio.toFixed(2)}:1). Обе раскладки законны; выбрана та, где
        донорский приём с обложкой сохраняется.
      </p>
      <Линейка>
        <AiProfileCard identity={ЛИЧНОСТЬ} contributions={ВКЛАД} />
      </Линейка>
    </div>
  );
}

/**
 * Часть «динамика»: столбики агентов и линия токенов.
 *
 * Второй слайд стопки. Легенда у столбиков есть, у линии её нет — и это
 * не забывчивость: легенда забирает 124 точки и возвращает столбикам
 * донорскую пропорцию. Числа печатает сама история.
 */
export const Динамика: Story = {
  render: () => <ДинамикаВид />,
};

function ДинамикаВид() {
  useRemeasureOnFont();
  const ширина = spanWidth(AI_PROFILE_SPANS.dynamics.agents);
  const bars = earningsGeometry({ size: "half", width: ширина, legend: true, bars: 30 });
  const линия = {
    w: cardChartWidth(ширина, "half"),
    h: cardChartHeight({ size: "half", legend: false }),
  };

  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Две половинные карточки {ширина} × {CARD_BUDGET}
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Столбики: область построения {bars.plotWidth.toFixed(0)} × {bars.plotHeight.toFixed(0)} ={" "}
        {(bars.plotWidth / bars.plotHeight).toFixed(2)}:1 при донорских 3.20:1, шаг{" "}
        {bars.step.toFixed(2)}, стакан {bars.track.toFixed(2)} — {(100 * 0.643).toFixed(1)}% шага,
        доля донора. Столбик {bars.track.toFixed(2)} × {bars.plotHeight.toFixed(0)} ={" "}
        {(bars.plotHeight / bars.track).toFixed(1)}:1 против донорских 13.7:1. Без легенды было бы{" "}
        {(
          earningsGeometry({ size: "half", width: ширина, legend: false, bars: 30 }).plotHeight /
          bars.track
        ).toFixed(1)}
        :1 — частокол. Линия: поле {линия.w} × {линия.h} = {(линия.w / линия.h).toFixed(2)}:1 при
        донорских 3.40:1, то есть наклоны выходят примерно вдвое круче. Легенды у `LineCard` нет:
        ряд один, называет его шапка.
      </p>
      <Линейка>
        <AiProfileCard part="dynamics" agents={АГЕНТЫ} tokens={ТОКЕНЫ_КАРТОЧКА} />
      </Линейка>
    </div>
  );
}

/**
 * Обе темы рядом — вложенной темой, без переключения тулбара.
 *
 * Смотреть надо на столбики и линию. Замеры (WCAG, порог 3:1 для
 * нетекстовой графики):
 *
 *   столбик #ad46ff к треку          светлая 3.46   тёмная 3.25
 *   линия #ad46ff к карточке         светлая 4.12   тёмная 3.67
 *   квадратик легенды на плитке      светлая 3.62   тёмная 4.14
 *   ступени тепловой карты к своей   светлая 1.39…7.30
 *   карточке                         тёмная  1.01…3.44
 *
 * То есть фиолетовые краски донора берут порог в ОБЕИХ темах — в отличие
 * от салатовых карточек «Доход» и «Линия», где светлая тема даёт 1.29 и
 * 1.95. А вот нижняя ступень тепловой карты от фона почти неотличима в
 * любой теме: «одна контрибуция» и «ни одной» на проекторе сольются.
 * Лечится `scale="readable"` — лестница из четырёх ступеней вместо пяти.
 */
export const ОбеТемы: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">Светлая тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Высота полная, 604: сжимать её ради витрины нельзя. Замер при 480 показал, почему —
          содержимому карточки личности нужно 440, обложке остаётся 40 при пороге 120, и донорский
          приём вырождается в полоску. Компонент об этом предупреждает в консоли.
        </p>
        <div className="flex flex-col gap-6">
          <AiProfileCard theme="light" identity={ЛИЧНОСТЬ} contributions={ВКЛАД} />
          <AiProfileCard theme="light" part="dynamics" agents={АГЕНТЫ} tokens={ТОКЕНЫ_КАРТОЧКА} />
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Тёмная тема</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Лестница тепловой карты в тёмной теме — не инверсия светлой, а свой набор ступеней (violet
          950→500 против 200→700): рост активности обязан давать рост контраста с фоном, а на тёмном
          «сильнее» значит «светлее».
          <br />
          Подложка съедает по 32 с каждой стороны, поэтому здесь передан gridWidth 1616. Пропс нужен
          ровно для этого: сетка `slide-grid` подстраивается под контейнер сама, а карточка линии
          получает ширину ЧИСЛОМ (`LineCard` ставит её стилем) — без поправки она осталась бы 828 в
          колонке 796 и вылезла бы за сетку на 32. Замер до правки показал ровно эти 32.
        </p>
        <div className="bg-canvas rounded-panel flex flex-col gap-6 p-8" data-theme="dark">
          <AiProfileCard theme="dark" gridWidth={1616} identity={ЛИЧНОСТЬ} contributions={ВКЛАД} />
          <AiProfileCard
            theme="dark"
            gridWidth={1616}
            part="dynamics"
            agents={АГЕНТЫ}
            tokens={ТОКЕНЫ_КАРТОЧКА}
          />
        </div>
      </div>
    </div>
  ),
};

/**
 * Крайние случаи. Каждый подписан тем, что именно он проверяет.
 */
export const КрайниеСлучаи: Story = {
  render: () => <КрайниеСлучаиВид />,
};

function КрайниеСлучаиВид() {
  useRemeasureOnFont();
  const ширина = spanWidth(AI_PROFILE_SPANS.profile.identity);

  const пустая = aiIdentityGeometry({ width: ширина, handle: false });
  const полная = aiIdentityGeometry({ width: ширина, handle: true, caption: true, facts: 4 });
  const перебор = aiIdentityGeometry({
    width: ширина,
    height: 420,
    handle: true,
    caption: true,
    facts: 4,
  });

  return (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">
          Минимум: одно имя, без обложки, без плиток, без месяцев
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Карточка личности без ника, подписи и плиток отдаёт обложке {пустая.cover} из{" "}
          {CARD_BUDGET} — пропорция {пустая.coverRatio.toFixed(2)}:1 против донорских 4.12:1. Это не
          банер, а почти квадратный портрет: приём донора здесь вырождается, и такую карточку
          честнее считать «фотографией с подписью». Обложки нет вовсе — рисуется приглушённая
          подложка с волосяной чертой по нижнему краю: цветного пятна на её месте быть не должно,
          оно прочтётся как содержание, которого нет. Тепловая карта из восьми недель: клетка
          ограничивается уже не шириной, а высотой полосы, и становится{" "}
          {contributionsMetrics({
            cardWidth: spanWidth(AI_PROFILE_SPANS.profile.contributions),
            size: "half",
            columns: 8,
            facts: false,
          }).cellHeight.toFixed(2)}{" "}
          — квадрат превращается в кирпич шириной{" "}
          {contributionsMetrics({
            cardWidth: spanWidth(AI_PROFILE_SPANS.profile.contributions),
            size: "half",
            columns: 8,
            facts: false,
          }).cellWidth.toFixed(2)}
          . Ничего не схлопывается в ноль — линейка внизу считает такие элементы.
        </p>
        <Линейка>
          <AiProfileCard
            identity={{ name: "Агент" }}
            contributions={{
              label: "Contributions",
              value: "$412",
              weeks: ГОД.slice(0, 8),
            }}
          />
        </Линейка>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок: карточка набита доверху</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Имя, ник с бейджем, подпись и четыре плитки 2×2 — содержимое занимает {полная.content} из{" "}
          {CARD_BUDGET}, обложке остаётся {полная.cover}, пропорция {полная.coverRatio.toFixed(2)}
          :1. Это САМЫЙ БЛИЗКИЙ к донору вариант (4.12:1), и он же самый плотный: следующая строка
          увела бы обложку ниже порога {COVER_MIN}. Тепловая карта при 52 неделях: клетка{" "}
          {contributionsMetrics({
            cardWidth: spanWidth(AI_PROFILE_SPANS.profile.contributions),
            size: "half",
            columns: 52,
            facts: false,
          }).cellWidth.toFixed(2)}{" "}
          — вдвое ниже порога читаемости 26, на проекторе решётка сольётся в шум. Пятьдесят две
          недели в эту колонку не помещаются, и это не вопрос вкуса.
        </p>
        <Линейка>
          <AiProfileCard
            identity={ЛИЧНОСТЬ}
            contributions={{
              ...ВКЛАД,
              weeks: [...ГОД, ...ГОД.slice(0, 14)],
              months: [...МЕСЯЦЫ, { label: "Mar", week: 38 }, { label: "Apr", week: 43 }],
            }}
          />
        </Линейка>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Имя набрано `headline-s` 36/40 и обрезается многоточием: вторая строка добавила бы 40
          точек, которых в бюджете нет, и обложка ушла бы в минус. Обрезанная фамилия на клиентском
          слайде недопустима — значит длинному имени нужна колонка шире (col-span-5 = 686), а не
          надежда на перенос. То же у ника, подписи и значений плиток. У столбиков подпись под
          каждым: при 30 днях на колонку приходится{" "}
          {(cardChartWidth(spanWidth(6), "half") / 30).toFixed(1)} точек, поэтому дата «Dec 24» там
          не помещается и обрезается — под столбики годятся только номера дней, а дату называет
          плашка периода и плитка легенды.
        </p>
        <Линейка>
          <AiProfileCard
            identity={{
              name: "Константинопольский Александр",
              handle: "@konstantinopolsky-alexander-agent",
              badge: "PRO",
              caption: "alexander.konstantinopolsky@example-company.com",
              facts: [
                { value: "9 218 400 000", label: "Токенов за всё время работы" },
                { value: "562 700 000", label: "Пиковый расход за сутки" },
                { value: "12 ч 54 мин", label: "Самая длинная задача" },
                { value: "62 дня", label: "Максимальная серия" },
              ],
            }}
            contributions={{
              ...ВКЛАД,
              label: "Вклад за отчётный год, включая выходные",
              value: "$7 462 000",
              activityLabel: "Активность по дням года",
              period: "Ежегодно",
              periods: ["Еженедельно", "Ежемесячно", "Ежегодно"],
            }}
          />
        </Линейка>
        <div className="mt-6">
          <Линейка>
            <AiProfileCard
              part="dynamics"
              agents={{
                ...АГЕНТЫ,
                label: "Запущено агентов за декабрь",
                bars: ДНИ.map((d) => ({ ...d, label: `Dec ${d.label}` })),
                legend: [
                  {
                    label: `Пик пришёлся на ${ПИК_АГЕНТОВ + 1} декабря, понедельник`,
                    value: `${ДНИ[ПИК_АГЕНТОВ].value} агентов`,
                    color: AI_PROFILE_BAR_COLOR,
                  },
                  {
                    label: "Дней простоя за месяц",
                    value: String(ДНИ.filter((d) => d.value === 0).length),
                    color: "var(--t-fill-strong)",
                  },
                ],
              }}
              tokens={{
                ...ТОКЕНЫ_КАРТОЧКА,
                label: "Израсходовано токенов за декабрь",
                value: "667 700 000 tokens",
                formatTick: (v) => `${v} 000 000`,
              }}
            />
          </Линейка>
        </div>
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">
          ⚠️ Опасный случай: карточка не помещается в высоту
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Высота 420 при полном наборе строк: содержимому нужно {перебор.content}, обложке остаётся{" "}
          {перебор.cover} при пороге {COVER_MIN}, а аватар заходит на неё на 32 — от снимка остаётся{" "}
          {Math.max(0, перебор.cover - 32)}. Компонент пишет об этом в консоль и НЕ подгоняет:
          молчаливое сжатие обложки дало бы полоску вместо кадра, а в PDF это уже не починить.
          Правильный ответ — убрать подпись или ряд плиток.
          <br />
          Второй опасный случай в этом же блоке — ряд с двумя порядками разницы. У столбика с
          ненулевым значением есть пол высоты, равный его скруглению (
          {
            earningsGeometry({ size: "half", width: spanWidth(6), legend: true, bars: 30 }).minBar
          }{" "}
          точек), поэтому день с одним агентом и день с пятью различаются, а день с нулём рисуется
          ПУСТЫМ стаканом — не обрубком: обрубок означал бы «мало», а не «ничего».
        </p>
        <div className="flex gap-6">
          <div className="w-[544px]">
            <AiIdentityCard identity={ЛИЧНОСТЬ} height={420} width={544} />
          </div>
          <div className="w-[544px]">
            <AiIdentityCard
              identity={{ ...ЛИЧНОСТЬ, caption: undefined, facts: ЛИЧНОСТЬ.facts?.slice(0, 2) }}
              height={420}
              width={544}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Геометрия числами — чтобы пропорции сверяли, а не оценивали.
 *
 * Таблица вызывает те же функции, по которым строится сама композиция,
 * поэтому разойтись с ней не может.
 */
export const Геометрия: Story = {
  render: () => <ГеометрияВид />,
};

function ГеометрияВид() {
  useRemeasureOnFont();

  const строки = [
    { span: 4, что: "личность" },
    { span: 5, что: "личность шире" },
    { span: 6, что: "график в паре" },
    { span: 7, что: "график в стопке (отвергнуто)" },
    { span: 8, что: "тепловая карта" },
    { span: 9, что: "тепловая карта шире" },
    { span: 12, что: "во всю ширину" },
  ];

  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Что получится при бюджете {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Клетка тепловой карты считается при 38 колонках донора, поле столбиков — при 30 днях и
        легенде, поле линии — без легенды. Донорские ориентиры: клетка 26–30, столбики 3.20:1, линия
        3.40:1.
      </p>
      <table className="text-body-l text-ink w-full tabular-nums">
        <thead className="text-body-m text-ink-secondary">
          <tr>
            {[
              "колонок",
              "ширина",
              "роль",
              "клетка 38×7",
              "поле столбиков",
              "столбик",
              "поле линии",
            ].map((h) => (
              <th key={h} className="border-line border-b py-3 text-left font-normal">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {строки.map((row) => {
            const w = spanWidth(row.span);
            const heat = contributionsMetrics({
              cardWidth: w,
              size: "half",
              columns: 38,
              facts: false,
            });
            const bars = earningsGeometry({ size: "half", width: w, legend: true, bars: 30 });
            const линия = {
              w: cardChartWidth(w, "half"),
              h: cardChartHeight({ size: "half", legend: false }),
            };
            return (
              <tr key={row.span}>
                <td className="border-line border-b py-3">{row.span}</td>
                <td className="border-line border-b py-3">{w}</td>
                <td className="border-line text-ink-secondary border-b py-3">{row.что}</td>
                <td className="border-line border-b py-3">{heat.cellWidth.toFixed(2)}</td>
                <td className="border-line border-b py-3">
                  {bars.plotWidth.toFixed(0)} × {bars.plotHeight.toFixed(0)} ={" "}
                  {(bars.plotWidth / bars.plotHeight).toFixed(2)}:1
                </td>
                <td className="border-line border-b py-3">
                  {bars.track.toFixed(1)} × {bars.plotHeight.toFixed(0)} ={" "}
                  {(bars.plotHeight / bars.track).toFixed(1)}:1
                </td>
                <td className="border-line border-b py-3">
                  {линия.w} × {линия.h} = {(линия.w / линия.h).toFixed(2)}:1
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Как на слайде: часть «кто и сколько» внутри `ContentSlide`.
 *
 * Заголовок в одну строку с лидом — тогда блоку остаётся ровно 604.
 *
 * ⚠️ Проверено замером на этой самой истории, а не выведено из правила.
 * Первый вариант заголовка был длиннее 46 знаков, перенёсся на вторую
 * строку, и шапка выросла со 180 до 240: блок кончался на 996 при нижнем
 * поле 992, а подвал начинался ВЫШЕ его низа — карточка ложилась на
 * подпись презентации на 24 точки. В Storybook это заметно не было (та же
 * грабля, что на демо-слайде «Стек»), поймал только замер положения
 * подвала. Заголовок в две строки означает `height={544}`, а не «ну,
 * почти влезло».
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Профиль вклада"
      title="За год агент наработал на $7 462"
      lead="Слева — кто работал, справа — сколько и когда: клетка тепловой карты равна одному дню"
      page={11}
      label="Витрина карточек"
    >
      <AiProfileCard identity={ЛИЧНОСТЬ} contributions={ВКЛАД} />
    </ContentSlide>
  ),
};

/**
 * Второй слайд той же истории — «динамика».
 *
 * Пара карточек отвечает на другой вопрос: не «сколько всего», а «как это
 * распределено по дням». Поэтому это отдельный слайд, а не вторая половина
 * первого: на слайде одна мысль.
 */
export const НаСлайдеДинамика: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Профиль вклада"
      title="Декабрь: 32 агента и 667,7 млн токенов"
      lead="Пик пришёлся на один день — он назван в легенде и подписан на линии"
      page={12}
      label="Витрина карточек"
    >
      <AiProfileCard part="dynamics" agents={АГЕНТЫ} tokens={ТОКЕНЫ_КАРТОЧКА} />
    </ContentSlide>
  ),
};

/**
 * То же тёмным слайдом.
 *
 * В отличие от карточек «Доход» и «Линия», тёмная тема здесь не
 * необходимость, а выбор: фиолетовые краски донора берут порог 3:1 и на
 * светлом (столбик к треку 3.46, линия к карточке 4.12). Тёмный слайд
 * стоит брать по ритму презентации, а не ради контраста.
 */
export const НаТёмномСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Профиль вклада"
      title="Декабрь: 32 агента и 667,7 млн токенов"
      lead="Те же карточки тёмной темой — здесь это выбор ритма, а не спасение контраста"
      page={13}
      label="Витрина карточек"
    >
      <AiProfileCard part="dynamics" agents={АГЕНТЫ} tokens={ТОКЕНЫ_КАРТОЧКА} />
    </ContentSlide>
  ),
};
