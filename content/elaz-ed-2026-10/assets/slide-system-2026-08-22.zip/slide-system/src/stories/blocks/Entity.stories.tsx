import type { Meta, StoryObj } from "@storybook/react-vite";
import { Buildings, Calendar, Global, MapPoint, User, Wallet } from "@solar-icons/react";
import { CoverCard, SpecCard } from "../../blocks/entity";
import { Avatar } from "../../blocks/people";
import Pill from "../../components/Pill";

/**
 * Карточка объекта.
 *
 * Перенос двух донорских приёмов: паспорта из medical-profile и заглавной
 * карточки с обложкой из профиля. Обе истории показывают то, чего в
 * библиотеке не было: набор фактов об ОДНОЙ сущности.
 *
 * Данные выдуманные и НЕ совпадают с числами деков.
 */

const meta = {
  title: "Блоки/Карточка объекта",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

export const Паспорт: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Паспорт объекта — шесть фактов</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Значения выстроены по правому краю, поэтому их можно просмотреть одним движением сверху
        вниз, не читая ключи. Иконки стоят у всех строк: частичный набор читался бы как «эти строки
        важнее», и блок предупреждает об этом в консоль в режиме разработки.
      </p>
      <div className="w-[720px]">
        <SpecCard
          title="ООО «Ромашка»"
          aside={<Pill>Клиент</Pill>}
          rows={[
            { label: "Сайт", value: "example.ru", Icon: Global },
            { label: "Отрасль", value: "Логистика", Icon: Buildings },
            { label: "Города присутствия", value: "7", Icon: MapPoint },
            { label: "Договор до", value: "31 декабря 2026", Icon: Calendar },
            { label: "Бюджет на квартал", value: "1 400 000 ₽", Icon: Wallet },
            { label: "Ответственный", value: "Ирина Петрова", Icon: User },
          ]}
        />
      </div>
    </div>
  ),
};

export const БезИконок: Story = {
  render: () => (
    <div className="max-w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Тот же паспорт без иконок</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
        Иконка полезна, когда помогает найти строку, не читая ключи. Если подходящих глифов в наборе
        нет, лучше не ставить ни одного: набор из четырёх узнаваемых и двух приблизительных хуже,
        чем чистый список. Строка при этом остаётся той же высоты — ритм не меняется.
      </p>
      <div className="w-[720px]">
        <SpecCard
          title="Домен example.ru"
          rows={[
            { label: "Возраст домена", value: "6 лет" },
            { label: "Страниц в индексе", value: "12 480" },
            { label: "Средняя позиция", value: "18,4" },
            { label: "Мобильная версия", value: "Отдельный поддомен" },
            { label: "Протокол", value: "HTTPS" },
          ]}
        />
      </div>
    </div>
  ),
};

export const СОбложкой: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Заглавная карточка — обложка без снимка</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Снимка на клиентской презентации часто нет вовсе, поэтому пустая обложка — не аварийное
          состояние, а рабочее: она держит габарит, и когда картинку принесут, вёрстка слайда не
          поедет. Заливать пустой кадр акцентом нельзя — цветное пятно во всю ширину читается как
          содержание, которого нет.
        </p>
        <div className="w-[720px]">
          <CoverCard
            name="Ромашка"
            caption="Логистика · 7 городов · клиент с 2021 года"
            badge="В работе"
          >
            <Avatar name="Ромашка" />
          </CoverCard>
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Обложка рядом с паспортом</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Штатная раскладка слайда «карточка клиента»: заглавная карточка слева, факты справа. Обе
          части одинаковой ширины по сетке — по пять колонок из двенадцати с желобом между ними.
        </p>
        <div className="slide-grid">
          <div className="col-span-5">
            <CoverCard name="Ирина Петрова" caption="Директор по маркетингу" badge="Заказчик">
              <Avatar name="Ирина Петрова" />
            </CoverCard>
          </div>
          <div className="col-span-5 col-start-7">
            <SpecCard
              rows={[
                { label: "Роль в проекте", value: "Принимает работы" },
                { label: "Согласование", value: "До двух дней" },
                { label: "Канал связи", value: "Почта и созвоны" },
              ]}
            />
          </div>
        </div>
      </section>
    </div>
  ),
};

export const КрайниеСлучаи: Story = {
  render: () => (
    <div className="flex max-w-[1680px] flex-col gap-14">
      <section>
        <h3 className="text-title-l text-ink mb-2">Длинное значение</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Предел паспорта — примерно сорок знаков в значении. За пределом ломается не высота: строка
          остаётся 64, потому что значение не переносится (оно `shrink-0`). Ломается строка поперёк
          — замер на значении в 51 знак: колонка ключа сжимается до нуля, её текст «Предмет»
          вылезает на 99 точек и ложится поверх значения, а само значение уходит за поле карточки на
          9,6. Лечится это не расширением карточки, а сокращением значения: паспорт — набор коротких
          фактов, а не место для абзаца.
        </p>
        <div className="w-[720px]">
          <SpecCard
            title="Договор № 114-СК"
            rows={[
              { label: "Предмет", value: "Поисковое продвижение и техническая поддержка сайта" },
              { label: "Срок", value: "12 месяцев" },
              { label: "Оплата", value: "Ежемесячно по акту" },
            ]}
          />
        </div>
      </section>

      <section>
        <h3 className="text-title-l text-ink mb-2">Семь строк с заголовком — потолок</h3>
        <p className="text-body-m text-ink-secondary mb-10 max-w-4xl">
          Считать надо всю карточку, а не сумму строк. Семь фактов по 64 дают 448, и к ним
          прибавляются поля карточки 2 × 32, строка заголовка 36 и просвет под ней 24 — итого 572
          при доступных 604 (замер). Восьмая строка выводит карточку в 636, то есть за край: слайд
          обрежется снизу. Порог зависит от заголовка — без него помещается восемь строк (576), — и
          именно поэтому блок сравнивает с 604 высоту, а не число строк.
        </p>
        <div className="w-[720px]">
          <SpecCard
            title="Сводка по площадке"
            rows={[
              { label: "Страниц всего", value: "12 480" },
              { label: "В индексе", value: "9 140" },
              { label: "С ошибками", value: "1 260" },
              { label: "Без описания", value: "3 810" },
              { label: "Дубли заголовков", value: "620" },
              { label: "Средняя скорость", value: "4,1 с" },
              { label: "Последний обход", value: "12 августа" },
            ]}
          />
        </div>
      </section>
    </div>
  ),
};
