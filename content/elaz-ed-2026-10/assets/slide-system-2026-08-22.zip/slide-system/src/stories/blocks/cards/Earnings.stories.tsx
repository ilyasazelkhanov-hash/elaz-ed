import { useEffect, useRef, useState } from "react";
import type { Meta, StoryObj } from "@storybook/react-vite";
import { useRemeasureOnFont } from "../../../blocks/cards/axis";
import EarningsCard, {
  EarningsPlot,
  earningsGeometry,
  type EarningsBar,
  type EarningsTick,
} from "../../../blocks/cards/earningsCard";
import { CARD_BUDGET, cardChartHeight } from "../../../blocks/cards/shell";
import ContentSlide from "../../../templates/ContentSlide";

/**
 * Карточка «Доход» — донорский графика поступлений.
 *
 * Столбики по месяцам стоят в серых «стаканах» полной высоты: стакан
 * показывает потолок шкалы, залитая часть — факт. Последний месяц выделен —
 * он же назван в шапке словом и числом.
 *
 * === Данные историй — донорские, а не выдуманные ===
 *
 * Разведка сняла со скриншотов высоты столбиков в точках (из 187 при
 * шкале 15.583 точки на 1000). Здесь они переведены обратно в деньги:
 * `значение = высота / 15.583 × 1000`, округление до десятков.
 *
 * Проверка перевода сошлась: декабрьский столбик Weekly имеет высоту 127.9,
 * что даёт 8208 → 8 210, а на скриншоте в шапке напечатано ровно «$8 210».
 * Это не подгонка — это единственная величина, которую можно было сверить,
 * и она совпала.
 *
 * === ⚠️ Что смотреть в первую очередь ===
 *
 * Светлая тема этой карточки слабая по замеру: салат #9ae600 к своему треку
 * #ebebeb даёт 1.29 при пороге 3:1. В тёмной те же краски дают 8.73.
 * Числа и разбор — в шапке `blocks/cards/earningsCard.tsx`. История «Обе
 * темы» ставит их рядом, чтобы разница была видна, а не описана.
 *
 * ⚠️ Замеры делать в 1:1. Истории без `slide: true` витрина не масштабирует,
 * поэтому в них `getBoundingClientRect` честен; история «Как на слайде»
 * масштабируется — для её замеров переключить тулбар «Масштаб» на «1:1».
 */

const meta = {
  title: "Карточки/Доход",
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/* ───────────── данные донора ───────────── */

const МЕСЯЦЫ = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const ряд = (values: readonly number[]): EarningsBar[] =>
  МЕСЯЦЫ.map((label, i) => ({ label, value: values[i] }));

const WEEKLY = ряд([3240, 7420, 9650, 7130, 3670, 2300, 3820, 5040, 6840, 4540, 11520, 8210]);
const MONTHLY = ряд([5200, 6100, 7300, 8900, 9600, 10800, 11200, 9800, 8600, 7400, 6900, 8100]);
const YEARLY = ряд([4200, 4800, 5600, 6100, 6800, 7500, 8200, 8900, 9600, 10300, 11000, 11600]);

/**
 * Тики донора: список неравномерный, и это не ошибка снятия. $3K и $5K
 * стоят близко, $10K — далеко; потолок шкалы 12000, то есть выше верхней
 * подписи остаётся запас, и ноябрьский столбик (11 520) его занимает.
 */
const ТИКИ: EarningsTick[] = [
  { value: 0, label: "$0" },
  { value: 3000, label: "$3K" },
  { value: 5000, label: "$5K" },
  { value: 10000, label: "$10K" },
];

const ПОТОЛОК = 12000;

const ПЕРИОДЫ = ["Weekly", "Monthly", "Yearly"] as const;

/* ───────────── линейка ───────────── */

/**
 * Оборачивает карточку и печатает её ФАКТИЧЕСКИЕ размеры плюс худшее
 * переполнение внутри неё.
 *
 * Пороги те же, что в `layout-verification.md`: 16 по высоте (ниже — это
 * выносные элементы шрифта, а не переполнение) и 4 по ширине. Считаются
 * только контейнеры (`children.length`), иначе каждая строка текста даёт
 * ложное срабатывание.
 */
function Линейка({ children }: { children: React.ReactNode }) {
  const box = useRef<HTMLDivElement>(null);
  const [итог, setИтог] = useState("замер после отрисовки");

  /*
   * Замер в эффекте, а не в ref-обработчике, и БЕЗ защёлки «мерить один
   * раз». Причина поймана здесь же: карточка перерисовывается после
   * загрузки шрифта (жёлоб оси замеряется заново), React возвращает
   * подпись к исходному тексту, и однократный замер остаётся навсегда
   * словами «замер после отрисовки». Эффект без списка зависимостей
   * пересчитывается на каждую перерисовку, а результат живёт в состоянии,
   * а не в DOM мимо React.
   */
  useEffect(() => {
    const el = box.current;
    const card = el?.firstElementChild as HTMLElement | null;
    if (!card) return;
    const id = requestAnimationFrame(() => {
      const r = card.getBoundingClientRect();
      const boxes = [card, ...card.querySelectorAll("*")].filter((e) => e.children.length);
      const dy = Math.max(...boxes.map((e) => e.scrollHeight - e.clientHeight));
      const dx = Math.max(...boxes.map((e) => e.scrollWidth - e.clientWidth));
      const scaled = card.closest(".slide-canvas");
      setИтог(
        `${Math.round(r.width)} × ${Math.round(r.height)} · ` +
          `переполнение по высоте ${dy} (порог 16), по ширине ${dx} (порог 4)` +
          (scaled ? " · холст масштабирован, мерить в 1:1" : ""),
      );
    });
    return () => cancelAnimationFrame(id);
  });

  return (
    <div ref={box}>
      {children}
      <p className="text-body-m text-ink-secondary mt-4 tabular-nums">{итог}</p>
    </div>
  );
}

/* ───────────── истории ───────────── */

/**
 * Типовой случай — ровно то, что на скриншоте заказчика.
 *
 * «December / $8 210», сегмент-контрол превращён в подпись периода,
 * выделен последний столбик, легенды нет.
 */
export const Карточка: Story = {
  render: () => <КарточкаВид />,
};

function КарточкаВид() {
  /*
   * Числа в тексте истории считает тот же `earningsGeometry`, что и сама
   * карточка, но пересчитать их после загрузки шрифта некому: хук живёт
   * внутри графика и перерисовывает только его. Без этого вызова витрина
   * напечатала бы ширину оси, замеренную ЗАПАСНЫМ шрифтом, — расхождение
   * на точку-две, которое потом ищут в вёрстке.
   */
  useRemeasureOnFont();
  const g = earningsGeometry({ bars: 12, ticks: ТИКИ });
  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Во всю рабочую ширину — 1680 × {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Графику остаётся {g.chartWidth} × {g.chartHeight}. Ось забирает {g.axis} плюс просвет{" "}
        {g.axisGap}, строка месяцев — 42 (28 подпись плюс 14 просвета), значит область построения{" "}
        {g.plotWidth} × {g.plotHeight}. Шаг {g.step.toFixed(1)}, стакан {g.track.toFixed(1)} — это{" "}
        {(100 * 0.643).toFixed(1)}% шага, доля донора (32 из 49.75). Скругление стакана {g.radius} (
        {((100 * g.radius) / g.track).toFixed(0)}% ширины, у донора 31%), кольцо выделения на{" "}
        {g.ringGap} наружу с радиусом {g.radius + g.ringGap} — концентрично.
      </p>
      <Линейка>
        <EarningsCard
          label="December"
          value="$8 210"
          delta={{ label: "+14,8%", direction: "up" }}
          period={{ label: "Weekly", segments: ПЕРИОДЫ }}
          bars={WEEKLY}
          ticks={ТИКИ}
          max={ПОТОЛОК}
          highlight={11}
        />
      </Линейка>
    </div>
  );
}

/**
 * Три режима донора одной колонкой.
 *
 * У донора переключатель менял данные, но НЕ оси: подписи $0…$10K и Jan…Dec
 * одинаковы во всех трёх режимах, меняются только высоты, сумма и чип.
 * Здесь это видно буквально — три карточки с одной осью и разными рядами.
 *
 * На слайд ставится ОДНА из них: переключателя нет, а три карточки подряд
 * означают три слайда или три колонки, но не три состояния одного блока.
 */
export const ТриПериода: Story = {
  render: () => (
    <div className="flex w-[1680px] flex-col gap-10">
      <div>
        <h3 className="text-title-l text-ink mb-2">Weekly · Monthly · Yearly</h3>
        <p className="text-body-m text-ink-secondary max-w-5xl">
          Выбранное слово набрано основным цветом, остальные — вторичным. Дорожки и
          подложки-таблетки нет намеренно: именно они превращают ряд слов в три кнопки, а нажать в
          PDF нельзя ни одну. Высота карточек здесь 460, а не 604 — три штуки в одну витрину иначе
          не встают; на слайде карточка берёт весь бюджет.
        </p>
      </div>
      {(
        [
          { p: "Weekly", label: "December", value: "$8 210", bars: WEEKLY, d: "+14,8%" },
          { p: "Monthly", label: "December", value: "$8 100", bars: MONTHLY, d: "+8,2%" },
          { p: "Yearly", label: "December", value: "$11 600", bars: YEARLY, d: "+21,4%" },
        ] as const
      ).map((row) => (
        <EarningsCard
          key={row.p}
          height={460}
          label={row.label}
          value={row.value}
          delta={{ label: row.d, direction: "up" }}
          period={{ label: row.p, segments: ПЕРИОДЫ }}
          bars={row.bars}
          ticks={ТИКИ}
          max={ПОТОЛОК}
          highlight={11}
        />
      ))}
    </div>
  ),
};

/**
 * Обе темы рядом — вложенной темой, без переключения тулбара.
 *
 * Смотреть надо не на карточку целиком, а на границу столбика и стакана.
 * Замеры (WCAG, порог 3:1 для нетекстовой графики):
 *
 *   столбик к стакану        светлая 1.29   тёмная 8.73
 *   выделенный к стакану     светлая 1.63   тёмная 6.87
 *   кольцо к стакану         светлая 3.18   тёмная 3.25
 *   подписи осей к карточке  светлая 5.41   тёмная 6.00
 *
 * То есть в светлой теме форму столбиков держит не цвет, а кольцо, ось и
 * шапка. Это принятое заказчиком следствие донорских красок, а не ошибка
 * вёрстки, но на проектор эту карточку правильно отправлять тёмной.
 */
export const ОбеТемы: Story = {
  render: () => <ОбеТемыВид />,
};

function ОбеТемыВид() {
  useRemeasureOnFont();
  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Светлая и тёмная — половинные карточки</h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Половинная карточка (828) даёт стакан{" "}
        {earningsGeometry({ size: "half", bars: 12, ticks: ТИКИ }).track.toFixed(1)} против{" "}
        {earningsGeometry({ bars: 12, ticks: ТИКИ }).track.toFixed(1)} на полной, поэтому скругление
        опускается на ступень: `rounded-tile` 12 вместо `rounded-card` 20, кольцо — `rounded-card`
        20 вместо `rounded-panel` 32, толщина кольца 2 вместо 4. Доля скругления при этом
        сохраняется:{" "}
        {(
          (100 * earningsGeometry({ size: "half", bars: 12, ticks: ТИКИ }).radius) /
          earningsGeometry({ size: "half", bars: 12, ticks: ТИКИ }).track
        ).toFixed(0)}
        % против донорского 31%.
      </p>
      <div className="flex gap-6">
        {(["light", "dark"] as const).map((theme) => (
          <div key={theme} className="w-[828px]">
            <EarningsCard
              theme={theme}
              size="half"
              height={520}
              label="December"
              value="$8 210"
              delta={{ label: "+14,8%", direction: "up" }}
              period={{ label: "Weekly", segments: ПЕРИОДЫ }}
              bars={WEEKLY}
              ticks={ТИКИ}
              max={ПОТОЛОК}
              highlight={11}
            />
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Крайние случаи. Каждый подписан тем, что именно он проверяет.
 */
export const КрайниеСлучаи: Story = {
  render: () => <КрайниеСлучаиВид />,
};

function КрайниеСлучаиВид() {
  useRemeasureOnFont();
  return (
    <div className="flex w-[1680px] flex-col gap-12">
      <div>
        <h3 className="text-title-l text-ink mb-2">Минимум данных — два столбика</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Стакан считается долей шага, а не абсолютным числом, поэтому при двух столбиках он
          становится {earningsGeometry({ bars: 2, ticks: ТИКИ }).track.toFixed(0)} точек шириной и
          получает скругление {earningsGeometry({ bars: 2, ticks: ТИКИ }).radius} (`
          {earningsGeometry({ bars: 2, ticks: ТИКИ }).barClass}`) вместо{" "}
          {earningsGeometry({ bars: 12, ticks: ТИКИ }).radius}. Ничего не схлопывается в ноль, но
          два столбика — это не график: сравнение двух чисел честнее плитками (`StatTiles`). История
          нужна как проверка формы, а не как образец слайда.
        </p>
        <EarningsCard
          height={420}
          label="Второе полугодие"
          value="$19 730"
          delta={{ label: "+11,2%", direction: "up" }}
          bars={[
            { label: "H1", value: 8210 },
            { label: "H2", value: 11520 },
          ]}
          ticks={ТИКИ}
          max={ПОТОЛОК}
          highlight={1}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Потолок: столбик выше верхней подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Домен донора 12000 при верхнем тике $10K — над подписью остаётся запас в 17%, и ноябрьский
          столбик (11 520) в него заходит. Крайний случай здесь — ряд, где значение РАВНО потолку:
          столбик заполняет стакан целиком, верхний край совпадает с верхом области построения, за
          холст ничего не выходит. Значение выше потолка обрезается до 100% — то есть шкала врёт
          молча, и потолок надо задавать по данным, а не по вкусу.
        </p>
        <EarningsCard
          height={420}
          label="Ноябрь"
          value="$12 000"
          period={{ label: "Weekly", segments: ПЕРИОДЫ }}
          bars={ряд([3240, 7420, 9650, 7130, 3670, 2300, 3820, 5040, 6840, 4540, 12000, 13500])}
          ticks={ТИКИ}
          max={ПОТОЛОК}
          highlight={10}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Длинные подписи</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Замер (1:1): под подпись месяца остаётся 123.9 точки — на этой карточке ось шире обычного
          и забирает место у столбиков. Русские месяцы помещаются: самый длинный, «Сентябрь»,
          занимает 88.2. «Декабрь 2026» — 126.7, и его обрезает многоточием (замер: срезано 3
          точки). Перенос вместо обрезки увеличил бы строку и съел область построения, поэтому его
          нет.
          <br />
          Подписи оси НЕ обрезаются: число с многоточием читается как другое число. Вместо этого
          колонка оси ЗАМЕРЯЕТСЯ по самой длинной подписи — «$1 250 000» даёт 104 точки хода строки,
          колонка встаёт в 105 против 48 у обычного «$10K», и область построения ужимается ровно на
          разницу. Руками ничего передавать не нужно; `axisWidth` остаётся на случай, когда замер не
          годится. Замер левого края: подпись начинается в 37 точках от края карточки при поле 36 —
          то есть ровно в поле и не дальше. Без замера она вылезла бы ВЛЕВО, за поле, и автопроверка
          ширины этого НЕ увидела бы: `scrollWidth` левый вылет не считает.
        </p>
        <EarningsCard
          height={460}
          size="full"
          label="Средний чек в разрезе каналов привлечения"
          value="$1 284 950"
          delta={{ label: "−1,8%", direction: "down" }}
          period={{ label: "Последние 12 месяцев" }}
          bars={[
            { label: "Январь", value: 620000 },
            { label: "Февраль", value: 780000 },
            { label: "Март", value: 910000 },
            { label: "Апрель", value: 1050000 },
            { label: "Май", value: 890000 },
            { label: "Июнь", value: 1180000 },
            { label: "Июль", value: 1250000 },
            { label: "Август", value: 1120000 },
            { label: "Сентябрь", value: 980000 },
            { label: "Октябрь", value: 1040000 },
            { label: "Ноябрь", value: 1160000 },
            { label: "Декабрь 2026", value: 1284950 },
          ]}
          ticks={[
            { value: 0, label: "$0" },
            { value: 500000, label: "$500 000" },
            { value: 1000000, label: "$1 000 000" },
            { value: 1250000, label: "$1 250 000" },
          ]}
          max={1400000}
          highlight={11}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">
          ⚠️ Опасный случай: ноль и два порядка разницы
        </h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          Столбик с ненулевым значением не может быть тоньше своего скругления — иначе у него
          срезаются круглые концы и он перестаёт читаться как столбик. Пол равен радиусу:{" "}
          {earningsGeometry({ bars: 12, ticks: ТИКИ }).minBar} точек из{" "}
          {earningsGeometry({ bars: 12, ticks: ТИКИ }).plotHeight} — это{" "}
          {(
            (100 * earningsGeometry({ bars: 12, ticks: ТИКИ }).minBar) /
            earningsGeometry({ bars: 12, ticks: ТИКИ }).plotHeight
          ).toFixed(1)}
          %. Значит любое значение ниже{" "}
          {(
            (ПОТОЛОК * earningsGeometry({ bars: 12, ticks: ТИКИ }).minBar) /
            earningsGeometry({ bars: 12, ticks: ТИКИ }).plotHeight
          ).toFixed(0)}{" "}
          рисуется одинаково, и февральские $90 выглядят как $560. Это не баг разметки, а предел
          формы: ряд, где значения различаются в сто раз, столбиками не показывают — берут таблицу
          или логарифм, которого на слайде быть не должно. Ноль рисуется ПУСТЫМ стаканом, без
          обрубка: обрубок означал бы «мало», а не «ничего».
        </p>
        <EarningsCard
          height={460}
          label="Февраль"
          value="$90"
          delta={{ label: "−98,8%", direction: "down" }}
          bars={ряд([7420, 90, 0, 560, 240, 0, 11520, 30, 4540, 0, 120, 8210])}
          ticks={ТИКИ}
          max={ПОТОЛОК}
          highlight={1}
        />
      </div>

      <div>
        <h3 className="text-title-l text-ink mb-2">Без выделения, без чипа, без периода</h3>
        <p className="text-body-m text-ink-secondary mb-6 max-w-5xl">
          `highlight` не передан — кольца нет, все столбики одной краской, все подписи вторичным
          цветом. Так карточка выглядит, когда мысль слайда не про один месяц, а про форму года
          целиком. Высота шапки при этом не меняется: она считается от кегля числа, а не от того,
          что в неё положили.
        </p>
        <EarningsCard
          height={420}
          label="Earned so far"
          value="$99 900"
          bars={MONTHLY}
          ticks={ТИКИ}
          max={ПОТОЛОК}
        />
      </div>
    </div>
  );
}

/**
 * График отдельно от карточки.
 *
 * `EarningsPlot` экспортируется, потому что стаканы иногда нужны без шапки —
 * например, второй формой на слайде сравнения. Слот здесь задан руками
 * (высота — то же, что даёт `cardChartHeight`), чтобы было видно: форма
 * строится от высоты слота и ничего не знает про карточку.
 */
export const ТолькоГрафик: Story = {
  render: () => (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">
        Область {1608} × {cardChartHeight({ legend: false })} — без шапки и легенды
      </h3>
      <p className="text-body-m text-ink-secondary mb-10 max-w-5xl">
        Высота приходит снаружи, проценты столбиков считаются от неё. Поэтому один и тот же ряд
        одинаково работает и в слоте 284, и в слоте 408 — подбирать высоту под данные не нужно.
      </p>
      <div
        className="bg-surface rounded-hero p-9"
        style={{ height: cardChartHeight({ legend: false }) + 72 }}
      >
        <EarningsPlot bars={WEEKLY} ticks={ТИКИ} max={ПОТОЛОК} highlight={11} />
      </div>
    </div>
  ),
};

/**
 * Геометрия числами — чтобы пропорции сверяли, а не оценивали.
 *
 * Донорское поле построения 597 × 187 = 3.19:1. Ближе всего к нему полная
 * карточка без легенды: 1544 × 366 = 4.22:1. Половинная — 724 × 398, то есть 1.82:1:
 * стаканы становятся высокими и узкими, форма года читается хуже. Точные числа
 * считает таблица ниже — она вызывает тот же `earningsGeometry`, что и сама
 * карточка, поэтому разойтись с ней не может.
 */
export const Геометрия: Story = {
  render: () => <ГеометрияВид />,
};

function ГеометрияВид() {
  useRemeasureOnFont();
  const rows = [
    { size: "full", legend: false, bars: 12 },
    { size: "full", legend: true, bars: 12 },
    { size: "full", legend: false, bars: 6 },
    { size: "half", legend: false, bars: 12 },
    { size: "half", legend: false, bars: 6 },
    { size: "half", legend: true, bars: 12 },
  ] as const;

  return (
    <div className="w-[1680px]">
      <h3 className="text-title-l text-ink mb-2">Что получится при бюджете {CARD_BUDGET}</h3>
      <p className="text-body-m text-ink-secondary mb-8 max-w-5xl">
        Все числа считает `earningsGeometry` — тот же расчёт, по которому строится сама карточка.
        Таблица нужна, чтобы выбрать размер до вёрстки слайда, а не после.
      </p>
      <table className="text-body-l text-ink w-full tabular-nums">
        <thead className="text-body-m text-ink-secondary">
          <tr>
            {[
              "карточка",
              "легенда",
              "столбиков",
              "область построения",
              "пропорция",
              "шаг",
              "стакан",
              "скругление",
            ].map((h) => (
              <th key={h} className="border-line border-b py-3 text-left font-normal">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const g = earningsGeometry({
              size: r.size,
              legend: r.legend,
              bars: r.bars,
              ticks: ТИКИ,
            });
            return (
              <tr key={`${r.size}-${r.legend}-${r.bars}`}>
                <td className="border-line border-b py-3">
                  {r.size === "full" ? "1680 полная" : "828 половина"}
                </td>
                <td className="border-line border-b py-3">{r.legend ? "есть" : "нет"}</td>
                <td className="border-line border-b py-3">{r.bars}</td>
                <td className="border-line border-b py-3">
                  {g.plotWidth} × {g.plotHeight}
                </td>
                <td className="border-line border-b py-3">
                  {(g.plotWidth / g.plotHeight).toFixed(2)}:1
                </td>
                <td className="border-line border-b py-3">{g.step.toFixed(1)}</td>
                <td className="border-line border-b py-3">{g.track.toFixed(1)}</td>
                <td className="border-line border-b py-3">
                  {g.radius} · кольцо {g.radius + g.ringGap}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* ═══════════════  На слайде  ═══════════════ */

/**
 * Карточка внутри ContentSlide — проверка бюджета 604.
 *
 * Шапка слайда (пилюля, заголовок в одну строку, лид) забирает 244, подвал
 * резервирует 56, блоку остаётся ровно {CARD_BUDGET}. Карточка берёт весь
 * бюджет: она задана высотой, а не содержимым, поэтому график обязан
 * поместиться в остаток, а не наоборот.
 *
 * ⚠️ Заголовок в ДВЕ строки съедает ещё 60 — карточка на 604 тогда не
 * поместится и низ обрежется. Либо заголовок в одну строку, либо
 * `height={544}`.
 */
export const НаСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      eyebrow="Доход"
      title="Декабрь принёс $8 210 — второй результат года"
      lead="Столбик стоит в стакане: серая часть — потолок шкалы, зелёная — факт месяца"
      page={7}
      label="Витрина карточек"
    >
      <EarningsCard
        label="December"
        value="$8 210"
        delta={{ label: "+14,8%", direction: "up" }}
        period={{ label: "Weekly", segments: ПЕРИОДЫ }}
        bars={WEEKLY}
        ticks={ТИКИ}
        max={ПОТОЛОК}
        highlight={11}
      />
    </ContentSlide>
  ),
};

/**
 * То же на тёмном слайде — как эту карточку правильно везти на проектор.
 *
 * Слайд тёмный целиком, карточка своей темы не задаёт: она берёт тему
 * слайда. Столбик к стакану 8.73 против 1.29 в светлой — разница видна
 * без замера, но замер приведён, чтобы решение было проверяемым.
 */
export const НаТёмномСлайде: Story = {
  parameters: { slide: true },
  render: () => (
    <ContentSlide
      theme="dark"
      eyebrow="Доход"
      title="Декабрь принёс $8 210 — второй результат года"
      lead="Та же карточка тёмной темой: краски донора здесь берут порог с запасом"
      page={8}
      label="Витрина карточек"
    >
      <EarningsCard
        label="December"
        value="$8 210"
        delta={{ label: "+14,8%", direction: "up" }}
        period={{ label: "Weekly", segments: ПЕРИОДЫ }}
        bars={WEEKLY}
        ticks={ТИКИ}
        max={ПОТОЛОК}
        highlight={11}
      />
    </ContentSlide>
  ),
};
