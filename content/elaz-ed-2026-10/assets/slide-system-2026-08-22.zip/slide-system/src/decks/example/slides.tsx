import CoverSlide from "../../templates/CoverSlide";
import ContentSlide from "../../templates/ContentSlide";
import StatementSlide from "../../templates/StatementSlide";
import LineCard from "../../blocks/cards/lineCard";

/**
 * Слайды пробной презентации.
 *
 * Дек собран с нуля по правилам системы, чтобы проверить: хватает ли
 * поставки для сборки новой презентации без обращения к чему-либо снаружи.
 *
 * Сетка: 12 колонок по 118 с желобом 24 = 1680. Карточка во всю ширину
 * получает width = 12 × 118 + 11 × 24 = 1680, высоту — весь бюджет блока
 * под шапкой ContentSlide, 604.
 */

const LABEL = "Минимальная презентация";
const ШИРИНА_12 = 12 * 118 + 11 * 24; // 1680 — вся рабочая ширина
const БЮДЖЕТ = 604; // высота под шапкой ContentSlide

const ТОЧКИ = [
  { label: "Янв", value: 1240 },
  { label: "Фев", value: 1310 },
  { label: "Мар", value: 1180 },
  { label: "Апр", value: 1520 },
  { label: "Май", value: 1740 },
  { label: "Июн", value: 2090 },
];

export function Обложка() {
  return (
    <CoverSlide
      eyebrow="Квартальный отчёт"
      title="Второй квартал закрыт с ростом в полтора раза"
      subtitle="Что выросло, за счёт чего и что делаем в третьем"
      footnote="Ромашка"
      meta="Июль 2026"
    />
  );
}

export function Динамика({ page }: { page: number }) {
  return (
    <ContentSlide
      eyebrow="Динамика"
      title="Рост держится третий месяц подряд"
      lead="Модельный пример: выручка по месяцам, июнь — лучший результат за полугодие."
      page={page}
      label={LABEL}
    >
      <div className="slide-grid h-full content-center">
        <div className="col-span-12">
          <LineCard
            label="Выручка за месяц"
            value="2 090 000 ₽"
            delta={{ label: "+20% к маю", direction: "up" }}
            period={{ label: "Первое полугодие" }}
            points={ТОЧКИ}
            width={ШИРИНА_12}
            height={БЮДЖЕТ}
            formatTick={(v: number) => `${Math.round(v / 100) / 10} млн`}
          />
        </div>
      </div>
    </ContentSlide>
  );
}

export function Финал() {
  return (
    <StatementSlide
      eyebrow="Что дальше"
      attribution="Ромашка · план на третий квартал"
      quoted={false}
    >
      Удерживаем темп и добираем два канала, которые не запускали
    </StatementSlide>
  );
}
