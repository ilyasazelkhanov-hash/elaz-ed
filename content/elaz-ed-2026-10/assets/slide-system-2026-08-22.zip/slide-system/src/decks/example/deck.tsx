import type { Deck } from "../../deck/types";
import { Обложка, Динамика, Финал } from "./slides";

/**
 * Минимальная презентация — проверка, что система собирает деки с нуля.
 *
 * Три слайда: обложка, содержательный на карточке, финал. Числа вымышлены.
 */
const deck: Deck = {
  id: "example",
  title: "Минимальная презентация",
  client: "Ромашка",
  slides: [
    { id: "cover", title: "Обложка", render: () => <Обложка /> },
    { id: "trend", title: "Динамика", render: (page) => <Динамика page={page} /> },
    { id: "final", title: "Финал", render: () => <Финал /> },
  ],
};

export default deck;
