import type { Meta, StoryObj } from "@storybook/react-vite";
import deck from "./deck";
import SlideFit from "../../slide/SlideFit";

/**
 * Stories эталонного дека «Девять эталонных слайдов».
 *
 * Слайды строятся ИЗ МАНИФЕСТА, а не перечисляются здесь руками: ручное
 * перечисление рано или поздно разойдётся с манифестом, и в Storybook
 * окажется слайд, которого нет в PDF, или наоборот. Номер страницы берётся
 * из позиции в манифесте — ровно тот же, что попадёт в выгрузку.
 *
 * ⚠️ Замерять вёрстку в этих историях можно ТОЛЬКО в режиме «1:1 — для
 * замеров» (тулбар «Масштаб»). По умолчанию холст 1920 сжат через
 * `transform: scale`, и `getBoundingClientRect` возвращает числа после
 * трансформации: поле 120 на ноутбуке окажется 74.9. Проверка режима —
 * `getComputedStyle(document.querySelector(".slide-canvas")).transform`
 * должен быть `none`.
 */
const meta = {
  title: "Презентации/Эталон",
  parameters: { slide: true },
} satisfies Meta;

export default meta;
type Story = StoryObj<typeof meta>;

/** Все слайды подряд — как их увидит клиент в PDF */
export const ВесьДек: Story = {
  name: "Весь дек",
  parameters: { slide: false },
  render: () => (
    <div className="bg-surface-muted flex flex-col items-center gap-10 p-10">
      {deck.slides.map((slide, index) => (
        <div key={slide.id} className="w-full max-w-[1400px]">
          <p className="text-body-m text-ink-secondary mb-3">
            {index + 1}. {slide.title}
          </p>
          <SlideFit className="shadow-card rounded-tile overflow-hidden">
            {slide.render(index + 1)}
          </SlideFit>
        </div>
      ))}
    </div>
  ),
};

/*
 * Отдельная story на каждый слайд.
 *
 * Storybook требует, чтобы экспорты были известны на этапе сборки — собрать
 * их циклом в объект и разложить нельзя, статический анализ такого не видит.
 * Поэтому экспорты выписаны, но КАЖДЫЙ берёт слайд из манифеста по индексу.
 */
const slideAt = (index: number): Story => ({
  name: `${index + 1}. ${deck.slides[index].title}`,
  render: () => deck.slides[index].render(index + 1),
});

export const Слайд01 = slideAt(0);
export const Слайд02 = slideAt(1);
export const Слайд03 = slideAt(2);
export const Слайд04 = slideAt(3);
export const Слайд05 = slideAt(4);
export const Слайд06 = slideAt(5);
export const Слайд07 = slideAt(6);
export const Слайд08 = slideAt(7);
export const Слайд09 = slideAt(8);
