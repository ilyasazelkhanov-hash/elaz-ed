import type { ReactNode } from "react";
import Slide, { SlideBody, type SlideTheme } from "../slide/Slide";
import Pill from "../components/Pill";
import SlideFooter from "./SlideFooter";

/**
 * Содержательный слайд: шапка и рабочая область.
 *
 * === Про структуру шапки ===
 *
 * Пилюля — заголовок — лид. Три уровня, и все три необязательны, но порядок
 * зафиксирован: пилюля называет раздел, заголовок формулирует мысль слайда,
 * лид её раскрывает одной фразой.
 *
 * Мысль слайда — именно в заголовке, а не в содержимом. Заголовок вида
 * «Результаты» ничего не сообщает; «Выручка выросла втрое за два квартала»
 * сообщает всё, и содержимое становится доказательством. Это правило
 * действует и когда слайд собирает агент — см. .claude/rules/slide-anatomy.md
 *
 * === Про высоту ===
 *
 * Рабочая область получает flex-1 и min-h-0. Второе обязательно: без него
 * flex-элемент не может стать меньше своего содержимого, и слайд, в который
 * положили слишком много, молча вырастет за нижний край холста. С min-h-0
 * содержимое обрежется по границе холста — и переполнение станет видно сразу,
 * а не на показе клиенту.
 */

export interface ContentSlideProps {
  /** Название раздела в пилюле */
  eyebrow?: string;
  /** Заголовок = мысль слайда, а не название темы */
  title?: ReactNode;
  /** Одна фраза, раскрывающая заголовок */
  lead?: ReactNode;
  children?: ReactNode;
  /** Номер слайда в подвале */
  page?: number;
  /** Подпись в подвале: название презентации */
  label?: string;
  theme?: SlideTheme;
}

export default function ContentSlide({
  eyebrow,
  title,
  lead,
  children,
  page,
  label,
  theme = "light",
}: ContentSlideProps) {
  const hasHeader = Boolean(eyebrow || title || lead);
  const hasFooter = page !== undefined || Boolean(label);

  return (
    <Slide theme={theme}>
      <SlideBody>
        {hasHeader ? (
          <header className="mb-block flex flex-col gap-6">
            {eyebrow ? (
              <div>
                <Pill caps>{eyebrow}</Pill>
              </div>
            ) : null}

            {title ? (
              <h2 className="text-headline-l text-ink max-w-[1500px] text-balance">{title}</h2>
            ) : null}

            {lead ? <p className="text-body-l text-ink-secondary max-w-[1200px]">{lead}</p> : null}
          </header>
        ) : null}

        {/*
         * min-h-0 обязателен — объяснение в шапке файла.
         *
         * pb-14 резервирует место под подвал. Подвал спозиционирован
         * абсолютно и из потока выпадает, поэтому содержимое о нём не знает:
         * блок, прижатый книзу через mt-auto, встаёт ровно на него.
         *
         * Поймано на демо-слайде «Стек»: кнопка легла поверх подписи
         * презентации, и в Storybook это было незаметно — увидели только
         * в PDF. 56px = строка подвала (20) плюс просвет (36).
         */}
        <div className={`min-h-0 flex-1 ${hasFooter ? "pb-14" : ""}`}>{children}</div>
      </SlideBody>

      {hasFooter ? <SlideFooter page={page} label={label} /> : null}
    </Slide>
  );
}
