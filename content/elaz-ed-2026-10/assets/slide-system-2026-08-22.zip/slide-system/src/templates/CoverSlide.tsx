import SlideSpot from "../slide/SlideSpot";
import type { ReactNode } from "react";
import Slide, { SlideBody, type SlideTheme } from "../slide/Slide";
import Pill from "../components/Pill";

/**
 * Обложка презентации.
 *
 * === Почему по умолчанию тёмная ===
 *
 * Обложка и разделители разделов — единственные места, где тёмная тема
 * работает на смысл, а не на украшение: они задают ритм. Идущие подряд
 * светлые содержательные слайды между тёмными «границами» читаются как главы,
 * а не как поток. Ровно поэтому в проекте две полноценные темы, а не одна.
 *
 * === Про кегль ===
 *
 * Заголовок берёт display-l (128px) — это единственный слайд, где такой кегль
 * уместен. Внутри содержательного слайда display съедает половину высоты и
 * оставляет содержимому угол.
 *
 * Если заголовок длиннее ~30 знаков, display-l даст три строки и упрётся
 * в подзаголовок. Для таких случаев есть size="m" (96px) — это не «мельче
 * потому что не влезло», а осознанный второй размер обложки.
 *
 * === Про нижнюю черту ===
 *
 * Черта принадлежит подписям, а не обложке: она отделяет их от заголовка.
 * Поэтому без единой подписи её нет. Замер до правки на <CoverSlide title=…>:
 * линия шириной 1680px на отметке 951 и пустой блок высотой 41px под ней
 * (обводка 1 + pt-10) — на клиентской обложке это читается как обрезанный
 * элемент. Заголовок при этом упирался в пустой блок и стоял низом на 887
 * вместо 992.
 */

export interface CoverSlideProps {
  /** Надзаголовок: тип документа, отрасль, дата */
  eyebrow?: string;
  title: ReactNode;
  subtitle?: ReactNode;
  /** Левая нижняя подпись: клиент, автор */
  footnote?: ReactNode;
  /** Правая нижняя подпись: дата, город */
  meta?: ReactNode;
  /** Логотипы, знак, что угодно в правом нижнем углу */
  aside?: ReactNode;
  /**
   * Блок между подзаголовком и подписями: полоса показателей, ряд плиток,
   * знак клиента.
   *
   * Слот заведён под обложки, где под заголовком стоят цифры — «два
   * счётчика, пять продуктов, семь команд». Собирать такую обложку заново
   * из `Slide` + `SlideBody` было бы дублированием: световое пятно, зерно,
   * `mt-auto` у заголовка и черта над подписями одинаковы у всех обложек
   * и меняться должны в одном месте.
   *
   * ⚠️ Содержимое слота уходит в общий поток, а не позиционируется
   * абсолютно, и место у него не зарезервировано: `mt-auto` над заголовком
   * просто отдаёт слоту всю свободную высоту. Слишком высокий блок
   * вытолкнет заголовок вверх, а потом и за холст. Проверять замером —
   * `layout-verification.md`.
   */
  children?: ReactNode;
  size?: "l" | "m";
  theme?: SlideTheme;
}

export default function CoverSlide({
  eyebrow,
  title,
  subtitle,
  footnote,
  meta,
  aside,
  children,
  size = "l",
  theme = "dark",
}: CoverSlideProps) {
  const titleClass = size === "l" ? "text-display-l" : "text-display-m";

  /*
   * Черта с подписями выводится, только если под ней есть хоть что-то.
   * aside учитывается наравне с текстом: логотип в правом углу — такая же
   * подпись, и черта под ним осмысленна.
   */
  const hasFootline = Boolean(footnote || meta || aside);

  return (
    <Slide theme={theme}>
      {/*
       * Световое пятно и зерно. Плоская заливка на 1920×1080 выглядит мёртвой,
       * а в тёмной теме на проекторе ещё и проступает полосами — зерно эти
       * полосы разбивает. Оба слоя статические и переживают печать в PDF.
       */}
      <SlideSpot alpha={0.22} y={0.1} />
      <div className="slide-grain" />

      <SlideBody>
        {eyebrow ? (
          <div className="mb-block">
            <Pill caps>{eyebrow}</Pill>
          </div>
        ) : null}

        {/* mt-auto прижимает заголовок к низу: обложка читается снизу вверх,
            от крупного к мелкому, и заголовок стоит на оптической опоре */}
        <div className="mt-auto flex flex-col gap-8">
          <h1 className={`${titleClass} text-ink max-w-[1400px] text-balance`}>{title}</h1>

          {subtitle ? (
            <p className="text-headline-s text-ink-secondary max-w-[1100px]">{subtitle}</p>
          ) : null}
        </div>

        {children ? <div className="mt-block">{children}</div> : null}

        {hasFootline ? (
          <div className="border-line mt-block flex items-end justify-between border-t pt-10">
            <div className="flex flex-col gap-2">
              {footnote ? <span className="text-title-m text-ink">{footnote}</span> : null}
              {meta ? <span className="text-body-m text-ink-secondary">{meta}</span> : null}
            </div>
            {aside}
          </div>
        ) : null}
      </SlideBody>
    </Slide>
  );
}
