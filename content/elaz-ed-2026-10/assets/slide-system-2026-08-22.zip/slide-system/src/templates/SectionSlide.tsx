import SlideSpot from "../slide/SlideSpot";
import type { ReactNode } from "react";
import Slide, { SlideBody, type SlideTheme } from "../slide/Slide";

/**
 * Разделитель раздела.
 *
 * === Зачем он в презентации ===
 *
 * Десять содержательных слайдов подряд читаются как один длинный слайд:
 * клиент теряет, где кончилась одна мысль и началась другая. Разделитель
 * ставит границу — и делает это темой, а не заголовком, потому что смена
 * фона видна с любого расстояния, а заголовок надо прочесть.
 *
 * Практическое правило: разделитель на каждые 4-6 содержательных слайдов.
 * Чаще — презентация распадается на обрывки, реже — граница не работает.
 *
 * === Про номер раздела ===
 *
 * Крупная цифра слева задаёт положение в маршруте: клиент видит «02 из 05»
 * и понимает, сколько осталось. Без неё разделитель сообщает только «дальше
 * что-то другое».
 *
 * === Сколько тем помещается ===
 *
 * Потолок геометрический, и он ближе, чем кажется. Колонка тем — col-span-4,
 * это 544px, под текст остаётся 512px: точка 12 плюс gap-5. На body-l (24/32)
 * в такую ширину входит около 40 знаков, дальше подпись ломается на две
 * строки. Замер пункта: одна строка — 57px, две — 89px, между пунктами
 * gap-6 (24px).
 *
 * Отсюда два потолка при рабочей области 904px:
 *
 * - подписи в ДВЕ строки: 6 → 654px, 8 → 880px (запас 24), 9 → 993px, низ
 *   уже за холстом, 10 → 1106px, под холстом остаётся 114px текста;
 * - подписи в ОДНУ строку: 81n − 24, то есть 11 пунктов до 867px.
 *
 * Оба потолка выше редакционного: канон слайда (slide-anatomy.md) требует
 * не больше шести пунктов — семь уже не читают, а пересчитывают. Поэтому
 * проверка ниже ругается на седьмом, а не на девятом: к моменту, когда
 * дело дойдёт до обрезки, слайд давно перестал работать по смыслу.
 */

export interface SectionSlideProps {
  /** Номер раздела: «02». Строкой, чтобы сохранить ведущий ноль */
  number?: string;
  title: ReactNode;
  /** Одна фраза о содержании раздела */
  summary?: ReactNode;
  /** Список тем раздела — что будет дальше */
  items?: string[];
  theme?: SlideTheme;
}

/**
 * Проверка длины списка — только в режиме разработки.
 *
 * Здесь console.warn, а не исключение (в отличие от SectionRailSlide):
 * длинный список — это перебор, а не сломанные данные. Слайд остаётся
 * осмысленным, safe-центрирование прижимает верх к границе рабочей области
 * и не даёт содержимому уйти вверх, где оно пропало бы молча. Ронять из-за
 * этого весь дек не за что, а автор предупреждение видит.
 *
 * В прод-сборке ветка вырезается целиком: import.meta.env.DEV — константа
 * времени сборки.
 */
function проверить(items: string[]) {
  if (!import.meta.env.DEV) return;
  if (items.length <= 6) return;

  console.warn(
    `SectionSlide: тем ${items.length}. Канон слайда разрешает не больше шести — ` +
      `семь пунктов не читают, а пересчитывают. Геометрия терпит дольше, но ` +
      `недолго: при подписях в две строки девять пунктов дают 993px при ` +
      `доступных 904, и низ списка уходит за холст. Делить на два разделителя ` +
      `или сворачивать в 3-4 группы.`,
  );
}

export default function SectionSlide({
  number,
  title,
  summary,
  items,
  theme = "dark",
}: SectionSlideProps) {
  if (items) проверить(items);

  return (
    <Slide theme={theme}>
      <SlideSpot alpha={0.18} x={0.18} y={0.5} />
      <div className="slide-grain" />

      <SlideBody>
        <div className="slide-grid my-auto items-center">
          <div className="col-span-7 flex flex-col gap-8">
            {number ? (
              <span className="text-display-s text-ink-tertiary tabular-nums">{number}</span>
            ) : null}

            <h2 className="text-display-m text-ink text-balance">{title}</h2>

            {summary ? (
              <p className="text-headline-s text-ink-secondary max-w-[820px]">{summary}</p>
            ) : null}
          </div>

          {items?.length ? (
            <ul className="col-span-4 col-start-9 flex flex-col gap-6">
              {items.map((item) => (
                <li key={item} className="border-line flex items-start gap-5 border-t pt-6">
                  {/*
                   * Точка вместо маркера списка: стандартный list-style
                   * не выравнивается по базовой линии крупного текста и
                   * висит выше строки. mt-3 ставит её на оптический центр
                   * первой строки body-l (кегль 24, межстрочный 32).
                   */}
                  <span className="bg-accent-blue mt-3 h-3 w-3 shrink-0 rounded-full" />
                  <span className="text-body-l text-ink-secondary">{item}</span>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </SlideBody>
    </Slide>
  );
}
