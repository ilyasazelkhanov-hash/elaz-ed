import type { ReactNode } from "react";
import Slide, { SlideBody, type SlideTheme } from "../slide/Slide";
import SlideSpot from "../slide/SlideSpot";
import Pill from "../components/Pill";

/**
 * Слайд-заявление: одна формулировка во весь холст.
 *
 * === Когда он нужен ===
 *
 * В конце аудита есть фраза, которую заказчик перескажет своему
 * руководителю. Если она лежит абзацем среди выводов, пересказывать будут
 * своими словами — и смысл поплывёт. Отдельный слайд превращает её
 * в цитату, которую можно скопировать целиком.
 *
 * === Почему тёмный ===
 *
 * По тому же правилу, что обложка и разделители: тёмный фон означает
 * границу. Заявление стоит в самом конце, и смена темы говорит «рассказ
 * закончился, дальше вывод» раньше, чем прочитан текст.
 *
 * === Про кегль ===
 *
 * Размер «m» (headline-m, 44px) — значение по умолчанию, потому что такие
 * формулировки длинные: 300+ знаков на display-кегле не поместятся, а
 * поместившись, займут весь холст сплошной стеной букв.
 *
 * Размер «l» (headline-l, 56px) — для коротких заявлений до ~180 знаков.
 * Это не «мельче, потому что не влезло», а два штатных размера под два
 * разных объёма.
 */

export interface StatementSlideProps {
  /** Пилюля над заявлением: «Формулировка для клиента» */
  eyebrow?: string;
  children: ReactNode;
  /** Кто это говорит или откуда взято */
  attribution?: ReactNode;
  size?: "l" | "m";
  /** Обрамить типографскими кавычками. Выключить, если это не цитата */
  quoted?: boolean;
  theme?: SlideTheme;
}

export default function StatementSlide({
  eyebrow,
  children,
  attribution,
  size = "m",
  quoted = true,
  theme = "dark",
}: StatementSlideProps) {
  const textClass = size === "l" ? "text-headline-l" : "text-headline-m";

  return (
    <Slide theme={theme}>
      <SlideSpot alpha={0.2} x={0.5} y={0.12} />
      <div className="slide-grain" />

      <SlideBody>
        <div className="my-auto flex max-w-[1480px] flex-col gap-10">
          {eyebrow ? (
            <div>
              <Pill caps>{eyebrow}</Pill>
            </div>
          ) : null}

          {/*
           * Акцентная черта вместо крупной кавычки-загогулины.
           *
           * Кавычка кеглем 128px читается как рисунок и перетягивает
           * внимание с текста, ради которого слайд и сделан. Черта
           * обозначает «здесь начинается цитата» и на этом останавливается.
           *
           * Размеры прежние — 140×6, — но взяты утилитами базовой сетки 4px
           * (w-35 = 35 × 4, h-1.5 = 1.5 × 4) вместо инлайнового style:
           * прямые значения в компонентах запрещены. Замер до и после
           * совпадает: ширина 140, высота 6, радиус на глаз 3px — капсула
           * ужимается до половины меньшей стороны.
           */}
          <span className="bg-accent-blue rounded-capsule h-1.5 w-35" aria-hidden="true" />

          {/*
           * Кавычки-ёлочки ставит слайд, а не данные. Если бы они лежали
           * в строке отчёта, при использовании той же строки в другом
           * месте (например, в списке выводов) кавычки поехали бы с ней
           * туда, где они не нужны.
           */}
          <blockquote className={`${textClass} text-ink text-balance`}>
            {quoted ? "«" : null}
            {children}
            {quoted ? "»" : null}
          </blockquote>

          {attribution ? <p className="text-body-l text-ink-secondary">{attribution}</p> : null}
        </div>
      </SlideBody>
    </Slide>
  );
}
