import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import DeckPage from "./deck/DeckPage";
import "./styles/index.css";

/**
 * Точка входа веб-приложения.
 *
 * Приложение здесь одно и служебное — страница печати презентации. Смотреть
 * и править слайды нужно в Storybook, а эта страница существует ради PDF:
 * скрипт экспорта открывает её в headless-браузере и печатает.
 *
 * Дек выбирается параметром адреса: /?deck=<идентификатор>
 */
createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <DeckPage />
  </StrictMode>,
);
