import type { Deck } from "./types";
import showcaseDeck from "../decks/showcase/deck";
import exampleDeck from "../decks/example/deck";

/**
 * Реестр презентаций.
 *
 * Каждая новая презентация добавляется сюда одной строкой — иначе её не
 * найдёт ни страница печати, ни скрипт экспорта в PDF.
 *
 * В системе лежит один дек — эталонный `showcase`. Это ОБРАЗЕЦ сборки:
 * девять содержательных слайдов на карточках, собранные по всем правилам
 * проекта. Клиентские презентации заводятся рядом скиллом `/new-deck`.
 *
 * === Про импорт всех деков разом ===
 *
 * Это осознанное исключение из запрета на barrel imports (см. CLAUDE.md):
 * реестр тянет в сборку все презентации сразу. Для страницы печати это
 * безразлично — она служебная, открывается локально скриптом экспорта
 * и в интернет не выкладывается.
 *
 * Если презентации когда-нибудь начнут раздаваться клиентам ссылкой,
 * реестр надо будет переделать на динамический import() — тогда вес чужих
 * презентаций перестанет попадать в чужую сборку.
 */
export const DECKS: Record<string, Deck> = {
  [showcaseDeck.id]: showcaseDeck,
  [exampleDeck.id]: exampleDeck,
};

export function getDeck(id: string | null): Deck | undefined {
  if (!id) return undefined;
  return DECKS[id];
}

export function deckIds(): string[] {
  return Object.keys(DECKS);
}
