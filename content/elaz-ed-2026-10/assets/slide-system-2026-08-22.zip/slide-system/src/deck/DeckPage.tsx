import { getDeck, deckIds } from "./registry";
import type { Deck } from "./types";

/**
 * Печатная страница презентации — то, что открывает скрипт экспорта в PDF.
 *
 * === Почему все слайды на одной странице, а не по одному ===
 *
 * Альтернатива — печатать каждый слайд отдельным вызовом и потом склеивать
 * PDF-файлы. Склейка требует ещё одной библиотеки и на ней же ломается:
 * встроенные шрифты дублируются в каждом куске, а нумерация страниц
 * начинается заново.
 *
 * Здесь слайды идут подряд, каждый в блоке с break-after: page, и браузер
 * сам делает многостраничный PDF одним вызовом. Размер страницы берётся
 * из @page в slide.css и равен холсту, поэтому масштабировать ничего не надо.
 *
 * === Почему нет перелистывания стрелками ===
 *
 * Выбранный формат выдачи — PDF. Режим показа с клавиатуры это отдельная
 * задача, и делать его «на всякий случай» здесь не нужно: смотреть и править
 * слайды удобнее в Storybook, а клиенту уходит файл.
 */
export default function DeckPage() {
  const params = new URLSearchParams(window.location.search);
  const deck = getDeck(params.get("deck"));

  if (!deck) return <DeckNotFound requested={params.get("deck")} />;

  return (
    <div className="flex flex-col items-center">
      {deck.slides.map((slide, index) => (
        <div key={slide.id} className="slide-print-page">
          {slide.render(index + 1)}
        </div>
      ))}
    </div>
  );
}

/**
 * Экран «дек не найден». Нужен не для красоты: скрипт экспорта запускается
 * без человека, и без явного сообщения пустая страница молча превратилась бы
 * в пустой PDF, который заметили бы уже после отправки клиенту.
 */
function DeckNotFound({ requested }: { requested: string | null }) {
  const available = deckIds();

  return (
    <div className="bg-canvas text-ink flex min-h-screen flex-col gap-6 p-16">
      <h1 className="text-headline-l">Презентация не найдена</h1>

      <p className="text-body-l text-ink-secondary max-w-3xl">
        {requested
          ? `В реестре нет презентации с идентификатором «${requested}».`
          : "В адресе не указан параметр ?deck=<идентификатор>."}
      </p>

      <div className="flex flex-col gap-3">
        <span className="text-title-m">Доступные:</span>
        {available.length ? (
          <ul className="flex flex-col gap-2">
            {available.map((id) => (
              <li key={id}>
                <a className="text-body-l text-accent-fg underline" href={`?deck=${id}`}>
                  {id}
                </a>
              </li>
            ))}
          </ul>
        ) : (
          <span className="text-body-l text-ink-secondary">
            Реестр пуст — добавьте презентацию в src/deck/registry.ts
          </span>
        )}
      </div>
    </div>
  );
}

export type { Deck };
