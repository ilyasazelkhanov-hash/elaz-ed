import { ArrowUp } from "@solar-icons/react";
import { CHART_EMPHASIS, CHART_MUTED, CHART_SERIES } from "../lib/chartPalette";
import { barFill } from "../lib/color";

/**
 * Графики и цифры. StatTiles и GrowthBars перенесены из донорского мобильного проекта
 * (courseProofSections.tsx), BarChart добавлен: на клиентском слайде данные
 * бывают настоящие, и полосок «формы роста» для них мало.
 *
 * === Порядок решений (он же порядок в skill dataviz) ===
 *
 * 1. Сначала форма. Одно число — это НЕ график из одного столбика, а плитка.
 *    Три-четыре заголовочных числа — ряд плиток, а не сгруппированные столбцы.
 * 2. Потом цвет, и по роли: величина → один тон, различение рядов →
 *    категорийный порядок, одна мысль → выделение.
 * 3. Палитра проверяется валидатором, а не глазом. Все цвета здесь уже
 *    прогнаны — см. src/lib/chartPalette.ts
 *
 * === Чего здесь нет ===
 *
 * Двух осей Y. Никогда. Два показателя разного масштаба — это два графика
 * или приведение к общей базе. Двойная ось позволяет нарисовать любой вывод
 * выбором масштабов, и на клиентской презентации это прямой обман.
 */

/* ───────────────  Плитки с числами  ─────────────── */

export interface StatTileItem {
  value: string;
  label: string;
  /** Изменение: «+12 300 за квартал». Без него плитка это просто число */
  delta?: string;
  /**
   * Рост ли это.
   *
   * Отдельный признак, а не вывод из знака: зелёная стрелка вверх у «было
   * 4 часа» врала бы — там время УПАЛО, и это хорошо. Такие подписи
   * нейтральные.
   */
  up?: boolean;
}

export function StatTiles({ items, columns = 2 }: { items: StatTileItem[]; columns?: 2 | 3 | 4 }) {
  const cols = columns === 4 ? "grid-cols-4" : columns === 3 ? "grid-cols-3" : "grid-cols-2";

  return (
    <div className={`grid gap-6 ${cols}`}>
      {items.map((item) => (
        <div key={item.label} className="bg-surface rounded-card p-8">
          <p className="text-display-s text-ink tabular-nums">{item.value}</p>
          <p className="text-body-l text-ink-secondary mt-2">{item.label}</p>

          {/*
           * Цвет и заливка — токены, а не прямые значения. Оба зависят от
           * темы: тёмно-зелёный #1c7430, верный на белом, на тёмной плитке
           * замерен в 2.0:1 — надпись не читалась вовсе.
           */}
          {item.delta ? (
            <span
              className={`text-label rounded-capsule mt-5 inline-flex items-center gap-2 px-4 py-2 ${
                item.up ? "bg-success-fill text-success-fg" : "bg-fill text-ink-secondary"
              }`}
            >
              {item.up ? <ArrowUp size={18} weight="Bold" color="var(--t-success-fg)" /> : null}
              {item.delta}
            </span>
          ) : null}
        </div>
      ))}
    </div>
  );
}

/* ───────────────  Форма роста  ─────────────── */

/**
 * Полоски без осей и подписей. Перенесено из донорского мобильного проекта.
 *
 * Это НЕ график и читать его как график нельзя: высоты заданы в процентах от
 * максимума, а не в значениях. Полоски показывают ФОРМУ — что рост был, — и
 * стоят рядом с крупным числом, которое и есть содержание.
 *
 * Такая честность нужна именно на клиентском слайде: полоски без подписей,
 * выданные за график, — это способ показать динамику, которой может и не быть.
 * Если у чисел есть значения, ставить BarChart, а не это.
 */
export function GrowthBars({
  values,
  highlightLast = 3,
  height = 140,
}: {
  /** Высоты в процентах от максимума, 0–100 */
  values: number[];
  /** Сколько последних полосок выделить акцентом */
  highlightLast?: number;
  height?: number;
}) {
  return (
    <div className="flex items-end gap-2" style={{ height }} aria-hidden="true">
      {values.map((value, i) => (
        <span
          key={i}
          className="flex-1"
          style={{
            height: `${value}%`,
            /* Скругление только сверху: низ полоски прижат к базовой линии,
               и круглый низ отрывал бы её от опоры.

               Радиус берётся токеном, а не числом: полоска здесь — мелкий
               элемент, её ступень в лестнице скруглений это `micro`. Пока
               стояло число 6, оно совпадало с токеном случайно и разошлось бы
               с ним при первой же правке набора */
            borderRadius: "var(--radius-micro) var(--radius-micro) 0 0",
            /* Градиент — только у выделенных полосок. У приглушённых краска
               это var(--t-fill-strong), и barFill возвращает её плоской:
               приглушённое обязано остаться тихим */
            background: barFill(i >= values.length - highlightLast ? CHART_EMPHASIS : CHART_MUTED),
          }}
        />
      ))}
    </div>
  );
}

/* ───────────────  Столбчатый график  ─────────────── */

export interface BarDatum {
  label: string;
  value: number;
  /** Выделить этот столбец. Используется в режиме emphasis */
  highlight?: boolean;
}

/**
 * Столбчатый график с подписями и значениями.
 *
 * === Про режимы цвета ===
 *
 * `emphasis` (по умолчанию) — один столбец в цвете, остальные приглушены.
 * У слайда одна мысль, и обычно она про один столбец. Категорийная раскраска
 * всех столбцов в этом случае хоронит ту единственную величину, ради которой
 * график и сделан.
 *
 * `series` — категорийный порядок, когда столбцы это РАЗНЫЕ СУЩНОСТИ и
 * сравниваются между собой, а не с общим фоном. Максимум пять: шестой цвет
 * не заводится, вместо него «прочее» или второй график.
 *
 * === Про подписи значений ===
 *
 * Значение подписано у КАЖДОГО столбца, и это осознанно: на слайде нет
 * наведения мышью, а сетка с осью занимает место и требует, чтобы её читали.
 * Прямая подпись отвечает на вопрос сразу. Поэтому же здесь нет оси Y —
 * она дублировала бы подписи.
 */
export function BarChart({
  data,
  mode = "emphasis",
  height = 320,
  formatValue = (v: number) => String(v),
}: {
  data: BarDatum[];
  mode?: "emphasis" | "series";
  height?: number;
  formatValue?: (value: number) => string;
}) {
  const max = Math.max(...data.map((d) => d.value), 0) || 1;

  return (
    <div className="flex flex-col gap-5">
      <div className="flex items-end gap-4" style={{ height }}>
        {data.map((d, i) => {
          const color =
            mode === "series"
              ? CHART_SERIES[i % CHART_SERIES.length]
              : d.highlight
                ? CHART_EMPHASIS
                : CHART_MUTED;

          return (
            <div key={d.label} className="flex h-full flex-1 flex-col justify-end gap-4">
              <span className="text-title-m text-ink text-center tabular-nums">
                {formatValue(d.value)}
              </span>
              <span
                style={{
                  height: `${(d.value / max) * 100}%`,
                  /* Скругление токеном, ступень `tile`: столбик крупнее
                     полоски «формы роста», но мельче карточки */
                  borderRadius: "var(--radius-tile) var(--radius-tile) 0 0",
                  /*
                   * Заливка столбца — вертикальный градиент, а не плоская
                   * краска: у донора объём держится ходом
                   * светлоты, и плоские заливки на 1920px выглядят мёртвыми.
                   *
                   * Ход считает barFill: краска остаётся НИЖНИМ стопом,
                   * вверх идёт осветление на 1.8 пункта светлоты. Столбец
                   * растёт снизу вверх, поэтому светлеет он к своей вершине —
                   * то есть к тому концу, который читают. Разбор амплитуды
                   * и замеры — у BAR_RISE в src/lib/color.ts.
                   *
                   * Приглушённые столбцы проходят через ту же функцию и
                   * остаются плоскими: CHART_MUTED это переменная CSS, а не
                   * hex, и сдвинуть её светлоту нечем.
                   */
                  background: barFill(color),
                }}
              />
            </div>
          );
        })}
      </div>

      {/* Базовая линия: тонкая и приглушённая. Она нужна как опора для
          столбцов, но соревноваться с данными не должна */}
      <div className="bg-line" style={{ height: 2 }} />

      <div className="flex gap-4">
        {data.map((d) => (
          <span key={d.label} className="text-body-m text-ink-secondary flex-1 text-center">
            {d.label}
          </span>
        ))}
      </div>
    </div>
  );
}
