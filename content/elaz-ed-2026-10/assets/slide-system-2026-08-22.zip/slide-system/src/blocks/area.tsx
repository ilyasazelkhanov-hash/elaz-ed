import { useEffect, useId, useState } from "react";

import { CHART_SERIES_SCATTER } from "../lib/chartPalette";
import { areaStops } from "../lib/color";

/**
 * График площадей — AreaChart. Два режима: стопка и наложение.
 *
 * === Что эта форма говорит, чего не говорит линия ===
 *
 * Линия отвечает на вопрос «как менялось». Площадь добавляет к нему второй
 * вопрос — «сколько этого всего» — и отвечает на него закрашенной массой.
 * Поэтому у площади есть обязательство, которого у линии нет: масса должна
 * быть пропорциональна величине. Отсюда все ограничения ниже.
 *
 * === Ноль в основании ЖЁСТКИЙ, и это не настройка ===
 *
 * У линии обрезанный низ — приём спорный, у площади — прямая ложь: закрашенная
 * масса перестаёт быть пропорциональной величине, и ряд, который больше
 * соседнего в полтора раза, рисуется втрое жирнее. Поэтому основание шкалы
 * зафиксировано нулём и параметром не открыто. Нужен масштаб с обрезанным
 * низом — это LineChart (blocks/chartsLine.tsx), там низ обрезать тоже нельзя,
 * но там хотя бы нет массы, которая врёт.
 *
 * === Площадь утверждает непрерывность ===
 *
 * Заливка между двумя точками — это утверждение, что между ними величина
 * существовала и менялась плавно. Для месяцев выручки это верно, для
 * «Москва · Питер · Казань» — нет: у категорий нет промежутка, и заливать
 * его нечем. Категории — это столбики (BarChart в blocks/charts.tsx).
 *
 * === Ряда максимум ТРИ ===
 *
 * Краски берутся из CHART_SERIES_SCATTER, а не из CHART_SERIES, и это не
 * экономия. В обоих режимах сравниваются ВСЕ пары рядов, а не только соседние:
 * при наложении площади лежат друг на друге, в стопке любые две полосы можно
 * поставить рядом взглядом. Проверенный набор для режима всех пар состоит из
 * трёх красок — см. разбор в src/lib/chartPalette.ts, где пятёрка проваливает
 * CVD-проверку (#2b7fff↔#ad46ff ΔE 0.7 при дейтеранопии, #a65f00↔#497d00
 * ΔE 3.2 там же). Четвёртому ряду цвет взять неоткуда, поэтому лишние ряды
 * отбрасываются громко.
 *
 * === Чего здесь нет ===
 *
 * **Второй оси Y.** Никогда — как и во всех графиках системы.
 *
 * **Режима «стопка до 100%».** У донора он есть, у нас нет, и по двум
 * причинам. Первая: состав целого в системе уже занят — StackedBar
 * (blocks/chartsParts.tsx) с подписями долей и свёрткой хвоста, а ShareRibbon
 * (blocks/share.tsx) отвечает на вопрос «на скольких первых частях держится
 * целое». Вторая: у стопки до 100% пропадает та самая масса, ради которой
 * форму и берут, — на графике, где сумма всегда 100%, падение всего рынка
 * выглядит ростом доли. На слайде, который смотрят полминуты, это ловушка.
 *
 * **Сглаживания кривой.** Дуга между точками рисует значения, которых
 * в данных нет, и при площади ещё и добавляет к массе несуществующие
 * квадратные пиксели. Ломаная честнее.
 */

/* ═══════════════  Данные и геометрия  ═══════════════ */

export interface AreaSeries {
  key: string;
  label: string;
  /** По одному значению на каждую подпись оси X */
  values: number[];
}

export type AreaMode = "stacked" | "overlap";

interface AreaGeometry {
  width: number;
  height: number;
  padTop: number;
  padBottom: number;
  padLeft: number;
  padRight: number;
}

/**
 * Умолчания те же, что у LineChart, и это намеренно: два графика динамики
 * в одной презентации обязаны выглядеть одной системой — одна высота, одна
 * ось, одно место подписей. Расхождение читается как разные шаблоны.
 *
 * Высота 460 при бюджете блока 604 в ContentSlide оставляет 144px на шапку
 * блока или на ряд плиток над графиком.
 */
const DEFAULT_GEOMETRY: AreaGeometry = {
  width: 1680,
  height: 460,
  padTop: 40,
  /* Место под подписи оси X */
  padBottom: 56,
  /* Место под подписи значений слева */
  padLeft: 130,
  /* Минимум под прямую подпись справа; расширяется по замеру, см. rightPadFor */
  padRight: 200,
};

/** Больше трёх рядов набор красок не выдерживает — см. шапку файла */
const MAX_SERIES = CHART_SERIES_SCATTER.length;

/* ═══════════════  Размеры подписей  ═══════════════ */

/*
 * Значения совпадают с blocks/chartsLine.tsx до пикселя. Файл не импортирует
 * их оттуда, потому что там они не экспортированы, а трогать сданный график
 * динамики ради этого нельзя. Дублирование здесь осознанное и такое же, как
 * у blocks/scatter.tsx, который держит собственную копию замерщика ширины.
 */
const NAME_SIZE = 22;
const NAME_WEIGHT = 600;
const VALUE_SIZE = 18;
const VALUE_WEIGHT = 500;
const AXIS_SIZE = 20;
const AXIS_WEIGHT = 500;

/** Отступ прямой подписи от края графика */
const LABEL_OFFSET = 24;
/** Значение стоит под именем ряда */
const VALUE_DROP = 28;
/** Просвет до края SVG: вплотную к краю подпись читается как обрезанная */
const EDGE_GAP = 8;
/** Бокс подписи относительно якоря — замер на витрине «Динамика» */
const LABEL_ABOVE = 16;
const LABEL_BELOW = 38;
/** Минимальное расстояние между якорями соседних подписей: 54 бокса + 6 просвета */
const LABEL_MIN_GAP = 60;
/** С какого сдвига подписи рисуется выноска */
const LEADER_MIN = 10;
/** Просвет между соседними подписями оси X */
const AXIS_GUTTER = 10;
/** Ширина, от которой считается шаг прореживания подписей оси */
const AXIS_STEP_WIDTH = 92;

/**
 * Толщина линии ряда.
 *
 * Пять, как у LineChart. Линия здесь несёт больше, чем там: в режиме
 * наложения именно она остаётся единственным надёжным носителем ряда там,
 * где площади налезли друг на друга (числа — в разделе про наложение ниже).
 */
const LINE_WIDTH = 5;

/**
 * Множитель непрозрачности площади в режиме НАЛОЖЕНИЯ.
 *
 * === Откуда число ===
 *
 * У донора два рецепта площади, а не один: плотный 0.55 → 0.04 и разрежённый
 * 0.35 → 0. Второй нужен ровно там, где площади лежат друг на друге. В
 * src/lib/color.ts заведён плотный (areaStops), и заводить второй рецепт
 * ради одного режима значило бы разложить одну сущность по двум местам.
 * Поэтому разрежение сделано множителем поверх того же рецепта:
 *
 *   0.55 × 0.6 = 0.33   против донорских 0.35
 *   0.04 × 0.6 = 0.024  против донорских 0
 *
 * То есть донорский второй вариант воспроизведён с точностью до двух сотых,
 * а правило «гаснуть в свой цвет, а не в transparent» осталось нетронутым:
 * цвет по-прежнему один на оба стопа, множитель трогает только непрозрачность.
 *
 * === Почему не подбирали по контрасту ===
 *
 * Потому что подобрать не получается ни при каком множителе, и это надо знать
 * до того, как начнёшь крутить число. Замер линии над ДВУМЯ чужими площадями
 * (худшее по трём рядам и четырём поверхностям, весь ход градиента):
 *
 *   множитель 1.0   1.05:1
 *   множитель 0.6   1.59:1
 *   множитель 0.3   2.18:1
 *   множитель 0.1   2.75:1
 *   заливки нет     3.04:1   ← потолок
 *
 * Потолок 3.04 — это контраст самой краски к тёмной карточке. Порог 3:1 для
 * нетекстовой графики достигается только при заливке, которой фактически нет.
 * Значит выбор не между «проходит» и «не проходит», а между «площадь видно»
 * и «площадь не видно», и число берётся у донора, а не подгоняется.
 * Честная формулировка последствий — в разделе про наложение ниже.
 *
 * === Почему одно число на обе темы ===
 *
 * В chartsLine.tsx у коридора прогноза плотность разная по темам (0.16 и
 * 0.20): там 16% на тёмном давали 1.16:1 против 1.22:1 на светлом, и разрыв
 * пришлось выравнивать. Здесь пересчёт такой разницы не показывает — плотный
 * конец площади при множителе 0.6 против своей поверхности:
 *
 *   светлая 1.48…1.58     тёмная 1.41…1.55
 *
 * Расхождение в пределах разброса между самими красками. Разводить темы
 * незачем, и лишнее определение темы (а это useLayoutEffect и лишний кадр
 * при выгрузке) не заводится.
 */
const OVERLAP_FADE = 0.6;

/* ═══════════════  Замер ширины текста  ═══════════════ */

/*
 * Ширина подписи нужна ДО отрисовки: от неё зависит поле справа и то, какие
 * подписи оси помещаются рядом. Прикидка «знаков × кегль» не годится —
 * разброс ширины знака по замеру от 0.27 до 0.70 кегля.
 */

/** Запасной коэффициент, когда DOM недоступен (сборка вне браузера) */
const FALLBACK_RATIO = 0.62;

const measureCache = new Map<string, number>();
let measureCtx: CanvasRenderingContext2D | null | undefined;

function fontStack() {
  const token = getComputedStyle(document.documentElement).getPropertyValue("--font-app").trim();
  return token || "sans-serif";
}

function textWidth(text: string, size: number, weight: number) {
  const key = `${weight} ${size} ${text}`;
  const cached = measureCache.get(key);
  if (cached !== undefined) return cached;

  if (measureCtx === undefined) {
    measureCtx =
      typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  }

  let width: number;
  if (measureCtx) {
    measureCtx.font = `${weight} ${size}px ${fontStack()}`;
    width = measureCtx.measureText(text).width;
  } else {
    width = text.length * size * FALLBACK_RATIO;
  }

  measureCache.set(key, width);
  return width;
}

let fontsSettled = false;

/**
 * Перерисовка после загрузки шрифта.
 *
 * До загрузки Google Sans `measureText` отвечает по запасному шрифту.
 * Для экрана это неважно — кадров много; выгрузка в PDF снимает РОВНО ОДИН
 * кадр сразу после `document.fonts.ready`, и без пересчёта в него попало бы
 * поле справа, посчитанное по метрикам Arial.
 */
function useRemeasureOnFont() {
  const [, remeasured] = useState(0);

  useEffect(() => {
    if (fontsSettled) return;
    let alive = true;
    void document.fonts?.ready.then(() => {
      if (!alive) return;
      fontsSettled = true;
      measureCache.clear();
      remeasured((n) => n + 1);
    });
    return () => {
      alive = false;
    };
  }, []);
}

/* ═══════════════  Шкала и подписи  ═══════════════ */

/** Красивый шаг сетки: 1, 2 или 5 на нужном порядке */
function niceStep(range: number, targetLines: number) {
  const raw = range / targetLines;
  const magnitude = 10 ** Math.floor(Math.log10(raw));
  const normalized = raw / magnitude;
  const step = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10;
  return step * magnitude;
}

/**
 * Поле справа под самую широкую прямую подпись.
 *
 * Возвращается МАКСИМУМ из заказанного и needed: замер поле только расширяет.
 * Иначе правка ширины поля в деке перестала бы что-либо значить.
 */
function rightPadFor(requested: number, blocks: { name: string; value: string }[]) {
  const widest = blocks.reduce(
    (acc, b) =>
      Math.max(
        acc,
        textWidth(b.name, NAME_SIZE, NAME_WEIGHT),
        textWidth(b.value, VALUE_SIZE, VALUE_WEIGHT),
      ),
    0,
  );
  return Math.max(requested, LABEL_OFFSET + widest + EDGE_GAP);
}

/**
 * Разведение прямых подписей по вертикали.
 *
 * Механика та же, что в chartsLine.tsx: сортировка сверху вниз, расталкивание
 * вниз, затем — если стопка вылезла за нижний край — сдвиг всей стопки вверх
 * и повторное расталкивание сверху. Так подписи не уезжают за холст, где их
 * молча срезал бы `overflow: hidden`.
 *
 * Здесь механизм нужен ЧАЩЕ, чем на линейном графике, и это следствие формы.
 * В стопке подпись хочет стоять посреди своей полосы, а тонкая полоса даёт
 * якорь вплотную к соседнему: два ряда по 3% от суммы разойдутся на 12px при
 * потребных 60. На линейном графике так сходятся только близкие значения,
 * здесь — любые малые доли.
 */
function stackLabels(targets: number[], height: number) {
  const order = targets.map((y, i) => ({ i, y })).sort((a, b) => a.y - b.y);

  for (let k = 1; k < order.length; k++) {
    order[k].y = Math.max(order[k].y, order[k - 1].y + LABEL_MIN_GAP);
  }

  const bottom = order.length ? order[order.length - 1].y + LABEL_BELOW : 0;
  const overflow = bottom - (height - EDGE_GAP);
  if (overflow > 0) {
    for (const o of order) o.y -= overflow;
    for (let k = 0; k < order.length; k++) {
      const floor = k === 0 ? LABEL_ABOVE + EDGE_GAP : order[k - 1].y + LABEL_MIN_GAP;
      order[k].y = Math.max(order[k].y, floor);
    }
  }

  const out = targets.slice();
  for (const o of order) out[o.i] = o.y;
  return out;
}

/**
 * Какие подписи оси X показывать.
 *
 * Прореживание по шагу плюс безусловные первая и последняя: без краёв периода
 * непонятно, чем он начинается и заканчивается. Проход идёт справа налево от
 * последней подписи, каждая следующая влево принимается только если её бокс
 * не достаёт до принятой. Боксы считаются по замеренной ширине и с учётом
 * выключки: у первой якорь слева, у последней справа, у остальных по центру.
 */
function axisIndices(labels: string[], x: (i: number) => number, step: number) {
  const last = labels.length - 1;
  if (last <= 0) return [0];

  const box = (i: number) => {
    const w = textWidth(labels[i], AXIS_SIZE, AXIS_WEIGHT);
    if (i === 0) return { left: x(i), right: x(i) + w };
    if (i === last) return { left: x(i) - w, right: x(i) };
    return { left: x(i) - w / 2, right: x(i) + w / 2 };
  };

  const kept: number[] = [];
  let limit = box(last).left;
  for (let i = Math.floor((last - 1) / step) * step; i >= step; i -= step) {
    const b = box(i);
    if (b.right + AXIS_GUTTER <= limit) {
      kept.push(i);
      limit = b.left;
    }
  }
  kept.reverse();

  const firstRight = box(0).right;
  while (kept.length && firstRight + AXIS_GUTTER > box(kept[0]).left) kept.shift();

  return [0, ...kept, last];
}

/** Выключка подписи оси: края прижаты, середина по центру */
function axisAnchor(i: number, last: number) {
  return i === 0 ? "start" : i === last ? "end" : "middle";
}

/**
 * Выноска от графика к отодвинутой подписи.
 *
 * Ступенькой, а не диагональю: горизонтальные хвосты показывают, откуда
 * и куда. Цветом ряда — это графика, а не текст, и именно цвет здесь
 * называет ряд; само имя ряда набрано `--t-ink`, правило dataviz.md цело.
 */
function Leader({ x, from, to, color }: { x: number; from: number; to: number; color: string }) {
  if (Math.abs(to - from) < LEADER_MIN) return null;
  return (
    <path
      d={`M ${x} ${from} L ${x + 4} ${from} L ${x + 8} ${to} L ${x + 12} ${to}`}
      fill="none"
      stroke={color}
      strokeWidth={2}
    />
  );
}

/* ═══════════════  График  ═══════════════ */

/**
 * График площадей.
 *
 * ═══ Режим «стопка» (mode="stacked") ═══
 *
 * Ряды складываются: каждая полоса стоит на сумме тех, что под ней. Верхняя
 * кромка стопки — это ИТОГ, и он читается точно. Это главное, ради чего берут
 * стопку: одновременно видно и целое, и вклад частей.
 *
 * ⚠️ **Честно про искажение формы.** Прямое основание есть только у НИЖНЕГО
 * ряда — его форму зритель читает верно. Все остальные едут на сумме соседей
 * снизу: провал нижнего ряда выглядит провалом всех верхних. Величина
 * верхних рядов — это ТОЛЩИНА полосы, а глаз меряет не толщину, а
 * вертикальный просвет, и на крутом склоне переоценивает её примерно на
 * 1/cos(наклона). Практический вывод, который стоит применять при вёрстке
 * слайда: **вниз ставится самый крупный и самый ровный ряд**, потому что
 * только его форму никто не исказит.
 *
 * ═══ Режим «наложение» (mode="overlap") ═══
 *
 * Каждый ряд считается от нуля, площади лежат друг на друге и просвечивают.
 * Здесь честна форма КАЖДОГО ряда — у всех прямое основание, — но взамен
 * ряды прячут друг друга.
 *
 * **Порядок отрисовки имеет значение, и вот какое.** Полупрозрачная плёнка
 * не просто закрывает — она подкрашивает всё, что под ней. Ряд, нарисованный
 * последним, показывает свою краску как есть; ряд, оказавшийся под ним,
 * показывает СМЕСЬ. Если бы порядок был произвольным, один и тот же ряд
 * выглядел бы разным цветом в разных местах графика — там, где он торчит
 * из-под соседа, и там, где перекрыт, — и сравнивать цвета стало бы нечем.
 *
 * Поэтому порядок задан правилом, а не порядком в данных: **сначала самый
 * крупный ряд, последним самый мелкий** (сортировка по сумме значений, при
 * равенстве сохраняется порядок в данных). Три следствия:
 *
 *   1. Мелкий ряд не тонет под крупным. При обратном порядке ряд, целиком
 *      лежащий внутри чужой площади, был бы виден только линией.
 *   2. Крупный ряд подкрашен не больше, чем на площади мелкого, — то есть
 *      на малой части своей длины.
 *   3. ЛИНИИ рисуются после ВСЕХ площадей, поэтому ни одна линия не уходит
 *      под чужую плёнку. Носитель ряда остаётся целым при любом раскладе.
 *
 * ⚠️ **Честно про читаемость.** На пересечении линия лежит на чужой площади,
 * и контраст к ней падает: при множителе 0.6 худший случай по трём рядам и
 * четырём поверхностям — 1.59:1 над двумя площадями и 1.99:1 над одной, при
 * реалистичной глубине (обе чужие площади на 40% своего хода) — 2.03…3.40:1.
 * Порог 3:1 (WCAG 1.4.11) в этом режиме недостижим в принципе: даже при
 * нулевой заливке потолок 3.04:1. Что из этого следует практически:
 *
 *   · ряд опознаётся по прямой подписи с выноской, а не только по цвету
 *     под линией — подписи здесь обязательная часть формы, а не украшение;
 *   · если ряды сильно пересекаются и вывод слайда именно в сравнении
 *     величин — брать стопку: там каждая линия отделена собственным
 *     краем и держит 2.90…5.23:1;
 *   · три ряда в наложении — потолок, и он не про цвета, а про плёнки:
 *     каждая следующая гасит все предыдущие.
 *
 * ═══ Что общего у режимов ═══
 *
 * Сетка лежит ПОД площадями и под плотной заливкой пропадает (её контраст
 * к холсту 1.11:1 в светлой теме и 1.40:1 в тёмной). Это не дефект:
 * сетка нужна там, где над площадью пусто, — то есть ровно там, где по ней
 * считывают верхнюю величину.
 */
export function AreaChart({
  series,
  labels,
  mode = "stacked",
  formatValue = (v) => v.toLocaleString("ru-RU"),
  geometry,
}: {
  series: AreaSeries[];
  /** Подписи оси X, по одной на точку */
  labels: string[];
  /** Стопка (виден итог) или наложение (видна форма каждого ряда) */
  mode?: AreaMode;
  formatValue?: (value: number) => string;
  geometry?: Partial<AreaGeometry>;
}) {
  useRemeasureOnFont();
  const uid = useId().replace(/:/g, "");

  const g = { ...DEFAULT_GEOMETRY, ...geometry };

  /*
   * Лишние ряды отбрасываются, а не красятся по кругу: четвёртый ряд цветом
   * первого — это график, который врёт про принадлежность площади. Отброс
   * громкий, см. предупреждение ниже.
   */
  const shown = series.slice(0, MAX_SERIES);

  /* Точек столько, на сколько хватает и подписей, и значений самого короткого ряда */
  const count = shown.reduce((acc, s) => Math.min(acc, s.values.length), labels.length);

  if (import.meta.env.DEV) {
    if (series.length > MAX_SERIES) {
      console.warn(
        `AreaChart: рядов ${series.length}, показаны первые ${MAX_SERIES} ` +
          `(${shown.map((s) => s.label).join(", ")}). На площадях сравниваются все пары ` +
          "красок, и проверенный набор CHART_SERIES_SCATTER состоит из трёх — четвёртому " +
          "взять цвет неоткуда. Сводите ряды в «прочее» либо разбивайте на два графика.",
      );
    }
    for (const s of shown) {
      if (s.values.length !== labels.length) {
        console.warn(
          `AreaChart: у ряда «${s.label}» ${s.values.length} значений при ${labels.length} ` +
            `подписях оси. График обрезан до ${count} точек — иначе площадь была бы ` +
            "нарисована по несуществующим значениям.",
        );
      }
    }
    if (count < 2) {
      console.warn(
        "AreaChart: точек меньше двух. Площади между одной точкой и ничем не существует — " +
          "одно число это плитка (StatTiles в blocks/charts.tsx), а не график.",
      );
    }
  }

  const values = shown.map((s) => s.values.slice(0, count));
  const axisLabels = labels.slice(0, count);

  /* Накопленные суммы: cum[si][i] — сумма рядов 0…si в точке i */
  const cum: number[][] = [];
  values.forEach((vs, si) => {
    cum[si] = vs.map((v, i) => v + (si ? cum[si - 1][i] : 0));
  });

  /*
   * Потолок шкалы. В стопке считается по ИТОГУ, в наложении — по наибольшему
   * ряду: иначе в наложении график занимал бы треть высоты впустую.
   */
  const peak =
    mode === "stacked"
      ? Math.max(0, ...(cum[cum.length - 1] ?? [0]))
      : Math.max(0, ...values.flat());
  const step = niceStep(peak || 1, 4);
  const top = Math.max(step, Math.ceil(peak / step) * step);

  /* Прямые подписи справа: имя ряда и его СОБСТВЕННОЕ последнее значение */
  const lastValue = values.map((vs) => vs[count - 1] ?? 0);
  const padRight = rightPadFor(
    g.padRight,
    shown.map((s, si) => ({ name: s.label, value: formatValue(lastValue[si]) })),
  );

  const plotW = g.width - g.padLeft - padRight;
  const plotH = g.height - g.padTop - g.padBottom;

  /* Знаменатель через max(1, …): при одной точке иначе деление на ноль */
  const x = (i: number) => g.padLeft + (i * plotW) / Math.max(1, count - 1);
  /* Ноль в основании жёсткий — см. шапку файла */
  const y = (v: number) => g.padTop + plotH - (v / top) * plotH;

  const gridValues = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => i * step);

  const labelStep = Math.max(1, Math.ceil(AXIS_STEP_WIDTH / (plotW / Math.max(1, count - 1))));
  const shownAxis = axisIndices(axisLabels, x, labelStep);

  /*
   * Контур площади: вперёд по верхней границе, назад по нижней, замкнуть.
   * Нижняя обходится с КОНЦА — иначе фигура получилась бы «бабочкой»
   * с самопересечением посередине.
   *
   * В наложении нижняя граница — нулевая линия, в стопке — верх соседа снизу.
   */
  const bounds = shown.map((_, si) => {
    const upper = mode === "stacked" ? cum[si] : values[si];
    const lower = mode === "stacked" && si > 0 ? cum[si - 1] : values[si].map(() => 0);
    return { upper, lower };
  });

  const areaPath = (si: number) => {
    const { upper, lower } = bounds[si];
    return [
      ...upper.map((v, i) => `${i ? "L" : "M"} ${x(i)} ${y(v)}`),
      ...lower
        .slice()
        .reverse()
        .map((v, i) => `L ${x(count - 1 - i)} ${y(v)}`),
      "Z",
    ].join(" ");
  };

  /*
   * Ход градиента задаётся в координатах SVG (userSpaceOnUse) и накрывает
   * СВОЮ площадь, а не весь график. Иначе плотный конец достался бы только
   * верхнему ряду, а нижний, каким бы крупным он ни был, вышел бы бледной
   * плёнкой в четыре сотых — то есть плотность заливки говорила бы о месте
   * ряда в стопке, а не о его величине.
   *
   * Вырожденный случай (ряд из одних нулей) даёт нулевую высоту хода;
   * такой градиент браузер рисует непредсказуемо, поэтому низ отодвигается
   * на пиксель. Сама площадь при этом всё равно нулевой высоты и не видна.
   */
  const gradientSpan = (si: number) => {
    const { upper, lower } = bounds[si];
    const y0 = Math.min(...upper.map(y));
    const y1 = Math.max(...lower.map(y));
    return { y0, y1: y1 > y0 ? y1 : y0 + 1 };
  };

  /*
   * Порядок отрисовки площадей: крупные первыми, мелкие последними.
   * Разбор — в описании компонента. Сортировка стабильная (ES2019), поэтому
   * равные по сумме ряды сохраняют порядок из данных.
   *
   * В стопке площади не пересекаются, и порядок ни на что не влияет —
   * рисуем как есть, чтобы отладочная разметка совпадала с данными.
   */
  const total = (si: number) => values[si].reduce((acc, v) => acc + v, 0);
  const drawOrder =
    mode === "overlap"
      ? shown.map((_, si) => si).sort((a, b) => total(b) - total(a))
      : shown.map((_, si) => si);

  /*
   * Куда просится прямая подпись. В наложении — на высоту последнего значения
   * ряда. В стопке — на СЕРЕДИНУ своей полосы: подпись у верхней кромки
   * читалась бы как подпись к итогу, а не к полосе.
   */
  const labelTarget = shown.map((_, si) =>
    mode === "stacked"
      ? (y(bounds[si].upper[count - 1]) + y(bounds[si].lower[count - 1])) / 2
      : y(lastValue[si]),
  );
  const labelY = stackLabels(labelTarget, g.height);

  return (
    <svg width={g.width} height={g.height} viewBox={`0 0 ${g.width} ${g.height}`} role="img">
      <defs>
        {shown.map((s, si) => {
          const span = gradientSpan(si);
          return (
            <linearGradient
              key={s.key}
              id={`area-${uid}-${si}`}
              gradientUnits="userSpaceOnUse"
              x1={0}
              y1={span.y0}
              x2={0}
              y2={span.y1}
            >
              {/*
               * Стопы приходят рецептом из lib/color.ts — того же, что отдаёт
               * areaFill для CSS. Здесь берётся areaStops, потому что в SVG
               * цвет и непрозрачность это два РАЗНЫХ атрибута (stop-color и
               * stop-opacity) и строкой `linear-gradient(...)` их не задать.
               * Источник правды один: areaFill — это cssGradient(areaStops).
               */}
              {areaStops(CHART_SERIES_SCATTER[si]).map((stop) => (
                <stop
                  key={stop.offset}
                  offset={stop.offset}
                  stopColor={stop.color}
                  stopOpacity={stop.opacity}
                />
              ))}
            </linearGradient>
          );
        })}
      </defs>

      {/* Сетка. Приглушённая: она опора, а не содержание */}
      {gridValues.map((v) => (
        <g key={v}>
          <line
            x1={g.padLeft}
            x2={g.padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={2}
          />
          <text
            x={g.padLeft - 24}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {formatValue(v)}
          </text>
        </g>
      ))}

      {/* Площади. Порядок отрисовки — см. drawOrder */}
      {drawOrder.map((si) => (
        <path
          key={shown[si].key}
          d={areaPath(si)}
          fill={`url(#area-${uid}-${si})`}
          opacity={mode === "overlap" ? OVERLAP_FADE : 1}
        />
      ))}

      {/* Линии — ПОСЛЕ всех площадей, чтобы ни одна не ушла под чужую плёнку */}
      {shown.map((s, si) => (
        <path
          key={s.key}
          d={bounds[si].upper.map((v, i) => `${i ? "L" : "M"} ${x(i)} ${y(v)}`).join(" ")}
          fill="none"
          stroke={CHART_SERIES_SCATTER[si]}
          strokeWidth={LINE_WIDTH}
          strokeLinejoin="round"
        />
      ))}

      {/* Якорь последнего значения, выноска и прямая подпись */}
      {shown.map((s, si) => {
        const color = CHART_SERIES_SCATTER[si];
        const px = x(count - 1);
        /*
         * Якорь подписи — там же, где её цель: на последнем значении ряда
         * в наложении и на середине полосы в стопке. Совпадение обязательно,
         * иначе выноска тянулась бы из точки, которой подпись не соответствует.
         *
         * Точка рисуется только в наложении. В стопке она встала бы на верхнюю
         * кромку полосы, то есть на НАКОПЛЕННУЮ сумму, а подпись рядом называет
         * собственное значение ряда — точка утверждала бы, что подписано именно
         * это место. Ставить её в середину полосы тоже нельзя: заливка там того
         * же цвета, и точка даёт к ней 1.61…2.27:1 — пятно вместо якоря. В стопке
         * подпись привязана к полосе самой полосой, она упирается в её край.
         */
        const py = labelTarget[si];
        const ly = labelY[si];

        return (
          <g key={s.key}>
            {mode === "overlap" ? <circle cx={px} cy={py} r={9} fill={color} /> : null}
            <Leader from={py} to={ly} x={px + 11} color={color} />
            {/*
             * Прямая подпись у конца ряда вместо легенды-коробки: имя стоит
             * там же, где сам ряд, и переводить взгляд на список цветов
             * не нужно. В наложении подпись несёт двойную нагрузку — см.
             * предупреждение о контрасте линии над чужой площадью.
             */}
            <text
              x={px + LABEL_OFFSET}
              y={ly}
              dominantBaseline="middle"
              fill="var(--t-ink)"
              style={{ fontSize: NAME_SIZE, fontWeight: NAME_WEIGHT }}
            >
              {s.label}
            </text>
            <text
              x={px + LABEL_OFFSET}
              y={ly + VALUE_DROP}
              dominantBaseline="middle"
              fill="var(--t-ink-secondary)"
              style={{ fontSize: VALUE_SIZE, fontWeight: VALUE_WEIGHT }}
            >
              {formatValue(lastValue[si])}
            </text>
          </g>
        );
      })}

      {/* Подписи оси X. Какие именно — считает axisIndices */}
      {shownAxis.map((i) => (
        <text
          key={i}
          x={x(i)}
          y={g.padTop + plotH + 36}
          textAnchor={axisAnchor(i, count - 1)}
          fill="var(--t-ink-secondary)"
          style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
        >
          {axisLabels[i]}
        </text>
      ))}
    </svg>
  );
}
