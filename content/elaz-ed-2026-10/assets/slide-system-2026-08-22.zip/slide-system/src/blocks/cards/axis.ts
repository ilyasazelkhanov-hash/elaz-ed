import { useEffect, useState } from "react";

/**
 * Оси, подписи и кривые карточек-дашборда.
 *
 * Общая часть для всех семи карточек волны: замерщик ширины текста, кегли
 * подписей, шаг оси Y, прореживание оси X, монотонная кривая. Вынесено
 * отдельно от `lineCard.tsx` сразу, а не «когда понадобится второй раз»:
 * карточки волны обязаны совпадать по осям до пикселя, иначе две соседние
 * на одном слайде прочитаются как два разных шаблона.
 *
 * ⚠️ Кегли донора переносить НЕЛЬЗЯ. У него ось Y набрана 12px, ось X —
 * 13px. Умножение на масштаб (×2.5) дало бы 30 и 33 — размеров, которых
 * в шкале проекта нет, а `fontSize` вне шкалы запрещён. Подписи взяты
 * кеглями системы.
 *
 * Числа, а не Tailwind-классы, потому что это SVG: у `<text>` утилита
 * кегля не работает, и от этих же чисел считается геометрия жёлоба и
 * прореживание. Значения РАВНЫ токенам шкалы.
 */

/* ═══════════════  Кегли подписей  ═══════════════ */

/** Подпись оси: `--text-body-m` 20/28, вес 500, трекинг −0.4 (−2% кегля) */
export const AXIS_SIZE = 20;
export const AXIS_WEIGHT = 500;
export const AXIS_TRACKING = -0.4;

/** Подпись точки-маркера: `--text-title-m` 26/32, вес 500, трекинг −0.52 */
export const MARK_SIZE = 26;
export const MARK_WEIGHT = 500;
export const MARK_TRACKING = -0.52;

/* ═══════════════  Бокс строки: замер, а не кегль  ═══════════════ */

/*
 * ⚠️ Поля вокруг поля построения нельзя считать «по кеглю». Бокс строки
 * ВЫШЕ кегля: у Google Sans 20/500 он 25 точек, и распределён вокруг
 * якоря несимметрично — по-разному для каждой опорной линии.
 *
 * Замер в 1:1, витрина «Карточки/Линия → Карточка», строка
 * «$6K Jan Дек 1 284 950 ₽», трекинг −0.4:
 *
 *   опора        верх бокса   низ бокса   высота
 *   middle 20      y − 14.40    y + 10.60    25.00
 *   hanging 20     y −  3.90    y + 21.10    25.00
 *   auto 26        y − 25.00    y +  7.50    32.50
 *
 * Отсюда три числа ниже. До замера поля стояли «по кеглю» (AXIS_SIZE/2 и
 * AXIS_SIZE), и обе оси вылезали за кадр: верхний тик срезался сверху на
 * 2.40, каждая подпись месяца свисала за нижний край на 1.10. SVG обрезает
 * по своему viewport молча — на экране это выглядело просто «шрифт такой».
 */

/** Подъём строки над якорем при `dominant-baseline: middle`. Замер 14.40 */
export const AXIS_HALF_BOX = 15;
/** Свес строки под якорь при `dominant-baseline: hanging`. Замер 21.10 */
export const AXIS_HANG_BOTTOM = 22;
/** Подъём строки маркера над якорем при опоре по умолчанию. Замер 25.00 */
export const MARK_ASCENT = 25;

/** Просвет между подписью оси Y и левым краем поля построения */
export const Y_GAP = 16;
/** Просвет между низом поля построения и строкой подписей оси X */
export const X_GAP = 14;
/** Минимальный чистый просвет между соседними подписями оси X */
export const X_GUTTER = 12;
/** Просвет между точкой-маркером и её подписью */
export const MARK_GAP = 14;

/* ═══════════════  Замер ширины текста  ═══════════════ */

/*
 * === Зачем мерить, а не прикидывать по числу знаков ===
 *
 * От ширины подписи зависят две вещи: жёлоб слева (иначе «1 500 000 ₽»
 * уедет за левый край SVG) и то, какие подписи оси X помещаются рядом.
 * Прикидка «знаков × кегль» здесь не работает: замер в
 * `blocks/chartsLine.tsx` дал разброс от 0.27 до 0.70 ширины кегля на
 * знак — в два с половиной раза.
 *
 * ⚠️ === Почему НЕ `canvas.measureText`, как в остальных графиках ===
 *
 * Соседние блоки системы (`chartsLine.tsx`, `area.tsx`, `scatter.tsx`)
 * мерят строку холстом. Здесь это ДАЁТ НЕВЕРНОЕ ЧИСЛО, и вот почему:
 * подписи оси набраны моноширинными цифрами (`font-variant-numeric:
 * tabular-nums`) — колонка чисел справа от графика обязана стоять ровно.
 * У контекста холста такого свойства нет вовсе: `ctx.font` принимает
 * только сокращённую запись шрифта, а `font-variant-numeric` в неё не
 * входит. Холст поэтому мерит ПРОПОРЦИОНАЛЬНЫМИ цифрами, которые у
 * узких знаков — «1», «.», «−» — заметно уже моноширинных.
 *
 * Замер расхождения (Google Sans 20/500, трекинг −0.4), витрина
 * «Карточки/Линия»: «$1.5K» вышел за левый край SVG на 5.13, «−2.5K» —
 * на 1.67, «10K» — на 2.20, «2.5K» и «7.5K» — на 2.52. Подписи без узких
 * знаков («$6K», «$2K») не разошлись вовсе. То есть ошибка не случайная,
 * а ровно на разнице ширин цифр.
 *
 * Скрытый узел DOM меряет ТО ЖЕ, что рисуется: тот же шрифт, тот же вес,
 * тот же трекинг, то же начертание цифр. Цена — узел в документе и
 * принудительный пересчёт вёрстки на каждую НОВУЮ строку; повторные
 * берутся из кэша, а строк на карточке два десятка.
 */

/** Запасной коэффициент, когда DOM недоступен (сборка вне браузера) */
const FALLBACK_RATIO = 0.62;

const measureCache = new Map<string, number>();
let ruler: HTMLSpanElement | null | undefined;

function getRuler() {
  if (ruler !== undefined) return ruler;
  if (typeof document === "undefined") {
    ruler = null;
    return ruler;
  }
  const el = document.createElement("span");
  /*
   * `position: absolute` + `visibility: hidden` — узел не участвует в
   * потоке и не виден, но вёрстка для него считается, а значит ширина
   * настоящая. `white-space: pre` держит пробелы: в «1 500 000 ₽» они
   * значащие, и схлопывание дало бы заниженное число.
   */
  el.style.cssText =
    "position:absolute;left:-9999px;top:-9999px;visibility:hidden;white-space:pre;pointer-events:none";
  el.setAttribute("aria-hidden", "true");
  document.body.appendChild(el);
  ruler = el;
  return ruler;
}

/**
 * Ширина строки тем же шрифтом, весом, трекингом и начертанием цифр,
 * какими она будет нарисована.
 */
export function cardTextWidth(
  text: string,
  size: number,
  weight: number,
  tracking = 0,
  tabular = true,
) {
  const key = `${weight} ${size} ${tracking} ${tabular ? "t" : "p"} ${text}`;
  const cached = measureCache.get(key);
  if (cached !== undefined) return cached;

  const el = getRuler();
  let width: number;
  if (el) {
    el.style.fontFamily = "var(--font-app)";
    el.style.fontSize = `${size}px`;
    el.style.fontWeight = String(weight);
    el.style.letterSpacing = `${tracking}px`;
    el.style.fontVariantNumeric = tabular ? "tabular-nums" : "normal";
    el.textContent = text;
    width = el.getBoundingClientRect().width;
  } else {
    width = text.length * size * FALLBACK_RATIO;
  }

  measureCache.set(key, width);
  return width;
}

/**
 * Ширина подписи оси.
 *
 * Моноширинные цифры включены ВСЕГДА — и у оси Y, где числа стоят
 * колонкой, и у оси X, где они могут быть («W52», «Неделя 12»). Обе оси
 * и РИСУЮТСЯ моноширинными: замер обязан мерить ровно то, что рисуется,
 * иначе возвращается ровно та ошибка, ради которой замерщик переписан
 * с холста на DOM.
 */
export const axisTextWidth = (text: string) =>
  cardTextWidth(text, AXIS_SIZE, AXIS_WEIGHT, AXIS_TRACKING);

/** Дождались ли мы загрузки шрифта хотя бы раз за жизнь страницы */
let fontsSettled = false;

/**
 * Перерисовка после того, как догрузился шрифт.
 *
 * До загрузки Google Sans `measureText` отвечает по ЗАПАСНОМУ шрифту, и
 * числа получаются чужие. Для экрана это не страшно — кадров много, — но
 * выгрузка в PDF снимает РОВНО ОДИН кадр, сразу после `document.fonts.ready`
 * (`scripts/export-pdf.ts`). Без пересчёта в этот единственный кадр попал бы
 * жёлоб, посчитанный по метрикам запасного шрифта.
 *
 * Ожидание безусловное, а не по `document.fonts.status`: статус бывает
 * «loaded» и до того, как шрифт вообще запрошен, — файл грузится лениво.
 */
export function useRemeasureOnFont() {
  const [, remeasured] = useState(0);

  useEffect(() => {
    if (fontsSettled) return;
    let alive = true;
    void document.fonts?.ready.then(() => {
      if (!alive) return;
      fontsSettled = true;
      /* Кэш мог собраться по запасному шрифту — он больше не верен */
      measureCache.clear();
      remeasured((n) => n + 1);
    });
    return () => {
      alive = false;
    };
  }, []);
}

/* ═══════════════  Ось Y: шаг считается, а не задаётся  ═══════════════ */

/** Гасит хвост двоичной арифметики: 0.1 + 0.2 на оси даёт 0.30000000000000004 */
export const tidy = (v: number) => Math.round(v * 1e9) / 1e9;

/** Округление «человеческого» шага: 1 · 2 · 2.5 · 5 · 10 своего порядка */
function niceStep(raw: number) {
  if (!(raw > 0)) return 1;
  const power = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / power;
  const m = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
  return m * power;
}

/**
 * Тики оси Y.
 *
 * === Три равных шага, а не «донорский верхний тик» ===
 *
 * Донор при Yearly рисует `$0 / $35K / $70K / $91K`: три равных шага плюс
 * четвёртый, пришпиленный к максимуму домена. Мы так не делаем.
 *
 * Причина в том, что ось с неравными шагами — это ось с переменным
 * масштабом на вид: расстояние между $70K и $91K вчетверо меньше
 * смыслового шага, и глаз, привыкший к первым трём промежуткам, прочитает
 * высоту точки неверно. На клиентском слайде эта цена несопоставимо больше,
 * чем ровный верхний тик.
 *
 * Наш шаг: `niceStep((max − min) / 3)`, домен растягивается до кратных шага.
 * На донорских данных Weekly (максимум 5200) это даёт РОВНО донорские тики
 * `0 / 2000 / 4000 / 6000`: 5200/3 = 1733 → шаг 2000 → верх
 * ceil(5200/2000)·2000 = 6000.
 *
 * === Ноль в домене жёстко ===
 *
 * У площади масса обязана быть пропорциональна величине, иначе ряд, который
 * больше соседнего в полтора раза, рисуется втрое жирнее. Домен всегда
 * включает ноль — обрезанного низа у этой формы не бывает. То же правило и
 * по той же причине держит `blocks/area.tsx`.
 */
export function cardAxisTicks(values: readonly number[], steps = 3) {
  const finite = values.filter((v) => Number.isFinite(v));
  const lo = Math.min(0, ...finite);
  const hi = Math.max(0, ...finite);

  /* Все значения нулевые: домен схлопнулся бы в точку и шкала дала бы NaN */
  if (hi === lo) return { ticks: [0, 1], min: 0, max: 1, step: 1 };

  const step = niceStep((hi - lo) / steps);
  const min = tidy(Math.floor(lo / step) * step);
  const max = tidy(Math.ceil(hi / step) * step);

  const ticks: number[] = [];
  for (let v = min; v <= max + step * 1e-9; v += step) ticks.push(tidy(v));

  return { ticks, min, max, step };
}

/**
 * Подпись тика по умолчанию: «6K» вместо «6000».
 *
 * Донор пишет «$6K». Знак валюты сюда не зашит — он свойство данных, а не
 * формы: у слайда про посещаемость его быть не должно. Слайд передаёт свой
 * `formatTick`, пример есть в историях.
 */
export function defaultTick(v: number) {
  const a = Math.abs(v);
  if (a >= 1_000_000) return `${tidy(v / 1_000_000)}M`;
  if (a >= 1000) return `${tidy(v / 1000)}K`;
  return String(tidy(v));
}

/* ═══════════════  Ось X: прореживание по замеру  ═══════════════ */

/**
 * Какие подписи оси X помещаются, не сталкиваясь.
 *
 * Жадный проход слева, но ПОСЛЕДНЯЯ подпись забронирована: без брони
 * жадность роняет именно её (она приходит последней и почти всегда
 * упирается в предыдущую), а последняя точка на графике динамики — та,
 * ради которой график и смотрят.
 */
export function cardAxisKeep(labels: readonly string[], xs: readonly number[], gutter = X_GUTTER) {
  const n = labels.length;
  if (n === 0) return new Set<number>();
  if (n === 1) return new Set<number>([0]);

  const half = labels.map((l) => axisTextWidth(l) / 2);
  const keep = new Set<number>([n - 1]);
  const lastLeft = xs[n - 1] - half[n - 1];

  let cursor = -Infinity;
  for (let i = 0; i < n - 1; i++) {
    const left = xs[i] - half[i];
    const right = xs[i] + half[i];
    if (left >= cursor + gutter && right + gutter <= lastLeft) {
      keep.add(i);
      cursor = right;
    }
  }
  return keep;
}

/**
 * Куда и как поставить подпись, чтобы она не вышла за края SVG.
 *
 * Подпись центрована по своей точке. У первой и последней точки половина
 * строки уходит за границу кадра — там якорь переставляется на край.
 * Без этого горизонтальная проверка переполнения (порог 4px) сработает
 * уже на выгрузке.
 */
export function clampLabel(x: number, halfWidth: number, width: number) {
  if (x - halfWidth < 0) return { x: 0, anchor: "start" as const };
  if (x + halfWidth > width) return { x: width, anchor: "end" as const };
  return { x, anchor: "middle" as const };
}

/* ═══════════════  Кривая  ═══════════════ */

export interface Pt {
  x: number;
  y: number;
}

/**
 * Монотонная кубическая интерполяция (Фрич — Карлсон).
 *
 * === Почему именно она, а не Catmull-Rom ===
 *
 * Обычный сглаживающий сплайн ПЕРЕЛЕТАЕТ через опорные точки: после
 * резкого подъёма он заворачивает выше самой высокой точки, после спада —
 * ниже самой низкой. На графике выручки это значит нарисовать месяц,
 * которого в данных нет, а у площади ещё и увести кромку ниже нуля, то
 * есть закрасить отрицательную массу.
 *
 * Монотонная схема гарантирует, что между двумя соседними точками кривая
 * не выходит за их значения, и даёт горизонтальную касательную в
 * экстремуме — ровно то, что разведка увидела в путях донора
 * («кубические сегменты C с горизонтальными касательными в экстремумах»).
 *
 * Сглаживание всё равно остаётся УТВЕРЖДЕНИЕМ, что между точками величина
 * менялась плавно. Для месяцев выручки это правда, для «Москва · Питер ·
 * Казань» — нет. Для таких данных у донора есть `shape="sharp"`.
 */
export function monotonePath(pts: readonly Pt[]) {
  const n = pts.length;
  if (n === 0) return "";
  if (n === 1) return `M ${pts[0].x} ${pts[0].y}`;

  const dx: number[] = [];
  const slope: number[] = [];
  for (let i = 0; i < n - 1; i++) {
    dx[i] = pts[i + 1].x - pts[i].x;
    slope[i] = dx[i] === 0 ? 0 : (pts[i + 1].y - pts[i].y) / dx[i];
  }

  const t: number[] = new Array(n);
  t[0] = slope[0];
  t[n - 1] = slope[n - 2];
  for (let i = 1; i < n - 1; i++) {
    if (slope[i - 1] * slope[i] <= 0) {
      /* Экстремум: касательная горизонтальна, кривая не перелетает */
      t[i] = 0;
    } else {
      const w1 = 2 * dx[i] + dx[i - 1];
      const w2 = dx[i] + 2 * dx[i - 1];
      t[i] = (w1 + w2) / (w1 / slope[i - 1] + w2 / slope[i]);
    }
  }

  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3;
    d += ` C ${pts[i].x + h} ${pts[i].y + t[i] * h} ${pts[i + 1].x - h} ${pts[i + 1].y - t[i + 1] * h} ${pts[i + 1].x} ${pts[i + 1].y}`;
  }
  return d;
}

/** Ломаная: промежуточные значения читать как интерполяцию нельзя */
export function polyPath(pts: readonly Pt[]) {
  return pts.map((p, i) => `${i ? "L" : "M"} ${p.x} ${p.y}`).join(" ");
}
