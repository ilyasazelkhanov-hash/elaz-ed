import { useId } from "react";

import { BOARD_CHART, BOARD_SERIES, BOARD_SERIES_ACTIVE } from "../../lib/boardPalette";
import type { SlideTheme } from "../../slide/Slide";
import {
  AXIS_HALF_BOX,
  AXIS_HANG_BOTTOM,
  AXIS_SIZE,
  AXIS_TRACKING,
  AXIS_WEIGHT,
  MARK_ASCENT,
  MARK_GAP,
  MARK_SIZE,
  MARK_TRACKING,
  MARK_WEIGHT,
  X_GAP,
  Y_GAP,
  axisTextWidth,
  cardAxisKeep,
  cardAxisTicks,
  cardTextWidth,
  clampLabel,
  defaultTick,
  monotonePath,
  polyPath,
  useRemeasureOnFont,
  type Pt,
} from "./axis";
import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
} from "./shell";

/**
 * Карточка «Линия» — перенос донорского линейного графика целиком.
 *
 * Спецификация замеров донора — во внутреннем разборе. Обвязка —
 * `./shell.tsx`, общие оси и кривые — `./axis.ts`. Здесь только середина:
 * поле построения, площадь, линия, точка-маркер.
 *
 *   ┌─ CardShell ───────────────────────────────────────────────┐
 *   │  Revenue                        Weekly  Monthly  Yearly   │  ← шапка shell
 *   │  $18 240  [+9,4%]                                         │
 *   │                                                           │
 *   │  $6K                                          ╭─╮         │  ← LineChart
 *   │  $4K              ╭──╮        ╭───╮      ╭────╯ ╰──╮      │
 *   │  $2K   ╭───╮ ╭────╯  ╰────────╯   ╰──────╯        ╰──     │
 *   │   $0 ──╯   ╰─╯▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓▓     │
 *   │       Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec     │
 *   └───────────────────────────────────────────────────────────┘
 *
 * Легенды нет, и это не упущение: ряд один, называет его подпись в шапке.
 * Поэтому `cardChartHeight` вызывается с `legend: false`, и графику
 * достаётся 408 точек вместо 284 — поле получается 1507×354 вместо
 * донорских 494×187, то есть 4.26:1 против 2.64:1.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ЦВЕТ. Решение заказчика, а не недосмотр — читать целиком
 * ═══════════════════════════════════════════════════════════════════
 *
 * Краски донорские: линия `#7ccf00` (lime-500, chart-2-active), площадь —
 * градиент от `#9ae600` (lime-400, chart-2) при непрозрачности 0.35 в
 * прозрачный вариант ТОГО ЖЕ цвета. Системная `CHART_SERIES` не берётся
 * намеренно: заказчик видел замеры ниже и просит «как на скриншотах».
 *
 * Замер (функция `contrast` из lib/color.ts; для площади — композит краски
 * с фоном карточки по её же непрозрачности). Порог WCAG 1.4.11 для
 * нетекстовой графики — 3:1:
 *
 *   что                             светлая #ffffff   тёмная #262626
 *   линия #7ccf00 к карточке              1.95 ✗           7.77 ✓
 *   верх площади (α 0.35) к карточке      1.18 ✗           2.43 ✗
 *   середина площади (α 0.175)            1.09 ✗           1.53 ✗
 *   линия к верху своей площади           1.65 ✗           3.20 ✓
 *
 * В СВЕТЛОЙ теме линия порог не берёт: 1.95 против 3. На проекторе с
 * засветкой салатовая линия на белом будет едва различима. В тёмной теме
 * запас четырёхкратный. Вывод, который надо доносить до клиента: карточка
 * рассчитана на ТЁМНУЮ тему, светлая — компромисс, принятый сознательно.
 *
 * Что из этого следует для вёрстки, и это уже не вкусовое:
 *
 *   1. Величину несёт не цвет, а ЧИСЛО. Крупное число в шапке и подписи
 *      оси обязательны — они и есть содержание. Убрать ось нельзя.
 *   2. У линии есть толщина, посчитанная от ширины поля (`LINE_RATIO`):
 *      форма читается силуэтом даже там, где цвет не читается.
 *   3. Точка-маркер получает кольцо цветом фона карточки. Кольцо — не
 *      украшение: контраст линии к своей же площади в светлой теме 1.65,
 *      то есть цветом точка от площади не отделяется, отделяет её прорезь.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ТЕКСТ НА ГРАДИЕНТЕ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Подпись маркера может попасть на площадь. Мерено НЕ формулой, а по
 * РЕАЛЬНЫМ ПИКСЕЛЯМ: карточка растеризована вместе с градиентом, дальше
 * взяты 7 позиций по длине × 3 по высоте (сразу под линией, середина
 * площади, у нулевой) и посчитан контраст к каждой роли текста.
 *
 *   тема    роль        худший   лучший   порог 4.5 для кегля 26
 *   светлая ink          17.38    19.79   ✓ везде
 *   светлая secondary     4.75     5.41   ✓ везде
 *   светлая tertiary      3.33     3.79   ✗ везде
 *   тёмная  ink           7.36    14.33   ✓ везде
 *   тёмная  secondary     3.05     5.93   ✗ 5 замеров из 21
 *   тёмная  tertiary      1.87     3.63   ✗ везде
 *
 * Отсюда жёсткое правило файла: **подпись маркера набирается `--t-ink`**.
 * Вторичным нельзя — в тёмной теме прямо под линией он падает до 3.05 при
 * пороге 4.5. Замер в ОДНОЙ точке этого бы не показал: у нулевой тот же
 * вторичный даёт 5.93 и выглядит благополучно. Мерить надо вдоль всего
 * хода градиента, а не там, где удобно.
 *
 * Подписи осей на градиент не попадают ВООБЩЕ, и это тоже проверено, а не
 * предположено: пересечение бокса каждой подписи с габаритом площади
 * посчитано на всех историях, включая отрицательные значения, — ноль
 * пересечений. Под ними чистая карточка, и вторичный там законен:
 * замер по пикселям даёт 5.41 в светлой теме и 6.00 в тёмной.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Чего из донора здесь нет
 * ═══════════════════════════════════════════════════════════════════
 *
 * **Раскрытия линии маской.** У донора линия появляется слева направо
 * через `clipPath` с растущей шириной. Разведка отдельно отметила, что до
 * конца анимации карточка выглядит ПУСТОЙ. В PDF кадр один, и попасть он
 * может в любой момент, — маски здесь нет вовсе.
 *
 * **Пульсирующей точки.** SMIL-анимация радиуса 5→13 и непрозрачности
 * 0.35→0. В одном кадре это либо жирное пятно, либо ничего.
 *
 * **Ореола вокруг точки.** Даже зафиксированный числами (r5, opacity 0.3)
 * он даёт 1.22:1 к светлой карточке и 1.92:1 к тёмной — это не акцент,
 * а грязь по краю точки. Осталось ядро с кольцом.
 *
 * **Наведения.** У донора по курсору подпись шапки становится названием
 * месяца, а число — значением точки. На слайде курсора нет, поэтому то же
 * печатается статически: `marker` ставит точку и подпись у неё.
 *
 * **Сегмент-контрола как органа управления.** Weekly/Monthly/Yearly
 * рисуется рядом слов без дорожки и бегунка — это подпись выбранного
 * периода, а не три кнопки. Механика в `./shell.tsx`.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface LinePoint {
  /** Подпись оси X: «Jan», «Q1», «Неделя 12» */
  label: string;
  /** Значение. Отрицательные допустимы — площадь тогда уходит ПОД нулевую линию */
  value: number;
}

/** Имя серии в донорской восьмёрке. По умолчанию салат — как на скриншоте */
export type LineSeries = keyof typeof BOARD_CHART;

/* ═══════════════  Геометрия: доли донора, а не его пиксели  ═══════════════ */

/*
 * Донор снят при поле построения 494×187 внутри SVG 544×221. У нас поле
 * втрое шире, поэтому переносятся ДОЛИ. Абсолютные числа донора при
 * переносе дали бы волосок вместо линии — разведка это отдельно отметила.
 */

/**
 * Толщина линии как доля ширины ПОЛЯ ПОСТРОЕНИЯ.
 *
 * Донор: 2.5 при поле 494 → 0.506%. При нашем поле 1507 (карточка во всю
 * ширину) это 7.6 → 8 по потолку ниже; при поле 707 (половина ширины) —
 * 3.6, и там срабатывает пол.
 */
const LINE_RATIO = 2.5 / 494;

/**
 * Пол и потолок толщины.
 *
 * Пол 5 — толщина линии в `blocks/chartsLine.tsx` и `blocks/area.tsx`.
 * Тоньше в системе линий нет, и половинная карточка не должна выбиваться
 * из общего вида: на проекторе 3.6px — это волосок.
 *
 * Потолок 8 — за ним монотонная кривая начинает съедать собственные
 * экстремумы: при радиусе изгиба, сравнимом с толщиной, пик срезается.
 */
const LINE_MIN = 5;
const LINE_MAX = 8;

/**
 * Радиус точки как доля ВСЕЙ высоты графика. Донор: r5 при SVG 221 → 2.26%.
 *
 * Доля берётся от полной высоты, а не от поля построения, намеренно: поле
 * сверху зависит от радиуса точки (под ней стоит подпись), а радиус — от
 * высоты поля. Замкнутый круг разрывается тем, что радиус считается раньше
 * полей, от числа, которое полями не зависит.
 */
const DOT_RATIO = 5 / 221;
/** Кольцо-просвет цветом фона: у донора 3 при r5 — три пятых радиуса */
const RING_RATIO = 3 / 5;

/**
 * Непрозрачность верхнего стопа площади. Донорская, не подобранная.
 *
 * Нижний стоп — тот же цвет при непрозрачности 0. Ключевое слово
 * `transparent` здесь запрещено: в CSS и SVG оно означает прозрачный
 * ЧЁРНЫЙ, и по нижней кромке площади пошла бы грязь (правило ui-craft.md).
 */
const AREA_TOP_OPACITY = 0.35;

/* ═══════════════  График  ═══════════════ */

export interface LineChartProps {
  points: readonly LinePoint[];
  /** Размеры поля. Считаются от карточки через `cardChartWidth` / `cardChartHeight` */
  width: number;
  height: number;
  /** `smooth` — монотонная кривая (донор), `sharp` — ломаная */
  shape?: "smooth" | "sharp";
  /** Серия донорской восьмёрки */
  series?: LineSeries;
  /** Подпись тика оси Y */
  formatTick?: (value: number) => string;
  /** Точка с напечатанной подписью — замена наведению у донора */
  marker?: { index: number; label: string };
}

export function LineChart({
  points,
  width,
  height,
  shape = "smooth",
  series = "lime",
  formatTick = defaultTick,
  marker,
}: LineChartProps) {
  useRemeasureOnFont();
  const uid = useId().replace(/:/g, "");

  const fill = BOARD_SERIES[BOARD_CHART[series]];
  const stroke = BOARD_SERIES_ACTIVE[BOARD_CHART[series]];

  const axis = cardAxisTicks(points.map((p) => p.value));
  const tickLabels = axis.ticks.map(formatTick);

  /*
   * Жёлоб слева — по САМОЙ ШИРОКОЙ подписи тика, а не по прикидке. Иначе
   * «1 250K» на карточке в половину ширины уедет за левый край SVG, и
   * поймается это уже в PDF.
   */
  const padLeft = Math.ceil(Math.max(0, ...tickLabels.map(axisTextWidth)) + Y_GAP);

  /*
   * Поле справа — половина последней подписи оси X: она центрована по своей
   * точке, а последняя точка стоит на правом краю поля построения.
   */
  const lastLabel = points.length ? points[points.length - 1].label : "";
  const padRight = Math.ceil(Math.max(2, axisTextWidth(lastLabel) / 2));

  /*
   * Строка подписей оси X. Свес бокса под якорь ЗАМЕРЕН (21.10 при опоре
   * `hanging`), а не взят равным кеглю: по кеглю каждая подпись месяца
   * свисала за нижний край SVG на 1.10 и молча срезалась.
   */
  const padBottom = Math.ceil(X_GAP + AXIS_HANG_BOTTOM);

  /*
   * Радиус точки — от полной высоты, поэтому считается ДО полей: под точкой
   * стоит подпись, и место под неё входит в поле сверху.
   */
  const dotR = Math.max(6, Math.round(height * DOT_RATIO));
  const ringW = Math.max(2, Math.round(dotR * RING_RATIO));

  /*
   * Поле сверху. Без маркера — подъём бокса верхнего тика (замер 14.40).
   * С маркером — точка целиком, просвет и подъём её подписи (замер 25.00).
   */
  const padTop = Math.ceil(
    Math.max(AXIS_HALF_BOX, marker ? dotR + ringW / 2 + MARK_GAP + MARK_ASCENT : 0),
  );

  const plotW = Math.max(1, width - padLeft - padRight);
  const plotH = Math.max(1, height - padTop - padBottom);

  const lineWidth = Math.min(LINE_MAX, Math.max(LINE_MIN, Math.round(plotW * LINE_RATIO)));

  const n = points.length;
  const x = (i: number) => (n < 2 ? padLeft + plotW / 2 : padLeft + (plotW * i) / (n - 1));
  const y = (v: number) => padTop + plotH - ((v - axis.min) / (axis.max - axis.min)) * plotH;

  const pts: Pt[] = points.map((p, i) => ({ x: x(i), y: y(p.value) }));
  const linePath = shape === "smooth" ? monotonePath(pts) : polyPath(pts);

  /* Площадь — тот же путь, замкнутый по НУЛЕВОЙ линии, а не по низу поля */
  const zeroY = y(0);
  const areaPath = n ? `${linePath} L ${pts[n - 1].x} ${zeroY} L ${pts[0].x} ${zeroY} Z` : "";

  const keep = cardAxisKeep(
    points.map((p) => p.label),
    pts.map((p) => p.x),
  );

  const mark =
    marker && marker.index >= 0 && marker.index < n
      ? {
          pt: pts[marker.index],
          label: marker.label,
          ...clampLabel(
            pts[marker.index].x,
            cardTextWidth(marker.label, MARK_SIZE, MARK_WEIGHT, MARK_TRACKING) / 2,
            width,
          ),
        }
      : null;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} role="img">
      <defs>
        {/*
         * Градиент площади. Единицы по умолчанию (`objectBoundingBox`) —
         * как у донора: верхний стоп привязан к САМОЙ ВЫСОКОЙ точке
         * площади, а не к верху поля. Благодаря этому пик всегда получает
         * одну и ту же плотность 0.35, и две карточки рядом с разными
         * масштабами выглядят одинаково насыщенно.
         *
         * Затухание — `stopOpacity` при НЕИЗМЕННОМ `stopColor`. Гасить в
         * `transparent` запрещено: это прозрачный чёрный, и по кромке
         * пошла бы грязь.
         */}
        <linearGradient id={`line-card-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={fill} stopOpacity={AREA_TOP_OPACITY} />
          <stop offset="1" stopColor={fill} stopOpacity={0} />
        </linearGradient>
      </defs>

      {/* Подписи оси Y. Сетки нет — у донора её тоже нет, опора здесь одна: числа */}
      {axis.ticks.map((v, i) => (
        <text
          key={v}
          x={padLeft - Y_GAP}
          y={y(v)}
          textAnchor="end"
          dominantBaseline="middle"
          fill="var(--t-ink-secondary)"
          style={{
            fontSize: AXIS_SIZE,
            fontWeight: AXIS_WEIGHT,
            letterSpacing: AXIS_TRACKING,
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {tickLabels[i]}
        </text>
      ))}

      {/*
       * Нулевая линия. У донора её нет, у нас есть, и вот зачем: нижняя
       * кромка площади прозрачна по построению (нижний стоп — 0), поэтому
       * без волосяной линии основание массы не видно вовсе и площадь
       * выглядит висящей. Цвет `--t-line` — та же роль, что у разделителей.
       */}
      <line
        x1={padLeft}
        x2={padLeft + plotW}
        y1={zeroY}
        y2={zeroY}
        stroke="var(--t-line)"
        strokeWidth={2}
      />

      {areaPath ? <path d={areaPath} fill={`url(#line-card-${uid})`} /> : null}

      {linePath ? (
        <path
          d={linePath}
          fill="none"
          stroke={stroke}
          strokeWidth={lineWidth}
          /*
           * Скругление стыков, а не донорский `miter`. При толщине 7–8
           * острый стык на изломе ломаной даёт клык длиной с саму толщину;
           * у донора при 2.5 это было незаметно.
           */
          strokeLinejoin="round"
          strokeLinecap="round"
        />
      ) : null}

      {/* Подписи оси X. Прорежены по замеру; крайние прижаты к краям SVG */}
      {points.map((p, i) => {
        if (!keep.has(i)) return null;
        const at = clampLabel(pts[i].x, axisTextWidth(p.label) / 2, width);
        return (
          <text
            key={`${p.label}-${i}`}
            x={at.x}
            y={padTop + plotH + X_GAP}
            textAnchor={at.anchor}
            dominantBaseline="hanging"
            fill="var(--t-ink-secondary)"
            style={{
              fontSize: AXIS_SIZE,
              fontWeight: AXIS_WEIGHT,
              letterSpacing: AXIS_TRACKING,
              /* Моноширинные и здесь: замерщик мерит именно так, см. axis.ts */
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {p.label}
          </text>
        );
      })}

      {mark ? (
        <>
          {/*
           * Ядро точки с кольцом цветом фона карточки. Кольцо вырезает
           * точку из площади: контраст линии к площади 1.65:1 в светлой
           * теме, то есть цветом точка от неё не отделяется.
           */}
          <circle
            cx={mark.pt.x}
            cy={mark.pt.y}
            r={dotR}
            fill={stroke}
            stroke="var(--t-surface)"
            strokeWidth={ringW}
          />
          {/* Подпись — `--t-ink`. Вторичным нельзя: замер на градиенте в шапке файла */}
          <text
            x={mark.x}
            y={mark.pt.y - dotR - ringW / 2 - MARK_GAP}
            textAnchor={mark.anchor}
            fill="var(--t-ink)"
            style={{
              fontSize: MARK_SIZE,
              fontWeight: MARK_WEIGHT,
              letterSpacing: MARK_TRACKING,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {mark.label}
          </text>
        </>
      ) : null}
    </svg>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface LineCardProps {
  /** Подпись серии в шапке: «Revenue» */
  label: string;
  /** Крупное число: «$18 240» */
  value: string;
  /** Плашка изменения: «+9,4%» */
  delta?: CardDelta;
  /** Подпись периода. Сегменты — ряд слов, а не переключатель */
  period?: CardPeriod;
  points: readonly LinePoint[];
  shape?: "smooth" | "sharp";
  series?: LineSeries;
  formatTick?: (value: number) => string;
  marker?: { index: number; label: string };
  /** Ширина КАРТОЧКИ. 1680 — вся рабочая ширина, 828 — половина */
  width?: number;
  /** Высота карточки. По умолчанию весь бюджет блока — 604 */
  height?: number;
  size?: CardShellSize;
  valueSize?: CardValueSize;
  /** Вложенная тема: светлая карточка на тёмном слайде и наоборот */
  theme?: SlideTheme;
  className?: string;
}

export default function LineCard({
  label,
  value,
  delta,
  period,
  points,
  shape,
  series,
  formatTick,
  marker,
  width = 1680,
  height = CARD_BUDGET,
  size = "full",
  valueSize = "m",
  theme,
  className,
}: LineCardProps) {
  /*
   * Размеры поля СЧИТАЮТСЯ обвязкой, а не задаются на глаз. Слот в карточке
   * `flex-1 min-h-0`: график выше слота карточку не растянет, а обрежется,
   * и в PDF обрезанное просто исчезнет.
   *
   * `legend: false` — у этой карточки легенды нет и быть не может: ряд
   * один, называет его подпись в шапке.
   */
  const chartW = cardChartWidth(width, size);
  const chartH = cardChartHeight({ height, size, valueSize, legend: false });

  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      period={period}
      size={size}
      height={height}
      theme={theme}
      className={className}
      style={{ width }}
    >
      <LineChart
        points={points}
        width={chartW}
        height={chartH}
        shape={shape}
        series={series}
        formatTick={formatTick}
        marker={marker}
      />
    </CardShell>
  );
}
