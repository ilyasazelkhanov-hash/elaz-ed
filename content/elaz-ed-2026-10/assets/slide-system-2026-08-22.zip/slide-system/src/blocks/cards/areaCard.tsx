import { useId } from "react";

import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
  type LegendTile,
} from "./shell";
import {
  AXIS_SIZE,
  AXIS_TRACKING,
  AXIS_WEIGHT,
  X_GAP,
  Y_GAP,
  axisTextWidth,
  cardAxisKeep,
  cardAxisTicks,
  clampLabel,
  defaultTick,
  monotonePath,
  polyPath,
  tidy,
  useRemeasureOnFont,
  type Pt,
} from "./axis";
import { BOARD_CHART, BOARD_SERIES, BOARD_SERIES_ACTIVE } from "../../lib/boardPalette";
import { areaStops } from "../../lib/color";
import type { SlideTheme } from "../../slide/Slide";

/**
 * Карточка «площадь» — перенос донорского площадного графика.
 *
 * Заказчик прислал скриншот и попросил сделать из него блок. Переносится
 * КАРТОЧКА ЦЕЛИКОМ: шапка «Visitors / 94 700 / +8,2%», подпись периода
 * справа, три стековые площади со сглаженной кромкой и градиентной заливкой,
 * пунктирная сетка (три-четыре линии), подписи оси слева, месяцы снизу, ряд
 * плиток легенды. Оболочка живёт в `./shell.tsx`, оси и кривая — в
 * `./axis.ts`; здесь только то, что стоит в слоте графика, и сборка целого.
 *
 *   ┌─ CardShell ────────────────────────────────────────────────┐
 *   │  Visitors                                    ▤ This year   │
 *   │  94 700  [+8,2%]                                           │
 *   │  13,5K ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╱▔▔▔▔▔▔  ← Paid  │
 *   │    9K  ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄╱▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔      Referral │
 *   │  4,5K  ┄┄┄┄┄┄╱▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔▔   Organic │
 *   │     0  ┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄┄ │
 *   │        Jan  Feb  Mar  …                              Dec   │
 *   │  ▪ Organic     ▪ Referral    ▪ Paid                        │
 *   │  50 500        25 900        18 300                        │
 *   └────────────────────────────────────────────────────────────┘
 *
 * ══════════ Что НЕ перенесено ══════════
 *
 * Наведение с вертикальным курсором, подмена числа в шапке на итог наведённой
 * категории, счётчик числа (`number-fade`), раскрытие графика маской
 * (`chart-reveal`, 1.8s), приглушение чужих плиток. В PDF нет ни курсора, ни
 * кадров — остаётся ОДИН кадр, и всё, что у донора появлялось по наведению,
 * обязано быть напечатано. Итоги рядов стоят в плитках легенды, общий итог —
 * в шапке; ровно это у донора переживает `prefers-reduced-motion`. Теряется
 * единственное — «наведи, чтобы увидеть месяц»: на слайде мысль формулирует
 * заголовок, а не всплывающая подсказка.
 *
 * Переключатель периода перенесён ПОДПИСЬЮ, а не органом управления — разбор
 * в шапке `shell.tsx`.
 *
 * ══════════ Кривая: здесь сплайн, и это расхождение с blocks/area.tsx ══════════
 *
 * Слайдовый график площадей (`src/blocks/area.tsx`) сглаживание запрещает:
 * «дуга между точками рисует значения, которых в данных нет». Довод верный,
 * и он не отменён — сужена область его действия.
 *
 * Здесь сглаживание есть, по трём причинам:
 *
 *   1. Заказчик просил карточку как на скриншоте, а сглаженная кромка — самая
 *      заметная её черта: донор рисует `type="monotone"`, это видно на глаз
 *      на каждом перегибе.
 *   2. Кривая МОНОТОННАЯ (Фрич — Карлсон, `monotonePath` в `./axis.ts`), а не
 *      обычный сплайн. Разница принципиальная: монотонная схема по
 *      построению не выносит кривую за значения соседних точек — между 2400
 *      и 2600 не будет ни 2700, ни 2350, а в экстремуме касательная
 *      горизонтальна. Обычный Catmull-Rom на всплеске перелетает и рисует
 *      пик, которого в данных нет. То есть отменён не запрет «не рисовать
 *      несуществующее», а способ его нарушить.
 *   3. Остаточное искажение — масса. Дуга добавляет к площади квадратные
 *      точки, которых в данных нет: на выпуклом участке чуть больше, на
 *      вогнутом чуть меньше. Цена названа: ЕСЛИ слайд про величину массы,
 *      а не про форму, брать `AreaChart` из `blocks/area.tsx` с ломаной.
 *      Здесь для этого есть `shape="sharp"` — ровно как у донора.
 *
 * Порог уместности тот же, что у донора: точек должно быть много (12
 * месяцев) и они должны быть равномерны по оси. На четырёх точках сплайн
 * рисует уже «дизайн», а не данные — там `shape="sharp"`.
 *
 * ══════════ ⚠️ Цвет: решение заказчика и его цена в числах ══════════
 *
 * Краски донорские, без правок: Organic — lime `#9ae600`, Referral — синий
 * `#3392ff`, Paid — purple `#c27aff`; обводки на ступень глубже (`#7ccf00`,
 * `#2b7fff`, `#ad46ff`). Разбор решения — в шапке `lib/boardPalette.ts`.
 *
 * Что это стоит ИМЕННО ЗДЕСЬ. Порог WCAG 1.4.11 для нетекстовой графики —
 * 3:1. Мерено дважды: арифметикой по каналам и ЧТЕНИЕМ ПИКСЕЛЕЙ отрисованной
 * карточки (SVG переведён в canvas, точки взяты на самой кромке в пяти местах
 * по длине — 8 · 30 · 50 · 72 · 95% пути). Ниже пиксельные числа: они
 * учитывают, что плотность заливки меняется вдоль графика, а арифметика по
 * одному стопу — нет.
 *
 * ЗАЛИВКА (донорский рецепт 0.55 → 0.04 поверх `fill-opacity` 0.6, то есть
 * фактические 0.330 · 0.254 · 0.177 · 0.101 · 0.024 сверху вниз по полосе):
 *
 *   светлая карточка #ffffff     тёмная карточка #262626
 *   lime    1.17 … 1.01          lime    2.29 … 1.06
 *   blue    1.43 … 1.03          blue    1.66 … 1.03
 *   purple  1.37 … 1.02          purple  1.75 … 1.04
 *
 * Ни одна заливка порога не берёт нигде, и это не дефект переноса: площадь
 * такой плотности — подложка, а не носитель. Носитель — ОБВОДКА:
 *
 *   кромка полосы     к карточке   к тому, что НАД ней   к своей заливке
 *   светлая тема
 *   lime   #7ccf00      1.95 ✗       1.62 … 1.83 ✗        1.70 … 1.82
 *   blue   #2b7fff      3.76 ✓       3.06 … 3.58 ✓        2.73 … 3.48
 *   purple #ad46ff      4.12 ✓       4.12 ✓               3.21 … 3.89
 *   тёмная тема
 *   lime   #7ccf00      7.77 ✓       6.13 … 7.31 ✓        3.84 … 5.72
 *   blue   #2b7fff      4.02 ✓       2.84 … 3.69          2.66 … 3.65
 *   purple #ad46ff      3.67 ✓       3.67 ✓               2.38 … 3.41
 *
 * Читать таблицу так. Второй столбец — единственный, который отвечает за
 * РАЗДЕЛЕНИЕ полос: над кромкой лежит хвост соседа сверху. Третий столбец —
 * граница ВНУТРИ одной полосы, её читать не нужно, и просадка до 2.38 там
 * ничего не стоит (по обе стороны один и тот же ряд). Разброс в обоих
 * столбцах — это ход вдоль длины: справа, где значения на пике, полоса выше и
 * заливка плотнее, поэтому контраст к ней ниже.
 *
 * Граница двух полос, если бы обводки не было вовсе: 1.14 и 1.40 в светлой
 * теме, 2.22 и 1.60 в тёмной. Отсюда два вывода, записанные в код, а не в
 * память:
 *
 *   · обводка обязательна и свойством не открыта — без неё стопка
 *     разваливается в одно пятно;
 *   · ⚠️ В СВЕТЛОЙ ТЕМЕ САЛАТОВАЯ ПОЛОСА ПОРОГ НЕ БЕРЁТ НИГДЕ: 1.62…1.95 при
 *     пороге 3. На проекторе с засветкой нижняя полоса будет читаться только
 *     по плитке легенды. Лечения в рамках «цвета как на скриншоте» нет:
 *     тёмная тема даёт той же кромке 6.13…7.77. Карточка едет на показ —
 *     `theme="dark"`.
 *
 * Подписи осей набраны `--t-ink-secondary` (5.41:1 в светлой теме, 6.00:1 в
 * тёмной) и лежат ВНЕ поля построения — слева от него и под ним, — поэтому
 * ни в одной точке не попадают на градиент. Третичный цвет здесь запрещён
 * дважды: кегль 20 мельче 24, и третичный светлый даёт всего 3.79:1.
 *
 * ══════════ Геометрия ══════════
 *
 * Донор: карточка 576, поле построения 494×162, ось слева 44, кегли 12 и 13,
 * обводка 2, сетка 1px пунктиром 4/4, отступ сверху 4.
 *
 * Переносятся ДОЛИ, а не пиксели — так же, как в `lineCard.tsx`. Кегли не
 * масштабируются вовсе: донорские 12–13 ниже пола шкалы (16), подписи взяты
 * кеглем системы (`AXIS_SIZE` 20 из `./axis.ts`) и одинаковы у всех карточек
 * волны — иначе две соседние карточки читаются как два разных шаблона.
 */

/* ═══════════════  Числа формы  ═══════════════ */

/**
 * Толщина обводки как доля ширины ПОЛЯ построения. Донор: 2 при поле 494.
 *
 * Пол и потолок — те же, что у линии в `lineCard.tsx`, и по тем же причинам:
 * 5 — толщина линии во всей системе (`blocks/chartsLine.tsx`, `blocks/area.tsx`),
 * тоньше на проекторе волосок; 8 — предел, за которым кривая начинает съедать
 * собственные экстремумы. При поле 1507 доля даёт 6, при 707 — срабатывает пол.
 */
const STROKE_RATIO = 2 / 494;
const STROKE_MIN = 5;
const STROKE_MAX = 8;

/** Пунктир сетки. Донор: 4/4 при поле 494 — та же доля, с полом и потолком */
const DASH_RATIO = 4 / 494;
const DASH_MIN = 6;
const DASH_MAX = 12;
/** Толщина линии сетки: донорский 1px при карточке 576 — это 2 при нашей 1680 */
const GRID_WIDTH = 2;

/**
 * Множитель непрозрачности заливки поверх рецепта `areaStops`.
 *
 * Донор ставит на путь `fill-opacity` 0.6 сверх градиента 0.55 → 0.04. Тот же
 * приём и то же число, что у `OVERLAP_FADE` в `blocks/area.tsx`: рецепт
 * площади в системе один (`lib/color.ts`), разрежение делается множителем,
 * а не вторым рецептом.
 */
const FILL_FADE = 0.6;

/**
 * Потолок числа рядов.
 *
 * Донор показывает три. Шесть — предел из `slide-anatomy.md` («список длиннее
 * 6 пунктов не ставить»), он же предел легенды: седьмая плитка на половинной
 * карточке получает 100 точек ширины и обрезает подпись. Лишние ряды
 * отбрасываются громко, а не красятся по кругу: два ряда одной краской —
 * это график, который врёт про принадлежность площади.
 */
const MAX_SERIES = 6;

/**
 * Порядок красок по умолчанию.
 *
 * Первые три — донорские именно для этой карточки: Organic `chart-2`,
 * Referral `chart-6`, Paid `chart-5`. Дальше краски, разведённые по тону,
 * но честно: ⚠️ на дальтонизм проверялась только системная палитра
 * (`chartPalette.ts`); донорская восьмёрка на CVD НЕ прогонялась. Поэтому за
 * четвёртым рядом смысл держит плитка легенды, а не цвет.
 */
const DEFAULT_ORDER = [
  BOARD_CHART.lime,
  BOARD_CHART.blue,
  BOARD_CHART.purple,
  BOARD_CHART.pink,
  BOARD_CHART.teal,
  BOARD_CHART.yellow,
] as const;

/**
 * Ниже этой высоты поля линии сетки встают чаще, чем через 30 точек.
 *
 * ⚠️ Линий не всегда четыре. Правило оси волны (`cardAxisTicks`) округляет
 * ШАГ вверх до 1 · 2 · 2,5 · 5, поэтому иногда трёх шагов не нужно: пик 355
 * даёт шаг 200 и всего три линии (0 / 200 / 400). Донорские четыре — частый
 * случай, а не гарантия, и код нигде на их число не опирается.
 */
const MIN_PLOT_HEIGHT = 120;

/* ═══════════════  Данные  ═══════════════ */

export interface AreaCardSeries {
  key: string;
  /** Название ряда — оно же подпись плитки легенды */
  label: string;
  /** По одному значению на каждую подпись оси X */
  values: readonly number[];
  /** Заливка. По умолчанию донорский порядок lime → blue → purple */
  color?: string;
  /** Обводка. По умолчанию та же краска ступенью глубже (`BOARD_SERIES_ACTIVE`) */
  stroke?: string;
  /** Значение в плитке легенды. По умолчанию сумма ряда через `formatLegend` */
  legendValue?: string;
}

/** Заливка и обводка ряда: своё, если задано, иначе донорский порядок */
function paint(series: AreaCardSeries, index: number) {
  const slot = DEFAULT_ORDER[index % DEFAULT_ORDER.length];
  return {
    fill: series.color ?? BOARD_SERIES[slot],
    stroke: series.stroke ?? BOARD_SERIES_ACTIVE[slot],
  };
}

/**
 * Замкнутый контур полосы: вперёд по верхней кромке, назад по нижней.
 *
 * ⚠️ Обратный проход считается ТЕМ ЖЕ `monotonePath` по перевёрнутому набору
 * точек, а не отдельным сглаживанием. При равномерном шаге по X монотонная
 * схема даёт в обе стороны одну и ту же кривую (касательные в узлах
 * симметричны, контрольные точки сегмента меняются местами), поэтому нижняя
 * кромка полосы ложится ровно на обводку соседа снизу. Отдельное сглаживание
 * разошлось бы с ней на доли точки, и при выгрузке 3840×2160 вдоль всей
 * кривой пошла бы светлая нитка.
 *
 * Начальное `M` обратного прохода заменяется на `L`: контур должен спуститься
 * от конца верхней кромки к концу нижней одной линией, а `M` начал бы новый
 * подпуть и разорвал заливку.
 */
function bandPath(upper: readonly Pt[], lower: readonly Pt[], smooth: boolean) {
  if (upper.length < 2) return "";
  const curve = smooth ? monotonePath : polyPath;
  const back = curve([...lower].reverse());
  return `${curve(upper)} ${back.replace(/^M/, "L")} Z`;
}

/* ═══════════════  Поле построения  ═══════════════ */

export interface AreaCardPlotProps {
  series: readonly AreaCardSeries[];
  /** Подписи оси X, по одной на точку */
  labels: readonly string[];
  /** Размеры поля. Считаются `cardChartWidth` / `cardChartHeight`, а не подбираются */
  width: number;
  height: number;
  /** `smooth` — монотонная кривая (донор), `sharp` — ломаная */
  shape?: "smooth" | "sharp";
  /** Потолок шкалы. Не задан — считается по правилу оси волны (`cardAxisTicks`) */
  axisTop?: number;
  /** Подпись деления оси Y */
  formatTick?: (value: number) => string;
}

/**
 * Стопка площадей: сетка, две оси, заливки, обводки.
 *
 * Вынесена отдельным экспортом ровно за одним: её можно поставить в слот
 * `CardShell` вручную, когда шапка собирается не из свойств `AreaCard`.
 *
 * ⚠️ Ноль в основании жёсткий и свойством не открыт. У линии обрезанный низ —
 * приём спорный, у площади — прямая ложь: закрашенная масса перестаёт быть
 * пропорциональной величине. Тот же запрет и по той же причине стоит в
 * `blocks/area.tsx` и в `cardAxisTicks`.
 *
 * ⚠️ Стопка искажает форму всех рядов, кроме нижнего: у него одного прямое
 * основание, остальные едут на сумме соседей снизу, и провал нижнего ряда
 * выглядит провалом всех верхних. Практический вывод при вёрстке слайда:
 * ВНИЗ СТАВИТСЯ САМЫЙ КРУПНЫЙ И САМЫЙ РОВНЫЙ РЯД. На скриншоте донора внизу
 * стоит Organic — самый крупный из трёх, и это не совпадение.
 */
export function AreaCardPlot({
  series,
  labels,
  width,
  height,
  shape = "smooth",
  axisTop,
  formatTick = defaultTick,
}: AreaCardPlotProps) {
  useRemeasureOnFont();
  const uid = useId().replace(/:/g, "");

  const shown = series.slice(0, MAX_SERIES);
  const count = shown.reduce((acc, s) => Math.min(acc, s.values.length), labels.length);

  /* Подрезка нулём: отрицательный вклад в стопке нарисовать нечем */
  const values = shown.map((s) => s.values.slice(0, count).map((v) => Math.max(0, v)));
  const axisLabels = labels.slice(0, count).map(String);

  /* Накопленные суммы: cum[si][i] — сумма рядов 0…si в точке i */
  const cum: number[][] = [];
  values.forEach((vs, si) => {
    cum[si] = vs.map((v, i) => v + (si ? cum[si - 1][i] : 0));
  });
  const totals = cum[cum.length - 1] ?? [];

  if (import.meta.env.DEV) {
    if (series.length > MAX_SERIES) {
      console.warn(
        `AreaCard: рядов ${series.length}, показаны первые ${MAX_SERIES}. Донор рисует три; ` +
          "шесть — потолок легенды и правила «список длиннее 6 пунктов не ставить». " +
          "Сводите хвост в «прочее» либо разбивайте на две карточки.",
      );
    }
    for (const s of shown) {
      if (s.values.length !== labels.length) {
        console.warn(
          `AreaCard: у ряда «${s.label}» ${s.values.length} значений при ${labels.length} ` +
            `подписях оси. График обрезан до ${count} точек — иначе площадь была бы ` +
            "нарисована по несуществующим значениям.",
        );
      }
      if (s.values.some((v) => v < 0)) {
        console.warn(
          `AreaCard: у ряда «${s.label}» есть отрицательные значения. Стопка складывает ряды ` +
            "снизу вверх, и отрицательный вклад нарисовать нечем — значения подрезаны нулём. " +
            "Для убыли берите столбики.",
        );
      }
    }
    if (count < 2) {
      console.warn(
        "AreaCard: точек меньше двух. Площади между одной точкой и ничем не существует — " +
          "одно число это плитка, а не график.",
      );
    }
  }

  /*
   * Ось. Своего округления здесь нет — правило одно на все карточки волны
   * (`cardAxisTicks`: три равных шага, ноль в домене, шаг 1 · 2 · 2.5 · 5).
   *
   * ⚠️ Донорские подписи 0 / 4.5K / 9K / 13.5K этим правилом НЕ получаются:
   * у донора верхний тик пришпилен к максимуму данных (13 500), а наше
   * правило даёт шаг 5000 и потолок 15 000. Расхождение сознательное — ось
   * с «красивым» шагом читается точнее, чем ось, у которой верхний
   * промежуток короче остальных. Кому нужен ровно донорский вид (или общая
   * шкала у двух карточек рядом) — свойство `axisTop`.
   */
  const forced = axisTop && axisTop > 0;
  const axis = forced
    ? { ticks: [0, 1, 2, 3].map((i) => tidy((axisTop * i) / 3)), min: 0, max: axisTop }
    : cardAxisTicks(totals);
  const tickLabels = axis.ticks.map(formatTick);

  /* Жёлоб слева — по САМОЙ ШИРОКОЙ подписи тика, иначе «1 250K» уедет за край SVG */
  const padLeft = Math.ceil(Math.max(0, ...tickLabels.map(axisTextWidth)) + Y_GAP);
  /* Справа — половина последней подписи оси X: она центрована по своей точке */
  const lastLabel = axisLabels.length ? axisLabels[axisLabels.length - 1] : "";
  const padRight = Math.ceil(Math.max(2, axisTextWidth(lastLabel) / 2));
  /* Строка подписей оси X: просвет плюс кегль (подпись висит от верха строки) */
  const padBottom = Math.ceil(X_GAP + AXIS_SIZE);
  /* Сверху — половина строки верхнего тика: её бокс поднимается над линией сетки */
  const padTop = Math.ceil(AXIS_SIZE / 2 + 2);

  const plotW = Math.max(1, width - padLeft - padRight);
  const plotH = Math.max(1, height - padTop - padBottom);

  if (import.meta.env.DEV && plotH < MIN_PLOT_HEIGHT) {
    console.warn(
      `AreaCard: полю построения осталось ${Math.round(plotH)} точек по высоте. Ниже ` +
        `${MIN_PLOT_HEIGHT} линии сетки встают чаще, чем через 30 точек, и пунктир ` +
        "читается как штриховка. Убирайте легенду или увеличивайте высоту карточки.",
    );
  }

  const strokeWidth = Math.min(STROKE_MAX, Math.max(STROKE_MIN, Math.round(plotW * STROKE_RATIO)));
  const dash = Math.min(DASH_MAX, Math.max(DASH_MIN, Math.round(plotW * DASH_RATIO)));

  /* Знаменатель через max(1, …): при одной точке иначе деление на ноль */
  const x = (i: number) =>
    count < 2 ? padLeft + plotW / 2 : padLeft + (plotW * i) / Math.max(1, count - 1);
  const y = (v: number) => padTop + plotH - ((v - axis.min) / (axis.max - axis.min)) * plotH;

  /* Границы полосы: сверху своя накопленная сумма, снизу — сумма соседа */
  const bands = shown.map((_, si) => ({
    upper: cum[si].map((v, i) => ({ x: x(i), y: y(v) })),
    lower: (si > 0 ? cum[si - 1] : cum[si].map(() => 0)).map((v, i) => ({ x: x(i), y: y(v) })),
  }));

  const keep = cardAxisKeep(
    axisLabels,
    Array.from({ length: count }, (_, i) => x(i)),
  );
  const smooth = shape === "smooth";

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} role="img">
      <defs>
        {shown.map((s, si) => (
          /*
           * Единицы по умолчанию (`objectBoundingBox`) — как у донора: ход
           * градиента накрывает СВОЮ полосу, а не всё поле. Иначе плотный
           * конец достался бы только верхней полосе, а нижняя, какой бы
           * крупной ни была, вышла бы плёнкой в четыре сотых — плотность
           * заливки говорила бы о месте ряда в стопке, а не о его величине.
           *
           * Рецепт стопов приходит из `lib/color.ts` — тот же, что у площади
           * под линией: 0.55 сверху, 0.04 снизу, цвет ОДИН на оба стопа.
           * Гасить в `transparent` запрещено — это прозрачный чёрный, и по
           * кромке пошла бы грязь (`ui-craft.md`).
           */
          <linearGradient key={s.key} id={`area-card-${uid}-${si}`} x1="0" y1="0" x2="0" y2="1">
            {areaStops(paint(s, si).fill).map((stop) => (
              <stop
                key={stop.offset}
                offset={stop.offset}
                stopColor={stop.color}
                stopOpacity={stop.opacity}
              />
            ))}
          </linearGradient>
        ))}
      </defs>

      {/*
       * Сетка лежит ПОД площадями и под ними почти пропадает: замер даёт
       * 1.09…1.19 к соседней заливке. Это не дефект — сетка нужна там, где
       * над стопкой пусто, то есть ровно там, где по ней считывают итог.
       */}
      {axis.ticks.map((v, i) => (
        <g key={v}>
          <line
            x1={padLeft}
            x2={padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={GRID_WIDTH}
            strokeDasharray={`${dash} ${dash}`}
          />
          <text
            x={padLeft - Y_GAP}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{
              fontSize: AXIS_SIZE,
              fontWeight: AXIS_WEIGHT,
              letterSpacing: AXIS_TRACKING,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {tickLabels[i]}
          </text>
        </g>
      ))}

      {/* Сначала ВСЕ заливки */}
      {shown.map((s, si) => (
        <path
          key={s.key}
          d={bandPath(bands[si].upper, bands[si].lower, smooth)}
          fill={`url(#area-card-${uid}-${si})`}
          opacity={FILL_FADE}
        />
      ))}

      {/*
       * Потом ВСЕ обводки. Порядок важен: заливка полосы доходит до кромки
       * соседа снизу и наполовину закрыла бы его обводку, если бы каждая
       * полоса рисовалась целиком. Донор рисует парами «заливка + обводка»,
       * и на его 2px это незаметно; на наших 5–6 — заметно.
       */}
      {shown.map((s, si) =>
        bands[si].upper.length < 2 ? null : (
          <path
            key={s.key}
            d={smooth ? monotonePath(bands[si].upper) : polyPath(bands[si].upper)}
            fill="none"
            stroke={paint(s, si).stroke}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        ),
      )}

      {/* Подписи оси X. Прорежены по замеру; крайние прижаты к краям SVG */}
      {axisLabels.map((label, i) => {
        if (!keep.has(i)) return null;
        const at = clampLabel(x(i), axisTextWidth(label) / 2, width);
        return (
          <text
            key={`${label}-${i}`}
            x={at.x}
            y={padTop + plotH + X_GAP}
            textAnchor={at.anchor}
            dominantBaseline="hanging"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT, letterSpacing: AXIS_TRACKING }}
          >
            {label}
          </text>
        );
      })}
    </svg>
  );
}

/* ═══════════════  Карточка целиком  ═══════════════ */

export interface AreaCardProps {
  /** Подпись серии сверху слева: «Visitors» */
  label: string;
  /** Крупное число в шапке. Не задано — сумма всех рядов через `formatLegend` */
  value?: string;
  /** `m` — `headline-l` 56 (по умолчанию), `l` — `display-s` 72 */
  valueSize?: CardValueSize;
  delta?: CardDelta;
  period?: CardPeriod;
  series: readonly AreaCardSeries[];
  /** Подписи оси X, по одной на точку */
  labels: readonly string[];
  /** `full` — во всю рабочую ширину, `half` — колонка */
  size?: CardShellSize;
  /**
   * Ширина карточки. Нужна именно свойством, а не из потока: поле построения
   * — это SVG в точках, и его ширину надо знать до отрисовки. По умолчанию
   * 1680 (`full`) или 828 (`half`). ⚠️ Если контейнер уже заданного числа,
   * график вылезет за карточку — ширина обязана совпадать с фактической.
   */
  width?: number;
  /** Высота карточки. По умолчанию весь бюджет блока в ContentSlide */
  height?: number;
  /** Плитки легенды. Выключать только вместе с подписями у самого графика */
  legend?: boolean;
  /** `smooth` — донорская кривая, `sharp` — ломаная (мало точек, неравные шаги) */
  shape?: "smooth" | "sharp";
  /** Потолок шкалы — задать, когда две карточки рядом обязаны иметь общую ось */
  axisTop?: number;
  formatTick?: (value: number) => string;
  /** Формат итогов рядов в легенде и числа в шапке */
  formatLegend?: (value: number) => string;
  /** Вложенная тема. ⚠️ На проектор — `dark`: замеры в шапке файла */
  theme?: SlideTheme;
  className?: string;
}

/**
 * Карточка «площадь» целиком: шапка, стопка площадей, легенда.
 *
 * Итоги рядов в легенде и число в шапке по умолчанию СЧИТАЮТСЯ ОТ ТЕХ ЖЕ
 * данных, что и график. Это не удобство: расписанные руками числа расходятся
 * с графиком при первой же правке данных, и заметить это на слайде некому.
 * Готовая строка передаётся только там, где итог по смыслу не сумма ряда —
 * например, средняя конверсия.
 */
export default function AreaCard({
  label,
  value,
  valueSize = "m",
  delta,
  period,
  series,
  labels,
  size = "full",
  width = size === "full" ? 1680 : 828,
  height = CARD_BUDGET,
  legend = true,
  shape = "smooth",
  axisTop,
  formatTick,
  formatLegend = (v) => v.toLocaleString("ru-RU"),
  theme,
  className,
}: AreaCardProps) {
  const shown = series.slice(0, MAX_SERIES);
  const sum = (s: AreaCardSeries) => s.values.reduce((acc, v) => acc + Math.max(0, v), 0);

  const tiles: LegendTile[] = shown.map((s, si) => ({
    label: s.label,
    value: s.legendValue ?? formatLegend(sum(s)),
    color: paint(s, si).fill,
  }));

  const headline = value ?? formatLegend(shown.reduce((acc, s) => acc + sum(s), 0));

  return (
    <CardShell
      label={label}
      value={headline}
      valueSize={valueSize}
      delta={delta}
      period={period}
      legend={legend ? tiles : undefined}
      size={size}
      height={height}
      theme={theme}
      className={className}
    >
      <AreaCardPlot
        series={shown}
        labels={labels}
        width={cardChartWidth(width, size)}
        height={cardChartHeight({ height, size, valueSize, legend })}
        shape={shape}
        axisTop={axisTop}
        formatTick={formatTick}
      />
    </CardShell>
  );
}
