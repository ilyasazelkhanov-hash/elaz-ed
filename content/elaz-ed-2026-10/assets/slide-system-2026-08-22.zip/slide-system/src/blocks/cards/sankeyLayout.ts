import { BOARD_CHART, BOARD_SERIES } from "../../lib/boardPalette";
import { cardTextWidth } from "./axis";

/**
 * Раскладка карточки-потока: числа, геометрия и проверки. Без разметки.
 *
 * Отделено от [`sankeyCard.tsx`](./sankeyCard.tsx) по границе «что считается»
 * и «что рисуется», и не ради размера файла. Раскладка потока — это два
 * десятка чисел, каждое из которых выведено из донорского замера, и по
 * правилам проекта утверждения о них («помещается», «пропорция точна»)
 * законны только после замера. Пока расчёт жил внутри компонента, замерить
 * его можно было лишь через DOM готового слайда; отсюда он вызывается витриной
 * напрямую, и все числа в подписях историй СЧИТАЮТСЯ, а не переписываются.
 *
 * Здесь же собраны предупреждения: `layoutSankeyCard` возвращает их списком,
 * компонент печатает их в консоль в режиме разработки, а витрина показывает
 * тексты на странице — иначе предупреждение видит только тот, кто в этот
 * момент смотрел в консоль.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface SankeyCardNode {
  /** Ключ, по которому на узел ссылаются связи */
  key: string;
  /** Подпись узла: «Focus», «Video calls» */
  label: string;
  /** Краска узла. Не задана — донорский порядок по индексу (только источники) */
  color?: string;
}

export interface SankeyCardLink {
  /** Ключ источника */
  from: string;
  /** Ключ приёмника */
  to: string;
  /** Величина потока. Во всех связях в одних единицах */
  value: number;
}

/* ═══════════════  Краски  ═══════════════ */

/**
 * Порядок донорского демо: emerald → purple → yellow → blue → pink
 * (chart-7 · chart-5 · chart-8 · chart-6 · chart-3 в нумерации донора).
 *
 * Порядок снят со скриншота, переставлять его нельзя: соседняя карточка того
 * же дека красится тем же кругом, и расхождение прочиталось бы как ошибка
 * сборки.
 *
 * Контраст к четырём поверхностям, порог 3:1 по WCAG 1.4.11 (`contrast` из
 * `lib/color.ts`):
 *
 *                    карточка  холст  карточка  холст
 *                     светлая светлая   тёмная тёмная
 *   emerald #00d492      1.94   1.81      7.81   9.66   ✗ в светлой
 *   purple  #c27aff      2.79   2.61      5.42   6.71   ✗ в светлой
 *   yellow  #fdc700      1.57   1.47      9.62  11.91   ✗ в светлой
 *   blue    #3392ff      3.14   2.93      4.83   5.97   ✓ на карточке
 *   pink    #fb64b6      2.76   2.58      5.48   6.78   ✗ в светлой
 *
 * Порог на белой карточке берёт одна краска из пяти. Это принятое заказчиком
 * решение (разбор — шапка `lib/boardPalette.ts`), и следствие то же, что у
 * остальных карточек волны: величину несёт напечатанная подпись у узла,
 * а не краска.
 */
export const SANKEY_CARD_COLORS = [
  BOARD_SERIES[BOARD_CHART.emerald],
  BOARD_SERIES[BOARD_CHART.purple],
  BOARD_SERIES[BOARD_CHART.yellow],
  BOARD_SERIES[BOARD_CHART.blue],
  BOARD_SERIES[BOARD_CHART.pink],
] as const;

/**
 * Краска приёмника.
 *
 * ⚠️ **Приёмники нейтральны, и это не экономия.** Цвет кодирует ОДНУ
 * сущность — источник. Красить ещё и семь приёмников значило бы либо
 * назначать цвета по кругу (запрещено `dataviz.md`), либо завести вторую
 * цветовую шкалу на одном рисунке, и тогда непонятно, что означает цвет ленты.
 *
 * Донор красит приёмники `neutral-400` #a1a1a1 в светлой теме — замер даёт
 * 2.53:1 к белой карточке, то есть порог для нетекстовой графики он не берёт.
 * Взят наш `--t-ink-tertiary`: 3.79 к белой карточке и 3.68 к тёмной — берёт
 * в обеих темах. Это одно из двух мест, где donor-значение заменено нашим,
 * и причина измеримая.
 *
 * ⚠️ Ограничение «третичным набирать только от 24px» тут ни при чём: это
 * заливка, а не текст, порог у неё 3:1, а не 4.5:1.
 */
export const TARGET_PAINT = "var(--t-ink-tertiary)";

/* ═══════════════  Потолки  ═══════════════ */

/**
 * Потолок источников выведен из палитры, а не задан числом: цвет кодирует
 * источник, палитра по кругу не назначается (`dataviz.md`), значит шестой
 * источник — это не шестая краска, а строка «Прочее» на стороне данных.
 */
export const SOURCE_CAP = SANKEY_CARD_COLORS.length;

/**
 * Потолок приёмников — донорский: у самого донора их семь. Это же и предел
 * читаемости: число лент растёт произведением, 5 × 7 даёт до 35 пересечений
 * в полосе шириной около 700 точек. Донорское демо укладывается в 19 лент —
 * и уже на грани, о чём разведка предупредила отдельно.
 */
export const TARGET_CAP = 7;

/* ═══════════════  Геометрия  ═══════════════ */

/**
 * Ширина столбика узла.
 *
 * Донор: 12 при поле графика 550 × 344. По ширине это 2.18% (у нас 35), по
 * высоте 3.49% (у нас 14.2) — поле карточки вытянуто вчетверо сильнее
 * донорского (1608 × 408 против 550 × 344), и переносить долю по одной оси
 * значит промахнуться вдвое в любую сторону. Взято среднее геометрическое
 * √(35 × 14.2) = 22.3, округлённое к сетке 4.
 */
export const NODE_W = 24;

/**
 * Скругление узла — только с ВНЕШНЕЙ стороны: у источника слева, у приёмника
 * справа. Внутренняя сторона прямая, к ней встык примыкают ленты. Это
 * донорская «полупилюля»; смысл в том, что скруглённая внутренняя кромка
 * оставляла бы просвет между узлом и лентой на своих же краях.
 *
 * Донорский радиус 5 при ширине 12 — 42% ширины. Наш `--radius-tile` 12 при
 * ширине 24 — 50%. Ступени между 6 и 12 в системе нет, и заводить её ради
 * восьми процентов не за что.
 */
export const NODE_RADIUS = "var(--radius-tile)";

/**
 * Просвет между соседними столбиками в колонке.
 *
 * Донор: nodePadding 14 при высоте графика 344, то есть 4.07%. У нас поле
 * 408 (без строки подписей полей) — 16.6, округлено к сетке 4.
 */
export const NODE_GAP = 16;

/**
 * Просвет между столбиком и его подписью.
 *
 * Донор: 8 при кегле имени 13, то есть 0.62 кегля. У нас имя 24 → 14.8,
 * округлено к сетке 4.
 */
export const LABEL_GAP = 16;

/** Просвет между именем узла и его числом внутри строки подписи */
export const INLINE_GAP = 12;

/**
 * Высота строки подписи. Равна межстрочному интервалу `text-body-l` (24/32).
 *
 * Число продублировано здесь из `typography.css` потому, что от него
 * считается ГЕОМЕТРИЯ: минимальная высота столбика выводится из него, и пока
 * оно стояло только в CSS, посчитать её было нечем. При правке шкалы это
 * место придётся править вместе с ней.
 */
export const LINE = 32;

/** Запас, чтобы боксы соседних подписей не касались вплотную */
export const LABEL_CLEAR = 6;

/** Высота строки подписей полей: межстрочный интервал `text-body-m` (20/28) */
export const CAPTION_LINE = 28;

/** Просвет между полем потока и строкой подписей полей. Желоб сетки */
export const CAPTION_GAP = 24;

/*
 * Кегли, веса и трекинг подписей — для замера ширины. Равны токенам шкалы:
 * имя `--text-body-l` 24/500/−0.48, число `--text-label` 18/500/−0.36.
 * Трекинг во всей типографике −(кегль × 0.02).
 */
export const NAME_SIZE = 24;
export const NAME_WEIGHT = 500;
export const NAME_TRACKING = -0.48;
export const META_SIZE = 18;
export const META_WEIGHT = 500;
export const META_TRACKING = -0.36;

/**
 * Потолок ширины колонки подписей — доля поля графика на каждую сторону.
 *
 * Донор отдаёт подписям 88 слева и 150 справа при ширине 550, то есть 16% и
 * 27%. Разведка предупредила, что при кегле 24 вместо 13 подписи станут вдвое
 * длиннее относительно графика и поле придётся увеличить до 22–25%. Взято
 * 25%: на донорских данных обе колонки укладываются свободно, а потолок
 * срабатывает только на длинных подписях — и тогда имя обрезается многоточием
 * с предупреждением.
 *
 * Резать полосу потока сильнее нельзя: при 25% с каждой стороны на ленты
 * остаётся 1608 − 2 × (402 + 16 + 24) = 724, то есть 45% ширины против
 * донорских 52%.
 */
export const LABEL_MAX_SHARE = 0.25;

/**
 * Опоры кривой ленты — донорские.
 *
 * Донор ставит их на 0.55 пролёта от КАЖДОГО конца, то есть опоры
 * перекрещены: первая правее второй. Касательные на концах при этом остаются
 * горизонтальными (у опоры та же ордината, что у конца), а середина кривой
 * становится туже, чем при классических 0.5. Лента примыкает к столбику
 * встык, а не под углом, — и при этом не растекается в середине полосы.
 */
export const CURVE = 0.55;

/** Ниже этой толщины лента перестаёт читаться. Не зажим — предупреждение */
export const RIBBON_MIN = 3;

/**
 * Минимальная ширина полосы под ленты. Ниже неё кривая вырождается
 * в диагональ, и стык с узлом читается надломом.
 */
export const BAND_MIN = 320;

/* ═══════════════  Плотность лент  ═══════════════ */

/**
 * Непрозрачность ленты. Донорское значение — и оно ПРОВЕРЕНО, а не списано.
 *
 * === Почему лента полупрозрачная ===
 *
 * Ленты пересекаются — это устройство формы, а не дефект вёрстки. Сплошная
 * заливка означала бы, что верхняя лента стирает нижнюю, и поток, проходящий
 * под другим, с диаграммы исчезает.
 *
 * === Проверка донорского 0.32 ===
 *
 * Условие то же, что у `SankeyFlow` в `blocks/sankey.tsx`: СТОПКА ЛЕНТ
 * ОБЯЗАНА ОСТАВАТЬСЯ ТИШЕ САМОГО СЛАБОГО СТОЛБИКА, иначе пересечение
 * начинает выглядеть данными. Слабейший столбик тёмной темы — синий #3392ff,
 * 4.83:1 к карточке #262626. Замер стопок из 2…5 лент композитом к карточке,
 * худшее сочетание красок из пяти:
 *
 *   α = 0.32   2 ленты 3.36   3 ленты 4.02   4 ленты 4.22   5 лент 4.20  ✓
 *   α = 0.36   2 ленты 3.73   3 ленты 4.44   4 ленты 4.53   5 лент 4.41  ✓
 *   α = 0.40   2 ленты 4.15   3 ленты 4.90   4 ленты 4.86   5 лент 4.56  ✗
 *
 * Донорские 0.32 условие берут с запасом 0.8 пункта, а 0.40 его ломает.
 * Одиночная лента даёт 1.63…2.24 в тёмной теме — порог 3:1 она не берёт
 * и брать не должна: носитель величины — столбик и подпись, лента показывает
 * направление.
 *
 * ⚠️ **Честно про светлую тему: там условие не выполняется, и починить это
 * прозрачностью нельзя.** Слабейший столбик светлой темы — жёлтый #fdc700,
 * 1.57:1 к белой карточке. Стопка уже из ДВУХ лент даёт 1.81 при α = 0.32
 * и 1.58 даже при α = 0.24, то есть перекрытие плотнее жёлтого узла при
 * любой работоспособной прозрачности. Причина не в лентах, а в том, что
 * жёлтая краска донора на белом почти не видна сама. Вывод тот же, что
 * в шапке `lib/boardPalette.ts`: **если карточка едет на проектор — тёмная
 * тема.**
 *
 * === Проверка ПИКСЕЛЯМИ, а не только моделью ===
 *
 * Всё выше посчитано моделью композита. Модель проверена съёмкой: снимок
 * полосы лент в 1:1, отсчёт по центральной линии ленты в пяти точках хода
 * (кривая вычислена из её же `d`), контраст к цвету карточки из того же
 * снимка.
 *
 *   светлая, лента Focus → Browsing   1.29 · 1.33 · 1.36 · 1.39 · 1.43
 *   светлая, лента Breaks → Browsing  1.17 · 1.61 · 1.30 · 1.35 · 1.42
 *   светлая, лента Learning → calls   1.39 · 1.40 · 1.42 · 1.43 · 1.43
 *   тёмная,  лента Focus → Browsing   1.95 · 1.78 · 1.69 · 1.60 · 1.50
 *
 * Одиночная лента идёт 1.17…1.43 в светлой теме и 1.50…1.95 в тёмной; 1.61
 * во второй строке — точка, где ленты пересекаются, и это ровно то, что
 * предсказывала модель. Отсчёт у самого источника (#1b5d48 в тёмной теме)
 * совпал с расчётом композита (#1a5e49) с точностью до единицы в канале.
 *
 * === Текста на лентах нет, и это тоже замер ===
 *
 * Подписи стоят в колонках слева и справа, за пределами полосы: замер хода
 * строки против внутреннего края бокса по всем историям витрины дал ноль
 * выходов. Если бы подпись легла на ленту, читаемым остался бы только
 * `text-ink`: на композите ленты в светлой теме он даёт 12.76…16.34,
 * а `text-ink-secondary` — 3.49…4.46, то есть порог 4.5 для кегля мельче 24
 * не берёт; в тёмной теме 5.34…7.81 против 2.21…3.23. Отсюда правило:
 * **на ленту текст не ставить.**
 */
export const RIBBON_ALPHA = 0.32;

/**
 * Статическая изоляция потока — донорские числа наведения (0.7 против 0.08).
 *
 * Замер к карточке: выделенная лента 1.39…2.19 в светлой теме и 3.08…5.47
 * в тёмной; погашенная 1.04…1.09 и 1.12…1.20. Абсолютные значения в светлой
 * теме низкие (та же причина, что выше), но приём работает на РАЗНИЦЕ:
 * выделенная плотнее погашенной вдвое в светлой теме и вчетверо в тёмной.
 */
export const HIGHLIGHT_ON = 0.7;
export const HIGHLIGHT_OFF = 0.08;

/* ═══════════════  Раздача высот  ═══════════════ */

/**
 * Высоты столбиков: пропорция величине, но не тоньше своего минимума.
 *
 * ⚠️ Это ТОТ ЖЕ алгоритм «налива», что в [`blocks/sankey.tsx`](../sankey.tsx),
 * и он продублирован намеренно. Карточки волны по устройству проекта замкнуты
 * на `shell.tsx` и `axis.ts` и ни разу не тянут код из соседних блоков; кроме
 * того, замерщик ширины здесь другой (DOM-линейка `axis.ts` против холста
 * в `sankey.tsx`). Цена дубля записана прямо здесь: **правка одного файла
 * обязывает перечитать второй.**
 *
 * Узлы, которым не хватает до минимума, закрепляются на минимуме, остаток
 * делится между свободными пропорционально величинам, проход повторяется,
 * пока закрепления не кончатся.
 */
export function fitHeights(values: number[], mins: number[], barTotal: number) {
  const n = values.length;
  const pinned = new Array<boolean>(n).fill(false);
  const out = new Array<number>(n).fill(0);

  for (let guard = 0; guard <= n; guard++) {
    const pinnedSum = mins.reduce((sum, m, i) => sum + (pinned[i] ? m : 0), 0);
    const rest = Math.max(0, barTotal - pinnedSum);
    const freeValue = values.reduce((sum, v, i) => sum + (pinned[i] ? 0 : v), 0);

    let changed = false;
    for (let i = 0; i < n; i++) {
      if (pinned[i]) {
        out[i] = mins[i];
        continue;
      }
      out[i] = freeValue > 0 ? (values[i] / freeValue) * rest : 0;
      if (out[i] < mins[i]) {
        pinned[i] = true;
        changed = true;
      }
    }
    if (!changed) break;
  }

  return out;
}

/* ═══════════════  Замер подписи  ═══════════════ */

/*
 * Ширина колонки подписей считается ЗАМЕРОМ, а не прикидкой «знаков × кегль»:
 * разброс ширины знака доходит до двух с половиной раз (разбор — в шапке
 * `axis.ts`). Числа меряются моноширинными, потому что так и рисуются:
 * колонка значений обязана стоять ровно.
 */
export const sankeyNameWidth = (text: string) =>
  cardTextWidth(text, NAME_SIZE, NAME_WEIGHT, NAME_TRACKING, false);

export const sankeyMetaWidth = (text: string) =>
  cardTextWidth(text, META_SIZE, META_WEIGHT, META_TRACKING, true);

/* ═══════════════  Раскладка целиком  ═══════════════ */

export interface SankeyRibbon {
  key: string;
  /** Индекс источника: от него краска и непрозрачность */
  si: number;
  /** Наибольшая из двух толщин — по ней идёт порядок отрисовки */
  thickest: number;
  y0s: number;
  y1s: number;
  y0t: number;
  y1t: number;
}

export interface SankeyLayoutInput {
  sources: readonly SankeyCardNode[];
  targets: readonly SankeyCardNode[];
  links: readonly SankeyCardLink[];
  /** Ширина поля графика: карточка минус два поля */
  chartWidth: number;
  /** Высота поля графика: остаток бюджета карточки под шапкой */
  chartHeight: number;
  /** Строка подписей полей забирает CAPTION_LINE + CAPTION_GAP */
  hasCaptions: boolean;
  formatValue: (value: number) => string;
  formatShare: (percent: number) => string;
  /** Ручные ширины колонок подписей — только чтобы выровнять две карточки */
  labelWidth?: readonly [number, number];
  /** Ключ источника, чей поток оставлен в полную силу */
  highlight?: string;
}

export interface SankeyLayout {
  keptSources: SankeyCardNode[];
  keptTargets: SankeyCardNode[];
  sourceValue: number[];
  targetValue: number[];
  sourceMeta: string[];
  targetMeta: string[];
  sourceH: number[];
  targetH: number[];
  sourceTop: number[];
  targetTop: number[];
  ribbons: SankeyRibbon[];
  /** Толстые впереди — они окажутся НИЖЕ тонких */
  drawOrder: SankeyRibbon[];
  total: number;
  /** Ширины колонок подписей */
  fromW: number;
  toW: number;
  /** Полоса лент: левый край и ширина */
  bandX: number;
  bandW: number;
  /** Высота поля потока без строки подписей полей */
  bandH: number;
  /** Сумма высот столбиков в колонке. От неё считается «честная» доля */
  barTotal: number;
  /** Минимальная высота столбика после ужимания под полосу */
  minBar: number;
  /** Тексты предупреждений: пусто — дефектов не нашлось */
  warnings: string[];
}

/**
 * Считает всю геометрию потока и собирает предупреждения.
 *
 * === Величины узлов считаются ИЗ СВЯЗЕЙ ===
 *
 * Узел своей величины не хранит. Иначе появились бы два источника правды —
 * подписанное число и сумма лент, — и они разошлись бы при первой правке
 * данных, причём молча: подпись говорила бы одно, картинка другое.
 *
 * === Порядок узлов задаётся данными ===
 *
 * `sources` и `targets` идут сверху вниз ровно так, как переданы. Сортировки
 * по величине внутри нет: молчаливая перестановка переписала бы вывод слайда.
 * Ленты внутри узла тоже не сортируются — они укладываются в порядке
 * ПРОТИВОПОЛОЖНОЙ колонки, и это же минимизирует лишние пересечения.
 *
 * === Одна шкала на две колонки ===
 *
 * Иначе лента приходила бы в приёмник другой толщиной, чем вышла из
 * источника, то есть форма врала бы о величине. Достигается тем, что
 * суммарная высота столбиков у обеих колонок равна: из высоты вычитаются
 * просветы САМОЙ ПЛОТНОЙ колонки, и та же сумма раздаётся в обеих. Колонка,
 * где узлов меньше, короче по габариту и центрируется.
 */
export function layoutSankeyCard(input: SankeyLayoutInput): SankeyLayout {
  const {
    sources,
    targets,
    links,
    chartWidth: W,
    chartHeight: H,
    hasCaptions,
    formatValue,
    formatShare,
    labelWidth,
    highlight,
  } = input;

  const warnings: string[] = [];
  const bandH = hasCaptions ? H - CAPTION_LINE - CAPTION_GAP : H;

  const keptSources = sources.slice(0, SOURCE_CAP);
  const keptTargets = targets.slice(0, TARGET_CAP);

  const sourceIndex = new Map(keptSources.map((n, i) => [n.key, i]));
  const targetIndex = new Map(keptTargets.map((n, i) => [n.key, i]));

  const liveLinks = links.filter(
    (l) => sourceIndex.has(l.from) && targetIndex.has(l.to) && l.value > 0,
  );

  const sourceValue = keptSources.map((n) =>
    liveLinks.reduce((sum, l) => (l.from === n.key ? sum + l.value : sum), 0),
  );
  const targetValue = keptTargets.map((n) =>
    liveLinks.reduce((sum, l) => (l.to === n.key ? sum + l.value : sum), 0),
  );

  const total = liveLinks.reduce((sum, l) => sum + l.value, 0);

  const sourceMeta = sourceValue.map((v) => formatValue(v));
  const targetMeta = targetValue.map((v) => formatShare(total > 0 ? (v / total) * 100 : 0));

  /* ── Колонки подписей ──────────────────────────────────────────────── */

  const columnCap = W * LABEL_MAX_SHARE;
  const wanted = (nodes: readonly SankeyCardNode[], metas: string[]) =>
    nodes.length
      ? Math.max(
          ...nodes.map((n, i) => sankeyNameWidth(n.label) + INLINE_GAP + sankeyMetaWidth(metas[i])),
        )
      : 0;

  const fromW = labelWidth ? labelWidth[0] : Math.min(wanted(keptSources, sourceMeta), columnCap);
  const toW = labelWidth ? labelWidth[1] : Math.min(wanted(keptTargets, targetMeta), columnCap);

  const bandX = fromW + LABEL_GAP + NODE_W;
  const bandW = Math.max(0, W - bandX - (toW + LABEL_GAP + NODE_W));

  /* ── Столбики ──────────────────────────────────────────────────────── */

  const gapCount = Math.max(keptSources.length, keptTargets.length) - 1;
  const barTotal = Math.max(0, bandH - NODE_GAP * Math.max(0, gapCount));

  /*
   * Подпись однострочная всегда — разбор в шапке `sankeyCard.tsx`. Минимум
   * ужимается, если он не помещается в полосу: иначе сумма столбиков
   * превысила бы полосу и колонка вылезла бы за поле карточки.
   */
  const wantMin = Math.max(0, LINE - NODE_GAP + LABEL_CLEAR);
  const densest = Math.max(keptSources.length, keptTargets.length);
  const minBar = densest * wantMin > barTotal && densest > 0 ? barTotal / densest : wantMin;

  const sourceMin = new Array<number>(keptSources.length).fill(minBar);
  const targetMin = new Array<number>(keptTargets.length).fill(minBar);

  const sourceH = fitHeights(sourceValue, sourceMin, barTotal);
  const targetH = fitHeights(targetValue, targetMin, barTotal);

  const stack = (heights: number[]) => {
    const span = heights.reduce((a, b) => a + b, 0) + NODE_GAP * Math.max(0, heights.length - 1);
    const tops: number[] = [];
    let y = (bandH - span) / 2;
    for (const h of heights) {
      tops.push(y);
      y += h + NODE_GAP;
    }
    return tops;
  };

  const sourceTop = stack(sourceH);
  const targetTop = stack(targetH);

  /* ── Ленты ─────────────────────────────────────────────────────────── */

  const fromOffset = new Array<number>(keptSources.length).fill(0);
  const toOffset = new Array<number>(keptTargets.length).fill(0);

  const ribbons: SankeyRibbon[] = keptSources.flatMap((source, si) =>
    keptTargets.flatMap((target, ti) => {
      const link = liveLinks.find((l) => l.from === source.key && l.to === target.key);
      if (!link) return [];

      const thickFrom = sourceValue[si] > 0 ? (link.value / sourceValue[si]) * sourceH[si] : 0;
      const thickTo = targetValue[ti] > 0 ? (link.value / targetValue[ti]) * targetH[ti] : 0;

      const y0s = sourceTop[si] + fromOffset[si];
      const y0t = targetTop[ti] + toOffset[ti];
      fromOffset[si] += thickFrom;
      toOffset[ti] += thickTo;

      return [
        {
          key: `${source.key}→${target.key}`,
          si,
          thickest: Math.max(thickFrom, thickTo),
          y0s,
          y1s: y0s + thickFrom,
          y0t,
          y1t: y0t + thickTo,
        },
      ];
    }),
  );

  const drawOrder = ribbons.slice().sort((a, b) => b.thickest - a.thickest);

  /* ── Проверки ──────────────────────────────────────────────────────── */

  if (!liveLinks.length) {
    warnings.push(
      "Ни одной связи. Пустая карточка проходит все автопроверки разом — проверьте ключи " +
        "from/to и что величины положительные.",
    );
  }

  if (sources.length > SOURCE_CAP) {
    warnings.push(
      `Источников ${sources.length} при потолке ${SOURCE_CAP}. Отброшены: ` +
        `${sources
          .slice(SOURCE_CAP)
          .map((n) => n.label)
          .join(", ")}. Потолок равен длине SANKEY_CARD_COLORS: цвет кодирует источник, ` +
        "а палитра по кругу не назначается. Сверните остаток в «Прочее» на стороне данных.",
    );
  }

  if (targets.length > TARGET_CAP) {
    warnings.push(
      `Приёмников ${targets.length} при потолке ${TARGET_CAP}. Отброшены: ` +
        `${targets
          .slice(TARGET_CAP)
          .map((n) => n.label)
          .join(", ")}. Семь — донорский предел: дальше ленты глазом не прослеживаются.`,
    );
  }

  const lost = links.filter((l) => !sourceIndex.has(l.from) || !targetIndex.has(l.to));
  if (lost.length) {
    warnings.push(
      `${lost.length} связей ведут к узлам, которых нет в списках или которые отброшены ` +
        `потолком: ${lost.map((l) => `${l.from}→${l.to}`).join(", ")}. Их величины в итог ` +
        "НЕ вошли — итог и доли посчитаны без них.",
    );
  }

  const dead = keptSources
    .filter((_, i) => sourceValue[i] <= 0)
    .concat(keptTargets.filter((_, i) => targetValue[i] <= 0));
  if (dead.length) {
    warnings.push(
      `Узлы без связей — ${dead.map((n) => n.label).join(", ")}. ` +
        "Столбик нулевой высоты выглядит как пропавшая подпись.",
    );
  }

  /*
   * «Честная» высота считается от barTotal и общей суммы: столбик обязан
   * занимать свою долю полосы. Прижатый к минимуму узел выглядит крупнее —
   * и во сколько раз, здесь же и сказано, чтобы искажение можно было
   * оценить, а не просто заметить.
   */
  const fairHeight = (v: number) => (total > 0 ? (v / total) * barTotal : 0);
  const blown = [
    ...keptSources.map((n, i) => ({ n, got: sourceH[i], v: sourceValue[i] })),
    ...keptTargets.map((n, i) => ({ n, got: targetH[i], v: targetValue[i] })),
  ].filter((x) => x.got > 0 && x.got - fairHeight(x.v) > 0.5);
  if (blown.length) {
    warnings.push(
      "Узлы прижаты к минимальной высоте и потому выглядят КРУПНЕЕ своей доли — " +
        `${blown
          .map((x) => {
            const fair = fairHeight(x.v);
            const times = fair > 0 ? (x.got / fair).toFixed(2) : "∞";
            return `${x.n.label} (${Math.round(x.got)} точек вместо ${Math.round(fair)}, ×${times})`;
          })
          .join(", ")}. ` +
        "Пропорция в этих узлах нарушена. Свернуть мелкие узлы в «Прочее» или укрупнить карточку.",
    );
  }

  const thin = ribbons.filter((r) => r.thickest > 0 && r.thickest < RIBBON_MIN);
  if (thin.length) {
    warnings.push(
      `Ленты тоньше ${RIBBON_MIN} точек — ${thin.map((r) => r.key).join(", ")}. ` +
        "На слайде их не видно, и поток читается как отсутствующий.",
    );
  }

  if (bandW < BAND_MIN && liveLinks.length) {
    warnings.push(
      `Под ленты остаётся ${Math.round(bandW)} точек при пороге ${BAND_MIN}. Подписи забрали ` +
        `${Math.round(fromW)} слева и ${Math.round(toW)} справа. Кривая вырождается ` +
        "в диагональ. Сократить подписи или ставить карточку во всю ширину.",
    );
  }

  const cut = [
    ...keptSources.map((n, i) => ({
      n,
      want: sankeyNameWidth(n.label),
      has: fromW - INLINE_GAP - sankeyMetaWidth(sourceMeta[i]),
    })),
    ...keptTargets.map((n, i) => ({
      n,
      want: sankeyNameWidth(n.label),
      has: toW - INLINE_GAP - sankeyMetaWidth(targetMeta[i]),
    })),
  ].filter((x) => x.want > x.has + 0.5);
  if (cut.length) {
    warnings.push(
      "Подписи обрезаны многоточием — " +
        `${cut.map((x) => `${x.n.label} (${Math.round(x.want - x.has)} точек)`).join(", ")}. ` +
        "Колонка подписи ограничена четвертью поля, иначе на ленты не останется места. " +
        "Сократить название узла.",
    );
  }

  if (highlight && !sourceIndex.has(highlight)) {
    warnings.push(
      `highlight="${highlight}" — такого источника нет. Все ленты погашены до ` +
        `${HIGHLIGHT_OFF}, диаграмма выглядит пустой.`,
    );
  }

  return {
    keptSources,
    keptTargets,
    sourceValue,
    targetValue,
    sourceMeta,
    targetMeta,
    sourceH,
    targetH,
    sourceTop,
    targetTop,
    ribbons,
    drawOrder,
    total,
    fromW,
    toW,
    bandX,
    bandW,
    bandH,
    barTotal,
    minBar,
    warnings,
  };
}

/**
 * Контур одной ленты.
 *
 * Заливка, а НЕ штрих. Донор рисует ленту штрихом: path без заливки, где
 * `stroke-width` равен толщине потока. У такой ленты толщина ОДИНАКОВА на
 * обоих концах, а у нас она обязана различаться: когда узел прижат
 * к минимальной высоте, его доля в столбике перестаёт совпадать с долей
 * в противоположном столбике. Штрих в этом случае соврал бы молча — заливка
 * показывает расхождение формой. Кривая при этом донорская, см. `CURVE`.
 */
export function sankeyRibbonPath(r: SankeyRibbon, bandW: number) {
  const c1 = bandW * CURVE;
  const c2 = bandW * (1 - CURVE);
  return [
    `M 0 ${r.y0s}`,
    `C ${c1} ${r.y0s}, ${c2} ${r.y0t}, ${bandW} ${r.y0t}`,
    `L ${bandW} ${r.y1t}`,
    `C ${c2} ${r.y1t}, ${c1} ${r.y1s}, 0 ${r.y1s}`,
    "Z",
  ].join(" ");
}
