import { useId, type CSSProperties } from "react";
import {
  AltArrowDown,
  ArrowUp,
  BranchingPathsUp,
  ClipboardList,
  CodeSquare,
  DocumentText,
  Folder,
  MagicStick3,
  Microphone3,
  Paperclip,
  PresentationGraph,
  Target,
  Widget,
} from "@solar-icons/react";
import BrandMark from "../../components/BrandMark";
import type { BrandSlug } from "../../components/brandPaths";
import type { SolarIcon } from "../../lib/solar";
import type { SlideTheme } from "../../slide/Slide";
import { CARD_BUDGET } from "./shell";

/**
 * Поле ввода ИИ-чата — перенос компонента `composer` из донорской системы.
 *
 * ⚠️ ЭТО НЕ БЛОК ДАННЫХ. Это СТАТИЧНЫЙ МАКЕТ ПРОДУКТА: картинка интерфейса
 * на слайде, такая же по роли, как скриншот приложения. Всё, что здесь
 * нарисовано, нарисовано, а не работает.
 *
 *   ┌ рабочее состояние ────────────────────────────────────────────┐
 *   │  ✦ Thinking 2.0s                                              │
 *   │ ╭───────────────────────────────────────────────────────────╮ │
 *   │ │ (📎)  Ask me anything          [Fable 5 ⌄]   (🎙) (↑)     │ │
 *   │ ╰───────────────────────────────────────────────────────────╯ │
 *   │  ⑂ Main   📁 project-sea ⌄        ✦ Agent ⌄   ( ◔ 57% )       │
 *   └───────────────────────────────────────────────────────────────┘
 *
 * ═══════════════════════════════════════════════════════════════════
 * КОГДА ЭТОТ БЛОК УМЕСТЕН, А КОГДА НЕТ
 * ═══════════════════════════════════════════════════════════════════
 *
 * УМЕСТЕН, когда слайд ПРО САМ ПРОДУКТ:
 *   · «вот как выглядит окно ввода» — демонстрация интерфейса;
 *   · «агент работает в контексте ветки и проекта» — слайд про то, что
 *     система знает о сессии (это ровно то, что печатает строка состояния);
 *   · «моделей несколько, выбор за пользователем» — слайд с раскрытым меню
 *     моделей;
 *   · «продукт умеет вот это» — слайд с раскрытым меню вложений, где семь
 *     строк меню и есть перечень возможностей.
 *
 * НЕ УМЕСТЕН, когда слайд ПРО ДАННЫЕ КЛИЕНТА:
 *   · показать выручку, конверсию, динамику, доли — здесь нет ни одного
 *     места, куда величина встала бы честно. Единственное число блока —
 *     заполнение контекста в процентах, и оно про сессию, а не про бизнес;
 *   · подставить в поле ввода фразу вроде «Выручка выросла на 42%» — это
 *     худший вариант из возможных: цифра клиента получает вид пользовательского
 *     ввода, то есть чего-то введённого руками и ничем не подтверждённого.
 *     Для чисел есть `Stat`, `CardShell` и карточки-графики рядом в этой папке;
 *   · «результат работы ИИ» — ответа здесь нет вовсе, есть только строка,
 *     в которую спрашивают. Ответ — это другой макет.
 *
 * Проверка одной фразой: если убрать блок и слайд потеряет ЧИСЛО — блок
 * выбран неверно. Если потеряет ПРЕДСТАВЛЕНИЕ О ПРОДУКТЕ — верно.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ЧТО ИЗ ДОНОРА НЕ ПЕРЕНЕСЕНО
 * ═══════════════════════════════════════════════════════════════════
 *
 * Донор — живой интерфейс. У него анимированный светящийся контур (4.5s
 * linear infinite), пляшущие полоски записи (четыре разные длительности),
 * раскрытие меню из угла, переход элементов управления в «жидкое стекло»,
 * наведение на кнопки (150ms), каретка в поле ввода.
 *
 * В PDF нет ни одного кадра из этого списка — там ровно одно изображение.
 * Поэтому:
 *
 *   микрофон        `Microphone3`, а НЕ `Microphone`. Обе из набора, выбор по
 *                   виду на увеличении ×8: у `Microphone` штрихи решётки
 *                   смещены вправо от оси, и в круге 56 при глифе 32 это
 *                   читается как дефект отрисовки, а не как рисунок сетки.
 *                   У `Microphone3` решётка по центру. Донорский знак (Remix
 *                   Icon) переносить нельзя — пути чужого набора запрещены.
 *   каретка         НЕ рисуется вовсе. Мигающая палка, застывшая в кадре,
 *                   читается как артефакт печати, а не как курсор.
 *   наведение       нет. У кнопок только состояние покоя.
 *   меню            не раскрываются по нажатию — рисуются раскрытыми сразу,
 *                   отдельным состоянием (`state="attach"` / `"model"`).
 *   полоски записи  четыре столбика РАЗНОЙ высоты. Донорские отношения высот
 *                   сохранены (см. `MIC_BARS`): без движения это читается как
 *                   эквалайзер, а не как четыре одинаковых палки.
 *   контур работы   три размытые обводки сведены к двум — разбор ниже.
 *   стекло          НЕ перенесено вовсе — разбор ниже.
 *
 * ⚠️ ПОЧЕМУ ОТКАЗ ОТ «ЖИДКОГО СТЕКЛА» ПОЛНЫЙ, А НЕ ЗАМЕНА
 *
 * У донора в рабочем состоянии фон каждой кнопки подменяется стопкой из
 * четырёх слоёв: `backdrop-filter: blur(6px) saturate(1.6)`, SVG-фильтр
 * смещения, тонировка rgba(255,255,255,0.059), блик под 150° и кромка 0.3px
 * коническим градиентом. Спецификация разведки предлагает безопасную замену —
 * плоская плёнка rgba(255,255,255,0.06) плюс сплошная кромка.
 *
 * Здесь не взято ни то, ни другое, и вот почему.
 *
 * 1. `backdrop-filter` и фильтр смещения зависят от того, что РЕАЛЬНО лежит
 *    под элементом. Chromium их растеризует, и результат надо смотреть не в
 *    своём предпросмотре, а в «Просмотре» заказчика — это уже наступленная
 *    грабля проекта (см. CLAUDE.md, раздел про Quartz).
 * 2. Плоская замена безопасна, но она СНИЖАЕТ контраст кнопок: плёнка в шесть
 *    сотых поверх заливки съедает разницу с капсулой, а кнопки на слайде и так
 *    держатся на разнице в 1.13…1.19:1 (замеры ниже).
 * 3. Главное: в рабочем состоянии одно и то же сообщение «идёт работа» уже
 *    сказано ДВАЖДЫ — светящимся контуром и подписью «Thinking 2.0s».
 *    Третий носитель того же факта не добавляет смысла, а платить за него
 *    приходится читаемостью органов управления.
 *
 * ⚠️ ПОЧЕМУ КОНТУР — ДВЕ ОБВОДКИ, А НЕ ТРИ
 *
 * Донорские три: sw 32 / размытие 14 / opacity 0.3 · sw 8 / размытие 6 /
 * opacity 0.8 · sw 2.5 / размытие 0.5 / opacity 1. Разные отрицательные
 * задержки анимации расслаивали пятно и давали объёмный свет.
 *
 * Без движения расслоения не существует: три статичные дуги на одном месте
 * складываются в одну. При этом масштаб ×1.538 (см. ниже) превратил бы
 * размытие 14 в 21.5 при обводке 49 — крупная мягкая площадь на холсте
 * 1920px, а это ровно тот случай, где на проекторе проступает бандинг.
 * Оставлены две: ореол (обводка 24, размытие 12, непрозрачность 0.28) и
 * острая дуга (обводка 4, размытие 0.75, непрозрачность 1).
 *
 * ═══════════════════════════════════════════════════════════════════
 * ГЕОМЕТРИЯ: НЕ МАСШТАБ, А ПЕРЕСБОРКА НА ТОКЕНАХ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Донор снят при ширине 560: капсула 560×52, круглые кнопки 36, поле 8,
 * зазор 10, кегли 13 и 14. Спецификация разведки прямо предупреждает: точное
 * масштабирование не переносится, потому что 13 и 14 при любом множителе
 * попадают мимо шкалы проекта (×2.5 → 32.5 и 35, ×3 → 39 и 42; в шкале нет
 * ни одного из четырёх).
 *
 * Поэтому геометрия СОБРАНА ОТ КНОПКИ, а не растянута:
 *
 *   круглая кнопка   56  — высота `rounded-button-m` (радиус 28 = половина)
 *   поле капсулы     12  — донорские 8 в той же доле (8/36 = 0.22 → 12/56)
 *   высота капсулы   80  = 12 + 56 + 12, ровно пара `rounded-button-xl`
 *
 * Отсюда множитель к донору 80/52 = 1.538, и он выдержан по всем осям:
 *
 *   слой                донор   ×1.538   взято   чем задано
 *   капсула h            52      80.0     80     12 + 56 + 12
 *   круглая кнопка       36      55.4     56     `rounded-button-m` ×2
 *   поле капсулы          8      12.3     12     сетка 4
 *   зазор в капсуле      10      15.4     16     сетка 4
 *   кнопка модели h      32      49.2     48     `rounded-button-s` ×2
 *   правая группа pl      6       9.2      8     сетка 4
 *   зазор правой группы   8      12.3     12     сетка 4
 *   зазор до статуса     10      15.4     16     сетка 4
 *   строка статуса h     26      40.0     40     `text-body-m` 28 + 6 + 6
 *   иконка статуса       16      24.6     24     сетка 4
 *   зазор групп статуса  12      18.5     20     сетка 4
 *   ВСЕГО h              88     135.4    136     80 + 16 + 40
 *
 * Совпадение итога (135.4 против 136) не подгонялось — оно следствие того,
 * что все слои взяты одним множителем.
 *
 * КЕГЛИ взяты из шкалы, а не из донора:
 *
 *   донор 14 (ввод, кнопка модели, заголовок строки меню) → `text-body-l` 24
 *   донор 13 (строка состояния, пояснения в меню)         → `text-body-m` 20
 *
 * ⚠️ И у этого есть следствие, ради которого стоило считать: плейсхолдер
 * «Ask me anything» у донора набран text-tertiary. В нашей системе третичный
 * цвет разрешён только от кегля 24 — на 20 он даёт 3.54:1 при пороге 4.5.
 * Ввод у нас ровно 24, поэтому донорский третичный плейсхолдер ЗАКОННЫЙ.
 * Если бы ввод сел на 20, плейсхолдер пришлось бы поднимать до вторичного —
 * и он перестал бы отличаться от введённого текста.
 *
 * Подписи строки состояния — 20, поэтому там третичного нет и быть не может:
 * они вторичные (у донора там text-secondary #737373, то же решение).
 *
 * ═══════════════════════════════════════════════════════════════════
 * ШИРИНА: ЧЕМ ШИРЕ, ТЕМ ХУЖЕ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Донорская пропорция капсулы 560/52 = 10.8:1, всего блока 560/88 = 6.4:1.
 * У нас высота фиксирована (136), значит пропорцию задаёт только ширина:
 *
 *   ширина   капсула   блок    что это
 *     828     10.4:1   6.1:1   `col-span-6` — почти донор, УМОЛЧАНИЕ
 *    1108     13.9:1   8.1:1   `col-span-8` — ещё читается
 *    1680     21.0:1  12.4:1   вся рабочая ширина — вдвое площе донора
 *
 * Это тот же перекос, что у карточек-графиков волны, но бьёт он иначе: у
 * графика плющится форма, здесь — пустеет поле ввода. При 1680 между текстом
 * и кнопкой модели остаётся около 900 точек пустоты, и капсула читается не
 * как поле ввода, а как разделительная линейка. Полная ширина здесь не
 * запрещена (блок ленточный, спецификация разведки даже отмечает, что 1680
 * это ровно ×3 донора), но она требует длинного текста в поле.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ШЕВРОНЫ: ЗДЕСЬ ОНИ РАЗРЕШЕНЫ, В `CardShell` — НЕТ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Рядом, в `shell.tsx`, шеврон у подписи периода СНЯТ намеренно: он обещает
 * выпадающий список, которого в PDF не будет, и нарисованный орган управления
 * читается как недоделанный интерфейс.
 *
 * Здесь наоборот, и противоречия нет — различается роль блока.
 *
 *   `CardShell` — блок СЛАЙДА. Читатель смотрит на данные клиента, и всё, что
 *   выглядит как кнопка, он воспринимает как кнопку этого слайда.
 *
 *   `ComposerCard` — ИЗОБРАЖЕНИЕ ЧУЖОГО ПРОДУКТА. Читатель смотрит на снимок
 *   экрана. В снимке экрана шеврон, микрофон и кнопка отправки — не органы
 *   управления слайда, а части изображённой вещи; убрать их значило бы
 *   показать продукт, которым нельзя пользоваться.
 *
 * Чтобы эта рамка читалась, а не подразумевалась, у блока есть подложка
 * (`mount="plate"`): холст + `shadow-thumbnail` — тот самый токен, который в
 * системе и означает «скриншот продукта». На тёмном или светлом слайде, где
 * фон совпадает с фоном донора, подложка не нужна (`mount="bare"`).
 *
 * ═══════════════════════════════════════════════════════════════════
 * ЦВЕТ: ЧТО СОВПАЛО С ДОНОРОМ, А ЧТО ПРИШЛОСЬ РЕШАТЬ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Скин проекта построен на том же наборе, что донор, поэтому большинство
 * ролей встали один в один:
 *
 *   донор                              наша роль            значения
 *   background-primary-default         `bg-surface`         #ffffff / #262626
 *   переписки-composer-add-background    `bg-fill`            #f5f5f5 / #1f1f1f
 *   border-button-default              `border-line`        #ebebeb / #2f2f2f
 *   background-tertiary-default        `bg-fill-strong`     #ebebeb / #2f2f2f
 *   separator-border-strong (выбранное)`bg-fill-strong`     #ebebeb / #2f2f2f
 *   text-primary                       `text-ink`           #0a0a0a / #fafafa
 *   text-secondary #737373             `text-ink-secondary` #6a6a6a / #a3a3a3
 *   text-tertiary                      `text-ink-tertiary`  #838383 / #7d7d7d
 *
 * Три места решались отдельно.
 *
 * 1. ГРАДИЕНТ КНОПКИ ОТПРАВКИ взят донорский и НЕ переворачивается по теме:
 *    linear-gradient(180deg, #2b7fff, #155dfc). У донора это единственный
 *    градиент интерфейса и он одинаков в обеих темах. Знак на нём белый;
 *    порог для нетекстовой графики 3:1, и он держится по всему ходу —
 *    замеры в `SEND_STOPS`.
 *
 * 2. КОЛЬЦО СЧЁТЧИКА КОНТЕКСТА. Донор берёт его НЕ из ролей, а из сырой
 *    шкалы: дорожка neutral-300 #d4d4d4, значение neutral-500 #737373,
 *    одинаково в обеих темах. Следствие — в тёмной теме дорожка СВЕТЛЕЕ
 *    значения, то есть пройденная часть выглядит непройденной. Спецификация
 *    разведки отдельно отмечает, что это не ошибка замера.
 *
 *    Здесь взяты роли: значение `--t-ink-secondary`, дорожка `--t-canvas`.
 *
 *    ⚠️ Дорожка именно ХОЛСТОМ, и первая версия (`--t-line`) была НЕВЕРНОЙ —
 *    поймано глазами на скриншоте, а не автопроверкой. Чип счётчика у нас
 *    `bg-fill-strong`, а это в светлой теме ровно #ebebeb — то же значение,
 *    что и `--t-line`. Контраст дорожки к чипу выходил 1.00:1: дорожки не
 *    было видно вообще, и кольцо читалось не как шкала, а как полумесяц.
 *
 *    С холстом дорожка отличается от чипа на 1.11:1 в светлой и 1.40:1 в
 *    тёмной — это те же числа, что у погашенной дорожки `Meter` и `Gauge`
 *    в системе, то есть решение не новое. Главное же — пара «значение ↔
 *    дорожка»: 5.05:1 в светлой и 7.43:1 в тёмной, у донора 3.20:1 в обеих.
 *    Смысл ролей ровно в этом: пустая часть уходит к фону, пройденная — к
 *    тексту, и направление одинаково в обеих темах.
 *
 *    ⚠️ Но и с этим кольцо остаётся ЗНАЧКОМ, а не шкалой: 24 точки на холсте
 *    1920 с трёх метров не измеряют. Величину несёт напечатанный процент
 *    рядом — то же правило, что у `Gauge`, где знаменатель обязателен.
 *
 * 3. ПОЛОСКИ ЗАПИСИ. У донора accent-500 #2b7fff в обеих темах. Взята роль
 *    `--t-accent-fg` (#155dfc / #50a2ff): она и есть «акцент, которым можно
 *    красить мелкое», и она переворачивается. Донорский #2b7fff в тёмной
 *    теме дал бы 4.83:1 к карточке — прошёл бы, но роль честнее одного числа.
 *
 * ⚠️ СЛАБОЕ МЕСТО, КОТОРОЕ НАДО ЗНАТЬ ЗАРАНЕЕ. Донорский скин низкоконтрастный
 * ПО ЗАМЫСЛУ, и перенос это наследует. Замер границ между элементами
 * управления (функция `contrast` из lib/color.ts):
 *
 *   граница                                  светлая   тёмная
 *   кнопка вложения `bg-fill` ↔ капсула        1.09      1.09
 *   кнопка модели `bg-fill` ↔ капсула          1.09      1.09
 *   обводка микрофона `line` ↔ капсула         1.19      1.13
 *   чип счётчика `fill-strong` ↔ холст         1.11      1.40
 *   сама капсула `surface` ↔ холст             1.07      1.24
 *
 * Порог 3:1 не берёт НИ ОДНА. Это не дефект переноса — ровно так выглядит
 * донор, и ровно так выглядят интерфейсы этого класса. Но на проекторе с
 * засветкой круглые кнопки сольются с капсулой, и читаться останутся только
 * глифы внутри них:
 *
 *   глиф `ink-secondary` на капсуле            5.41      6.00
 *   глиф `ink-secondary` на `bg-fill`          4.96      6.53
 *   текст ввода `ink` на капсуле              19.80     14.50
 *   плейсхолдер `ink-tertiary` на капсуле      3.79      3.68  (кегль 24, порог 3)
 *   подписи состояния `ink-secondary`          5.05      7.43
 *   «57%» на чипе `fill-strong`                4.54      5.31
 *
 * Отсюда практический вывод: смысл кнопки несёт ГЛИФ, а не подложка, —
 * поэтому глифы здесь `Linear` и крупные (32 из 56 = 57%, у донора 20 из
 * 36 = 56%), а всё, что кнопка сообщает словом, напечатано словом.
 */

/* ═══════════════  Геометрия  ═══════════════ */

/**
 * Все размеры блока. Числа, а не Tailwind-классы, потому что от них считается
 * высота: `composerHeight` должна СЧИТАТЬ бюджет, а не примерять его.
 * Значения равны токенам сетки 4 и парам «радиус кнопки → высота».
 */
export const COMPOSER = {
  /** Высота капсулы. 12 + 56 + 12, пара `rounded-button-xl` */
  capsule: 80,
  /** Поле капсулы со всех сторон. Донор 8 */
  pad: 12,
  /** Зазор между частями капсулы. Донор 10 */
  gap: 16,
  /** Круглая кнопка: вложение, микрофон, отправка. Донор 36 */
  control: 56,
  /** Глиф в круглой кнопке. Донор 20 из 36 = 56%, у нас 32 из 56 = 57% */
  glyph: 32,
  /** Кнопка модели. Донор 32 */
  modelHeight: 48,
  /** Шеврон кнопки модели. Донор 18 */
  chevron: 28,
  /** Отступ правой группы от кнопки модели. Донор 6 */
  rightPad: 8,
  /** Зазор между микрофоном и отправкой. Донор 8 */
  rightGap: 12,
  /** Зазор между капсулой и строкой состояния. Донор 10 */
  rowGap: 16,
  /** Строка состояния: `text-body-m` 28 + 6 + 6. Донор 26 */
  status: 40,
  /** Иконка строки состояния. Донор 16 */
  statusIcon: 24,
  /** Зазор между кнопками строки состояния. Донор 12 */
  statusGap: 20,
  /** Зазор внутри кнопки строки состояния. Донор 4 */
  statusInner: 8,
  /** Кольцо счётчика контекста. Донор 16 */
  ring: 24,
  /** Строка «идёт работа» над капсулой */
  thinking: 32,
  /** Поле подложки-скриншота */
  plate: 48,
  /**
   * ⚠️ Насколько светящийся контур ВЫХОДИТ за габарит блока с каждой стороны.
   *
   * Ореол — обводка 24 (12 наружу) плюс размытие 12; 16 покрывает и то, и
   * другое. Замер подтверждает: в рабочем состоянии `scrollWidth` контейнера
   * больше `clientWidth` ровно на 16 с каждой стороны.
   *
   * Практическое следствие: блок в рабочем состоянии нельзя ставить вплотную
   * к краю рабочей области или к соседней колонке. Желоб сетки 24, то есть
   * 16 в него помещаются, но запаса остаётся 8 — поэтому на слайде рабочее
   * состояние ставится по центру с полем, а не встык.
   */
  glowSpill: 16,
} as const;

/** Ширина правой группы: pl 8 + 56 + 12 + 56. Нужна, чтобы посадить меню моделей */
const RIGHT_GROUP = COMPOSER.rightPad + COMPOSER.control + COMPOSER.rightGap + COMPOSER.control;

/* ── меню ── */

/** Ширина меню вложений. Донор 361 × 1.538 = 555 */
const ATTACH_WIDTH = 556;
/** Ширина меню моделей. Донор 266 × 1.538 = 409 */
const MODEL_WIDTH = 408;
/** Поле меню. Донор 8 и 10 */
const MENU_PAD = 12;
/**
 * Строка меню. Донор 32 (обычная) и 36 (плагины).
 *
 * У нас все строки ОДНОЙ высоты: `text-body-l` 32 + 6 + 6 = 44, что и есть
 * донорские 32 × 1.538 = 49 с поправкой на то, что наш бокс строки выше.
 * Донор различал плагины только потому, что там лежала растровая картинка
 * 24px; у нас во всех строках один и тот же глиф Solar, различать нечем.
 */
const MENU_ROW = 44;
/** Просвет между заголовком раздела и строками. Донор 8 */
const MENU_HEAD_GAP = 12;
/** Просвет между разделами. Донор 8 */
const MENU_SECTION_GAP = 12;
/** Глиф строки меню. Донор 20 */
const MENU_GLYPH = 32;
/** Знак провайдера в меню моделей. Донор 14 */
const MENU_BRAND = 24;
/** Заголовок раздела: `text-body-l` 24/32 */
const MENU_HEAD = 32;

/** Разделитель в меню моделей: донор 7 сверху, 12 снизу */
const MENU_RULE_TOP = 12;
const MENU_RULE_BOTTOM = 20;

/** Блок усилия: строка 32 + просвет 12 + дорожка с ручкой 24 + просвет 8 + подписи 28 */
const EFFORT_HEIGHT = 32 + 12 + 24 + 8 + 28;

/** Высота меню вложений при заданном числе строк по разделам */
export function attachMenuHeight(sections: readonly { rows: readonly unknown[] }[]) {
  const body = sections.reduce(
    (sum, s) => sum + MENU_HEAD + MENU_HEAD_GAP + s.rows.length * MENU_ROW,
    0,
  );
  return MENU_PAD * 2 + body + MENU_SECTION_GAP * Math.max(0, sections.length - 1);
}

/** Высота меню моделей */
export function modelMenuHeight(rows: number, effort: boolean) {
  const head = MENU_HEAD + MENU_HEAD_GAP + rows * MENU_ROW;
  const tail = effort ? MENU_RULE_TOP + 1 + MENU_RULE_BOTTOM + EFFORT_HEIGHT : 0;
  return MENU_PAD * 2 + head + tail;
}

/**
 * Полная высота блока.
 *
 * ⚠️ Считать её обязательно, а не прикидывать: бюджет блока в `ContentSlide`
 * — 604 (`CARD_BUDGET`), и раскрытое меню вложений из семи строк съедает
 * почти весь. Числа при умолчаниях:
 *
 *   покой / запись / модель-в-покое   136
 *   работа (строка «Thinking»)        184
 *   меню моделей (4 + усилие)       381 + 16 + 136 = 533
 *   меню вложений (3 + 4)           432 + 16 + 136 = 584
 *   меню вложений + подложка        584 + 96       = 680  ← НЕ ВЛЕЗАЕТ
 *
 * Отсюда правило: слайд с раскрытым меню вложений — отдельный слайд без
 * подложки и без лида. Ровно это и говорит спецификация разведки.
 */
export function composerHeight({
  state = "rest",
  status = true,
  mount = "bare",
  attachSections,
  modelRows = 4,
  effort = true,
}: {
  state?: ComposerState;
  status?: boolean;
  mount?: ComposerMount;
  attachSections?: readonly { rows: readonly unknown[] }[];
  modelRows?: number;
  effort?: boolean;
} = {}) {
  let h = COMPOSER.capsule;
  if (status) h += COMPOSER.rowGap + COMPOSER.status;
  if (state === "working") h += COMPOSER.thinking + COMPOSER.rowGap;
  if (state === "attach" && attachSections) h += attachMenuHeight(attachSections) + COMPOSER.rowGap;
  if (state === "model") h += modelMenuHeight(modelRows, effort) + COMPOSER.rowGap;
  if (mount === "plate") h += COMPOSER.plate * 2;
  return h;
}

/** Бюджет высоты блока в `ContentSlide` — тот же, что у карточек волны */
export const COMPOSER_BUDGET = CARD_BUDGET;

/* ═══════════════  Краски  ═══════════════ */

/**
 * Градиент кнопки отправки — донорский, сверху вниз, одинаков в обеих темах.
 *
 * Записан стопами, а не строкой, чтобы контраст белого знака можно было
 * проверить ПО ВСЕМУ ХОДУ через `runContrast`, а не по двум концам. Числа —
 * в витрине «Карточки/Поле ввода».
 */
export const SEND_STOPS = [
  { offset: 0, color: "#2b7fff", opacity: 1 },
  { offset: 1, color: "#155dfc", opacity: 1 },
] as const;

/**
 * Градиент светящегося контура рабочего состояния — донорский, слева направо.
 *
 * Средний стоп у донора записан как rgb(150,119,200); здесь тот же цвет
 * в hex — #9677c8. Перевод точный, не округление.
 */
export const GLOW_STOPS = [
  { offset: 0, color: "#5eead4" },
  { offset: 0.3, color: "#46baec" },
  { offset: 0.5, color: "#9677c8" },
  { offset: 0.7, color: "#e633a4" },
  { offset: 1, color: "#00faa7" },
] as const;

/**
 * Высоты четырёх полосок записи.
 *
 * Донорский кадр: 3.7 / 6.4 / 5.5 / 6.7. Это снимок анимации, поэтому взяты
 * не сами числа, а их ОТНОШЕНИЯ к максимуму (0.552 / 0.955 / 0.821 / 1.000),
 * умноженные на нашу базу 24 — высоту, которая помещается в глиф 32 с полем.
 * Разные высоты обязательны: четыре одинаковые палки без движения читаются
 * как решётка, а не как звук.
 */
export const MIC_BARS = [13, 23, 20, 24] as const;
/** Ширина полоски записи и зазор. Донор 2.5 и 2.5 при глифе 20 */
const MIC_BAR = 4;

/* ═══════════════  Типы  ═══════════════ */

export type ComposerState = "rest" | "attach" | "model" | "recording" | "working";
export type ComposerMount = "bare" | "plate";

export interface ComposerStatus {
  /** Ветка: «Main» */
  branch: string;
  /** Папка проекта: «project-sea» */
  project: string;
  /** Режим агента: «Agent» */
  mode: string;
  /** Заполнение контекста, доля 0…1. Печатается процентом и рисуется кольцом */
  context: number;
}

export interface ComposerMenuRow {
  icon: SolarIcon;
  label: string;
  /** Пояснение справа от названия. Донорское «Set a goal for faster results» */
  note?: string;
}

export interface ComposerMenuSection {
  title: string;
  rows: readonly ComposerMenuRow[];
}

export interface ComposerModelRow {
  label: string;
  /** Знак провайдера справа. Только из `BRAND_PATHS` — рисовать нельзя */
  brand?: BrandSlug;
  selected?: boolean;
}

export interface ComposerEffort {
  /** Название: «Effort» */
  label: string;
  /** Выбранное значение ПЕЧАТАЕТСЯ: «Medium». Ползунок его не сообщает */
  value: string;
  /** Положение ручки, доля 0…1 */
  position: number;
  /** Подписи концов: «Faster» / «Smarter» */
  from: string;
  to: string;
}

export interface ComposerCardProps {
  /** Ширина блока. 828 = `col-span-6` — пропорция ближе всего к донору */
  width?: number;
  state?: ComposerState;
  /** Текст в поле. Пусто — печатается плейсхолдер третичным цветом */
  text?: string;
  placeholder?: string;
  /** Подпись кнопки модели */
  model?: string;
  /** Строка состояния. `false` — блок из одной капсулы (донорский `<Composer />`) */
  status?: ComposerStatus | false;
  /** Подпись рабочего состояния: «Thinking 2.0s» */
  thinking?: string;
  /** Разделы меню вложений. Рисуются при `state="attach"` */
  attachMenu?: readonly ComposerMenuSection[];
  /** Строки меню моделей. Рисуются при `state="model"` */
  modelMenu?: readonly ComposerModelRow[];
  /** Блок усилия под разделителем в меню моделей */
  effort?: ComposerEffort | false;
  /** `plate` — холст с `shadow-thumbnail`: рамка «это снимок экрана» */
  mount?: ComposerMount;
  /** Вложенная тема: тёмный композер на светлом слайде и наоборот */
  theme?: SlideTheme;
  className?: string;
  style?: CSSProperties;
}

/* ═══════════════  Данные донора  ═══════════════ */

/** Меню вложений — тексты и разделы со страницы донора */
export const COMPOSER_ATTACH_MENU: readonly ComposerMenuSection[] = [
  {
    title: "Add",
    rows: [
      { icon: Folder, label: "Files and folders" },
      { icon: Target, label: "Goal", note: "Set a goal for faster results" },
      { icon: ClipboardList, label: "Plan mode", note: "Manage complex tasks" },
    ],
  },
  {
    title: "Plugins",
    rows: [
      { icon: DocumentText, label: "Documents", note: "Create and edit documents" },
      { icon: Widget, label: "Spreadsheets", note: "Generate spreadsheets" },
      { icon: PresentationGraph, label: "Presentations", note: "Create marketing assets" },
      { icon: CodeSquare, label: "Code blocks", note: "Write and edit existing code" },
    ],
  },
];

/**
 * Меню моделей — строки со страницы донора.
 *
 * Знаки провайдеров берутся из `BRAND_PATHS` (simple-icons, CC0). У «Fable 5»
 * знака нет и придумывать его нельзя — строка идёт без знака. Это заметно и
 * это правильно: подделка чужой марки хуже пустого места.
 */
export const COMPOSER_MODEL_MENU: readonly ComposerModelRow[] = [
  { label: "Composer 2.5", brand: "cursor" },
  { label: "GPT-5.6 Sol", brand: "openai" },
  { label: "Fable 5", selected: true },
  { label: "Sonnet 5", brand: "claude" },
];

/** Ползунок усилия со страницы донора */
export const COMPOSER_EFFORT: ComposerEffort = {
  label: "Effort",
  value: "Medium",
  position: 0.5,
  from: "Faster",
  to: "Smarter",
};

/* ═══════════════  Части  ═══════════════ */

/** Круглая кнопка капсулы. Три вида заливки — ровно как у донора */
function ControlButton({
  variant,
  children,
}: {
  variant: "fill" | "outline" | "send";
  children: React.ReactNode;
}) {
  /* Кнопка отправки — скруглённый квадрат (решение заказчика, расходится
     с круглой донорской), остальные органы управления остаются круглыми:
     разная форма отделяет действие от переключателей вернее, чем цвет */
  const base = `flex shrink-0 items-center justify-center ${
    variant === "send" ? "rounded-tile" : "rounded-capsule"
  }`;
  const skin =
    /* `bg-fill-strong`, а не `bg-fill`: кнопка лежит на карточке, где
       `bg-fill` после разворота поверхностей даёт ΔE 0.69 и пропадает */
    variant === "fill"
      ? "bg-fill-strong"
      : variant === "outline"
        ? "border-line border bg-surface"
        : "";

  return (
    <span
      className={`${base} ${skin}`}
      style={{
        width: COMPOSER.control,
        height: COMPOSER.control,
        /*
         * Градиент кнопки отправки — единственный градиент интерфейса донора.
         * Записан из стопов, чтобы значение и проверка контраста шли из
         * одного места: `SEND_STOPS` уходит и сюда, и в витрину.
         */
        background:
          variant === "send"
            ? `linear-gradient(180deg, ${SEND_STOPS.map((s) => `${s.color} ${s.offset * 100}%`).join(", ")})`
            : undefined,
      }}
    >
      {children}
    </span>
  );
}

/** Кольцо счётчика контекста. Донорская геометрия сохранена в viewBox 16×16 */
function ContextRing({ value }: { value: number }) {
  const r = 6;
  const circumference = 2 * Math.PI * r;
  const filled = circumference * Math.min(1, Math.max(0, value));

  return (
    <svg
      viewBox="0 0 16 16"
      width={COMPOSER.ring}
      height={COMPOSER.ring}
      className="shrink-0"
      style={{ transform: "rotate(-90deg)" }}
      aria-hidden="true"
    >
      {/*
       * Дорожка — `--t-canvas`, и это не «фон вместо цвета», а решение по
       * замеру. Разбор — в шапке файла, у пункта про кольцо.
       */}
      <circle cx="8" cy="8" r={r} fill="none" stroke="var(--t-canvas)" strokeWidth={2.5} />
      {/* Значение — `--t-ink-secondary`: темнее дорожки в светлой теме,
          светлее в тёмной. У донора обе краски сырые и в тёмной теме
          пройденная часть выглядит непройденной */}
      <circle
        cx="8"
        cy="8"
        r={r}
        fill="none"
        stroke="var(--t-ink-secondary)"
        strokeWidth={2.5}
        strokeDasharray={`${filled.toFixed(4)} ${(circumference - filled).toFixed(4)}`}
      />
    </svg>
  );
}

/** Кнопка строки состояния: иконка, подпись, при необходимости шеврон */
function StatusButton({
  icon: Icon,
  label,
  chevron,
}: {
  icon: SolarIcon;
  label: string;
  chevron?: boolean;
}) {
  /*
   * ⚠️ `min-w-0` плюс `truncate` на подписи — обязательны, и это не запас
   * прочности. Строка состояния разносит две группы по краям, поэтому при
   * длинном имени проекта она не «разъезжается», а РАСТИТ ВЕСЬ БЛОК: замер
   * первой сборки дал 58 точек за пределами объявленной ширины 828, то есть
   * на слайде блок залез бы в желоб и в соседнюю колонку.
   *
   * Обрезка многоточием теряет хвост имени, но не трогает соседа. Из двух зол
   * это меньшее: потерянный хвост виден как многоточие, а наехавший блок
   * читается как ошибка сборки.
   */
  return (
    <span
      className="text-body-m text-ink-secondary flex min-w-0 items-center"
      style={{ gap: COMPOSER.statusInner }}
    >
      <span className="flex shrink-0 items-center">
        <Icon size={COMPOSER.statusIcon} weight="Linear" color="var(--t-ink-secondary)" />
      </span>
      <span className="min-w-0 truncate">{label}</span>
      {chevron ? (
        <span className="flex shrink-0 items-center">
          <AltArrowDown size={COMPOSER.statusIcon} weight="Linear" color="var(--t-ink-secondary)" />
        </span>
      ) : null}
    </span>
  );
}

/** Строка меню: глиф, название, пояснение */
function MenuRow({ row }: { row: ComposerMenuRow }) {
  const Icon = row.icon;
  return (
    <div
      className="flex items-center rounded-card px-2"
      style={{ height: MENU_ROW, gap: MENU_HEAD_GAP }}
    >
      <Icon size={MENU_GLYPH} weight="Linear" color="var(--t-ink-secondary)" />
      <span className="text-body-l text-ink shrink-0 whitespace-nowrap">{row.label}</span>
      {row.note ? (
        <span className="text-body-m text-ink-secondary min-w-0 truncate">{row.note}</span>
      ) : null}
    </div>
  );
}

/** Меню вложений — раскрыто, потому что раскрыться ему в PDF нечем */
function AttachMenu({ sections }: { sections: readonly ComposerMenuSection[] }) {
  return (
    <div
      className="bg-surface shadow-overlay flex flex-col rounded-panel"
      style={{
        width: ATTACH_WIDTH,
        padding: MENU_PAD,
        gap: MENU_SECTION_GAP,
        height: attachMenuHeight(sections),
      }}
    >
      {sections.map((section) => (
        /*
         * ⚠️ Просвета между СТРОКАМИ здесь нет, и это не забывчивость.
         * Просвет стоит только под заголовком раздела — через `marginBottom`,
         * а не через `gap` колонки. Разница не косметическая: `gap` раздал бы
         * тот же просвет и между строками, и меню стало бы на 60 точек выше
         * того, что считает `attachMenuHeight`. Ровно это и случилось при
         * первой сборке — замер показал переполнение контейнера на 48.
         */
        <div key={section.title} className="flex flex-col">
          {/* Заголовок раздела с отступом слева — как у донора: он равен
              горизонтальному полю строки, поэтому текст заголовка стоит на
              одной вертикали с глифами строк */}
          <span
            className="text-body-l text-ink-secondary flex items-center px-2"
            style={{ height: MENU_HEAD, marginBottom: MENU_HEAD_GAP }}
          >
            {section.title}
          </span>
          {section.rows.map((row) => (
            <MenuRow key={row.label} row={row} />
          ))}
        </div>
      ))}
    </div>
  );
}

/** Меню моделей — раскрыто, выбранная строка подсвечена заливкой */
function ModelMenu({
  rows,
  effort,
  title = "Models",
}: {
  rows: readonly ComposerModelRow[];
  effort: ComposerEffort | false;
  title?: string;
}) {
  return (
    <div
      className="bg-surface shadow-overlay flex flex-col rounded-panel"
      style={{
        width: MODEL_WIDTH,
        padding: MENU_PAD,
        height: modelMenuHeight(rows.length, Boolean(effort)),
      }}
    >
      <span
        className="text-body-l text-ink-secondary flex items-center px-2"
        style={{ height: MENU_HEAD, marginBottom: MENU_HEAD_GAP }}
      >
        {title}
      </span>

      {rows.map((row) => (
        <div
          key={row.label}
          className={`flex items-center justify-between rounded-card px-2 ${
            row.selected ? "bg-fill-strong" : ""
          }`}
          style={{ height: MENU_ROW, gap: MENU_HEAD_GAP }}
        >
          <span className="text-body-l text-ink min-w-0 truncate">{row.label}</span>
          {/*
           * Знак провайдера — только из набора. Бренда нет → строка идёт без
           * знака, и это заметно намеренно: нарисованный от руки чужой знак
           * на клиентском слайде хуже пустого места.
           */}
          {row.brand ? <BrandMark brand={row.brand} size={MENU_BRAND} tone="ink" /> : null}
        </div>
      ))}

      {effort ? (
        <>
          {/* Разделитель во всю ширину меню: отрицательные поля съедают
              внутреннее поле, как у донора */}
          <div
            className="bg-line shrink-0"
            style={{
              height: 1,
              marginLeft: -MENU_PAD,
              marginRight: -MENU_PAD,
              marginTop: MENU_RULE_TOP,
              marginBottom: MENU_RULE_BOTTOM,
            }}
          />
          <div className="flex flex-col px-2">
            <div
              className="flex items-center justify-between"
              style={{ height: MENU_HEAD, marginBottom: MENU_HEAD_GAP }}
            >
              <span className="text-body-l text-ink-secondary">{effort.label}</span>
              {/*
               * ⚠️ Значение ПЕЧАТАЕТСЯ. Положение ручки его не сообщает:
               * ползунок без движения и без подписи — просто точка на палке,
               * из которой «Medium» не вычитывается.
               */}
              <span className="text-body-l text-ink">{effort.value}</span>
            </div>

            <div className="relative flex items-center" style={{ height: 24 }}>
              <div className="bg-fill-strong w-full rounded-capsule" style={{ height: 8 }} />
              {/*
               * Ручка — `bg-action`, а не «белая с тенью, как у донора».
               * Замер: белая ручка (`bg-surface`) на дорожке `bg-fill-strong`
               * даёт 1.19:1 в светлой теме и 1.13:1 в тёмной — в тёмной её
               * попросту не видно, а тень в системе это волосяное кольцо
               * цветом `line`, то есть ровно цветом дорожки.
               *
               * `action` (#0a0a0a / #fafafa) переворачивается и даёт 16.61:1
               * и 12.83:1 к дорожке. Роль подходит и по смыслу: `action` — то,
               * что нажимают, а ручка ползунка единственное такое место меню.
               */}
              <span
                className="bg-action absolute rounded-capsule"
                style={{
                  width: 24,
                  height: 24,
                  left: `${effort.position * 100}%`,
                  marginLeft: -12,
                }}
                aria-hidden="true"
              />
            </div>

            <div
              className="text-body-m text-ink-secondary flex items-center justify-between"
              style={{ height: 28, marginTop: 8 }}
            >
              <span>{effort.from}</span>
              <span>{effort.to}</span>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
}

/**
 * Светящийся контур рабочего состояния.
 *
 * Две обводки вместо донорских трёх — разбор в шапке файла. Дуга занимает
 * треть периметра (`pathLength=100`, штрих 33.33), то есть ровно ту долю,
 * которую донор показывал в среднем кадре анимации.
 *
 * ⚠️ КОНТУР — УКРАШЕНИЕ, А НЕ СООБЩЕНИЕ, и особенно в светлой теме. Замер
 * донорского градиента по всему ходу (101 точка):
 *
 *   к белой капсуле  худший 1.38 (бирюзовый конец), лучший 4.16
 *   к тёмной капсуле худший 3.64, лучший 10.98
 *
 * То есть в светлой теме два конца дуги из пяти стопов практически не видны.
 * Именно поэтому рабочее состояние ОБЯЗАНО нести подпись «Thinking 2.0s»:
 * убрать её и оставить один контур — значит на светлом слайде не сообщить
 * ничего. В тёмной теме контур честно берёт порог 3:1 по всему ходу.
 */
function GlowOutline({ width }: { width: number }) {
  const uid = useId();
  const gradient = `glow-${uid}`;
  const soft = `glow-soft-${uid}`;
  const sharp = `glow-sharp-${uid}`;
  const pad = COMPOSER.glowSpill;
  const h = COMPOSER.capsule;

  return (
    <svg
      className="pointer-events-none absolute"
      style={{ left: -pad, top: -pad, width: width + pad * 2, height: h + pad * 2, opacity: 0.7 }}
      viewBox={`${-pad} ${-pad} ${width + pad * 2} ${h + pad * 2}`}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={gradient} x1="0" y1="0" x2="1" y2="0">
          {GLOW_STOPS.map((s) => (
            <stop key={s.offset} offset={s.offset} stopColor={s.color} stopOpacity={1} />
          ))}
        </linearGradient>
        <filter id={soft} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation={12} />
        </filter>
        <filter id={sharp} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation={0.75} />
        </filter>
      </defs>

      {/* Ореол: широкий и мягкий. Донорские 32/14 уведены до 24/12 — на
          холсте 1920 крупная мягкая площадь проступает полосами */}
      <rect
        x={0}
        y={0}
        width={width}
        height={h}
        rx={h / 2}
        fill="none"
        stroke={`url(#${gradient})`}
        strokeWidth={24}
        strokeOpacity={0.28}
        pathLength={100}
        strokeDasharray="33.33 66.67"
        strokeDashoffset={-20}
        filter={`url(#${soft})`}
      />
      {/* Острая дуга: она и несёт форму */}
      <rect
        x={0}
        y={0}
        width={width}
        height={h}
        rx={h / 2}
        fill="none"
        stroke={`url(#${gradient})`}
        strokeWidth={4}
        pathLength={100}
        strokeDasharray="33.33 66.67"
        strokeDashoffset={-20}
        filter={`url(#${sharp})`}
      />
    </svg>
  );
}

/* ═══════════════  Блок  ═══════════════ */

export default function ComposerCard({
  width = 828,
  state = "rest",
  text,
  placeholder = "Ask me anything",
  model = "Fable 5",
  status = { branch: "Main", project: "project-sea", mode: "Agent", context: 0.57 },
  thinking = "Thinking 2.0s",
  attachMenu = COMPOSER_ATTACH_MENU,
  modelMenu = COMPOSER_MODEL_MENU,
  effort = COMPOSER_EFFORT,
  mount = "bare",
  theme,
  className,
  style,
}: ComposerCardProps) {
  const recording = state === "recording";
  const working = state === "working";

  const body = (
    <div className="flex flex-col" style={{ width }}>
      {/* ── меню: рисуются раскрытыми, потому что раскрыть их в PDF нечем ── */}
      {state === "attach" ? (
        <div style={{ paddingLeft: COMPOSER.pad, marginBottom: COMPOSER.rowGap }}>
          <AttachMenu sections={attachMenu} />
        </div>
      ) : null}

      {state === "model" ? (
        /*
         * Меню моделей встаёт правым краем под правый край кнопки модели.
         * Отступ справа считается, а не подбирается: поле капсулы 12 плюс
         * ширина правой группы 132 — ровно столько лежит правее кнопки.
         */
        <div
          className="flex justify-end"
          style={{
            paddingRight: COMPOSER.pad + RIGHT_GROUP,
            marginBottom: COMPOSER.rowGap,
          }}
        >
          <ModelMenu rows={modelMenu} effort={effort} />
        </div>
      ) : null}

      {/* ── строка «идёт работа» ── */}
      {working ? (
        <div
          className="text-body-m text-ink-secondary flex items-center"
          style={{
            height: COMPOSER.thinking,
            marginBottom: COMPOSER.rowGap,
            paddingLeft: COMPOSER.pad + COMPOSER.control / 2 - COMPOSER.glyph / 2,
            gap: COMPOSER.statusInner,
          }}
        >
          <MagicStick3 size={COMPOSER.statusIcon} weight="Bold" color="var(--t-accent-fg)" />
          {thinking}
        </div>
      ) : null}

      {/* ── капсула ── */}
      <div className="relative shrink-0" style={{ height: COMPOSER.capsule }}>
        {working ? <GlowOutline width={width} /> : null}

        <div
          className="bg-surface shadow-card relative flex h-full items-center rounded-capsule"
          style={{ padding: COMPOSER.pad, gap: COMPOSER.gap }}
        >
          {/* вложение */}
          <ControlButton variant="fill">
            <Paperclip size={COMPOSER.glyph} weight="Linear" color="var(--t-ink-secondary)" />
          </ControlButton>

          {/*
           * Поле ввода. Каретки нет: застывшая палка читается как артефакт
           * печати. Текст пустой → плейсхолдер третичным цветом — законно
           * ровно потому, что кегль здесь 24 (на 20 третичный запрещён).
           */}
          <span
            className={`text-body-l min-w-0 flex-1 truncate ${
              text ? "text-ink" : "text-ink-tertiary"
            }`}
          >
            {text || placeholder}
          </span>

          {/* кнопка модели */}
          <span
            className="bg-fill-strong text-body-l text-ink flex shrink-0 items-center rounded-capsule whitespace-nowrap"
            style={{
              height: COMPOSER.modelHeight,
              paddingLeft: COMPOSER.gap,
              paddingRight: COMPOSER.pad,
              gap: 4,
            }}
          >
            {model}
            <AltArrowDown size={COMPOSER.chevron} weight="Linear" color="var(--t-ink-secondary)" />
          </span>

          {/* правая группа */}
          <span
            className="flex shrink-0 items-center"
            style={{ paddingLeft: COMPOSER.rightPad, gap: COMPOSER.rightGap }}
          >
            <ControlButton variant="outline">
              {recording ? (
                /*
                 * Запись. Четыре полоски разной высоты — донорские отношения,
                 * см. MIC_BARS. Без движения это читается как эквалайзер;
                 * четыре одинаковые палки читались бы как решётка.
                 */
                <span
                  className="flex items-center"
                  style={{ gap: MIC_BAR, height: COMPOSER.glyph }}
                  aria-hidden="true"
                >
                  {MIC_BARS.map((barHeight, i) => (
                    <span
                      key={i}
                      className="rounded-capsule"
                      style={{
                        width: MIC_BAR,
                        height: barHeight,
                        background: "var(--t-accent-fg)",
                      }}
                    />
                  ))}
                </span>
              ) : (
                <Microphone3 size={COMPOSER.glyph} weight="Linear" color="var(--t-ink-secondary)" />
              )}
            </ControlButton>

            <ControlButton variant="send">
              <ArrowUp size={COMPOSER.glyph} weight="Linear" color="#ffffff" />
            </ControlButton>
          </span>
        </div>
      </div>

      {/* ── строка состояния ── */}
      {status ? (
        <div
          className="flex shrink-0 items-center justify-between"
          style={{
            height: COMPOSER.status,
            marginTop: COMPOSER.rowGap,
            paddingLeft: COMPOSER.pad,
            paddingRight: COMPOSER.pad,
            gap: COMPOSER.statusGap,
          }}
        >
          <span className="flex min-w-0 items-center" style={{ gap: COMPOSER.statusGap }}>
            <StatusButton icon={BranchingPathsUp} label={status.branch} />
            <StatusButton icon={Folder} label={status.project} chevron />
          </span>

          <span className="flex min-w-0 items-center" style={{ gap: COMPOSER.statusGap }}>
            <StatusButton icon={MagicStick3} label={status.mode} chevron />
            {/*
             * Чип счётчика контекста. Процент напечатан рядом с кольцом —
             * кольцо 24px с 3-точечной обводкой на слайде читается как
             * значок, а не как шкала, и величину несёт именно число.
             */}
            <span
              className="bg-fill-strong text-body-m text-ink-secondary flex shrink-0 items-center rounded-capsule tabular-nums"
              style={{
                gap: COMPOSER.statusInner,
                paddingLeft: 8,
                paddingRight: 12,
                paddingTop: 4,
                paddingBottom: 4,
              }}
            >
              <ContextRing value={status.context} />
              {Math.round(status.context * 100)}%
            </span>
          </span>
        </div>
      ) : null}
    </div>
  );

  return (
    <div
      data-theme={theme}
      className={[
        "inline-flex",
        theme ? "text-ink" : "",
        /*
         * Подложка-скриншот. `shadow-thumbnail` в системе и означает «снимок
         * продукта»; холст под капсулой повторяет фон донорской страницы,
         * поэтому капсула `bg-surface` читается ровно так же, как у него.
         *
         * ⚠️ Подложка — это РАМКА, а не контрастная подкладка, и путать не
         * надо. На содержательном слайде её заливка совпадает с фоном слайда
         * (обе `canvas`), поэтому видна только волосяная обводка: 1.11:1 в
         * светлой теме и 1.40:1 в тёмной. Её работа — очертить границу кадра,
         * чтобы композер читался как изображение чужого продукта, а не как
         * элемент самого слайда. Заменить `surface-muted` не помогает:
         * 1.06:1 к холсту светлой темы, то есть ещё хуже.
         *
         * На слайде, где под блоком лежит карточка или фотография, подложка не
         * нужна вовсе — там граница уже есть.
         */
        mount === "plate" ? "bg-canvas shadow-thumbnail rounded-hero" : "",
        className,
      ]
        .filter(Boolean)
        .join(" ")}
      style={{ padding: mount === "plate" ? COMPOSER.plate : undefined, ...style }}
    >
      {body}
    </div>
  );
}
