import { BOARD_CHART, BOARD_SERIES, BOARD_SERIES_ACTIVE } from "../../lib/boardPalette";
import type { SlideTheme } from "../../slide/Slide";
import {
  AXIS_HALF_BOX,
  AXIS_HANG_BOTTOM,
  AXIS_SIZE,
  AXIS_TRACKING,
  AXIS_WEIGHT,
  MARK_SIZE,
  MARK_TRACKING,
  MARK_WEIGHT,
  X_GAP,
  Y_GAP,
  axisTextWidth,
  cardAxisKeep,
  cardAxisTicks,
  cardTextWidth,
  clampLabel,
  defaultTick,
  useRemeasureOnFont,
} from "./axis";
import { placeMark, type Box } from "./scatterMarks";
import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
  type LegendTile,
} from "./shell";

/**
 * Карточка «Точечная» — перенос донорского точечного графика целиком.
 *
 * Спецификация замеров донора — во внутреннем разборе. Обвязка —
 * [`shell.tsx`](./shell.tsx), общие оси и замерщик текста — [`axis.ts`](./axis.ts).
 * Здесь только середина карточки: поле построения, сетка, круги, ключ площади.
 *
 *   ┌─ CardShell ───────────────────────────────────────────────┐
 *   │  Revenue per account                    [🗓 This quarter]  │  ← шапка shell
 *   │  742  [+6,8%]                                             │
 *   │                                                           │
 *   │  1,7K ┆    ┆    ┆    ┆         ⬤                          │  ← ScatterPlot
 *   │  1,1K ┆    ┆  ◯ ┆ ⬤  ┆   ◯                                │
 *   │   550 ┆ ◯  ┆ ⬤  ┆    ┆                                    │
 *   │     0 ┆────┆────┆────┆────                                │
 *   │       0    25   50   75   100                             │
 *   │  Revenue      Площадь — Accounts · 24…140        Sessions │
 *   │  ▪ Starter · avg   ▪ Growth · avg   ▪ Scale · avg         │  ← легенда shell
 *   │  270               783              1 388                 │
 *   └───────────────────────────────────────────────────────────┘
 *
 * ═══════════════════════════════════════════════════════════════════
 * Почему это НЕ обёртка над `blocks/scatter.tsx`
 * ═══════════════════════════════════════════════════════════════════
 *
 * Слайдовый блок [`scatter.tsx`](../scatter.tsx) отвечает на тот же вопрос
 * («связаны ли два показателя»), и все его СМЫСЛОВЫЕ решения перенесены сюда
 * дословно — формула площади, кольцо-просвет, обязательные названия осей,
 * отказ от линии тренда и от наведения. Но переиспользовать сам компонент
 * нельзя, и причин ровно четыре, все измеримые:
 *
 *   1. ЦВЕТ. `ScatterChart` жёстко берёт `CHART_SERIES_SCATTER` — системную
 *      палитру, проверенную валидатором. Карточка обязана носить краски
 *      донора (`BOARD_SERIES`), заказчик просил «как на скриншотах».
 *      Смешивать наборы в одном деке запрещено (шапка `boardPalette.ts`).
 *   2. ВЫСОТА. Геометрия `ScatterChart` по умолчанию 1680×520, поля 56/76/
 *      140/56. В карточке графику остаётся 284 точки (полная ширина) или
 *      316 (половина) — поля блока съели бы почти всё поле построения.
 *   3. КЛЮЧ ПЛОЩАДИ. Блок ставит вложенные круги в правое поле SVG: два
 *      круга наибольшего радиуса — это 80 точек по высоте и ~160 по ширине.
 *      В карточке правого поля нет вовсе (см. «Пропорции» ниже), а 80 точек
 *      по высоте — это 37% поля построения (замер: 218). Ключ текстовый.
 *   4. ПОДПИСИ ТОЧЕК. Блок раскладывает подпись у КАЖДОЙ точки движком
 *      из четырёх кандидатов с проверкой пересечений. При высоте поля 218
 *      подписи кеглем 26 встанут друг на друга, и движок просто выбросит
 *      большую их часть. У донора подписей точек нет вовсе — их показывало
 *      наведение; здесь подписываются 1–2 ключевые точки через `marks`.
 *
 * Общий модуль под обе формы завести нельзя по той же причине, по которой
 * у карточек волны есть свой `axis.ts`: у блока и у карточки разные шкалы
 * кеглей, разные палитры и разные бюджеты высоты. Общим остаётся ЗНАНИЕ,
 * и оно вынесено в комментарии, а не в код.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ПЛОЩАДЬ, А НЕ ДИАМЕТР. Формула
 * ═══════════════════════════════════════════════════════════════════
 *
 *   r(v) = R_MAX · √(v / v_max),   но не меньше R_MIN
 *
 * Глаз читает ПЯТНО, то есть площадь: S = π·r². Если положить радиус
 * пропорциональным величине (r ∝ v), площадь пойдёт как КВАДРАТ величины:
 * вдвое большее значение займёт вчетверо большее пятно, втрое большее —
 * вдевятеро. Корень возвращает пропорцию площади самой величине:
 *
 *   S(v) / S(v_max) = π·r(v)² / π·R_MAX² = v / v_max
 *
 * Проверка на числах историй (24 / 60 / 140 клиентов при R_MAX 24 —
 * замеренный радиус половинной карточки):
 *
 *   величина   r = 24·√(v/140)   S = π·r²    S / S_max   v / v_max
 *   140            24.00           1810        1.000       1.000   ✓
 *    60            15.71            776        0.429       0.429   ✓
 *    24             9.94            310        0.171       0.171   ✓
 *
 * Тот же набор радиусом-пропорционально дал бы 24 / 10.29 / 4.11 и площади
 * 1.000 / 0.184 / 0.029 — точка на 60 клиентов выглядела бы впятеро мельче
 * вместо чуть больше чем вдвое. Ровно за это в системе уже отвергнуты трапеция воронки
 * (`blocks/stages.tsx`) и круговая диаграмма.
 *
 * Отсчёт ведётся от НУЛЯ, а не от наименьшего значения набора: у площади
 * нет «расстояний между», она читается только как доля целого. Растянуть
 * радиусы между min и max набора выглядит наглядно, но тогда пятна
 * перестают быть долями.
 *
 * ⚠️ Пол R_MIN пропорцию НАРУШАЕТ: пятно точки, попавшей под пол, больше
 * своей доли. Это осознанный размен на различимость (круг меньше 16 точек
 * в поперечнике с трёх метров не отличается от точки), и он ловится
 * предупреждением в разработке: если под пол ушла часть набора, разброс
 * данных шире, чем эта форма способна показать.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ПРОПОРЦИИ. Карточке нужна ПОЛОВИНА ширины, а не вся
 * ═══════════════════════════════════════════════════════════════════
 *
 * У точечной диаграммы форма облака — и есть содержание. Растянутое по
 * горизонтали поле кладёт облако на бок: одна и та же зависимость на поле
 * 3:1 читается как крутая, на поле 8:1 — как пологая. Замер полей:
 *
 *   размер карточки        поле построения    пропорция   донор 3.09:1
 *   full 1680, легенда      1542 × 189           8.16:1     ✗ втрое площе
 *   half  828, легенда       702 × 218           3.22:1     ✓ донорская
 *
 * Числа сняты в 1:1 по крайним линиям сетки (витрина «Карточки/Точечная»,
 * истории «Карточка» и «Потолок»), а не посчитаны по формуле.
 *
 * Поэтому `size="half"` — ЗНАЧЕНИЕ ПО УМОЛЧАНИЮ этой карточки, в отличие
 * от остальных карточек волны. Во всю ширину она собирается, но в
 * разработке об этом предупреждает: там она честна к числам и лжёт про
 * форму связи.
 *
 * Заполнить лишнюю ширину нечем: ограничить поле донорской пропорцией
 * значило бы отдать ему 189 × 3.09 = 584 точки из 1542 и оставить внутри
 * карточки 958 точек пустоты — это не «воздух», это дефект вёрстки. Правильное лекарство — две половинные карточки рядом,
 * ровно как советует шапка `shell.tsx`.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ЦВЕТ. Решение заказчика — читать целиком
 * ═══════════════════════════════════════════════════════════════════
 *
 * Краски донорские: Starter `#9ae600` (lime-400), Growth `#3392ff`, Scale
 * `#c27aff` (purple-400); обводка круга — «активный» вариант той же семьи
 * (`#7ccf00` / `#2b7fff` / `#ad46ff`), как на скриншоте. Системная
 * `CHART_SERIES_SCATTER` не берётся намеренно.
 *
 * Замер (`contrast` из lib/color.ts; заливка композитится с фоном карточки
 * по донорской непрозрачности 0.85). Порог WCAG 1.4.11 для нетекстовой
 * графики — 3:1:
 *
 *   что                            светлая #ffffff   тёмная #262626
 *   обводка Starter #7ccf00              1.95 ✗           7.77 ✓
 *   обводка Growth  #2b7fff              3.76 ✓           4.02 ✓
 *   обводка Scale   #ad46ff              4.12 ✓           3.67 ✓
 *   заливка Starter (α 0.85 → #a9ea26)   1.45 ✗           7.51 ✓
 *   заливка Growth  (α 0.85 → #52a2ff)   2.63 ✗           3.88 ✓
 *   заливка Scale   (α 0.85 → #cb8eff)   2.37 ✗           4.31 ✓
 *
 * В СВЕТЛОЙ теме порог не берёт НИ ОДНА заливка (1.45 / 2.63 / 2.37 против
 * 3), а у салата не берёт и обводка — 1.95. На проекторе с засветкой
 * пузырёк Starter будет виден как «что-то светло-зелёное». В ТЁМНОЙ теме
 * порог берут все шесть значений, худшее 3.67. Вывод, который надо
 * доносить до клиента: карточка рассчитана на тёмную тему, светлая —
 * компромисс, принятый сознательно.
 *
 * Отдельно про непрозрачность: 0.85 — донорская, и именно она уводит
 * заливку под порог. Полная непрозрачность подняла бы светлую тему до
 * 1.53 / 3.14 / 2.79 — салат и фиолетовый всё равно не берут, а сквозь
 * пузырёк перестал бы просвечивать сосед. Размен решён в пользу донора.
 *
 * Что из этого следует для вёрстки, и это уже не вкусовое:
 *
 *   1. Ряд называет ЛЕГЕНДА, а не цвет: плитка с именем когорты и её
 *      средним. Убрать легенду у этой карточки нельзя.
 *   2. Положение точки читается по СЕТКЕ и подписанным делениям, а не по
 *      цвету. Ось обязательна, оба названия осей обязательны.
 *   3. У круга есть обводка в полную силу цвета: форма читается силуэтом
 *      там, где цвет не читается.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ТЕКСТ НА ЗАЛИВКЕ
 * ═══════════════════════════════════════════════════════════════════
 *
 * Градиентов в этой карточке нет — их нет и у донора. Но подпись точки
 * (`marks`) может лечь на пузырёк, и это ровно та же беда, что у подписи
 * маркера на градиенте в `lineCard.tsx`. Замер композита заливки с фоном
 * карточки (α 0.85, кегль 26, порог 4.5):
 *
 *   роль подписи      на Starter   на Growth   на Scale   на карточке
 *   светлая, ink         13.66 ✓      7.51 ✓     8.35 ✓      19.80 ✓
 *   светлая, secondary    3.73 ✗      2.05 ✗     2.28 ✗       5.41 ✓
 *   тёмная,  ink          1.93 ✗      3.74 ✗     3.37 ✗      14.50 ✓
 *   тёмная,  secondary    1.25 ✗      1.55 ✗     1.39 ✗       6.00 ✓
 *
 * Отсюда правило: подпись точки НЕ ложится на пузырёк вовсе. В тёмной теме
 * даже `--t-ink` (#fafafa) на салате даёт 1.93 при пороге 4.5 — читаемого
 * цвета текста на этой заливке не существует ВООБЩЕ, ни светлого, ни
 * тёмного. Раскладка подписи поэтому проверяет пересечение с КРУГАМИ, и
 * если свободного места рядом нет, подпись не рисуется, а в разработке
 * печатается предупреждение (`scatterMarks.ts`).
 *
 * Подписи осей, названия осей и подпись площади на пузырьки не попадают по
 * построению: они стоят В ПОЛЯХ, вне поля построения. Под ними чистая
 * карточка, и вторичный там законен — 5.41 в светлой теме и 6.00 в тёмной
 * при пороге 4.5 для кегля 20.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Чего из донора здесь нет
 * ═══════════════════════════════════════════════════════════════════
 *
 * **Наведения.** У донора курсор на точке подменяет подпись и число в
 * шапке на эту запись и приглушает остальные серии (`transition-opacity
 * 200ms`, приглушение задаётся инлайновой прозрачностью). В PDF курсора
 * нет; всё, что нужно прочитать, напечатано: когорты — легендой, ключевые
 * точки — через `marks`.
 *
 * **Шеврона в плашке периода.** Он обещает выпадающий список, которого в
 * PDF не будет. Механика — в `shell.tsx`.
 *
 * **Пунктира 4/4 при 1px.** На нашем поле это дало бы 3px штрих с 3px
 * просветом — рябь на проекторе (спецификация донора, пункт «что мешает
 * на слайде»). Шаг увеличен до `6 6` при толщине 2 — ровно тот же пунктир,
 * что у соседней `comboCard.tsx`: две карточки на одном слайде с разной
 * сеткой читаются как два разных инструмента.
 *
 * **Ничего из осей.** Плотность сетки донорская: по Y три равных шага
 * (у донора подписи 0 · 550 · 1.1K · 1.7K — четыре подписи, три
 * промежутка), по X четыре (0 · 25 · 50 · 75 · 100 — пять подписей).
 * Три шага по Y — это ещё и значение по умолчанию `cardAxisTicks`, то есть
 * плотность горизонталей совпадает с соседними карточками волны.
 *
 * Лишний шаг по X оправдан тем, что поле шире, чем выше: при равном числе
 * промежутков вертикали стояли бы вдвое реже горизонталей, и облако
 * казалось бы вытянутым по горизонтали ещё сильнее, чем оно есть.
 *
 * Кегль подписи при этом вырос с донорских 12 до 20 (пол шкалы проекта —
 * 16), поэтому пять подписей могут не поместиться на узкой карточке.
 * Прореживание идёт по ЗАМЕРУ ширины каждой строки (`cardAxisKeep`), а не
 * по фиксированному шагу, и линия сетки при этом остаётся: пропадает
 * подпись, а не деление.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface ScatterCardPoint {
  /** Значение по горизонтальной оси */
  x: number;
  /** Значение по вертикальной оси */
  y: number;
  /**
   * Третья величина — размер пузырька. Кодируется ПЛОЩАДЬЮ, см. `bubbleRadius`.
   *
   * Либо задана у ВСЕХ точек, либо ни у одной: график с половиной пузырьков
   * и половиной точек читается как ошибка данных. Смешение ловится
   * предупреждением в разработке.
   */
  size?: number;
  /** Имя записи. Рисуется, только если точка названа в `marks` */
  label?: string;
}

/** Имя краски в донорской восьмёрке */
export type BoardSeriesName = keyof typeof BOARD_CHART;

export interface ScatterCardSeries {
  key: string;
  /** Имя когорты для легенды: «Starter», «Growth», «Scale» */
  label: string;
  points: readonly ScatterCardPoint[];
  /** Краска донорской восьмёрки. Не задана — берётся по порядку донора */
  series?: BoardSeriesName;
  /**
   * Значение в плитке легенды. Не задано — считается СРЕДНЕЕ по Y и к имени
   * когорты добавляется «· avg», ровно как у донора: суффикс появляется
   * вместе с усреднением, а не стоит всегда.
   */
  legendValue?: string;
}

/** Ключевая точка, подписанная статически — замена наведению у донора */
export interface ScatterCardMark {
  /** `key` серии */
  series: string;
  /** Индекс точки внутри серии */
  index: number;
  /** Подпись. Не задана — берётся `point.label` */
  label?: string;
}

/**
 * Порядок красок донора: Starter — салат, Growth — синий, Scale — фиолетовый.
 * Ссылки по индексу, перестановка молча перекрасила бы все истории.
 */
const SERIES_ORDER: readonly BoardSeriesName[] = ["lime", "blue", "purple"];

/**
 * Потолок числа когорт — ТРИ.
 *
 * У донора их три, и это не случайность формата: на точечной сравниваются
 * ВСЕ пары цветов сразу, а не соседние, как у столбиков. Системный набор
 * для точечных (`CHART_SERIES_SCATTER`) урезан до трёх ровно по этой
 * причине — прогон пятёрки валидатором дал два провала при дальтонизме
 * (шапка `chartPalette.ts`).
 *
 * ⚠️ Донорская восьмёрка на различимость пар НЕ проверялась вовсе (шапка
 * `boardPalette.ts`), поэтому три здесь — не доказанный потолок, а
 * перенесённое ограничение донора. Четвёртой когорте цвета не даём.
 */
const MAX_SERIES = SERIES_ORDER.length;

/* ═══════════════  Геометрия: доли донора, а не его пиксели  ═══════════════ */

/**
 * Наибольший радиус пузырька как доля высоты ПОЛЯ ПОСТРОЕНИЯ.
 *
 * 40/388 — отношение из `blocks/scatter.tsx`, где 40 посчитано от шага
 * сетки: пузырёк не должен перекрывать деление целиком. Донорское
 * отношение чуть меньше — 14.05 при плоскости 158, то есть 8.9% против
 * наших 10.3%; разница в пределах округления радиуса до целого.
 *
 * Считается от ОЦЕНКИ высоты поля (см. `plotHGuess` ниже), а не от
 * итоговой: итоговая зависит от самого радиуса. Замер в 1:1: половинная
 * карточка — 24, во всю ширину — 21, половинная с ключом на своей
 * строке — 20. От радиуса зависит и потолок разброса: (rMax / 8)² — то
 * есть 9.0:1, 6.9:1 и 6.3:1 соответственно.
 */
const BUBBLE_MAX_RATIO = 40 / 388;
/** Пол и потолок наибольшего радиуса: ниже 16 пузырь неотличим от точки */
const BUBBLE_MAX_MIN = 16;
const BUBBLE_MAX_MAX = 40;

/**
 * Пол радиуса. Круг меньше 16 точек в поперечнике с трёх метров
 * перестаёт отличаться от точки — см. предупреждение о пропорции в шапке.
 */
const BUBBLE_MIN = 8;

/**
 * Непрозрачность заливки — ДОНОРСКАЯ, 0.85.
 *
 * `blocks/scatter.tsx` держит 0.62: там заливка обязана пропускать
 * соседний пузырёк, чтобы два наложенных читались как два. Здесь взято
 * донорское значение, и цена названа вслух: при 0.85 нижний пузырёк
 * просвечивает слабо, границу держит его обводка. Для карточки на 3–4
 * точки в когорте этого хватает; для плотного облака в полсотни точек
 * форма не карточная — там слайдовый блок.
 */
const BUBBLE_FILL_OPACITY = 0.85;

/**
 * Толщина обводки как доля ширины SVG. Донор: 1.5 при 544 → 0.276%.
 *
 * Пол 3 — толщина обводки в `blocks/scatter.tsx`: тоньше на проекторе
 * волосок. Потолок 5 — за ним обводка съедает мелкий пузырёк изнутри:
 * при r 8 полоса 6 не оставляет заливке ничего.
 */
const STROKE_RATIO = 1.5 / 544;
const STROKE_MIN = 3;
const STROKE_MAX = 5;

/**
 * Радиус простой точки (когда третьей величины нет) как доля ширины SVG.
 * Донор: 4.51 при 544 → 0.829%. На половинной карточке доля даёт 6.5 и
 * срабатывает пол, на полной — 13.
 */
const DOT_RATIO = 4.51 / 544;
/** Пол 10 — радиус простой точки в `blocks/scatter.tsx`: мельче в системе точек нет */
const DOT_MIN = 10;
const DOT_MAX = 14;

/**
 * Кольцо-просвет вокруг простой точки — цветом карточки.
 *
 * Тот же приём, что у `IconSquare` в стопке (`ui-craft.md`) и у точки
 * в `blocks/scatter.tsx`: без него две близкие точки одного ряда слипаются
 * в восьмёрку, и вместо двух наблюдений читается одно. У донора кольца нет
 * — у него точки разводило наведение.
 */
const RING = 3;

/** Пунктир сетки. Донор: 4 4 при 544. Совпадает с `comboCard.tsx` */
const GRID_DASH = "6 6";

/**
 * Промежутков на оси X — четыре, как у донора (0 · 25 · 50 · 75 · 100).
 * По Y остаются три — значение по умолчанию `cardAxisTicks`, то есть
 * плотность горизонталей та же, что у соседних карточек волны. Почему
 * оси разной плотности — в шапке файла.
 */
const X_STEPS = 4;

/** Просвет между строкой подписей оси X и строкой названий осей */
const TITLE_GAP = 12;
/** Просвет между названиями осей и подписью площади в той же строке */
const TITLE_GUTTER = 24;

/* ═══════════════  Круги  ═══════════════ */

/**
 * Радиус пузырька по величине: r(v) = R_MAX · √(v / v_max), не меньше R_MIN.
 *
 * Вывод формулы и проверка на числах — в шапке файла. Коротко: пятно
 * читается площадью, S = π·r², поэтому пропорциональной величине должна
 * быть площадь, а не радиус, — иначе разница преувеличена в квадрате
 * (вдвое большее значение выглядит вчетверо большим).
 */
export function bubbleRadius(value: number, maxValue: number, rMax: number) {
  if (!(maxValue > 0)) return BUBBLE_MIN;
  return Math.max(BUBBLE_MIN, rMax * Math.sqrt(Math.max(0, value) / maxValue));
}

/* ═══════════════  График  ═══════════════ */

export interface ScatterPlotProps {
  series: readonly ScatterCardSeries[];
  /** Размеры слота. Считаются обвязкой через `cardChartWidth` / `cardChartHeight` */
  width: number;
  height: number;
  /** Что отложено по горизонтали. Без названия положение точки не значит ничего */
  xTitle: string;
  /** Что отложено по вертикали */
  yTitle: string;
  /** Что означает ПЛОЩАДЬ пузырька. Обязательно, если у точек есть `size` */
  sizeTitle?: string;
  formatX?: (value: number) => string;
  formatY?: (value: number) => string;
  formatSize?: (value: number) => string;
  /** Ключевые точки с напечатанной подписью — замена наведению у донора */
  marks?: readonly ScatterCardMark[];
}

export function ScatterPlot({
  series,
  width,
  height,
  xTitle,
  yTitle,
  sizeTitle,
  formatX = defaultTick,
  formatY = defaultTick,
  formatSize = defaultTick,
  marks = [],
}: ScatterPlotProps) {
  useRemeasureOnFont();

  /*
   * Лишние когорты отбрасываются, а не красятся по кругу: четвёртая
   * когорта цветом первой — это график, который врёт про принадлежность
   * точек. Отброс громкий, см. предупреждение ниже.
   */
  const shown = series.slice(0, MAX_SERIES);
  const points = shown.flatMap((s) => s.points);

  const sized = points.filter((p) => p.size !== undefined);
  const isBubble = sized.length > 0;
  const maxSize = isBubble ? Math.max(...sized.map((p) => p.size ?? 0)) : 0;
  const minSize = isBubble ? Math.min(...sized.map((p) => p.size ?? 0)) : 0;

  /*
   * Оси — ОБЩИЕ с остальными карточками волны: `cardAxisTicks` из axis.ts,
   * три равных шага, домен включает ноль.
   *
   * ⚠️ Ноль в домене здесь — расхождение с `blocks/scatter.tsx`, где его
   * намеренно НЕ требуют: у точки нет длины, сравниваются расстояния между
   * точками, и ноль им не нужен. Донор, однако, рисует обе оси от нуля
   * (0 · 25 · 50 · 75 · 100 и 0 · 550 · 1.1K · 1.7K), и соседние карточки
   * волны тоже. Расхождение осей внутри одной волны дороже: две карточки
   * на слайде с разными правилами шкалы читаются как ошибка.
   *
   * Цена названа и ловится предупреждением: если данные занимают меньше
   * трети шкалы, облако сплющено нулём, и такому набору нужна не карточка,
   * а слайдовый `ScatterChart` с плотным доменом.
   */
  const xAxis = cardAxisTicks(
    points.map((p) => p.x),
    X_STEPS,
  );
  const yAxis = cardAxisTicks(points.map((p) => p.y));
  const xLabels = xAxis.ticks.map(formatX);
  const yLabels = yAxis.ticks.map(formatY);

  /* Радиусы считаются ДО полей: они зависят только от данных и от ширины
     SVG, а поля зависят от них — иначе получился бы замкнутый круг */
  const dotR = Math.min(DOT_MAX, Math.max(DOT_MIN, Math.round(width * DOT_RATIO)));
  const strokeW = Math.min(STROKE_MAX, Math.max(STROKE_MIN, Math.round(width * STROKE_RATIO)));

  /* Строка названий осей внизу; подпись площади встаёт между ними, если
     помещается, иначе получает свою строку — информация важнее высоты */
  const sizeCaption =
    isBubble && sizeTitle
      ? `Площадь — ${sizeTitle} · ${formatSize(minSize)}…${formatSize(maxSize)}`
      : "";
  const captionInline =
    sizeCaption.length > 0 &&
    axisTextWidth(yTitle) + axisTextWidth(xTitle) + axisTextWidth(sizeCaption) + TITLE_GUTTER * 2 <=
      width;
  const captionOwnRow = sizeCaption.length > 0 && !captionInline;

  const titleRows = 1 + (captionOwnRow ? 1 : 0);
  const padBottom = Math.ceil(
    X_GAP + AXIS_HANG_BOTTOM + titleRows * (TITLE_GAP + AXIS_HANG_BOTTOM),
  );

  /*
   * Наибольший радиус считается от высоты поля построения, а сама высота
   * зависит от поля сверху, которое зависит от радиуса. Круг разрывается
   * так: за высоту берётся оценка при поле сверху, равном подъёму бокса
   * верхнего тика (15) — это заведомо меньше настоящего поля, значит
   * оценка радиуса завышена не будет.
   */
  const plotHGuess = Math.max(1, height - AXIS_HALF_BOX - padBottom);
  const rMax = isBubble
    ? Math.min(BUBBLE_MAX_MAX, Math.max(BUBBLE_MAX_MIN, Math.round(plotHGuess * BUBBLE_MAX_RATIO)))
    : dotR;
  const ringW = isBubble ? 0 : RING;

  /*
   * Поля вокруг поля построения. Круг у самой границы шкалы выступает за
   * неё на свой радиус — поле обязано его вместить, иначе SVG обрежет
   * пузырёк молча, без ошибки и без предупреждения.
   */
  const bulge = rMax + Math.ceil(strokeW / 2) + Math.ceil(ringW / 2) + 2;
  const padTop = Math.ceil(Math.max(AXIS_HALF_BOX, bulge));
  const padLeft = Math.ceil(Math.max(Math.max(0, ...yLabels.map(axisTextWidth)) + Y_GAP, bulge));
  const padRight = Math.ceil(Math.max(axisTextWidth(xLabels[xLabels.length - 1] ?? "") / 2, bulge));

  const plotW = Math.max(1, width - padLeft - padRight);
  const plotH = Math.max(1, height - padTop - padBottom);

  const x = (v: number) => padLeft + ((v - xAxis.min) / (xAxis.max - xAxis.min)) * plotW;
  const y = (v: number) => padTop + plotH - ((v - yAxis.min) / (yAxis.max - yAxis.min)) * plotH;

  const plotBottom = padTop + plotH;

  /*
   * Границы для подписей точек ШИРЕ поля построения, и это не поблажка.
   * Верхнее и правое поля SVG пусты по построению: там только запас под
   * пузырёк у самой границы шкалы. Левое поле занято подписями делений,
   * нижнее — подписями оси и названиями осей, поэтому туда подпись не
   * пускают. Замер показал цену узких границ: на донорских данных обе
   * подписи, поставленные в углах облака, отбрасывались целиком — справа
   * не хватало 20 точек запаса, слева мешал сосед.
   */
  const bounds: Box = { left: padLeft, right: width, top: 0, bottom: plotBottom };

  const dots = shown.flatMap((s, si) => {
    const name = s.series ?? SERIES_ORDER[si];
    return s.points.map((p, pi) => ({
      key: `${s.key}:${pi}`,
      seriesKey: s.key,
      index: pi,
      fill: BOARD_SERIES[BOARD_CHART[name]],
      stroke: BOARD_SERIES_ACTIVE[BOARD_CHART[name]],
      cx: x(p.x),
      cy: y(p.y),
      r: isBubble ? bubbleRadius(p.size ?? 0, maxSize, rMax) : dotR,
      label: p.label,
    }));
  });

  /* Крупные позади, мелкие поверх — иначе мелкий пузырёк исчезает под
     крупным целиком, и наблюдение пропадает из графика */
  const drawOrder = dots.map((_, i) => i).sort((a, b) => dots[b].r - dots[a].r);

  const circleBoxes: Box[] = dots.map((d) => ({
    left: d.cx - d.r - strokeW,
    right: d.cx + d.r + strokeW,
    top: d.cy - d.r - strokeW,
    bottom: d.cy + d.r + strokeW,
  }));

  const placedMarks = marks.map((m) => {
    const i = dots.findIndex((d) => d.seriesKey === m.series && d.index === m.index);
    if (i < 0) return null;
    const text = m.label ?? dots[i].label ?? "";
    if (!text) return null;
    const w = cardTextWidth(text, MARK_SIZE, MARK_WEIGHT, MARK_TRACKING);
    const place = placeMark(dots[i], w, bounds, circleBoxes);
    return place ? { text, ...place } : { text, x: 0, y: 0, anchor: null };
  });

  /* Прореживание подписей оси X по ЗАМЕРУ их ширины: делений всего четыре,
     но «1 250 000 ₽» рядом с таким же соседом не помещается и на них */
  const keepX = cardAxisKeep(
    xLabels,
    xAxis.ticks.map((v) => x(v)),
  );

  if (import.meta.env.DEV) {
    if (series.length > MAX_SERIES) {
      console.warn(
        `ScatterCard: когорт ${series.length}, показаны первые ${MAX_SERIES} ` +
          `(${shown.map((s) => s.label).join(", ")}). На точечной сравниваются все пары цветов сразу, ` +
          "и донор ограничился тремя. Сводите когорты либо разбивайте на две карточки.",
      );
    }
    if (isBubble && sized.length !== points.length) {
      console.warn(
        `ScatterCard: size задан у ${sized.length} точек из ${points.length}. ` +
          "Точки без размера получат минимальный радиус и прочитаются как самые мелкие. " +
          "Либо задать size всем, либо не задавать никому.",
      );
    }
    if (isBubble && !sizeTitle) {
      console.warn(
        "ScatterCard: у точек есть size, но sizeTitle не передан. Площадь пузырька без подписи " +
          "не значит ничего — это то же самое, что график без осей.",
      );
    }
    if (isBubble && maxSize > 0) {
      const clamped = sized.filter((p) => rMax * Math.sqrt((p.size ?? 0) / maxSize) < BUBBLE_MIN);
      if (clamped.length) {
        console.warn(
          `ScatterCard: ${clamped.length} точек упёрлись в минимальный радиус ${BUBBLE_MIN}. ` +
            `Разброс ${formatSize(minSize)}…${formatSize(maxSize)} шире, чем ${((rMax / BUBBLE_MIN) ** 2).toFixed(1)}:1 ` +
            "по площади: их пятна больше своей доли, то есть мелкие значения преувеличены. " +
            "Сворачивайте хвост в «прочее» либо берите другую форму.",
        );
      }
    }
    for (const axis of [
      { name: "X", a: xAxis, vals: points.map((p) => p.x) },
      { name: "Y", a: yAxis, vals: points.map((p) => p.y) },
    ]) {
      const span = Math.max(...axis.vals) - Math.min(...axis.vals);
      const scale = axis.a.max - axis.a.min;
      /*
       * Порог предъявляется только НАБОРУ: у одной-двух точек «доля шкалы»
       * ничего не значит (у одной она всегда 0), а вырожденный набор из
       * одинаковых значений — отдельный случай, его ловит сам домен.
       */
      if (axis.vals.length >= 3 && span > 0 && scale > 0 && span / scale < 0.35) {
        console.warn(
          `ScatterCard: по оси ${axis.name} данные занимают ${Math.round((span / scale) * 100)}% шкалы. ` +
            "Домен карточки включает ноль (как у донора и у соседних карточек волны), и облако им сплющено. " +
            "Такому набору нужен слайдовый blocks/scatter.tsx — он считает границы от данных.",
        );
      }
    }
    const lost = placedMarks.filter((m) => m && m.anchor === null);
    if (lost.length) {
      console.warn(
        `ScatterCard: не поместились подписи точек (${lost.map((m) => m?.text).join(", ")}). ` +
          "Свободного места рядом с точкой нет, а класть подпись на пузырёк нельзя: в тёмной теме " +
          "на салатовой заливке читаемого цвета текста не существует (замеры в шапке файла). " +
          "Сократите подпись либо подпишите другую точку.",
      );
    }
    if (plotW / plotH > 5) {
      console.warn(
        `ScatterCard: поле построения ${Math.round(plotW)}×${Math.round(plotH)} = ${(plotW / plotH).toFixed(1)}:1 ` +
          "при донорских 3.09:1. Растянутое поле кладёт облако на бок: та же зависимость читается как " +
          'более пологая. Ставьте карточку в половину ширины (size="half", col-span-6).',
      );
    }
  }

  return (
    <svg
      width={width}
      height={height}
      viewBox={`0 0 ${width} ${height}`}
      role="img"
      aria-label={`${yTitle} против ${xTitle}: ${shown.map((s) => s.label).join(", ")}`}
    >
      {/* Горизонтальная сетка и подписи делений оси Y */}
      {yAxis.ticks.map((v, i) => (
        <g key={`y${v}`}>
          <line
            x1={padLeft}
            x2={padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={2}
            strokeDasharray={GRID_DASH}
          />
          <text
            x={padLeft - Y_GAP}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{
              fontSize: AXIS_SIZE,
              fontWeight: AXIS_WEIGHT,
              letterSpacing: AXIS_TRACKING,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {yLabels[i]}
          </text>
        </g>
      ))}

      {/*
       * Вертикальная сетка. Она нужна ровно так же, как горизонтальная:
       * без неё положение точки по X читается только у самого края поля.
       * У донора сетка тоже двойная.
       */}
      {xAxis.ticks.map((v, i) => {
        const at = clampLabel(x(v), axisTextWidth(xLabels[i]) / 2, width);
        return (
          <g key={`x${v}`}>
            <line
              x1={x(v)}
              x2={x(v)}
              y1={padTop}
              y2={plotBottom}
              stroke="var(--t-line)"
              strokeWidth={2}
              strokeDasharray={GRID_DASH}
            />
            {keepX.has(i) ? (
              <text
                x={at.x}
                y={plotBottom + X_GAP}
                textAnchor={at.anchor}
                dominantBaseline="hanging"
                fill="var(--t-ink-secondary)"
                style={{
                  fontSize: AXIS_SIZE,
                  fontWeight: AXIS_WEIGHT,
                  letterSpacing: AXIS_TRACKING,
                  fontVariantNumeric: "tabular-nums",
                }}
              >
                {xLabels[i]}
              </text>
            ) : null}
          </g>
        );
      })}

      {/* Круги. Крупные позади мелких */}
      {drawOrder.map((i) => {
        const d = dots[i];
        return isBubble ? (
          <circle
            key={d.key}
            cx={d.cx}
            cy={d.cy}
            r={d.r}
            fill={d.fill}
            fillOpacity={BUBBLE_FILL_OPACITY}
            /* Обводка «активным» вариантом краски — как у донора. Она, а не
               заливка, держит форму там, где цвет не берёт порог */
            stroke={d.stroke}
            strokeWidth={strokeW}
          />
        ) : (
          <circle
            key={d.key}
            cx={d.cx}
            cy={d.cy}
            r={d.r}
            fill={d.fill}
            /* Кольцо-просвет цветом КАРТОЧКИ, а не холста: карточка — та
               поверхность, на которой точка лежит */
            stroke="var(--t-surface)"
            strokeWidth={RING}
          />
        );
      })}

      {/* Подписи ключевых точек. `--t-ink`: на пузырёк они по построению
          не ложатся, а на карточке ink даёт 17.38 и 14.33 */}
      {placedMarks.map((m, i) =>
        m && m.anchor ? (
          <text
            key={`m${i}`}
            x={m.x}
            y={m.y}
            textAnchor={m.anchor}
            dominantBaseline="middle"
            fill="var(--t-ink)"
            style={{
              fontSize: MARK_SIZE,
              fontWeight: MARK_WEIGHT,
              letterSpacing: MARK_TRACKING,
              fontVariantNumeric: "tabular-nums",
            }}
          >
            {m.text}
          </text>
        ) : null,
      )}

      {/*
       * Названия осей — как у донора: мера Y слева, мера X справа, одной
       * строкой под графиком. Повёрнутой на 90° подписи здесь нет
       * намеренно: наклонять голову перед слайдом, который смотрят с трёх
       * метров, дороже, чем занять строку.
       */}
      <text
        x={0}
        y={plotBottom + X_GAP + AXIS_HANG_BOTTOM + TITLE_GAP}
        dominantBaseline="hanging"
        fill="var(--t-ink-secondary)"
        style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT, letterSpacing: AXIS_TRACKING }}
      >
        {yTitle}
      </text>
      <text
        x={width}
        y={plotBottom + X_GAP + AXIS_HANG_BOTTOM + TITLE_GAP}
        textAnchor="end"
        dominantBaseline="hanging"
        fill="var(--t-ink-secondary)"
        style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT, letterSpacing: AXIS_TRACKING }}
      >
        {xTitle}
      </text>

      {/*
       * Ключ площади. У донора его нет вовсе — и это его слабое место:
       * пузырьки разного размера без подписи не значат ничего, читатель
       * видит «больше», но не знает, во сколько раз и в чём измерено.
       *
       * Вложенные круги, как в `blocks/scatter.tsx`, здесь не помещаются:
       * два круга наибольшего радиуса — это 2·rMax по высоте, то есть до
       * четверти поля построения. Текст несёт ТУ ЖЕ информацию (мера и её
       * границы), кроме зрительного эталона размера; это названный размен,
       * а не упрощение.
       */}
      {sizeCaption ? (
        <text
          x={captionInline ? width / 2 : 0}
          y={
            plotBottom +
            X_GAP +
            AXIS_HANG_BOTTOM +
            TITLE_GAP +
            (captionInline ? 0 : AXIS_HANG_BOTTOM + TITLE_GAP)
          }
          textAnchor={captionInline ? "middle" : "start"}
          dominantBaseline="hanging"
          fill="var(--t-ink-secondary)"
          style={{
            fontSize: AXIS_SIZE,
            fontWeight: AXIS_WEIGHT,
            letterSpacing: AXIS_TRACKING,
            fontVariantNumeric: "tabular-nums",
          }}
        >
          {sizeCaption}
        </text>
      ) : null}
    </svg>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface ScatterCardProps {
  /** Подпись серии в шапке: «Revenue per account» */
  label: string;
  /** Крупное число: «742» */
  value: string;
  /** Плашка изменения: «+6,8%» */
  delta?: CardDelta;
  /** Подпись периода. Сегменты — ряд слов, а не переключатель */
  period?: CardPeriod;
  series: readonly ScatterCardSeries[];
  /** Что отложено по горизонтали: «Sessions» */
  xTitle: string;
  /** Что отложено по вертикали: «Revenue» */
  yTitle: string;
  /** Что означает площадь пузырька: «ARR клиента». Обязательно при `size` у точек */
  sizeTitle?: string;
  formatX?: (value: number) => string;
  formatY?: (value: number) => string;
  formatSize?: (value: number) => string;
  /**
   * Значение в плитке легенды. По умолчанию — полное число с разрядами.
   *
   * Отдельно от `formatY` намеренно: ось СОКРАЩАЕТ («1.5K»), потому что
   * подпись деления — это разметка, и четыре знака в ней читаются дольше,
   * чем нужно. В плитке лежит ТО САМОЕ число, ради которого легенда и
   * стоит, — сокращать его значит прятать данные («1.388K» вместо
   * «1 388»). У донора в плитке тоже полное число с разделителем.
   */
  formatLegend?: (value: number) => string;
  /** Ключевые точки с напечатанной подписью */
  marks?: readonly ScatterCardMark[];
  /** Плитки легенды снизу. Выключать нельзя без крайней нужды — см. шапку */
  legend?: boolean;
  /** Ширина КАРТОЧКИ. 828 — половина рабочей ширины, 1680 — вся */
  width?: number;
  /** Высота карточки. По умолчанию весь бюджет блока — 604 */
  height?: number;
  /** `half` по умолчанию: точечной нужны донорские пропорции поля */
  size?: CardShellSize;
  valueSize?: CardValueSize;
  /** Вложенная тема: светлая карточка на тёмном слайде и наоборот */
  theme?: SlideTheme;
  className?: string;
}

export default function ScatterCard({
  label,
  value,
  delta,
  period,
  series,
  xTitle,
  yTitle,
  sizeTitle,
  formatX,
  formatY = defaultTick,
  formatSize,
  formatLegend = (v) => Math.round(v).toLocaleString("ru-RU"),
  marks,
  legend = true,
  width = 828,
  height = CARD_BUDGET,
  size = "half",
  valueSize = "m",
  theme,
  className,
}: ScatterCardProps) {
  /*
   * Плитки легенды. Значение по умолчанию — СРЕДНЕЕ по Y когорты, как у
   * донора («Starter · avg / 270»). Суффикс «· avg» ставится только вместе
   * с усреднением: если слайд передал своё значение, оно может быть чем
   * угодно — итогом, медианой, долей, — и называть его средним было бы
   * прямой неправдой.
   */
  const tiles: LegendTile[] = series.slice(0, MAX_SERIES).map((s, si) => {
    const name = s.series ?? SERIES_ORDER[si];
    const ys = s.points.map((p) => p.y);
    const avg = ys.length ? ys.reduce((a, b) => a + b, 0) / ys.length : 0;
    return {
      label: s.legendValue ? s.label : `${s.label} · avg`,
      value: s.legendValue ?? formatLegend(avg),
      color: BOARD_SERIES[BOARD_CHART[name]],
    };
  });

  /*
   * Размеры слота СЧИТАЮТСЯ обвязкой, а не задаются на глаз: слот в
   * карточке `flex-1 min-h-0`, график выше слота карточку не растянет,
   * а обрежется, и в PDF обрезанное просто исчезнет.
   */
  const chartW = cardChartWidth(width, size);
  const chartH = cardChartHeight({ height, size, valueSize, legend });

  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      period={period}
      legend={legend ? tiles : undefined}
      size={size}
      height={height}
      theme={theme}
      className={className}
      style={{ width }}
    >
      <ScatterPlot
        series={series}
        width={chartW}
        height={chartH}
        xTitle={xTitle}
        yTitle={yTitle}
        sizeTitle={sizeTitle}
        formatX={formatX}
        formatY={formatY}
        formatSize={formatSize}
        marks={marks}
      />
    </CardShell>
  );
}
