import type { CSSProperties, ReactNode } from "react";
import { Gallery, Stars } from "@solar-icons/react";

import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
} from "./shell";
import type { SlideTheme } from "../../slide/Slide";

/**
 * Карточка «Генерация картинок» — перенос из донорской системы дашбордов.
 *
 * У донора это не график, а КУСОК ИНТЕРФЕЙСА: сайдбар, лента переписки,
 * кадр генерации с обратным отсчётом, справа masonry-галерея прошлых
 * генераций, снизу композер и статус-бар. На слайд едет не всё: интерфейс
 * здесь становится СТАТИЧНЫМ МАКЕТОМ — тем же, чем на слайде бывает
 * скриншот продукта.
 *
 *   ┌─ карточка (шелл: подпись, число, модель) ───────────────────────────┐
 *   │  Prompt                        │ Gallery  Styles                    │
 *   │  ┌──────────────┐              │ ┌────┐ ┌────┐ ┌────┐               │
 *   │  │ запрос       │  ┌────┐┌────┐│ │    │ │    │ │    │               │
 *   │  └──────────────┘  │рябь││ ✓  ││ └────┘ │    │ └────┘               │
 *   │  Image generated   │12s ││    ││ ┌────┐ └────┘ ┌────┐               │
 *   │                    └────┘└────┘│ │    │ ┌────┐ │    │               │
 *   │                    ожидание готово                                  │
 *   └─────────────────────────────────────────────────────────────────────┘
 *
 * === Что из донора НЕ перенесено и почему ===
 *
 * | Донор                              | Здесь                              |
 * | ---------------------------------- | ---------------------------------- |
 * | обратный отсчёт перекидными цифрами| подпись «12s» рядом с состоянием   |
 * | рябь по canvas                     | статичное зерно `.plate-grain`     |
 * | проявка картинки радиальной маской | ДВА кадра рядом: до и после        |
 * | ряд действий (лайк, дизлайк, копия)| убран целиком                      |
 * | вуаль и подпись плитки по наведению| вуаль напечатана, подпись по флагу |
 * | табы Gallery / Styles              | ряд слов, выбранное — основным     |
 * | прокрутка masonry, разворот плитки | фиксированный набор плиток         |
 * | композер, статус-бар, сайдбар      | не перенесены                      |
 *
 * Ряд действий убран не ради места. Лайк, дизлайк и «копировать» — это
 * органы управления, и весь их смысл в нажатии: у донора копирование
 * отвечает галочкой и всплывающим уведомлением. В PDF нажать нельзя,
 * поэтому нарисованные кнопки читаются как недоделанный интерфейс —
 * ровно то, что запрещено в `.claude/rules/slide-anatomy.md`. То же
 * решение уже принято в шелле для переключателя периода.
 *
 * === Пара кадров вместо анимации ===
 *
 * Смысл донорского компонента — момент превращения ожидания в результат.
 * Он раскрывается только в движении: отсчёт тикает, картинка проявляется
 * маской. В PDF остаётся один кадр, причём неизвестно какой, — то есть
 * от идеи не остаётся ничего.
 *
 * Компенсация взята из самой спецификации разведки: показать ДВА кадра
 * рядом — слева ожидание с конкретной цифрой отсчёта и рябью, справа
 * готовый результат. Переход тогда виден как разница двух кадров, а не
 * как движение. Отсюда и подпись под каждым кадром: без неё пара читается
 * как «две разные картинки», а не как «один кадр в два момента».
 *
 * === ⚠️ Про размер кадра. Рекомендация разведки невыполнима ===
 *
 * Разведка советует увеличить донорский кадр 200×250 «минимум втрое»
 * (≈600×750). Замер показывает, что на слайде это невозможно: бюджет
 * блока в `ContentSlide` — 604 точки по высоте (`CARD_BUDGET`), то есть
 * 750 не помещается даже без карточки, шапки и подписи.
 *
 * Что помещается на самом деле (замер, полная карточка 1680×604):
 *
 *   слот карточки          1608 × 408
 *   кадр с галереей         297 × 371   ×1.485 к донору
 *   кадр без галереи        297 × 371   (высота та же, ширина свободна)
 *   плитка галереи          184         ×1.405 к донору
 *
 * То есть множитель ×1.4…1.5, а не ×3. Больше даёт только отказ от
 * галереи В ПОЛЬЗУ кадра при половинной карточке — но там режет высота.
 * Число здесь считается, а не задаётся: `aiImageGeometry`.
 *
 * Утешение: относительно НОСИТЕЛЯ кадр не уменьшился. У донора 250 из
 * 900 точек окна — 27.8% высоты; у нас 371 из 1080 — 34.4%. Мелким кадр
 * выглядит не на слайде, а в разборной витрине, где рядом нет холста.
 *
 * === Картинок в репозитории нет ===
 *
 * Блок обязан работать на заглушках — тот же приём, что у `MediaCover`
 * (`blocks/media.tsx`) и `CoverCard` (`blocks/entity.tsx`): заглушка
 * держит габарит, чтобы вёрстка слайда не поехала, когда снимки принесут.
 * Габарит задаётся кадру и плитке ЧИСЛОМ, а `<img>` вставляется внутрь
 * с `object-cover`, поэтому подстановка картинки ничего не двигает.
 */

/* ═══════════════  Геометрия  ═══════════════ */

/**
 * Пропорция кадра. Донор 200×250 — ровно 4:5, отношение высоты к ширине 1.25.
 * Переносится ПРОПОРЦИЯ, а не пара чисел: числа считаются от бюджета слайда.
 */
const FRAME_RATIO = 250 / 200;

/** Просвет между кадрами пары. Донор ставил кадры по одному, пара — наша */
const FRAME_GAP = 16;

/** Подпись под кадром: `text-body-m` 20/28 */
const CAPTION_LINE = 28;
/** Просвет кадр → подпись: `mt-2` */
const CAPTION_GAP = 8;

/**
 * Строка состояния ВНУТРИ кадра и подпись на плитке — `text-label` 18/24.
 *
 * Кегль перенесён, а не выбран: у донора обе набраны 13/18 при макете 1440,
 * и 13 × 4/3 = 17.33 — ближайшая ступень шкалы это 18. Подпись ПОД кадром
 * набрана крупнее (`text-body-m` 20/28), потому что она наша, а не
 * донорская: у донора кадр ничем не подписан, и разбирать пару «до и
 * после» читателю придётся по ней.
 */
const NOTE_LINE = 24;
/** Поля строки состояния внутри кадра: `px-5 pb-5` */
const NOTE_PAD = 20;
/** Поля подписи на плитке: `px-3 pb-3` */
const TILE_CAPTION_PAD = 12;

/**
 * Средняя ширина знака — только для предупреждений. Вёрстка меряет
 * браузером, формула нужна, чтобы предсказать обрезку ДО показа.
 *
 * Числа замерены в 1:1 на девяти строках, латиница и кириллица вперемешку
 * (`text-label` 18 / `text-body-m` 20):
 *
 *   «Vintage editorial Messi, Argentina kit» 38 зн → 290.7 / 323.0  7.65 / 8.50
 *   «Botanical poster, pressed leaves»       32 зн → 255.5 / 283.9  7.98 / 8.87
 *   «Vintage editorial Messi»                23 зн → 180.3 / 200.3  7.84 / 8.71
 *   «City scene at dusk»                     18 зн → 146.2 / 162.4  8.12 / 9.02
 *   «12-я секунда: рябь и отсчёт»            27 зн → 225.2 / 250.3  8.34 / 9.27
 *   «Generating image»                       16 зн → 144.5 / 160.6  9.03 / 10.04
 *
 * Разброс 7.65…9.03 — шрифт пропорциональный, и короткая строка из широких
 * букв даёт на 18% больше длинной. Взято значение ближе к верхнему краю
 * диапазона, а не среднее: предупреждение должно срабатывать ДО обрезки,
 * а не после. Ценой ложных срабатываний на строках из узких букв.
 */
const CHAR_18 = 8.4;
/** То же для `text-body-m` 20/28 — подпись под кадром */
const CHAR_20 = 9.3;

/** Просвет между колонками макета — желоб сетки слайда */
const COLUMN_GAP = 24;
/** Разделитель между лентой и галереей: `border-l` */
const DIVIDER = 1;

/**
 * Доля галереи в слоте.
 *
 * У донора центральная колонка 718, панель 410, между ними 16 — то есть
 * панель занимает 410 / (718 + 16 + 410) = 35.84% пары. Переносится ДОЛЯ:
 * наш слот в 1.4 раза шире донорского, и абсолютные 410 дали бы панель
 * заметно уже донорской по ощущению.
 *
 * Проверка на полной карточке: 1608 × 0.3584 = 576.3 → 576, и на трёх
 * колонках с просветом 12 это ровно 184 на плитку. Целое число не
 * подгонялось — так сошлось.
 */
const GALLERY_SHARE = 410 / (718 + 16 + 410);

/** Просвет masonry. Донор 8 при 1440 → 8 × 4/3 = 10.7 → на сетке 4 это 12 */
const GALLERY_GAP = 12;

/** Строка табов панели: `text-body-m` */
const TAB_LINE = 28;
/** Просвет табы → masonry */
const TAB_GAP = 12;

/** Подпись «Prompt» над пузырём: `text-body-m` */
const PROMPT_LABEL_LINE = 28;
/** Просвет подпись → пузырь: `mt-2` */
const PROMPT_LABEL_GAP = 8;
/** Строка текста запроса: `text-body-m` 20/28 */
const PROMPT_LINE = 28;
/** Поля пузыря по вертикали: `py-5` 20 + 20 */
const PROMPT_PAD = 40;
/** Сколько строк запроса показывается, когда пузырь стоит СВЕРХУ */
const PROMPT_TOP_LINES = 2;
/** Просвет пузырь → кадры при верхнем размещении */
const PROMPT_TOP_GAP = 16;

/** Потолок кадров в паре: третий кадр перестаёт быть «до и после» */
export const MAX_FRAMES = 3;
/**
 * Потолок плиток галереи.
 *
 * Не «сколько влезет», а сколько имеет смысл: разведка предлагает 3×3, и
 * это же следует из `slide-anatomy.md` — список длиннее шести пунктов не
 * читают, а пересчитывают, и девять плиток это уже предел, за которым
 * галерея превращается в текстуру.
 */
export const MAX_GALLERY = 9;

export type AiPromptPlacement = "side" | "top";

export interface AiImageGeometry {
  /** Слот карточки под содержимое: ширина × высота */
  slotW: number;
  slotH: number;
  /** Ширина колонки ленты (пузырь + кадры) */
  feedW: number;
  /** Ширина колонки под пузырь запроса */
  promptW: number;
  /** Высота блока запроса при верхнем размещении, иначе 0 */
  promptH: number;
  /** Кадр генерации */
  frameW: number;
  frameH: number;
  /** Ширина всей пары кадров с просветами */
  framesW: number;
  /** Панель галереи; ноль, если галереи нет */
  galleryW: number;
  tileW: number;
  /** Высота, отведённая masonry, — слот минус строка табов */
  masonryH: number;
  placement: AiPromptPlacement;
}

/**
 * Вся геометрия карточки одним вычислением.
 *
 * Вынесено наружу, чтобы витрина печатала ТЕ ЖЕ числа, которыми рисует
 * блок. Переписанное руками число живёт своей жизнью: поменяется доля
 * галереи — проза останется прежней и будет врать увереннее самого блока.
 */
export function aiImageGeometry({
  width,
  height = CARD_BUDGET,
  size = "full",
  valueSize = "m",
  frames = 2,
  gallery = false,
  galleryColumns = 3,
  promptPlacement,
}: {
  width?: number;
  height?: number;
  size?: CardShellSize;
  valueSize?: CardValueSize;
  frames?: number;
  gallery?: boolean;
  galleryColumns?: number;
  promptPlacement?: AiPromptPlacement;
} = {}): AiImageGeometry {
  const cardWidth = width ?? (size === "full" ? 1680 : 828);
  const slotW = cardChartWidth(cardWidth, size);
  const slotH = cardChartHeight({ height, size, valueSize, legend: false });

  /*
   * Размещение запроса: сбоку у полной карточки, сверху у половинной.
   *
   * Причина не в красоте, а в замере. Сбоку пузырь получает колонку в
   * 349 точек — это ~30 знаков в строку кеглем 20, донорский запрос в
   * 118 знаков ложится в четыре строки. На половинной карточке той же
   * колонки не остаётся: кадры съедают 424 из 788, пузырю досталось бы
   * 340 минус желоб, и это при вдвое меньшей высоте. Сверху он занимает
   * всю ширину и обрезается по двум строкам.
   */
  const placement = promptPlacement ?? (size === "full" ? "side" : "top");

  const galleryW = gallery ? Math.round(slotW * GALLERY_SHARE) : 0;
  const tileW = gallery
    ? Math.floor((galleryW - GALLERY_GAP * (galleryColumns - 1)) / Math.max(1, galleryColumns))
    : 0;
  const masonryH = gallery ? slotH - TAB_LINE - TAB_GAP : 0;

  const feedW = gallery ? slotW - galleryW - COLUMN_GAP * 2 - DIVIDER : slotW;

  const promptH =
    placement === "top"
      ? PROMPT_LABEL_LINE + PROMPT_LABEL_GAP + PROMPT_TOP_LINES * PROMPT_LINE + PROMPT_PAD
      : 0;

  /* Место, которое остаётся кадру по высоте: слот минус запрос сверху,
     минус строка подписи под кадром и просвет до неё */
  const frameAreaH =
    slotH - (placement === "top" ? promptH + PROMPT_TOP_GAP : 0) - CAPTION_LINE - CAPTION_GAP;

  const count = Math.max(1, frames);
  const byHeight = Math.floor(frameAreaH / FRAME_RATIO);
  /*
   * Сбоку кадр ограничен ТОЛЬКО высотой: ширину, которая ему осталась,
   * определить нельзя, пока не известна ширина самого кадра — колонка
   * запроса берёт остаток. Круг разрывается здесь: кадр считается от
   * высоты, запрос получает то, что осталось, и если осталось мало —
   * блок предупреждает, а не молча сжимает кадр.
   */
  const byWidth =
    placement === "top"
      ? Math.floor((feedW - FRAME_GAP * (count - 1)) / count)
      : Number.POSITIVE_INFINITY;
  const frameW = Math.max(0, Math.min(byHeight, byWidth));
  const frameH = Math.round(frameW * FRAME_RATIO);
  const framesW = frameW * count + FRAME_GAP * (count - 1);
  const promptW = placement === "side" ? feedW - COLUMN_GAP - framesW : feedW;

  return {
    slotW,
    slotH,
    feedW,
    promptW,
    promptH,
    frameW,
    frameH,
    framesW,
    galleryW,
    tileW,
    masonryH,
    placement,
  };
}

/* ═══════════════  Раскладка masonry  ═══════════════ */

export interface MasonryPlacement {
  /** Индекс плитки в исходном массиве */
  index: number;
  /** Высота плитки в точках, посчитанная от ширины колонки и пропорции */
  height: number;
}

export interface MasonryLayout {
  /** По плитке на колонку, в порядке сверху вниз */
  columns: MasonryPlacement[][];
  /** Итоговая высота каждой колонки */
  heights: number[];
  /** Индексы плиток, которым не хватило места ни в одной колонке */
  dropped: number[];
}

/**
 * Раскладка masonry: плитки разной пропорции в колонки равной ширины.
 *
 * === Порядок ИСХОДНЫЙ, а не отсортированный ===
 *
 * Классический жадный алгоритм для такой задачи (LPT) сортирует элементы
 * по убыванию и кладёт каждый в самую низкую колонку — так дно получается
 * ровнее. Здесь он НЕ применён: сортировка переставила бы плитки, а автор
 * слайда, передавая массив, задаёт порядок сам. Молча его менять нельзя.
 *
 * Плата за это — раггед дно. На наборе по умолчанию колонки выходят
 * 361 / 365 / 334 при отведённых 368, то есть разброс 31 точка. Это
 * нормальный вид masonry, а не дефект вёрстки: у донора дно вообще
 * уходит под прокрутку.
 *
 * === Что не влезло — ВЫБРАСЫВАЕТСЯ, а не обрезается ===
 *
 * Плитка, которой не хватило высоты, не ставится вовсе и попадает в
 * `dropped`. Обрезанная наполовину плитка на слайде читается как ошибка
 * печати; отсутствующая — просто как более короткая колонка. Блок при
 * этом предупреждает в консоль: молча терять содержимое нельзя.
 */
export function packGallery(
  ratios: readonly number[],
  columns: number,
  tileW: number,
  maxH: number,
  gap: number = GALLERY_GAP,
): MasonryLayout {
  const count = Math.max(1, Math.floor(columns));
  const cols: MasonryPlacement[][] = Array.from({ length: count }, () => []);
  const heights = new Array<number>(count).fill(0);
  const dropped: number[] = [];

  ratios.forEach((ratio, index) => {
    /* Пропорция — ширина к высоте, как `aspect-ratio` у донора (449/600).
       Неположительная означает «пропорция не задана»: плитка становится
       квадратной, а не исчезает */
    const height = ratio > 0 ? Math.round(tileW / ratio) : tileW;

    let best = -1;
    for (let i = 0; i < count; i += 1) {
      const next = heights[i] === 0 ? height : heights[i] + gap + height;
      if (next > maxH) continue;
      if (best === -1 || heights[i] < heights[best]) best = i;
    }

    if (best === -1) {
      dropped.push(index);
      return;
    }

    heights[best] = heights[best] === 0 ? height : heights[best] + gap + height;
    cols[best].push({ index, height });
  });

  return { columns: cols, heights, dropped };
}

/* ═══════════════  Вуаль под подписью  ═══════════════ */

/**
 * Вуаль — затемнение под подписью, лежащей на картинке.
 *
 * === Почему она НАПЕЧАТАНА, а не по наведению ===
 *
 * У донора вуаль и подпись плитки появляются по курсору. В PDF курсора
 * нет: либо подпись видна всегда, либо её нет вовсе. Раз видна всегда —
 * затемнение перестаёт быть эффектом и становится частью вёрстки, и его
 * приходится считать, а не подбирать.
 *
 * === Числа считаны, а не взяты у донора ===
 *
 * Донор гасит вуаль в rgba(neutral-950, 0.55) у нижнего края. Замер
 * говорит, что этого мало: белый текст на 0.55 поверх БЕЛОЙ картинки даёт
 * 4.42:1 при пороге 4.5 для кегля мельче 24. Картинка может быть любой,
 * и белое небо в верхнем ряду — обычное дело, поэтому считать надо по
 * худшему фону, то есть по чистому белому.
 *
 * Белый текст поверх rgba(10,10,10,α) на БЕЛОЙ картинке:
 *
 *   α     цвет подложки   контраст
 *   0.40    #9d9d9d        2.71   ✗
 *   0.50    #858585        3.69   ✗
 *   0.55    #787878        4.42   ✗  ← донорское значение
 *   0.62    #676767        5.66   ✓  ← нижняя ступень нашей вуали
 *   0.78    #404040       10.37   ✓  ← у самого края
 *
 * === Где стоит текст и что там намерено ===
 *
 * Полоса вуали вдвое выше текстового блока, и текст занимает её нижнюю
 * половину. Замер в 1:1 (кадр 297×371, полоса 88): строка стоит от 0.227
 * до 0.500 высоты полосы, считая снизу. Пять точек по высоте строки —
 * контраст белого текста на четырёх подложках:
 *
 *   доля  α       #ffffff  #f0f0f0  #1c1c1c  #000000
 *   0.227 0.714      8.05     8.62    19.15    20.13
 *   0.295 0.694      7.46     8.02    19.10    20.15
 *   0.363 0.674      6.92     7.47    19.05    20.17
 *   0.432 0.654      6.42     6.95    19.00    20.20
 *   0.500 0.635      5.96     6.48    18.94    20.22
 *
 * Худшая точка — верхний край строки на белой картинке, 5.96:1 при пороге
 * 4.5 для кегля 18. Запас 1.3 раза; донорские 0.55 дали бы 4.42 и порог
 * не взяли бы. Верхняя половина полосы (α от 0.62 до нуля) нужна не тексту,
 * а тому, чтобы граница затемнения не читалась как прямоугольник поверх
 * картинки.
 *
 * Затухание идёт в rgba(10,10,10,0), а НЕ в `transparent`: ключевое слово
 * означает прозрачный ЧЁРНЫЙ, и по краю пошла бы грязь — правило из
 * `.claude/rules/ui-craft.md`.
 */
const VEIL =
  "linear-gradient(to top, rgba(10,10,10,0.78) 0%, rgba(10,10,10,0.62) 55%, rgba(10,10,10,0) 100%)";

/** Высота полосы вуали = удвоенный текстовый блок (строка + нижнее поле) */
function veilHeight(line: number, pad: number) {
  return (line + pad) * 2;
}

/* ═══════════════  Кадр генерации  ═══════════════ */

export type AiFrameState = "pending" | "ready";

export interface AiImageFrame {
  /**
   * Состояние кадра. `pending` — ожидание: зерно вместо картинки и
   * счётчик; `ready` — результат.
   */
  state: AiFrameState;
  /** Подпись ПОД кадром: чем этот кадр отличается от соседнего */
  caption: string;
  /** Строка на вуали внутри кадра: «Generating image» или подпись картинки */
  note?: string;
  /** Счётчик рядом со строкой: «12s». У готового кадра его быть не должно */
  timer?: string;
  /** Путь к картинке. Нет — заглушка той же геометрии */
  src?: string;
}

function Frame({ frame, width, height }: { frame: AiImageFrame; width: number; height: number }) {
  const pending = frame.state === "pending";
  /*
   * Скругление кадра — ДОЛЯ его ширины, а не донорское число.
   * У донора 16 при ширине 200 — 8%. Наши 297 × 8% = 23.8, ближайшая
   * ступень набора — `rounded-card` 20 (6.7%). Перенести 16 как есть
   * значило бы утончить скругление вдвое по пропорции: тот же дефект,
   * что уже разобран для кромки плитки в `ui-craft.md`.
   *
   * Правило концентричности здесь не применяется: кадр не прижат к углу
   * карточки, между ними стоит колонка запроса и подпись снизу.
   */
  const Glyph = pending ? Stars : Gallery;

  return (
    <figure className="flex shrink-0 flex-col" style={{ width }}>
      <div
        className="bg-surface-muted relative overflow-hidden rounded-card"
        style={{ width, height }}
      >
        {frame.src ? (
          <img src={frame.src} alt="" className="h-full w-full object-cover" />
        ) : (
          /* Заглушка: глиф ink-tertiary. Замер к подложке — 3.33:1 в
             светлой теме (#838383 на #f0f0f0) и 4.14:1 в тёмной
             (#7d7d7d на #1c1c1c) при пороге 3:1 для нетекстовой
             графики. Тот же приём, что у MediaCover */
          <div className="grid h-full w-full place-items-center">
            <Glyph size={Math.round(width * 0.22)} weight="Linear" color="var(--t-ink-tertiary)" />
          </div>
        )}

        {pending ? (
          /*
           * Рябь донора идёт по canvas и всё время движется. В PDF от
           * движения не остаётся ничего, поэтому взято статичное зерно
           * системы — `.plate-grain` из `styles/effects.css`. Оно и
           * задумано как неподвижный слой: шум из SVG-фильтра, без файла
           * картинки и без анимации.
           */
          <span className="plate-grain" aria-hidden="true" />
        ) : null}

        {frame.note ? (
          <>
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-x-0 bottom-0"
              style={{ height: veilHeight(NOTE_LINE, NOTE_PAD), background: VEIL }}
            />
            <div className="absolute inset-x-0 bottom-0 flex items-center gap-4 px-5 pb-5">
              <span className="text-label text-on-media min-w-0 flex-1 truncate">{frame.note}</span>
              {frame.timer ? (
                <span className="text-label text-on-media shrink-0 tabular-nums">
                  {frame.timer}
                </span>
              ) : null}
            </div>
          </>
        ) : null}
      </div>

      <figcaption
        className="text-body-m text-ink-secondary truncate"
        style={{ marginTop: CAPTION_GAP, height: CAPTION_LINE }}
      >
        {frame.caption}
      </figcaption>
    </figure>
  );
}

/* ═══════════════  Плитка галереи  ═══════════════ */

export interface AiGalleryTile {
  /** Подпись-alt плитки. Печатается только при `tileCaptions` */
  caption: string;
  /** Пропорция ширина / высота, как `aspect-ratio` у донора: 1, 0.8, 0.75… */
  ratio: number;
  /** Путь к картинке. Нет — заглушка той же геометрии */
  src?: string;
}

function Tile({
  tile,
  width,
  height,
  showCaption,
}: {
  tile: AiGalleryTile;
  width: number;
  height: number;
  showCaption: boolean;
}) {
  return (
    /*
     * Скругление плитки — та же доля, что у кадра: донор 10 при 131 это
     * 7.6%, наши 184 × 7.6% = 14, ближайшая ступень `rounded-tile` 12.
     */
    <figure
      className="bg-surface-muted relative shrink-0 overflow-hidden rounded-tile"
      style={{ width, height }}
    >
      {tile.src ? (
        <img src={tile.src} alt={tile.caption} className="h-full w-full object-cover" />
      ) : (
        <div className="grid h-full w-full place-items-center">
          <Gallery
            size={Math.round(Math.min(width, height) * 0.22)}
            weight="Linear"
            color="var(--t-ink-tertiary)"
          />
        </div>
      )}

      {showCaption ? (
        <>
          <span
            aria-hidden="true"
            className="pointer-events-none absolute inset-x-0 bottom-0"
            style={{ height: veilHeight(NOTE_LINE, TILE_CAPTION_PAD), background: VEIL }}
          />
          <figcaption className="text-label text-on-media absolute inset-x-0 bottom-0 truncate px-3 pb-3">
            {tile.caption}
          </figcaption>
        </>
      ) : null}
    </figure>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface AiImageCardProps {
  /** Подпись серии в шапке шелла */
  label?: ReactNode;
  /** Крупное число в шапке: «128 генераций», «12 s» */
  value: ReactNode;
  valueSize?: CardValueSize;
  delta?: CardDelta;
  /**
   * Подпись справа сверху. У донора на её месте стоит модель («Fable 5»)
   * в статус-баре, а не период. Роль та же — «чем и когда снято», —
   * поэтому берётся тот же слот шелла, только с другой иконкой.
   */
  period?: CardPeriod;

  /** Текст запроса — то, что у донора набрано в композере */
  prompt: string;
  /** Подпись над пузырём. Донор её не подписывает, у нас пузырь один */
  promptLabel?: string;
  /** Подпись ответа под пузырём. Донор: «Image generated» */
  replyLabel?: string;

  /** Кадры генерации. Пара «ожидание | готово» — типовой случай */
  frames: readonly AiImageFrame[];
  /** Где стоит запрос: сбоку от кадров или над ними */
  promptPlacement?: AiPromptPlacement;

  /** Плитки архива. Нет — карточка остаётся лентой без панели */
  gallery?: readonly AiGalleryTile[];
  /** Ряд табов панели. Донор: «Gallery», «Styles» */
  galleryTabs?: readonly string[];
  /** Выбранный таб. По умолчанию первый */
  activeTab?: string;
  /** Число колонок masonry. Донор — три */
  galleryColumns?: number;
  /** Подпись поверх каждой плитки. По умолчанию выключена — см. предупреждение */
  tileCaptions?: boolean;
  /** Приписка справа от табов: «6 из 128» */
  galleryNote?: string;

  size?: CardShellSize;
  /** Ширина карточки. По умолчанию 1680 у полной, 828 у половинной */
  width?: number;
  height?: number;
  theme?: SlideTheme;
  className?: string;
  style?: CSSProperties;
}

export default function AiImageCard({
  label = "Image generation",
  value,
  valueSize = "m",
  delta,
  period,
  prompt,
  promptLabel = "Prompt",
  replyLabel = "Image generated",
  frames,
  promptPlacement,
  gallery,
  galleryTabs = ["Gallery", "Styles"],
  activeTab,
  galleryColumns = 3,
  tileCaptions = false,
  galleryNote,
  size = "full",
  width,
  height = CARD_BUDGET,
  theme,
  className,
  style,
}: AiImageCardProps) {
  const shown = frames.slice(0, MAX_FRAMES);
  const tiles = gallery?.slice(0, MAX_GALLERY) ?? [];
  const hasGallery = tiles.length > 0;

  const geom = aiImageGeometry({
    width,
    height,
    size,
    valueSize,
    frames: shown.length,
    gallery: hasGallery,
    galleryColumns,
    promptPlacement,
  });

  const layout = hasGallery
    ? packGallery(
        tiles.map((t) => t.ratio),
        galleryColumns,
        geom.tileW,
        geom.masonryH,
      )
    : null;

  if (import.meta.env.DEV) {
    if (frames.length === 0) {
      console.warn(
        "AiImageCard: кадров нет. Карточка про генерацию изображения без единого кадра — " +
          "это подпись и пустое поле; пустой слайд проходит все автопроверки разом.",
      );
    }

    if (frames.length > MAX_FRAMES) {
      console.warn(
        `AiImageCard: кадров ${frames.length}, показано ${MAX_FRAMES}. Приём держится на ` +
          `противопоставлении «до и после»: третий кадр его ещё уточняет, четвёртый ` +
          `превращает пару в ленту, и читатель начинает искать различия там, где их нет.`,
      );
    }

    const states = new Set(shown.map((f) => f.state));
    if (shown.length > 1 && states.size === 1) {
      console.warn(
        `AiImageCard: все кадры в состоянии «${shown[0].state}». Пара кадров заменяет ` +
          `анимацию донора именно разницей состояний; одинаковые кадры читаются как две ` +
          `разные картинки, и смысл «ожидание → результат» пропадает. Если это ` +
          `сознательно варианты одного запроса, а не моменты одного кадра, — ` +
          `предупреждение можно не читать.`,
      );
    }

    for (const frame of shown) {
      if (frame.state === "ready" && frame.timer) {
        console.warn(
          `AiImageCard: у готового кадра «${frame.caption}» задан счётчик «${frame.timer}». ` +
            `Отсчёт у донора существует только пока идёт генерация — на готовом кадре он ` +
            `утверждает, что ожидание продолжается.`,
        );
      }
      if (frame.state === "pending" && !frame.note) {
        console.warn(
          `AiImageCard: у кадра ожидания «${frame.caption}» нет строки состояния. Зерно без ` +
            `подписи — это просто серый прямоугольник: в PDF нечему тикать, и состояние ` +
            `можно передать только текстом.`,
        );
      }

      /*
       * Строка состояния и подпись под кадром обрезаются многоточием, и это
       * правильно: лишняя строка не растянула бы карточку, а выдавила бы
       * кадры за нижний край, где в PDF их отрежет. Но обрезка молчалива —
       * поэтому её надо предсказать до того, как слайд уедет клиенту.
       *
       * Бюджет строки состояния: ширина кадра минус поля 20+20 минус место
       * под счётчик со своим просветом.
       */
      const timerRoom = frame.timer ? frame.timer.length * CHAR_18 + 16 : 0;
      const noteRoom = geom.frameW - NOTE_PAD * 2 - timerRoom;
      if (frame.note && frame.note.length * CHAR_18 > noteRoom) {
        console.warn(
          `AiImageCard: строка «${frame.note}» — ${frame.note.length} знаков, а в кадр ` +
            `шириной ${geom.frameW} их входит ${Math.floor(noteRoom / CHAR_18)}. Остаток ` +
            `обрежется многоточием.`,
        );
      }
      if (frame.caption.length * CHAR_20 > geom.frameW) {
        console.warn(
          `AiImageCard: подпись «${frame.caption}» — ${frame.caption.length} знаков, а под ` +
            `кадром шириной ${geom.frameW} их входит ${Math.floor(geom.frameW / CHAR_20)}. ` +
            `Подпись под кадром — единственное место, где сказано, чем один кадр пары ` +
            `отличается от другого; обрезать её значит потерять сам приём.`,
        );
      }
    }

    if (geom.frameW < 200) {
      console.warn(
        `AiImageCard: кадр ${geom.frameW}×${geom.frameH} — уже донорских 200×250 при том, ` +
          `что носитель в 1.33 раза шире. Высоты не хватает: слот ${geom.slotW}×${geom.slotH}. ` +
          `Либо убрать запрос сверху (promptPlacement="side"), либо оставить один кадр, ` +
          `либо взять полную карточку.`,
      );
    }

    if (geom.placement === "side" && geom.promptW < 260) {
      console.warn(
        `AiImageCard: под запрос осталось ${geom.promptW} точек. Кеглем 20 это ` +
          `${Math.max(0, Math.round((geom.promptW - 48) / 10))} знаков в строку — запрос ` +
          `вытянется в столбик по слову. Порог 260 взят от донорского запроса в 118 знаков: ` +
          `ниже него он занимает больше шести строк. Ставить запрос сверху ` +
          `(promptPlacement="top") или убирать галерею.`,
      );
    }

    if (gallery && gallery.length > MAX_GALLERY) {
      console.warn(
        `AiImageCard: плиток ${gallery.length}, показано ${MAX_GALLERY}. Разведка предлагает ` +
          `3×3; в slide-anatomy.md список длиннее шести пунктов не читают, а пересчитывают. ` +
          `Архив на двадцать плиток — это отдельный слайд, а не панель сбоку.`,
      );
    }

    if (layout?.dropped.length) {
      console.warn(
        `AiImageCard: не поместились плитки ${layout.dropped.join(", ")} — колонки уже заняты ` +
          `(${layout.heights.join(" / ")} из ${geom.masonryH}). Плитка не обрезана, а не ` +
          `нарисована вовсе: обрезанная наполовину читается как брак печати. Убрать лишние ` +
          `или взять более широкие пропорции.`,
      );
    }

    if (hasGallery && tileCaptions) {
      const room = Math.floor((geom.tileW - TILE_CAPTION_PAD * 2) / CHAR_18);
      const cut = tiles.filter((t) => t.caption.length > room).length;
      if (cut > 0) {
        console.warn(
          `AiImageCard: подписи на плитках при ширине ${geom.tileW}. Кеглем 18 туда входит ` +
            `${room} знаков; обрежется ${cut} подпись из ${tiles.length}, то есть плитка ` +
            `покажет огрызок вместо названия. У донора подпись появлялась по наведению и ` +
            `висела над картинкой шириной панели, а не плитки.`,
        );
      }
      const lowest = Math.min(...(layout?.columns.flat().map((c) => c.height) ?? [0]));
      const veil = veilHeight(NOTE_LINE, TILE_CAPTION_PAD);
      if (lowest > 0 && veil / lowest > 0.5) {
        console.warn(
          `AiImageCard: вуаль под подписью — ${veil} точек, а самая низкая плитка ` +
            `${lowest}: затемнение занимает ${Math.round((veil / lowest) * 100)}% её высоты ` +
            `и читается как заливка, а не как подпись поверх картинки. Либо убрать подписи ` +
            `с плиток, либо не давать горизонтальных пропорций.`,
        );
      }
    }

    if (hasGallery && galleryColumns !== 3) {
      console.warn(
        `AiImageCard: колонок галереи ${galleryColumns}, у донора три. Плитка стала ` +
          `${geom.tileW} точек — донорская после переноса это 184.`,
      );
    }

    if (geom.placement === "side" && geom.promptW > 720) {
      console.warn(
        `AiImageCard: под запрос отдано ${geom.promptW} точек — это ` +
          `${Math.round((geom.promptW - 48) / 10)} знаков в строку кеглем 20 при удобном ` +
          `пределе около 70. Столько места остаётся, когда полная карточка стоит без ` +
          `галереи: кадры занимают ${geom.framesW} из ${geom.slotW}, остальное достаётся ` +
          `пузырю. Либо архив справа, либо size="half".`,
      );
    }
  }

  const tabs = galleryTabs;
  const active = activeTab ?? tabs[0];

  /* Пузырь запроса. Подложка `bg-surface-muted`, как у плиток легенды в
     шелле: у донора пузырь СВЕТЛЕЕ своей панели, у нас карточка белая —
     светлее некуда, поэтому подложка уходит на ступень вниз */
  const promptBlock = (
    <div className="flex min-w-0 flex-col" style={{ width: geom.promptW }}>
      <span
        className="text-body-m text-ink-secondary truncate"
        style={{ height: PROMPT_LABEL_LINE }}
      >
        {promptLabel}
      </span>
      {/*
       * Сверху пузырь обрезается по двум строкам, сбоку — по шести.
       * Обрезка не украшение: пузырь стоит в потоке с фиксированной
       * высотой слота, и лишняя строка не растянула бы карточку, а
       * выдавила бы кадры за нижний край.
       *
       * Классы записаны полными литералами: Tailwind сканирует исходники
       * текстом, и `line-clamp-${n}` в сборку не попал бы.
       */}
      <p
        className={`text-body-m text-ink rounded-panel bg-surface-muted px-6 py-5 ${
          geom.placement === "top" ? "line-clamp-2" : "line-clamp-6"
        }`}
        style={{ marginTop: PROMPT_LABEL_GAP }}
      >
        {prompt}
      </p>
      {geom.placement === "side" ? (
        <span
          className="text-body-m text-ink-secondary truncate"
          style={{ marginTop: PROMPT_TOP_GAP, height: PROMPT_LABEL_LINE }}
        >
          {replyLabel}
        </span>
      ) : null}
    </div>
  );

  const framesBlock = (
    <div className="flex shrink-0" style={{ gap: FRAME_GAP }}>
      {shown.map((frame, i) => (
        <Frame
          key={`${frame.caption}-${i}`}
          frame={frame}
          width={geom.frameW}
          height={geom.frameH}
        />
      ))}
    </div>
  );

  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      period={period}
      size={size}
      height={height}
      theme={theme}
      className={className}
      style={style}
    >
      <div className="flex h-full min-w-0" style={{ gap: COLUMN_GAP }}>
        {/* Лента: запрос и кадры */}
        {/*
         * При верхнем размещении кадры ЦЕНТРИРУЮТСЯ по колонке.
         *
         * Причина — замер. На половинной карточке пара кадров занимает 424
         * точки из 788: кадр упирается в высоту, а не в ширину, и растянуть
         * его нечем. Прижатая влево пара оставляет справа 364 точки пустоты
         * ровно там, где у донора шла лента, — и это читается как ошибка
         * вёрстки, а не как воздух. Центрированная пара читается как
         * композиция. Сбоку центрировать нечего: там колонка запроса
         * забирает остаток ширины целиком.
         */}
        <div
          className={
            geom.placement === "side"
              ? "flex min-w-0 items-start"
              : "flex min-w-0 flex-col items-center"
          }
          style={{
            width: geom.feedW,
            gap: geom.placement === "side" ? COLUMN_GAP : PROMPT_TOP_GAP,
          }}
        >
          {promptBlock}
          {framesBlock}
        </div>

        {hasGallery && layout ? (
          /* Разделитель вместо подложки панели: собственный фон у панели
             потребовал бы поля, а поле съело бы ширину плитки. Волосяная
             линия отделяет архив от ленты и ничего не стоит по месту */
          <div
            className="border-line flex shrink-0 flex-col border-l"
            style={{ width: geom.galleryW + COLUMN_GAP + DIVIDER, paddingLeft: COLUMN_GAP }}
          >
            {/*
             * Табы донора — органы управления с бегунком и заливкой. На
             * слайде их не нажать, поэтому от них остаётся ряд слов:
             * выбранное основным цветом, остальные вторичным. Ровно так
             * же поступает шелл с переключателем периода.
             */}
            <div className="flex shrink-0 items-center gap-5" style={{ height: TAB_LINE }}>
              {tabs.map((tab) => (
                <span
                  key={tab}
                  className={
                    tab === active ? "text-body-m text-ink" : "text-body-m text-ink-secondary"
                  }
                >
                  {tab}
                </span>
              ))}
              {galleryNote ? (
                <span className="text-body-m text-ink-secondary ml-auto truncate tabular-nums">
                  {galleryNote}
                </span>
              ) : null}
            </div>

            <div
              className="flex min-h-0"
              style={{ marginTop: TAB_GAP, gap: GALLERY_GAP, height: geom.masonryH }}
            >
              {layout.columns.map((column, ci) => (
                <div
                  key={ci}
                  className="flex flex-col"
                  style={{ width: geom.tileW, gap: GALLERY_GAP }}
                >
                  {column.map((slot) => (
                    <Tile
                      key={slot.index}
                      tile={tiles[slot.index]}
                      width={geom.tileW}
                      height={slot.height}
                      showCaption={tileCaptions}
                    />
                  ))}
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>
    </CardShell>
  );
}
