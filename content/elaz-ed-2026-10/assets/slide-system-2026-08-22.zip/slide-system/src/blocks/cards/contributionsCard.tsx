import { useLayoutEffect, useRef, useState, type ReactNode } from "react";
import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardShellSize,
  type CardValueSize,
} from "./shell";
import { BOARD_CONTRIB_DARK, BOARD_CONTRIB_LIGHT, BOARD_TIER_ZERO } from "../../lib/boardPalette";
import type { SlideTheme } from "../../slide/Slide";

/**
 * Карточка «Вклад за год» — перенос донорского календаря вклада.
 *
 * Заказчик прислал скриншот и попросил сделать из него блок. Переносится
 * КАРТОЧКА ЦЕЛИКОМ, а не одна тепловая лента:
 *
 *   ┌─ карточка ────────────────────────────────────────────────────┐
 *   │  Contributions this year                                      │
 *   │  $7 462  [+14,8%]                                             │
 *   │                                                               │
 *   │  ┌ 9B ────────┐ ┌ 562.7M ────┐ ┌ 12h 54m ───┐ ┌ 62 days ───┐  │
 *   │  │ Lifetime…  │ │ Peak…      │ │ Longest…   │ │ Top streak │  │
 *   │  └────────────┘ └────────────┘ └────────────┘ └────────────┘  │
 *   │                                                               │
 *   │  Activity                        Weekly  Monthly  Yearly      │
 *   │  ▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪  │
 *   │  ▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪▪  │
 *   │  Jan     Feb     Mar     Apr … …                        Dec   │
 *   └───────────────────────────────────────────────────────────────┘
 *
 * Шапка (подпись, число, чип изменения) и бюджет высоты приходят из
 * [`shell.tsx`](./shell.tsx) — своей шапки здесь нет. Всё, что ниже шапки,
 * живёт в этом файле: ряд плиток-фактов, строка «Activity» с подписью
 * периода, тепловая сетка года и подписи месяцев.
 *
 * ═══════════════  ⚠️ Чем это НЕ дубль соседей  ═══════════════
 *
 * В проекте уже две матрицы цветных клеток, и «третья» требует оправдания.
 *
 *   ось              lattice.tsx      heatmapCard.tsx    здесь
 *   ─────────────────────────────────────────────────────────────────────
 *   что это          блок слайда      карточка           карточка
 *   матрица          6–12 × 3–5       12 × 7 (час×день)  53 × 7 (год)
 *   клеток           до 60            84                 371
 *   в клетке         ЧИСЛО 24/32      ничего, 40×40      ничего, 22.5×22.5
 *   подписи осей     обе оси          обе оси            только месяцы
 *   шкала            синяя, 4 ступени синяя, непрерывная фиолетовая, 5 или 4
 *   что читают       значение ячейки  суточный ритм      форма года
 *
 * Разница не в оформлении, а в том, что клетка перестаёт быть читаемой
 * единицей: при 371 клетке ни цифры, ни подписи строк не помещаются, и
 * сообщением становится РИСУНОК года — где густо, где провал, где стрик.
 * Обратно тоже: год нельзя показать 60 клетками решётки.
 *
 * ═══════════════  ⚠️ Главное измерение: сторона клетки  ═══════════════
 *
 * Вопрос «читается ли клетка с 3–5 метров» решается числом, а не мнением.
 *
 * Карточка во всю рабочую ширину: слот графика 1608 × 408 (замер функциями
 * `cardChartWidth`/`cardChartHeight` из shell.tsx при бюджете 604, числе
 * `headline-l` и без легенды). Внутри слота:
 *
 *   плитки фактов        100
 *   просвет               24
 *   строка «Activity»     32
 *   просвет               12
 *   СЕТКА                208   ← остаток, а не выбранное число
 *   просвет                8
 *   подписи месяцев       24
 *   ─────────────────────────
 *   итого                408
 *
 * Полный год от воскресенья до субботы — это **53 колонки**, а не 52:
 * 365 дней плюс хвосты первой и последней недели на семь не делятся.
 * При просвете 8 клетка выходит **22.49 × 22.49** (ограничивает ширина
 * колонки: высота дала бы 22.86, сетка 205.43 центруется в полосе 208).
 * Ровно 52 колонки дали бы 23.08 × 22.86. Донорская клетка — 10.97 при
 * карточке 582.
 *
 * Что это значит на показе, тоже числами. 22.49 из 1920 — это 1.17% ширины
 * кадра. На экране шириной 2.5 м клетка занимает **2.9 см**, с четырёх
 * метров это угловой размер **0.42° (25′)** — примерно как знак `text-body-l`
 * (24px → 3.1 см → 27′). То есть САМА КЛЕТКА видна: она крупнее нижнего
 * кегля шкалы (16px → 2.1 см → 18′).
 *
 * Замер в 1:1 (Storybook, история «На слайде», `transform` холста = `none`):
 * карточка 1680 × 604, полоса сетки 1608 × 208, сетка 1608 × 205.39, клетка
 * 22.48 × 22.48, просвет 8, радиус клетки 6, клеток 371 = 53 × 7. Расчёт и
 * факт расходятся на 0.01 — это округление долевой колонки браузером.
 *
 * ⚠️ Но видно пятно, а не ступень. Соседние ступени лестницы различаются
 * в 1.24–1.54 раза по контрасту (замеры ниже), и на пятне 2.9 см с засветкой
 * проектора это различие пропадает первым. Вывод для слайда: **год целиком
 * годится, чтобы показать ФОРМУ года** — где густо, где провал, где стрик;
 * читать по ним отдельный день или отличать «три вклада» от «пяти» нельзя.
 * Если слайд должен сообщать именно интенсивность, сводить недели по две
 * (27 колонок, клетка 51.85 × 22.86) — пятно становится вдвое шире, а лента
 * остаётся во всю ширину. Обе раскладки показаны в историях.
 *
 * ═══════════════  ⚠️ Лестница: первая ступень слабее нуля  ═══════════════
 *
 * Краски — донорские, как просил заказчик: `BOARD_CONTRIB_LIGHT` /
 * `BOARD_CONTRIB_DARK`, нулевая ступень `BOARD_TIER_ZERO`. Замер функцией
 * `contrast` (lib/color.ts) к СВОЕЙ карточке — к #ffffff в светлой теме
 * и к #262626 в тёмной:
 *
 *   ступень          светлая            тёмная
 *   0 «нет»          #d4d4d4  1.48      #2f2f2f  1.13
 *   1                #ddd6ff  1.39      #2f0d68  1.01
 *   2                #a684ff  2.85      #5d0ec0  1.65
 *   3                #8e51ff  4.40      #7008e7  2.07
 *   4                #7f22fe  5.89      #7f22fe  2.57
 *   5                #7008e7  7.30      #8e51ff  3.44
 *
 * Лестница НЕМОНОТОННА на первом шаге, и в обеих темах сразу: ступень «один
 * вклад» контрастирует с фоном СЛАБЕЕ, чем ступень «вкладов не было»
 * (1.39 против 1.48 и 1.01 против 1.13). Друг от друга они отличаются в
 * 1.07 и 1.14 раза — это неразличимо и вблизи, не то что с четырёх метров.
 *
 * То есть на слайде «день с активностью» выглядит пустее, чем пустой день.
 * Это не ошибка переноса: у донора карточка #f7f7f7 / #171717, и на ней
 * порядок другой. На нашей белой карточке донорская лестница переворачивается
 * внизу. Разведка отметила ту же беду и на самом доноре в тёмной теме.
 *
 * Поэтому у карточки есть `scale`:
 *
 *   `scale="donor"` (по умолчанию) — пять ступеней, ровно как на скриншоте.
 *   `scale="readable"` — нижняя ступень отброшена, остаются четыре:
 *        светлая 2.85 · 4.40 · 5.89 · 7.30 при нуле 1.48 — шаг 0→1 = 1.92
 *        тёмная  1.65 · 2.07 · 2.57 · 3.44 при нуле 1.13 — шаг 0→1 = 1.46
 *      Лестница становится монотонной, «был вклад» отличается от «не было».
 *
 * Умолчание оставлено донорским сознательно: заказчик просил цвета как на
 * скриншотах, а решение о числе ступеней — содержательное, и принимать его
 * молча внутри блока нельзя. Число ступеней меняет то, ЧТО читается со
 * слайда, а не только как он выглядит.
 *
 * ═══════════════  Что из донора не перенесено  ═══════════════
 *
 * • Появление клеток волной (`cell-pop`, 0.38s) — в PDF один кадр, и какой
 *   именно, неизвестно. Анимация не несёт данных: сетка статична по природе.
 * • Подсказки по наведению — их нет и у донора (курсор `default`), значение
 *   дня жило только в `aria-label`. На слайде отдельный день не читается
 *   (см. измерение выше), поэтому и метки на клетках здесь нет: 364 узла с
 *   текстом ради того, чего не видно, — это вес и шум.
 * • Сегмент-контрол «Weekly / Monthly / Yearly» как ОРГАН УПРАВЛЕНИЯ.
 *   Здесь это подпись: выбранное слово основным цветом, остальные —
 *   вторичным, ни дорожки, ни подложки-пилюли, ни бегунка. Ровно так его
 *   рисует и сам донор («выбранное состояние отличается ТОЛЬКО весом и
 *   цветом текста»), только вес у нас один, поэтому различие держит цвет.
 *   Не нужны остальные периоды — не передавать `periods`, останется одно
 *   слово; не нужен и он — не передавать ничего.
 *
 * ═══════════════  Почему подписи месяцев вторичным цветом  ═══════════════
 *
 * У донора месяцы набраны третичным (#525252 / #a1a1a1). У нас третичный
 * разрешён только от кегля 24 (замер: в светлой теме 3.79:1 на карточке при
 * пороге 4.5), а месяцы — `text-label` 18. Поэтому вторичный: 5.41:1 в
 * светлой теме на карточке, 6.00:1 в тёмной.
 */

/* ═══════════════  Геометрия  ═══════════════ */

/** Строк в сетке — дни недели. Семь, и это не настройка */
const ROWS = 7;

/** Плитка факта: `py-4` 32 + значение 36 + `gap-1` 4 + подпись 28 = 100.
 *  Ровно как плитка легенды в shell.tsx — карточки одного семейства */
const FACTS_HEIGHT = 100;

/** Просвет между плитками фактов и блоком активности. Тот же, что в shell */
const ROW_GAP = 24;

/** Строка «Activity»: `text-body-l` 24/32 */
const ACTIVITY_HEIGHT = 32;

/** Просвет «Activity» → сетка (донор 4 при кегле 14; у нас 12 при 24) */
const ACTIVITY_GAP = 12;

/** Просвет сетка → месяцы (донор 6; у нас 8 — он же просвет между клетками) */
const MONTHS_GAP = 8;

/** Строка месяцев: `text-label` 18/24 */
const MONTHS_HEIGHT = 24;

/**
 * Просвет между клетками. Донор: 4 при клетке 10.97, то есть 36% стороны.
 * У нас 8 при клетке 22.86 — 35%. Перенесена ДОЛЯ, а не число.
 */
const CELL_GAP: Record<CardShellSize, number> = { full: 8, half: 4 };

/** Ширина карточки по умолчанию: во всю рабочую область или в шесть колонок */
const DEFAULT_CARD_WIDTH: Record<CardShellSize, number> = { full: 1680, half: 828 };

export interface ContributionsMetrics {
  /** Ширина слота графика: карточка минус поля */
  slotWidth: number;
  /** Высота слота графика */
  slotHeight: number;
  /** Высота полосы, отданной сетке */
  bandHeight: number;
  /** Просвет между клетками */
  gap: number;
  /** Ширина клетки — доля `1fr` от ширины слота */
  cellWidth: number;
  /** Высота клетки */
  cellHeight: number;
  /** Фактическая высота сетки */
  gridHeight: number;
  columns: number;
}

/**
 * Размеры сетки числами.
 *
 * Высота клетки — `min` из двух пределов, и ни один нельзя убрать:
 *
 *   по ширине   (slot − (n−1)·gap) / n — сколько даёт колонка;
 *   по высоте   (полоса − 6·gap) / 7  — сколько осталось от бюджета.
 *
 * При 53 колонках во всю ширину узок ПЕРВЫЙ (22.49 против 22.86) — клетка
 * квадратная, а сетка (205.43) на 2.57 ниже полосы и центруется в ней.
 * При 27 колонках узок ВТОРОЙ, и клетка становится кирпичом 51.85 × 22.86:
 * лента остаётся во всю ширину, а пятно вдвое шире. На половинной карточке
 * первый предел падает до 11.23 против 30.86 — клетка квадратная и мелкая,
 * ровно донорская, а сетка вдвое ниже полосы.
 *
 * Без `min` сетка вылезла бы за слот, а в PDF вылезшее просто обрезается.
 */
export function contributionsMetrics({
  cardWidth,
  slotWidth: measured,
  height = CARD_BUDGET,
  size = "full",
  valueSize = "m",
  columns = 52,
  facts = true,
}: {
  cardWidth?: number;
  /** Замеренная ширина слота. Передана — вытесняет расчёт от `cardWidth` */
  slotWidth?: number;
  height?: number;
  size?: CardShellSize;
  valueSize?: CardValueSize;
  columns?: number;
  facts?: boolean;
} = {}): ContributionsMetrics {
  const slotWidth = measured ?? cardChartWidth(cardWidth ?? DEFAULT_CARD_WIDTH[size], size);
  const slotHeight = cardChartHeight({ height, size, valueSize, legend: false });
  const gap = CELL_GAP[size];

  const bandHeight =
    slotHeight -
    (facts ? FACTS_HEIGHT + ROW_GAP : 0) -
    ACTIVITY_HEIGHT -
    ACTIVITY_GAP -
    MONTHS_GAP -
    MONTHS_HEIGHT;

  const cellWidth = (slotWidth - (columns - 1) * gap) / columns;
  const cellHeight = Math.max(0, Math.min(cellWidth, (bandHeight - (ROWS - 1) * gap) / ROWS));

  return {
    slotWidth,
    slotHeight,
    bandHeight,
    gap,
    cellWidth,
    cellHeight,
    gridHeight: ROWS * cellHeight + (ROWS - 1) * gap,
    columns,
  };
}

/* ═══════════════  Тема  ═══════════════ */

/**
 * Активная тема по ближайшему предку с `data-theme` + фактическая ширина
 * слота.
 *
 * Тема нужна в JS, а не в CSS, потому что лестниц ДВЕ и это не инверсия
 * одной: в светлой теме ступени идут violet 200→700 (бледный → глухой),
 * в тёмной 950→500 (почти чёрный → яркий). Тот же приём и по той же причине
 * применён в [`lattice.tsx`](../lattice.tsx) и [`chartsLine.tsx`](../chartsLine.tsx);
 * оттуда он не импортируется, потому что там он не экспортирован, а тащить
 * ради трёх строк общий модуль — лишняя связность между блоками.
 *
 * `useLayoutEffect`, а не `useEffect`: он отрабатывает ДО отрисовки, поэтому
 * первого кадра со светлой лестницей на тёмном слайде не бывает. Для PDF это
 * существенно — там кадр ровно один.
 *
 * Ширина меряется `offsetWidth`, а НЕ `getBoundingClientRect().width`:
 * в Storybook холст по умолчанию сжат `transform: scale`, и прямоугольник
 * вернул бы число после трансформации — клетка посчиталась бы от ширины
 * ноутбука. `offsetWidth` даёт ширину по вёрстке (правило
 * `.claude/rules/layout-verification.md`).
 *
 * Зачем мерить, если ширина уже пришла свойством: свойство — это ОБЕЩАНИЕ
 * вызывающего. Карточка, поставленная в колонку другой ширины, посчитала бы
 * клетку не от той величины и молча вылезла бы за слот. Замер обещание
 * проверяет и, если оно разошлось с действительностью, чинит расчёт сам.
 */
function useGridEnvironment(expectedWidth: number) {
  const ref = useRef<HTMLDivElement>(null);
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [width, setWidth] = useState(expectedWidth);

  useLayoutEffect(() => {
    const node = ref.current;
    if (!node) return;

    const host = node.closest("[data-theme]");
    setTheme(host?.getAttribute("data-theme") === "dark" ? "dark" : "light");

    // Округление до целого: offsetWidth и так целый, сравнение точное
    const measured = node.offsetWidth;
    if (measured > 0 && Math.abs(measured - width) > 1) setWidth(measured);
  });

  return { ref, theme, width };
}

/* ═══════════════  Данные  ═══════════════ */

/**
 * Колонка сетки — неделя, семь дней сверху вниз.
 *
 * `null` означает «такого дня в году нет» (хвосты первой и последней
 * недели), а не «нулевая активность»: пустая клетка не рисуется вовсе,
 * нулевая рисуется серой. Их нельзя путать — иначе год начинается и
 * кончается фальшивыми пустыми днями.
 */
export type ContributionWeek = readonly (number | null)[];

export interface ContributionMonth {
  /** «Jan», «Янв» — как в источнике, блок не переводит */
  label: string;
  /** Индекс колонки, с которой начинается месяц (от нуля) */
  week: number;
}

export interface ContributionFact {
  /** Готовое значение: «9B», «12h 54m». Форматирование — забота слайда */
  value: string;
  /** Подпись под значением */
  label: string;
}

/** Лестница: `donor` — пять ступеней как на скриншоте, `readable` — четыре */
export type ContributionScale = "donor" | "readable";

/**
 * Ступень клетки: −1 «дня нет», 0 «активности не было», 1…steps.
 *
 * Отображение ЛИНЕЙНОЕ от потолка: ступень = ⌈значение / потолок · ступени⌉.
 * Квантили (равное число клеток на ступень) дали бы более нарядную картинку,
 * но они врут: при них год без всплесков раскрашивается так же ярко, как год
 * с ними, потому что шкала подстраивается под распределение. На клиентском
 * слайде это прямая подмена вывода.
 */
function tierOf(value: number | null, max: number, steps: number) {
  if (value === null || Number.isNaN(value)) return -1;
  if (value <= 0) return 0;
  return Math.min(steps, Math.max(1, Math.ceil((value / max) * steps)));
}

/* ═══════════════  Плитки фактов  ═══════════════ */

/**
 * Ряд сводных чисел под шапкой: значение сверху, подпись под ним.
 *
 * ⚠️ Расхождение со снятым замером донора, названное вслух: у донора
 * значение и подпись набраны ОДНИМ кеглем (14/20) и различаются только
 * цветом. Здесь значение крупнее — `title-l` 30 против `body-m` 20.
 *
 * Причина носителя, а не вкуса. Донорская карточка — 582 точки на экране
 * в полуметре от глаз; наша — 1680 на проекторе в четырёх метрах. Разница
 * «основной цвет против вторичного» на таком расстоянии съедается засветкой
 * первой, и плитка превращается в две одинаковые строки, где неясно, что из
 * них число. Система для этого случая и держит правило: иерархия, которую
 * нельзя удержать цветом, держится размером.
 *
 * Подложка `bg-surface-muted`, а не белая: у донора плитка СВЕТЛЕЕ карточки
 * (#ffffff на #f7f7f7), у нас карточка сама белая — светлее некуда, поэтому
 * плитка уходит на ступень вниз. То же переворачивание, что у плиток легенды
 * и плашки периода в shell.tsx. Обводки нет по той же причине: разницу
 * поверхностей уже несёт заливка, контур был бы третьим сигналом об одном.
 *
 * Контраст текста на этой подложке (замер `contrast`, lib/color.ts):
 *   светлая  значение #0a0a0a на #f0f0f0 — 17.37:1 · подпись #6a6a6a — 4.75:1
 *   тёмная   значение #fafafa на #1c1c1c — 16.33:1 · подпись #a3a3a3 — 6.76:1
 * Подпись 20px требует 4.5 — проходит в обеих темах.
 */
export function ContributionFacts({
  items,
  size = "full",
}: {
  items: readonly ContributionFact[];
  size?: CardShellSize;
}) {
  return (
    <div
      className={`grid shrink-0 ${size === "full" ? "gap-6" : "gap-3"}`}
      style={{
        height: FACTS_HEIGHT,
        gridTemplateColumns: `repeat(${items.length}, minmax(0, 1fr))`,
      }}
    >
      {items.map((item) => (
        <div
          key={item.label}
          className="bg-surface-muted flex min-w-0 flex-col justify-center gap-1 rounded-tile px-5 py-4"
        >
          <span className="text-title-l text-ink truncate tabular-nums">{item.value}</span>
          <span className="text-body-m text-ink-secondary truncate">{item.label}</span>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════  Подпись периода  ═══════════════ */

/**
 * Ряд слов вместо сегмент-контрола.
 *
 * Форма повторяет `PeriodLabel` из shell.tsx (там она стоит в шапке
 * карточки, здесь — в строке «Activity», как на скриншоте донора).
 * Продублирована сознательно: в shell она не экспортирована, а править
 * общий файл ради одной карточки — значит менять оболочку всех семи.
 *
 * Просвет `gap-5` (20) — тот же, что в shell: у донора соседство кнопок
 * держала дорожка, без неё слова, стоящие вплотную, слипаются в строку.
 */
function PeriodWords({ period, periods }: { period?: string; periods?: readonly string[] }) {
  if (!periods?.length) {
    return period ? <span className="text-label text-ink shrink-0">{period}</span> : null;
  }

  return (
    <div className="text-label flex shrink-0 items-center gap-5">
      {periods.map((item) => (
        <span key={item} className={item === period ? "text-ink" : "text-ink-secondary"}>
          {item}
        </span>
      ))}
    </div>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface ContributionsCardProps {
  /** Подпись сверху слева: «Contributions this year» */
  label: ReactNode;
  /** Крупное число: «$7 462» */
  value: ReactNode;
  /** `m` — `headline-l` 56 (по умолчанию), `l` — `display-s` 72 */
  valueSize?: CardValueSize;
  /** Чип изменения рядом с числом */
  delta?: CardDelta;
  /** Ряд сводных чисел. Не передан — сетка получает на 124 больше */
  facts?: readonly ContributionFact[];
  /** Подпись над сеткой. По умолчанию «Activity» */
  activityLabel?: ReactNode;
  /** Выбранный период — ПОДПИСЬ, а не переключатель */
  period?: string;
  /** Весь ряд периодов, включая выбранный. Не передан — одно слово */
  periods?: readonly string[];
  /** Колонки сетки: недели года, каждая — семь дней сверху вниз */
  weeks: readonly ContributionWeek[];
  /** Подписи месяцев с номером колонки, в которой месяц начинается */
  months?: readonly ContributionMonth[];
  /**
   * Потолок шкалы. Не передан — берётся максимум по данным.
   *
   * Передавать стоит, когда рядом стоит вторая такая карточка: без общего
   * потолка два года раскрасятся каждый по своему максимуму, и слабый год
   * будет выглядеть как сильный.
   */
  max?: number;
  /** `donor` — пять ступеней как на скриншоте, `readable` — четыре. См. шапку */
  scale?: ContributionScale;
  size?: CardShellSize;
  /** Высота карточки. По умолчанию весь бюджет блока — 604 */
  height?: number;
  /**
   * Ширина карточки. Нужна, чтобы посчитать клетку ДО отрисовки; после
   * отрисовки блок сверяет её с фактической и пересчитывает при расхождении.
   */
  cardWidth?: number;
  /** Вложенная тема */
  theme?: SlideTheme;
  className?: string;
}

export default function ContributionsCard({
  label,
  value,
  valueSize = "m",
  delta,
  facts,
  activityLabel = "Activity",
  period,
  periods,
  weeks,
  months,
  max,
  scale = "donor",
  size = "full",
  height = CARD_BUDGET,
  cardWidth,
  theme,
  className,
}: ContributionsCardProps) {
  const columns = weeks.length;
  const expected = contributionsMetrics({
    cardWidth,
    height,
    size,
    valueSize,
    columns,
    facts: Boolean(facts?.length),
  });

  const { ref, theme: active, width } = useGridEnvironment(expected.slotWidth);

  // Пересчёт от ФАКТИЧЕСКОЙ ширины: свойство могло разойтись с колонкой
  const metrics =
    width === expected.slotWidth
      ? expected
      : contributionsMetrics({
          slotWidth: width,
          height,
          size,
          valueSize,
          columns,
          facts: Boolean(facts?.length),
        });

  const full = active === "dark" ? BOARD_CONTRIB_DARK : BOARD_CONTRIB_LIGHT;
  const ladder: readonly string[] = scale === "readable" ? full.slice(1) : full;
  const zero = BOARD_TIER_ZERO[active];

  const ceiling = max ?? Math.max(1, ...weeks.flatMap((w) => w.map((d) => d ?? 0)));

  const template = `repeat(${columns}, minmax(0, 1fr))`;

  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      size={size}
      height={height}
      theme={theme}
      className={className}
    >
      <div className="flex h-full flex-col" style={{ gap: ROW_GAP }}>
        {facts?.length ? <ContributionFacts items={facts} size={size} /> : null}

        <div className="flex min-h-0 flex-1 flex-col">
          <div
            className="flex shrink-0 items-center justify-between gap-6"
            style={{ height: ACTIVITY_HEIGHT }}
          >
            <span className="text-body-l text-ink min-w-0 truncate">{activityLabel}</span>
            <PeriodWords period={period} periods={periods} />
          </div>

          {/*
           * Полоса сетки. `items-center`: когда клетку ограничивает ширина
           * (половинная карточка), сетка ниже полосы, и остаток делится
           * поровну сверху и снизу вместо того, чтобы висеть под «Activity».
           *
           * `min-h-0` обязателен — без него флекс-элемент не может стать
           * меньше содержимого, и сетка вытолкнула бы месяцы из карточки.
           */}
          <div
            ref={ref}
            className="flex min-h-0 flex-1 items-center"
            style={{ marginTop: ACTIVITY_GAP }}
          >
            {/*
             * Порядок в разметке — ПО КОЛОНКАМ (`grid-auto-flow: column`),
             * поэтому данные лежат неделями и не приходится переплетать их
             * построчно. Строки заданы явной высотой, колонки — долями `1fr`
             * от ширины слота: доли не копят ошибку округления, а цельная
             * высота строки не даёт сетке вылезти из полосы.
             */}
            <div
              className="w-full"
              role="img"
              aria-label={
                typeof activityLabel === "string" ? activityLabel : "Активность по дням года"
              }
              style={{
                display: "grid",
                gridAutoFlow: "column",
                gridTemplateColumns: template,
                gridTemplateRows: `repeat(${ROWS}, ${metrics.cellHeight}px)`,
                gap: metrics.gap,
              }}
            >
              {weeks.map((week, w) =>
                Array.from({ length: ROWS }, (_, d) => {
                  const tier = tierOf(week[d] ?? null, ceiling, ladder.length);
                  return (
                    <div
                      key={`${w}-${d}`}
                      className="rounded-micro"
                      style={{
                        background: tier < 0 ? undefined : tier === 0 ? zero : ladder[tier - 1],
                      }}
                    />
                  );
                }),
              )}
            </div>
          </div>

          {/*
           * Месяцы. Тот же шаблон колонок и тот же просвет, что у сетки, —
           * поэтому подпись стоит ровно над своей неделей, а не «примерно
           * там». Донорский `justify-between` этого не даёт: он распределяет
           * двенадцать слов поровну, и к декабрю подпись уезжает от своего
           * месяца на неделю.
           *
           * Каждая подпись РАСТЯНУТА до начала следующего месяца. Не ради
           * вида: в колонке шириной 23 слово «Jan» (30 точек) вылезло бы за
           * свой бокс, и проверка ширины из layout-verification.md сочла бы
           * это переполнением. Растянутый бокс — 133 точки, ход строки
           * помещается целиком.
           */}
          {months?.length ? (
            <div
              className="shrink-0"
              style={{
                marginTop: MONTHS_GAP,
                height: MONTHS_HEIGHT,
                display: "grid",
                gridTemplateColumns: template,
                gap: metrics.gap,
              }}
            >
              {months.map((month, i) => {
                const next = months[i + 1]?.week ?? columns;
                return (
                  <span
                    key={`${month.label}-${month.week}`}
                    className="text-label text-ink-secondary min-w-0 truncate"
                    style={{
                      gridColumn: `${month.week + 1} / span ${Math.max(1, next - month.week)}`,
                    }}
                  >
                    {month.label}
                  </span>
                );
              })}
            </div>
          ) : null}
        </div>
      </div>
    </CardShell>
  );
}
