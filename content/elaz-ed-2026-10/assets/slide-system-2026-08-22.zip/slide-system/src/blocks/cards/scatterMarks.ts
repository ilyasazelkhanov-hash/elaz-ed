import { MARK_GAP } from "./axis";

/**
 * Раскладка подписи ключевой точки на точечной карточке.
 *
 * Вынесено из [`scatterCard.tsx`](./scatterCard.tsx) отдельным файлом:
 * это самостоятельная задача — «найти свободное место рядом с кругом», —
 * и она не про рисование. В карточке остаётся геометрия поля и краски,
 * здесь только поиск места и его правило.
 *
 * ⚠️ Правило жёсткое: подпись НЕ ложится на пузырёк вовсе. Причина —
 * замер контраста в шапке `scatterCard.tsx`: в тёмной теме на салатовой
 * заливке `#9ae600` при непрозрачности 0.85 белый текст (`--t-ink`
 * #fafafa) даёт 1.93:1, а вторичный #a3a3a3 — 1.25:1 при пороге 4.5. Читаемого цвета текста на этой
 * заливке НЕ СУЩЕСТВУЕТ, поэтому «немного задеть пузырёк» здесь не
 * компромисс, а потерянная подпись.
 */

export interface Box {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

export interface Circle {
  cx: number;
  cy: number;
  r: number;
}

export type MarkAnchor = "start" | "end" | "middle";

export interface MarkPlacement {
  x: number;
  y: number;
  anchor: MarkAnchor;
}

/**
 * Бокс подписи относительно её якоря при `dominant-baseline: middle`.
 *
 * Замер в 1:1 (`blocks/scatter.tsx`, витрина «Блоки/Точечная диаграмма»)
 * для кегля 20 дал подъём 14.40 и свес 10.60 при высоте бокса 25.
 * Здесь кегль 26 (`MARK_SIZE` из `axis.ts`), числа пересчитаны по кеглю
 * (×1.3 → 18.7 и 13.8) и округлены ВВЕРХ: бокс, посчитанный меньше
 * настоящего, пропустил бы наложение подписи на пузырёк, а лишняя точка
 * просвета не стоит ничего.
 *
 * Асимметрия нормальна: бокс строки считается от метрик шрифта, а не от
 * чернил конкретного слова.
 */
export const MARK_UP = 20;
export const MARK_DOWN = 15;

const overlaps = (a: Box, b: Box) =>
  a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;

const inside = (a: Box, bounds: Box) =>
  a.left >= bounds.left &&
  a.right <= bounds.right &&
  a.top >= bounds.top &&
  a.bottom <= bounds.bottom;

/**
 * Куда поставить подпись ключевой точки.
 *
 * Четыре кандидата в порядке предпочтения: справа, слева, сверху, снизу.
 * Справа первым, потому что подпись читается слева направо и взгляд от
 * круга уходит вправо естественно; сверху и снизу — запасные, они съедают
 * вертикаль, которой в карточке меньше всего.
 *
 * Кандидат принимается, только если бокс подписи целиком внутри
 * переданных границ И не пересекается ни с одним кругом (габарит круга
 * берётся вместе с его обводкой — считает вызывающая сторона).
 *
 * Границы задаёт карточка, и они ШИРЕ поля построения: туда входят пустые
 * верхнее и правое поля SVG. Замер показал, почему это важно: при границах
 * ровно по полю построения обе подписи донорского примера отбрасывались —
 * справа не хватало 20 точек, слева мешал сосед.
 *
 * Ни один не подошёл — возвращается `null`, подпись не рисуется, а в
 * разработке печатается предупреждение. Молча положить подпись поверх
 * данных нельзя: на слайде это читается как ошибка вёрстки, а в PDF
 * никакого «навести и прочитать» уже не будет.
 */
export function placeMark(
  circle: Circle,
  width: number,
  bounds: Box,
  circles: readonly Box[],
): MarkPlacement | null {
  const gap = MARK_GAP;
  const half = width / 2;
  const { cx, cy, r } = circle;

  const candidates: (MarkPlacement & { box: Box })[] = [
    {
      x: cx + r + gap,
      y: cy,
      anchor: "start",
      box: {
        left: cx + r + gap,
        right: cx + r + gap + width,
        top: cy - MARK_UP,
        bottom: cy + MARK_DOWN,
      },
    },
    {
      x: cx - r - gap,
      y: cy,
      anchor: "end",
      box: {
        left: cx - r - gap - width,
        right: cx - r - gap,
        top: cy - MARK_UP,
        bottom: cy + MARK_DOWN,
      },
    },
    {
      x: cx,
      y: cy - r - gap - MARK_DOWN,
      anchor: "middle",
      box: {
        left: cx - half,
        right: cx + half,
        top: cy - r - gap - MARK_DOWN - MARK_UP,
        bottom: cy - r - gap,
      },
    },
    {
      x: cx,
      y: cy + r + gap + MARK_UP,
      anchor: "middle",
      box: {
        left: cx - half,
        right: cx + half,
        top: cy + r + gap,
        bottom: cy + r + gap + MARK_UP + MARK_DOWN,
      },
    },
  ];

  for (const c of candidates) {
    if (!inside(c.box, bounds)) continue;
    if (circles.some((b) => overlaps(c.box, b))) continue;
    return { x: c.x, y: c.y, anchor: c.anchor };
  }
  return null;
}
