import type { CSSProperties, ReactNode } from "react";
import {
  ArrowUp,
  BranchingPathsUp,
  CheckCircle,
  MagicStick3,
  Microphone,
  Paperclip,
} from "@solar-icons/react";
import { cardTextWidth, useRemeasureOnFont } from "./axis";
import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
} from "./shell";
import { cssGradient, type GradientStop } from "../../lib/color";
import { BOARD_HEAT } from "../../lib/boardPalette";
import type { SolarIcon } from "../../lib/solar";
import type { SlideTheme } from "../../slide/Slide";

/**
 * Карточка-дашборд «переписка с агентом» — перенос донорского переписки.
 *
 *   ┌─ карточка ────────────────────────────────────────────────────────┐
 *   │  Остаток контекста                        Ask  Agent  Plan        │
 *   │  57%                                                              │
 *   │                                                                   │
 *   │                 ┌────────────────────────────────┐  ┌──┐          │
 *   │                 │ обнови токены тёмной темы …    │  │ М│          │
 *   │                 └────────────────────────────────┘  └──┘          │
 *   │  ┌──┐  Обдумывал 12,4 с                                           │
 *   │  │✦ │  Готово — семантические токены и переключатель темы …       │
 *   │  └──┘  ┌─ TSX · theme-toggle.tsx           +56 −14 ─────────────┐ │
 *   │        │  export function ThemeToggle() {                       │ │
 *   │        └───────────────────────────────────────────────────────┘ │
 *   │  ⎡ 📎  Ask me anything            Fable 5   🎤  ↑ ⎤               │
 *   │    main · project-sea · Agent · 57%                               │
 *   └───────────────────────────────────────────────────────────────────┘
 *
 * Оболочка (шапка, крупное число, чип, ярлык периода) живёт в
 * [`shell.tsx`](./shell.tsx) — своей шапки здесь нет. Спецификация разведки — во внутреннем разборе.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Что перенесено, а что нет: у донора это ТРИ колонки, здесь ОДНА
 * ═══════════════════════════════════════════════════════════════════
 *
 * Донор — трёхколоночная оболочка: сайдбар 260 с деревом репозиториев,
 * центр с лентой и композером, правая панель 410 с диффом и кодом. Всё это
 * при окне 1440, то есть основной текст 14/20.
 *
 * Целиком на слайд это не переносится, и разведка назвала причину числом:
 * коэффициент 1920/1440 = 1.333, донорские 14px становятся 18.7 — ниже
 * рабочего кегля презентации (24) и почти на полу шкалы (16). Три колонки
 * на 1680 точках означают ленту шириной ~830, а в ней при кегле 24 строка
 * держит около 65 знаков: донорская реплика пользователя (137 знаков) встала
 * бы в 3 строки, а ответ с карточкой кода не поместился бы вовсе.
 *
 * Поэтому взят ОДИН фрагмент крупно — ровно та из двух развилок разведки,
 * которая оставляет текст читаемым: **лента переписки во всю ширину
 * карточки**. Сайдбар и панель диффа не переносятся: дерево чатов и номера
 * строк кода на слайде не читают, а место они съедают целиком.
 *
 * Что из этого следует для раскладки: карточка переписки — форма
 * СПИСОЧНАЯ, и её место — вся рабочая ширина. Это противоположно линиям и
 * столбикам, которые честнее ставить в половину (замер пропорций поля — в
 * шапке `shell.tsx`). `size="half"` здесь предусмотрен, но он рабочий только
 * для очень коротких реплик — цифры в витрине, история «Опасный случай».
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ Движение у донора несёт смысл. Что вместо него
 * ═══════════════════════════════════════════════════════════════════
 *
 * Демо донора крутит цикл: печать запроса → пузырь → «Thinking N.Ns»
 * с растущим таймером → карточка плана, где шаги по очереди отмечаются
 * и счётчик «N steps left» перещёлкивается → потоковый вывод ответа →
 * карточка кода → сброс в пустую ленту. Композер всё это время обведён
 * бегущим градиентным штрихом.
 *
 * В PDF остаётся один кадр, и неизвестно какой. Отсюда три решения:
 *
 *   1. **Таймер печатается числом.** `meta: "Обдумывал 12,4 с"` — это
 *      застывшее значение, а не индикатор. Растущий счётчик на статике
 *      выглядит как случайное число; напечатанное — как факт.
 *   2. **План берётся наполовину выполненным.** Состояния шага три:
 *      `done` · `active` · `todo`, и кадр «часть с галочками, один
 *      в контуре» — единственный, который сообщает «работа идёт».
 *      Ровно это предложила разведка.
 *   3. **Бегущая обводка композера НЕ переносится.** Она у донора собрана
 *      из трёх вложенных rect со stroke-width 32/8/2.5 и размытием 14/6/0.5;
 *      застывший сегмент такой дуги читается как дефект печати, а не как
 *      «агент работает». Смысл «идёт работа» уже несёт план.
 *
 * И отдельно — **пустая лента**. У донора цикл начинается с пустого экрана,
 * и разведка отметила это как ловушку скриншота. Здесь пустой массив реплик
 * даёт предупреждение в DEV: пустая карточка проходит все автопроверки
 * разом (в `npm run check` не зря есть отдельная проверка на пустоту).
 *
 * ═══════════════════════════════════════════════════════════════════
 * Чего на слайде нет: органы управления
 * ═══════════════════════════════════════════════════════════════════
 *
 * | У донора | Здесь |
 * | --- | --- |
 * | Табы «Changes / Browser» со скользящей подложкой | нет панели — нет табов |
 * | Переключатель режима Ask/Agent/Plan | ряд слов в ярлыке периода `shell.tsx` |
 * | Ряд обратной связи: лайк, дизлайк, копировать, повторить | **не перенесён** |
 * | Кнопка copy в шапке карточки кода | **не перенесена** |
 * | Кнопка сворачивания плана | **не перенесена** |
 * | Поле ввода с курсором | подпись-плейсхолдер, курсора нет |
 * | Прокрутка ленты и кода | лента заведомо помещается, иначе предупреждение |
 *
 * Четыре кнопки обратной связи и copy убраны по правилу
 * `.claude/rules/slide-anatomy.md`: нарисованная кнопка, которая не
 * нажимается, читается как недоделанный интерфейс. Композер оставлен —
 * но это не исключение из правила, а другой случай: композер здесь не
 * «кнопка», а опознавательный знак продукта, как строка адреса в мокапе
 * браузера. Он необязателен (`composer` не передан — его нет) и стоит
 * дорого: 148 точек из 408, ровно карточка кода в четыре строки.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ ПОТОЛКИ. Почему они есть и откуда взяты числа
 * ═══════════════════════════════════════════════════════════════════
 *
 * Реплика может быть любой длины, а бюджет блока в `ContentSlide` — 604,
 * из них ленте достаётся 408 (604 − 72 поля − 100 шапка − 24 просвет).
 * Значит потолок нужен, и он должен быть посчитан, а не назначен.
 *
 * Минимальная строка ленты — однострочный ответ ассистента: аватар 44
 * выше строки 32, поэтому ряд равен 44. Просвет между рядами 24.
 *
 *     44·N + 24·(N−1) ≤ 408   →   68·N ≤ 432   →   N ≤ 6.35
 *
 * Отсюда `MAX_MESSAGES` = **6**. Если хоть одна реплика — пузырь
 * пользователя (однострочный 64), потолок падает до четырёх:
 * 88·N ≤ 432 → N ≤ 4.9.
 *
 * Потолок ДЛИНЫ одной реплики. Пузырь в L строк занимает 32·L + 32:
 *
 *     L = 1 →  64      L = 3 → 128      L = 5 → 192
 *     L = 2 →  96      L = 4 → 160      L = 6 → 224
 *
 * Четырёхстрочная реплика — это 160 из 408, 39% ленты; две такие плюс
 * просвет дают 344, и на ответ с вложением остаётся 64 — меньше, чем нужно
 * даже пустой карточке кода (90). Поэтому `MAX_LINES` = **3**.
 *
 * Вложения считаются так же:
 *
 *     карточка кода   90 + 28·L   (шапка 48 + поля 40 + строки 28·L + обводка 2)
 *     карточка плана  82 + 48·S   (поля 40 + заголовок 32 + просвет 16 + 40·S + 8·(S−1) + 2)
 *
 * `CODE_MAX_LINES` = **6** (90 + 168 = 258, то есть 63% ленты — больше
 * не остаётся места на саму реплику). `PLAN_MAX_STEPS` = **5** — донорское
 * число шагов; 82 + 240 = 322, и это уже 79% ленты, поэтому план живёт
 * только рядом с однострочной репликой.
 *
 * ⚠️ **Потолки — это предупреждения, а не обрезка.** Реплика длиннее
 * потолка рисуется целиком: молча обрезать текст многоточием нельзя, иначе
 * на слайде окажется утверждение, которого никто не писал. Настоящие
 * ворота — `overflow`: блок складывает фактические высоты и сравнивает
 * с полем. Всё, что он нашёл, уходит в `console.warn` в DEV и печатается
 * в витрине списком.
 *
 * ⚠️ **Прижатие ленты книзу отключается при переполнении.** У донора лента
 * `justify-end`. Прижатие книзу при содержимом выше поля увело бы верх
 * в минус — ровно та грабля, из-за которой в проекте появилось `safe`
 * центрирование (`.claude/rules/layout-verification.md`): пропавший верх
 * не видно, обрезанный низ видно. Поэтому при `overflow > 0` лента
 * переключается на `justify-start`.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Высоты рядов НЕ задаются жёстко
 * ═══════════════════════════════════════════════════════════════════
 *
 * Замерщик `cardTextWidth` считает перенос по своим правилам (жадная
 * укладка слов той же гарнитурой, кеглем, весом и трекингом), а рисует
 * текст браузер. Совпадение почти всегда точное, но гарантии нет —
 * переносы по дефису, неразрывные пробелы, лигатуры.
 *
 * Поэтому расчёт здесь **совещательный**: он питает предупреждения и выбор
 * `justify-end` / `justify-start`, а высоты в разметке остаются
 * естественными. Если бы высота ряда фиксировалась числом, расхождение
 * в одну строку резало бы текст молча — то есть чинило бы отчёт, а не слайд.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Цвета: замер на своих подложках
 * ═══════════════════════════════════════════════════════════════════
 *
 * Донорских красок графиков здесь нет вовсе — переписка не график, у неё
 * нет рядов. Всё, кроме кнопки отправки, набрано ролями системы. Замеры
 * (контраст к той поверхности, на которой элемент реально лежит):
 *
 *   что                          роль / подложка              светлая  тёмная
 *   текст реплики пользователя   ink / fill-strong             16.61   12.83
 *   текст ответа                 ink / surface                 19.80   14.50
 *   мета «Обдумывал 12,4 с» 18   ink-secondary / surface        5.41    6.00
 *   код и шаги плана 20          ink / surface-muted           17.37   16.33
 *   подписи в карточке кода 18   ink-secondary / surface-muted   4.75    6.76
 *   галочка и контур шага        accent-fg / surface-muted       4.60    6.45
 *   счётчик «+56»                success-fg / surface-muted      4.81    7.69
 *   счётчик «−14»                error-fg / surface-muted        5.02    6.11
 *   кружок невыполненного шага   ink-tertiary / surface-muted    3.33    4.14
 *   плитка аватара               action / surface              19.80   14.50
 *   глиф на аватаре              action-fg / action            19.80   17.95
 *   плейсхолдер композера 24     ink-secondary / surface-muted   4.75    6.76
 *   глиф и ярлык модели          ink-secondary / surface         5.41    6.00
 *   строка состояния 18          ink-secondary / surface         5.41    6.00
 *
 * Пороги: текст мельче 24 — 4.5, текст от 24 — 3, нетекстовая графика — 3.
 * Проходит всё; худшее место — подписи 18 на приглушённой подложке
 * в светлой теме, 4.75 при пороге 4.5.
 *
 * ⚠️ **Разделение панелей в светлой теме держится на 1.14** (приглушённая
 * #f0f0f0 к карточке #ffffff), обводка `line` к приглушённой — 1.05.
 * Это не недосмотр: светлый скин донора весь лежит между #ffffff и #ebebeb,
 * и плитки легенды в `shell.tsx` стоят ровно на той же разнице. На проекторе
 * с засветкой карточка кода в светлой теме от фона почти не отличается —
 * если переписка едет на показ, брать тёмную тему.
 *
 * ⚠️ **Подсветка синтаксиса донора НЕ перенесена.** У него keyword #7ccf00,
 * класс #00bc7d, пунктуация #525252 — на нашей светлой приглушённой
 * подложке это 1.71 · 2.17 · 6.86 при пороге 4.5 для кегля 20. Две краски
 * из трёх не читаются, а раскрасить половину токенов и бросить остальные
 * хуже, чем не раскрашивать вовсе: цвет начал бы означать не синтаксис,
 * а «этот токен видно». Код набран одним тоном.
 *
 * ⚠️ **Бейдж языка не фиолетовый.** У донора текст #c27aff на #3c0466/50 —
 * это тёмная тема. На нашей светлой приглушённой подложке #c27aff даёт
 * 2.45 при пороге 4.5. Бейдж собран ролями: карточный фон на приглушённой
 * подложке плюс вторичный текст.
 */

/* ═══════════════  Моноширинный набор  ═══════════════ */

/**
 * Гарнитура кода.
 *
 * ⚠️ Токена моноширинного шрифта в системе НЕТ, и заводить его молча
 * нельзя (`.claude/rules/design-tokens.md`). Здесь взят ровно тот системный
 * стек, который уже стоит в трёх слайдах реального дека
 * (`s08-duplicates.tsx`, `s13-structure.tsx`, `s14-meta.tsx`), — то есть это
 * не подобранное значение, а существующая практика проекта.
 *
 * Кегль и трекинг остаются системными: строка кода набрана классом
 * `text-body-m` (20/28, трекинг −0.4), подменяется только семейство.
 * Инлайнового `fontSize` здесь нет.
 */
const MONO: CSSProperties = { fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" };

/* ═══════════════  Кегли для замера  ═══════════════ */

/*
 * Значения РАВНЫ токенам шкалы (`src/styles/typography.css`) и нужны
 * замерщику: он принимает числа, а не классы. Рисуется всё классами.
 */
const TEXT = { size: 24, weight: 500, tracking: -0.48, line: 32 } as const; // body-l
const SMALL = { size: 20, weight: 500, tracking: -0.4, line: 28 } as const; // body-m
const META = { size: 18, weight: 500, tracking: -0.36, line: 24 } as const; // label

/* ═══════════════  Геометрия ленты  ═══════════════ */

/** Просвет между рядами ленты. 24 — желоб сетки (донор 12 при окне 1440) */
const MSG_GAP = 24;

/**
 * Аватар. Сторона 44, радиус `rounded-tile` 12 — доля 27.3%, ровно та же,
 * что у `IconSquare` (24 из 88). Крупная и мелкая плитка системы обязаны
 * читаться как одна форма.
 *
 * Аватар стоит СБОКУ, а не строкой сверху: строка автора отняла бы 56 точек
 * высоты у каждого ответа (44 плюс просвет 12), то есть при трёх репликах —
 * 168 из 408. Колонка сбоку стоит 64 точки ШИРИНЫ, а ширины в карточке
 * во всю рабочую область избыток.
 */
const AVATAR = 44;
const AVATAR_GAP = 20;
const AVATAR_GLYPH = 24;

/** Пузырь пользователя: `px-6 py-4`. Высота = 32·строк + 32 */
const BUBBLE_PAD_Y = 16;

/** Просвет между текстом ответа и вложением: `gap-4` */
const BLOCK_GAP = 16;
/** Просвет между метой и текстом ответа: `gap-2` */
const META_GAP = 8;

/**
 * Доля ширины ленты под пузырь пользователя.
 *
 * У донора `calc(50% + 6px)` от центральной колонки. Шесть точек — поправка
 * на отрицательный правый отступ пузыря (−6), который у нас не переносится:
 * донор выдвигал пузырь за поле колонки, а у нас справа стоит аватар.
 * Остаётся ровно половина.
 */
const BUBBLE_SHARE = 0.5;

/* ═══════════════  Карточка кода  ═══════════════ */

const CODE_HEADER = 48;
const CODE_PAD_Y = 20;
const CODE_PAD_X = 24;
const CODE_BORDER = 1;

/** Высота карточки кода: шапка + поля + строки + две обводки */
export const codeCardHeight = (lines: number) =>
  CODE_HEADER + CODE_PAD_Y * 2 + SMALL.line * lines + CODE_BORDER * 2;

/* ═══════════════  Карточка плана  ═══════════════ */

const PLAN_PAD = 20;
const PLAN_STEP = 40;
const PLAN_STEP_GAP = 8;
const PLAN_BOX = 24;
const PLAN_BOX_GAP = 12;
const PLAN_STEP_PAD_X = 12;

/** Высота карточки плана: поля + заголовок + просвет + шаги + две обводки */
export const planCardHeight = (steps: number) =>
  PLAN_PAD * 2 +
  TEXT.line +
  BLOCK_GAP +
  PLAN_STEP * steps +
  PLAN_STEP_GAP * Math.max(0, steps - 1) +
  CODE_BORDER * 2;

/* ═══════════════  Композер  ═══════════════ */

/**
 * Капсула 80 — это `rounded-button-xl` системы: радиус 40, высота 80,
 * то есть радиус ровно половина высоты. Донор: h52 при окне 1440, после
 * ×1.333 — 69.3; ближайшая ступень кнопок системы вверх и есть 80.
 * Внутри круглые кнопки 56 (`-m`) плюс поля 12: 56 + 24 = 80 сходится.
 */
const COMPOSER_H = 80;
const COMPOSER_BTN = 56;
const COMPOSER_GLYPH = 28;
const COMPOSER_PAD = 12;
const COMPOSER_GAP = 16;
const STATUS_H = 32;
const STATUS_GAP = 12;
const STATUS_ICON = 20;

/** Полная цена композера в высоте: капсула + просвет + строка состояния */
export const COMPOSER_HEIGHT = COMPOSER_H + STATUS_GAP + STATUS_H;

/**
 * Градиент кнопки отправки — единственная краска во всём блоке.
 *
 * Донорский: linear-gradient(180°, #2b7fff → #155dfc). Оба конца взяты
 * из `BOARD_HEAT` (ступени 500 и 600 акцентной шкалы заказчика), а не
 * выписаны литералами: шкала уже замерена, и подмена ступени сломала бы
 * замеры вместе с ней.
 *
 * Стопы вынесены отдельно, чтобы витрина могла прогнать по ним
 * `runContrast` из `lib/color.ts`: тот сканирует ВЕСЬ ход в 101 точке,
 * а не концы. Контраст вдоль хода меняется, и проверка одного конца —
 * это проверка не того; класс дефекта уже стоил слайда в `blocks/layers.tsx`.
 */
export const SEND_STOPS: GradientStop[] = [
  { offset: 0, color: BOARD_HEAT[5], opacity: 1 },
  { offset: 1, color: BOARD_HEAT[6], opacity: 1 },
];

/* ═══════════════  Потолки  ═══════════════ */

/** Реплик в ленте. Расчёт — в шапке файла: 44·N + 24·(N−1) ≤ 408 */
export const MAX_MESSAGES = 6;
/** Строк в одной реплике. Четвёртая строка забирает 39% ленты */
export const MAX_LINES = 3;
/** Строк в карточке кода. Шесть строк — 258 точек, 63% ленты */
export const CODE_MAX_LINES = 6;
/** Шагов в карточке плана. Донорское число */
export const PLAN_MAX_STEPS = 5;

/* ═══════════════  Данные  ═══════════════ */

export interface ChatCodeBlock {
  /** Бейдж языка: «TSX» */
  language: string;
  /** Имя файла: «theme-toggle.tsx» */
  file: string;
  /** Счётчик диффа. Числа без знака — знак рисует блок */
  diff?: { added?: number; removed?: number };
  /** Строки кода. НЕ переносятся: длиннее поля — предупреждение */
  lines: readonly string[];
}

export interface ChatPlanStep {
  label: string;
  /** `done` — с галочкой, `active` — в контуре, `todo` — пустой кружок */
  state: "done" | "active" | "todo";
}

export interface ChatPlan {
  /** Донорское «N steps left» — здесь готовая подпись, счёт на стороне слайда */
  title: string;
  steps: readonly ChatPlanStep[];
}

export interface ChatMessage {
  role: "user" | "assistant";
  /** Текст реплики. Может отсутствовать, если реплика — только вложение */
  text?: string;
  /** Застывший таймер донора: «Обдумывал 12,4 с». Только у ассистента */
  meta?: string;
  plan?: ChatPlan;
  code?: ChatCodeBlock;
}

export interface ChatStatusItem {
  label: string;
  icon?: SolarIcon;
}

export interface ChatComposer {
  /** Подпись вместо курсора: «Ask me anything» */
  placeholder: string;
  /** Ярлык модели: «Fable 5» */
  model?: string;
  /** Строка состояния: ветка, проект, режим, остаток контекста */
  status?: readonly ChatStatusItem[];
}

/* ═══════════════  Замер моноширинной строки  ═══════════════ */

/*
 * Свой замерщик, а не `cardTextWidth`: тот жёстко ставит `var(--font-app)`,
 * потому что вся его работа — оси и подписи. Мешать в него второе семейство
 * значило бы менять общий файл ради одного блока. Кэш и приём («узел вне
 * потока, `white-space: pre`, ширина по `getBoundingClientRect`») те же.
 */
const monoCache = new Map<string, number>();
let monoRuler: HTMLSpanElement | null | undefined;

function getMonoRuler() {
  if (monoRuler !== undefined) return monoRuler;
  if (typeof document === "undefined") {
    monoRuler = null;
    return monoRuler;
  }
  const el = document.createElement("span");
  el.style.cssText =
    "position:absolute;left:-9999px;top:-9999px;visibility:hidden;white-space:pre;pointer-events:none";
  el.style.fontFamily = MONO.fontFamily as string;
  el.setAttribute("aria-hidden", "true");
  document.body.appendChild(el);
  monoRuler = el;
  return monoRuler;
}

/** Ширина строки кода тем же семейством, кеглем, весом и трекингом */
export function monoTextWidth(text: string, size = SMALL.size, tracking = SMALL.tracking) {
  const key = `${size} ${tracking} ${text}`;
  const cached = monoCache.get(key);
  if (cached !== undefined) return cached;

  const el = getMonoRuler();
  /* Без DOM (сборка вне браузера) — грубая оценка по ширине знака 0.6em */
  const width = el
    ? ((el.style.fontSize = `${size}px`),
      (el.style.fontWeight = String(SMALL.weight)),
      (el.style.letterSpacing = `${tracking}px`),
      (el.textContent = text),
      el.getBoundingClientRect().width)
    : text.length * size * 0.6;

  monoCache.set(key, width);
  return width;
}

/* ═══════════════  Перенос строк  ═══════════════ */

/**
 * Жадная укладка слов — тем же способом, каким её сделает браузер.
 *
 * Возвращает и число строк, и слово, которое само по себе шире поля:
 * такое слово браузер не перенесёт, оно вылезет за пузырь. Молча этого
 * допускать нельзя — уходит в предупреждение.
 */
export function wrapLines(
  text: string,
  maxWidth: number,
  metric: { size: number; weight: number; tracking: number },
) {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return { lines: 0, tooWide: null as string | null };

  const width = (s: string) => cardTextWidth(s, metric.size, metric.weight, metric.tracking, false);

  let lines = 1;
  let current = "";
  let tooWide: string | null = null;

  for (const word of words) {
    const candidate = current ? `${current} ${word}` : word;
    if (width(candidate) <= maxWidth) {
      current = candidate;
      continue;
    }
    if (current) lines += 1;
    current = word;
    if (width(word) > maxWidth) tooWide = word;
  }

  return { lines, tooWide };
}

/* ═══════════════  Раскладка  ═══════════════ */

export interface ChatRowLayout {
  index: number;
  role: ChatMessage["role"];
  /** Строк текста реплики после переноса */
  lines: number;
  /** Высота ряда: содержимое, но не ниже аватара */
  height: number;
  /** Из чего сложилась высота — для витрины */
  parts: { meta: number; text: number; plan: number; code: number };
}

export interface AiChatLayout {
  /** Ширина ленты: карточка минус два поля */
  contentWidth: number;
  /** Ширина колонки содержимого реплики: лента минус аватар с просветом */
  columnWidth: number;
  /** Потолок ширины пузыря пользователя */
  bubbleMax: number;
  /** Ширина поля кода внутри карточки кода */
  codeWidth: number;
  /** Высота поля под ленту: слот карточки минус композер */
  available: number;
  /** Фактическая высота ленты */
  threadHeight: number;
  /** Насколько лента выше поля. ≤ 0 — помещается */
  overflow: number;
  rows: ChatRowLayout[];
  warnings: string[];
}

export function layoutAiChat({
  messages,
  composer,
  width = 1680,
  height = CARD_BUDGET,
  size = "full",
  valueSize = "m",
}: {
  messages: readonly ChatMessage[];
  composer?: ChatComposer;
  width?: number;
  height?: number;
  size?: CardShellSize;
  valueSize?: CardValueSize;
}): AiChatLayout {
  const contentWidth = cardChartWidth(width, size);
  const columnWidth = contentWidth - AVATAR - AVATAR_GAP;
  const bubbleMax = Math.round(contentWidth * BUBBLE_SHARE);
  const codeWidth = columnWidth - CODE_PAD_X * 2 - CODE_BORDER * 2;
  const stepWidth =
    columnWidth - PLAN_PAD * 2 - CODE_BORDER * 2 - PLAN_STEP_PAD_X * 2 - PLAN_BOX - PLAN_BOX_GAP;

  const slot = cardChartHeight({ height, size, valueSize, legend: false });
  const available = slot - (composer ? COMPOSER_HEIGHT + MSG_GAP : 0);

  const warnings: string[] = [];

  if (!messages.length) {
    warnings.push(
      "лента пуста — карточка проходит все автопроверки разом, потому что проверять в ней нечего",
    );
  }
  if (messages.length > MAX_MESSAGES) {
    warnings.push(
      `реплик ${messages.length} при потолке ${MAX_MESSAGES}: даже однострочные не встают в ${available} точек`,
    );
  }

  const rows: ChatRowLayout[] = messages.map((message, index) => {
    const textMax = message.role === "user" ? bubbleMax - CODE_PAD_X * 2 : columnWidth;
    const wrapped = message.text
      ? wrapLines(message.text, textMax, TEXT)
      : { lines: 0, tooWide: null };

    if (wrapped.tooWide) {
      warnings.push(
        `реплика ${index + 1}: слово «${wrapped.tooWide}» шире поля ${Math.round(textMax)} — браузер его не перенесёт`,
      );
    }
    if (wrapped.lines > MAX_LINES) {
      warnings.push(
        `реплика ${index + 1} занимает ${wrapped.lines} строк при потолке ${MAX_LINES}: это ${TEXT.line * wrapped.lines + (message.role === "user" ? BUBBLE_PAD_Y * 2 : 0)} точек из ${available}`,
      );
    }

    /*
     * Просвет `META_GAP` считается только когда под подписью ЕСТЬ текст:
     * в разметке это `gap` флекс-колонки, а у колонки из одного ребёнка
     * просвета нет. Замер это подтвердил — до правки расчёт был выше
     * фактического ряда ровно на 8 в истории «Длинные подписи».
     */
    let meta = 0;
    if (message.meta) {
      meta = META.line + (message.text ? META_GAP : 0);
      const metaWrap = wrapLines(message.meta, columnWidth, META);
      if (metaWrap.lines > 1) {
        warnings.push(
          `реплика ${index + 1}: подпись «${message.meta}» не встала в одну строку — ряд под неё высотой ${META.line}, лишнее обрежется`,
        );
      }
    }

    const text =
      wrapped.lines > 0
        ? TEXT.line * wrapped.lines + (message.role === "user" ? BUBBLE_PAD_Y * 2 : 0)
        : 0;

    let plan = 0;
    if (message.plan) {
      const steps = message.plan.steps.length;
      plan = planCardHeight(steps);
      if (steps > PLAN_MAX_STEPS) {
        warnings.push(
          `реплика ${index + 1}: шагов плана ${steps} при потолке ${PLAN_MAX_STEPS} — карточка ${plan} точек из ${available}`,
        );
      }
      const titleWrap = wrapLines(message.plan.title, columnWidth - PLAN_PAD * 2, TEXT);
      if (titleWrap.lines > 1) {
        warnings.push(
          `реплика ${index + 1}: заголовок плана не встал в одну строку — ряд под него ${TEXT.line}`,
        );
      }
      message.plan.steps.forEach((step, si) => {
        const stepWrap = wrapLines(step.label, stepWidth, SMALL);
        if (stepWrap.lines > 1) {
          warnings.push(
            `реплика ${index + 1}, шаг ${si + 1}: подпись не встала в одну строку — ряд шага ${PLAN_STEP}, лишнее обрежется`,
          );
        }
      });
    }

    let code = 0;
    if (message.code) {
      const count = message.code.lines.length;
      code = codeCardHeight(count);
      if (count > CODE_MAX_LINES) {
        warnings.push(
          `реплика ${index + 1}: строк кода ${count} при потолке ${CODE_MAX_LINES} — карточка ${code} точек из ${available}`,
        );
      }
      message.code.lines.forEach((line, li) => {
        const w = monoTextWidth(line);
        if (w > codeWidth) {
          warnings.push(
            `реплика ${index + 1}, строка кода ${li + 1}: ${Math.round(w)} точек при поле ${Math.round(codeWidth)} — строка не переносится и будет обрезана`,
          );
        }
      });
    }

    const blocks = [meta + text, plan, code].filter((v) => v > 0);
    const content = blocks.reduce((a, b) => a + b, 0) + BLOCK_GAP * Math.max(0, blocks.length - 1);

    return {
      index,
      role: message.role,
      lines: wrapped.lines,
      height: Math.max(AVATAR, content),
      parts: { meta, text, plan, code },
    };
  });

  const threadHeight =
    rows.reduce((sum, row) => sum + row.height, 0) + MSG_GAP * Math.max(0, rows.length - 1);
  const overflow = threadHeight - available;

  if (overflow > 0) {
    warnings.push(
      `лента ${threadHeight} точек при поле ${available} — переполнение ${overflow}; прижатие книзу отключено, обрежется низ`,
    );
  }

  return {
    contentWidth,
    columnWidth,
    bubbleMax,
    codeWidth,
    available,
    threadHeight,
    overflow,
    rows,
    warnings,
  };
}

/* ═══════════════  Части разметки  ═══════════════ */

function Avatar({ role, initial }: { role: ChatMessage["role"]; initial: string }) {
  const box: CSSProperties = { width: AVATAR, height: AVATAR };

  /*
   * Ассистент — плитка `bg-action` с глифом `text-action-fg`. Пара уже
   * перевёрнута системой: в светлой теме чёрная плитка с белым глифом,
   * в тёмной белая с тёмным. Акцентная заливка потребовала бы считать цвет
   * глифа по теме (`glyphOn` в `lib/color.ts`): белый на #50a2ff даёт 2.4
   * при пороге 3 для нетекстовой графики.
   */
  if (role === "assistant") {
    return (
      <div
        className="bg-action flex shrink-0 items-center justify-center rounded-tile"
        style={box}
        aria-hidden="true"
      >
        <MagicStick3 size={AVATAR_GLYPH} weight="Bold" color="var(--t-action-fg)" />
      </div>
    );
  }

  return (
    <div
      className="bg-fill-strong text-body-m text-ink flex shrink-0 items-center justify-center rounded-tile"
      style={box}
      aria-hidden="true"
    >
      {initial}
    </div>
  );
}

function CodeCard({ code }: { code: ChatCodeBlock }) {
  const { added, removed } = code.diff ?? {};
  return (
    <div className="border-line bg-surface-muted overflow-hidden rounded-tile border">
      <header
        className="border-line flex items-center border-b"
        style={{ height: CODE_HEADER, paddingInline: CODE_PAD_X, gap: COMPOSER_GAP }}
      >
        {/*
         * Бейдж языка. Радиус `rounded-micro` 6 — вложенный в плитку 12,
         * поле 6: концентричность держится и на этом уровне.
         */}
        <span className="border-line bg-surface text-label text-ink-secondary shrink-0 rounded-micro border px-2 py-1">
          {code.language}
        </span>
        <span className="text-body-m text-ink min-w-0 flex-1 truncate" style={MONO}>
          {code.file}
        </span>
        {added !== undefined ? (
          <span className="text-label text-success-fg shrink-0 tabular-nums" style={MONO}>
            +{added}
          </span>
        ) : null}
        {/* Минус — типографский, U+2212: дефис на цифрах читается как перенос */}
        {removed !== undefined ? (
          <span className="text-label text-error-fg shrink-0 tabular-nums" style={MONO}>
            −{removed}
          </span>
        ) : null}
      </header>
      <div style={{ paddingBlock: CODE_PAD_Y, paddingInline: CODE_PAD_X }}>
        {code.lines.map((line, index) => (
          <div
            key={`${index}-${line}`}
            className="text-body-m text-ink"
            style={{ ...MONO, whiteSpace: "pre" }}
          >
            {line}
          </div>
        ))}
      </div>
    </div>
  );
}

function PlanCard({ plan }: { plan: ChatPlan }) {
  return (
    <div className="border-line bg-surface-muted rounded-tile border" style={{ padding: PLAN_PAD }}>
      <div className="text-body-l text-ink truncate" style={{ height: TEXT.line }}>
        {plan.title}
      </div>
      <div className="flex flex-col" style={{ marginTop: BLOCK_GAP, gap: PLAN_STEP_GAP }}>
        {plan.steps.map((step) => (
          <div
            key={step.label}
            /*
             * `self-start max-w-full` — ряд шириной по содержимому.
             *
             * У донора контур активного шага идёт «по всей строке», но строка
             * там 341 точку. У нас карточка плана 1544, и капсула во всю её
             * ширину читается как ПОЛЕ ВВОДА, а не как отметка «этот шаг
             * сейчас выполняется». Ряд ужат по содержимому и ограничен
             * шириной карточки: длинная подпись упрётся в потолок и обрежется
             * с предупреждением, короткая получит контур по себе.
             */
            className={[
              "flex max-w-full shrink-0 items-center self-start rounded-capsule border",
              step.state === "active" ? "border-accent-fg" : "border-transparent",
            ].join(" ")}
            style={{ height: PLAN_STEP, paddingInline: PLAN_STEP_PAD_X, gap: PLAN_BOX_GAP }}
          >
            {step.state === "done" ? (
              <CheckCircle
                size={PLAN_BOX}
                weight="Bold"
                color="var(--t-accent-fg)"
                aria-hidden="true"
              />
            ) : (
              /*
               * Пустой кружок. У выполняющегося шага контур акцентный
               * и вдвое толще, у ожидающего — третичный: 3.33 в светлой
               * теме при пороге 3 для нетекстовой графики.
               */
              <span
                className={[
                  "shrink-0 rounded-capsule",
                  step.state === "active"
                    ? "border-accent-fg border-2"
                    : "border-ink-tertiary border",
                ].join(" ")}
                style={{ width: PLAN_BOX, height: PLAN_BOX }}
                aria-hidden="true"
              />
            )}
            <span
              className={`text-body-m min-w-0 flex-1 truncate ${
                step.state === "active" ? "text-ink" : "text-ink-secondary"
              }`}
            >
              {step.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ComposerRow({ composer }: { composer: ChatComposer }) {
  const circle: CSSProperties = { width: COMPOSER_BTN, height: COMPOSER_BTN };

  return (
    <div className="flex shrink-0 flex-col" style={{ gap: STATUS_GAP }}>
      <div
        className="border-line bg-surface-muted flex items-center rounded-capsule border"
        style={{ height: COMPOSER_H, paddingInline: COMPOSER_PAD, gap: COMPOSER_GAP }}
      >
        {/*
         * Круглые кнопки — плоская заливка `bg-surface` и обводка `line`.
         *
         * У донора они «стеклянные»: подложка rgba(255,255,255,0.06), блик
         * под 150° и обводка conic-градиентом толщиной 0.3px. Разведка сразу
         * отметила, что на 1920 это почти не видно и в PDF растеризуется,
         * и предложила плоскую заливку с обводкой.
         *
         * Заливка взята карточная, а НЕ `fill`: замер к капсуле
         * (`surface-muted`) — `fill` даёт 1.04 в светлой теме и 1.04 в тёмной,
         * то есть кнопки пропадают вовсе; `surface` даёт 1.14 и 1.13.
         * Обводка `line` добавляет 1.05 в светлой и 1.27 в тёмной — в тёмной
         * работает, в светлой кнопку держит только заливка. Больше в этом
         * скине ступеней нет.
         */}
        <span
          className="border-line bg-surface flex shrink-0 items-center justify-center rounded-capsule border"
          style={circle}
          aria-hidden="true"
        >
          <Paperclip size={COMPOSER_GLYPH} weight="Linear" color="var(--t-ink-secondary)" />
        </span>

        {/* Плейсхолдер, а не поле: курсора в PDF нет, мигать нечему */}
        <span className="text-body-l text-ink-secondary min-w-0 flex-1 truncate">
          {composer.placeholder}
        </span>

        {composer.model ? (
          <span className="border-line bg-surface text-label text-ink shrink-0 rounded-capsule border px-4 py-2">
            {composer.model}
          </span>
        ) : null}

        <span
          className="border-line bg-surface flex shrink-0 items-center justify-center rounded-capsule border"
          style={circle}
          aria-hidden="true"
        >
          <Microphone size={COMPOSER_GLYPH} weight="Linear" color="var(--t-ink-secondary)" />
        </span>

        {/*
         * Кнопка отправки. Стопы и разбор — у `SEND_STOPS` выше.
         *
         * Замер белого глифа (`--t-on-media` = #ffffff) вдоль хода:
         * верх 3.76 · четверть 4.08 · середина 4.45 · три четверти 4.81 ·
         * низ 5.25; худшая точка всего хода — 3.76. Порог для нетекстовой
         * графики 3, берётся везде.
         *
         * ⚠️ Сама кнопка к тёмной карточке #262626: верх 4.02, середина
         * 3.40, низ 2.88 — нижняя треть градиента порог 3 НЕ берёт. Кнопку
         * в тёмной теме держит белый глиф внутри, а не её кромка. Донорский
         * градиент оставлен как есть по тому же решению заказчика, что
         * и краски серий (`lib/boardPalette.ts`).
         */}
        {/*
         * ⚠️ КНОПКА ОТПРАВКИ — СКРУГЛЁННЫЙ КВАДРАТ, А НЕ КРУГ. Решение заказчика
         * от 2026-08-22, и оно расходится с донором осознанно: у донора кнопка
         * отправки круглая (радиус capsule при стороне 36).
         *
         * Радиус взят `rounded-tile` = 12 при стороне 56, то есть 21% стороны.
         * Это не подбор: у соседних круглых кнопок мокапа (вложение, микрофон)
         * радиус равен половине стороны, и квадрат с радиусом крупнее четверти
         * читался бы как «недокруг» — форма без имени. На 21% угол виден как
         * угол, и кнопка отправки отличается от соседей ФОРМОЙ, а не только
         * заливкой.
         */}
        <span
          className="rounded-tile flex shrink-0 items-center justify-center"
          style={{ ...circle, background: cssGradient(SEND_STOPS, 180) }}
          aria-hidden="true"
        >
          <ArrowUp size={COMPOSER_GLYPH} weight="Linear" color="var(--t-on-media)" />
        </span>
      </div>

      {composer.status?.length ? (
        <div
          className="text-label text-ink-secondary flex items-center"
          style={{ height: STATUS_H, gap: MSG_GAP }}
        >
          {composer.status.map((item) => {
            const Icon = item.icon ?? BranchingPathsUp;
            return (
              <span key={item.label} className="flex min-w-0 items-center gap-2">
                <Icon size={STATUS_ICON} weight="Linear" color="var(--t-ink-secondary)" />
                <span className="truncate">{item.label}</span>
              </span>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface AiChatCardProps {
  /** Подпись сверху слева: «Остаток контекста» */
  label: ReactNode;
  /**
   * Крупное число шапки.
   *
   * ⚠️ Обязательно, как у всех карточек семейства. Переписка сама по себе
   * числа не несёт, поэтому его должен назвать слайд — и это дисциплина,
   * а не формальность: у донора смысловой акцент в том, что агент это среда
   * с состоянием (ветка, проект, режим, остаток контекста), и «57%» —
   * ровно такое состояние. Заголовок слайда обязан опираться на это число.
   */
  value: ReactNode;
  valueSize?: CardValueSize;
  delta?: CardDelta;
  /** Ярлык периода. Донорский режим Ask/Agent/Plan — это `segments` */
  period?: CardPeriod;
  /** Реплики сверху вниз */
  messages: readonly ChatMessage[];
  /** Композер. Не передан — его нет, и ленте достаётся на 148 точек больше */
  composer?: ChatComposer;
  /** Буква в аватаре пользователя */
  userInitial?: string;
  size?: CardShellSize;
  /**
   * Ширина карточки.
   *
   * ⚠️ Должна совпадать с фактической шириной места: от неё считаются
   * потолок пузыря, поле кода и все предупреждения. Для `size="half"` — 828.
   */
  width?: number;
  height?: number;
  theme?: SlideTheme;
}

export default function AiChatCard({
  label,
  value,
  valueSize = "m",
  delta,
  period,
  messages,
  composer,
  userInitial = "П",
  size = "full",
  width = 1680,
  height = CARD_BUDGET,
  theme,
}: AiChatCardProps) {
  useRemeasureOnFont();

  const layout = layoutAiChat({ messages, composer, width, height, size, valueSize });

  if (import.meta.env.DEV) {
    for (const warning of layout.warnings) console.warn(`AiChatCard: ${warning}`);
  }

  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      period={period}
      size={size}
      height={height}
      theme={theme}
    >
      <div className="flex h-full flex-col overflow-hidden" style={{ gap: MSG_GAP }}>
        {/*
         * Лента. `justify-end` — донорское прижатие книзу; при переполнении
         * оно отключается, иначе верх ушёл бы в минус и пропал бы молча
         * (разбор — в шапке файла и в `.claude/rules/layout-verification.md`).
         */}
        <div
          className={`flex min-h-0 flex-1 flex-col ${
            layout.overflow > 0 ? "justify-start" : "justify-end"
          }`}
          style={{ gap: MSG_GAP }}
        >
          {messages.map((message, index) => {
            const key = `${index}-${message.role}`;

            if (message.role === "user") {
              return (
                <div
                  key={key}
                  className="flex shrink-0 items-start justify-end"
                  style={{ gap: AVATAR_GAP }}
                >
                  <div
                    className="bg-fill-strong text-body-l text-ink min-w-0 rounded-tile px-6 py-4"
                    style={{ maxWidth: layout.bubbleMax }}
                  >
                    {message.text}
                  </div>
                  <Avatar role="user" initial={userInitial} />
                </div>
              );
            }

            return (
              <div key={key} className="flex shrink-0 items-start" style={{ gap: AVATAR_GAP }}>
                <Avatar role="assistant" initial={userInitial} />
                <div className="flex min-w-0 flex-1 flex-col" style={{ gap: BLOCK_GAP }}>
                  {message.meta || message.text ? (
                    <div className="flex flex-col" style={{ gap: META_GAP }}>
                      {message.meta ? (
                        <span
                          className="text-label text-ink-secondary truncate"
                          style={{ height: META.line }}
                        >
                          {message.meta}
                        </span>
                      ) : null}
                      {message.text ? (
                        <span className="text-body-l text-ink">{message.text}</span>
                      ) : null}
                    </div>
                  ) : null}
                  {message.plan ? <PlanCard plan={message.plan} /> : null}
                  {message.code ? <CodeCard code={message.code} /> : null}
                </div>
              </div>
            );
          })}
        </div>

        {composer ? <ComposerRow composer={composer} /> : null}
      </div>
    </CardShell>
  );
}
