import { Fragment, useId } from "react";
import { useRemeasureOnFont } from "./axis";
import CardShell, {
  CARD_BUDGET,
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
} from "./shell";
import {
  CAPTION_GAP,
  CAPTION_LINE,
  HIGHLIGHT_OFF,
  HIGHLIGHT_ON,
  INLINE_GAP,
  LABEL_GAP,
  LINE,
  NODE_RADIUS,
  NODE_W,
  RIBBON_ALPHA,
  SANKEY_CARD_COLORS,
  TARGET_PAINT,
  layoutSankeyCard,
  sankeyRibbonPath,
  type SankeyCardLink,
  type SankeyCardNode,
} from "./sankeyLayout";
import type { SlideTheme } from "../../slide/Slide";

export type { SankeyCardLink, SankeyCardNode };

/**
 * Карточка-дашборд «поток» (Sankey): во что разошлось целое.
 *
 *   ┌─ карточка ──────────────────────────────────────────────────────┐
 *   │  Tracked time                                  🗓 This week      │
 *   │  86 ч                                                           │
 *   │                                                                 │
 *   │      Focus  32 ч ▐╲___________________╱▌ Browsing · 22%         │
 *   │   Meetings  18 ч ▐╲‾‾╲______________╱‾▌ Writing · 18%           │
 *   │     Breaks  12 ч ▐___╲___________╱___▌ Messaging · 13%          │
 *   │      Admin  14 ч ▐______╲____╱______▌ Productivity · 12%        │
 *   │   Learning  10 ч ▐_________╱_________▌ Email · 8%               │
 *   │                                        ▌ Video calls · 14%      │
 *   │                                        ▌ Everything else · 13%  │
 *   │  Tracked time                          Share of tracked time    │
 *   └─────────────────────────────────────────────────────────────────┘
 *
 * Перенос восьмой донорской карточки. Оболочка (шапка, крупное число, чип
 * изменения, ярлык периода) живёт в [`shell.tsx`](./shell.tsx) — своей шапки
 * здесь нет. Вся геометрия и все замеры — в
 * [`sankeyLayout.ts`](./sankeyLayout.ts). Спецификация разведки — во внутреннем разборе.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ В системе УЖЕ ЕСТЬ диаграмма потоков. Чем эта отличается
 * ═══════════════════════════════════════════════════════════════════
 *
 * | Блок | Что это на слайде | Палитра |
 * | --- | --- | --- |
 * | [`blocks/sankey.tsx`](../sankey.tsx) `SankeyFlow` | САМ БЛОК во всю рабочую область 1680 × 604, шапка слайда над ним | `CHART_SERIES` |
 * | этот файл `SankeyCard` | СОДЕРЖИМОЕ карточки дашборда: над потоком своя шапка с итогом, чипом и периодом | `BOARD_SERIES` |
 *
 * Правило выбора одной строкой: **слайд про переход целиком — `SankeyFlow`;
 * дашборд, где поток стоит рядом с другими карточками того же семейства, —
 * этот блок.** Ставить оба в один дек нельзя: рядом окажутся `#9ae600`
 * и `#497d00`, и это прочитается как ошибка сборки, а не как два набора
 * (разбор двух палитр — в шапке `lib/boardPalette.ts`).
 *
 * Что взято у `SankeyFlow` и НЕ переизобретено: раздача высот «наливом»
 * с минимумом от подписи, ОДНА шкала на две колонки, укладка лент в порядке
 * противоположной колонки, порядок отрисовки «толстые под тонкими», потолки
 * с предупреждением. Что сделано иначе — ниже, каждое расхождение с числом.
 *
 * ═══════════════════════════════════════════════════════════════════
 * ⚠️ Донорские ДВЕ СТРОКИ у подписи источника не переносятся. Расчёт
 * ═══════════════════════════════════════════════════════════════════
 *
 * У донора подпись источника — две строки на одном якоре: имя 13px (dy −2)
 * и под ним значение 12px (dy +14), то есть пара занимает ~16 точек при
 * высоте графика 344. Кегли 12–13 ниже пола нашей шкалы (16), масштабировать
 * их нельзя, а ближайшие токены — `body-l` 24 и `label` 18. Две строки этими
 * кеглями дают 32 + 24 = 56 точек, и вот что из этого выходит.
 *
 * Минимальная высота столбика = высота подписи − просвет + запас. При двух
 * строках это 56 − 16 + 6 = 46. Полоса под столбики при семи приёмниках —
 * 408 − 16 · 6 = 312. Донорские источники (32 · 18 · 12 · 14 · 10 из 86)
 * просят 116.1 · 65.3 · 43.5 · 50.8 · 36.3 — трое из пяти ниже минимума.
 * Раздача «наливом» закрепляет их на 46, остаток делится между двумя, второй
 * тоже проваливается под минимум, и столбики встают
 * 128 · 46 · 46 · 46 · 46 вместо своих долей. Диаграмма, где четыре узла
 * из пяти одинаковы, про величины не сообщает ничего.
 *
 * Поэтому подпись здесь ОДНОСТРОЧНАЯ: имя `body-l` и через просвет 12 —
 * значение `label`, обе по базовой линии. Высота строки 32, минимум
 * 32 − 16 + 6 = 22, и на донорских данных не срабатывает ни разу: самый
 * мелкий источник получает свои 36.3 точки. Ровно так же подписан узел
 * в `SankeyFlow` — и теперь понятно, почему: это не стилистика, а
 * единственная раскладка, при которой пропорция выживает в бюджете слайда.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Что из донора НЕ перенесено, кроме подписи
 * ═══════════════════════════════════════════════════════════════════
 *
 * **Наведение.** У донора оно несло всю изоляцию потока: связанные ленты
 * 0.32 → 0.7, все остальные → 0.08, заливка узла переключалась на вариант
 * `-active`, а шапка подменяла заголовок и число на данные наведённого узла
 * («Focus / 32h» вместо «Tracked time / 86h»). В PDF курсора нет.
 *
 * Замена — статическая и ровно та, которую предложила разведка: `highlight`
 * оставляет один поток в полную силу, остальные гасит. Это застывший кадр
 * донорского наведения, и включать его надо тогда, когда заголовок слайда
 * формулирует вывод именно про этот поток.
 *
 * **Шеврон у кнопки периода.** Обещает выпадающий список, которого в PDF не
 * будет; ярлык рисует `shell.tsx`, там же разбор.
 *
 * **Переходы** 200 / 150 мс на лентах и узлах и `number-fade` у числа
 * в шапке. В PDF остаётся один кадр.
 *
 * **Лента как `stroke`.** Разбор — у `sankeyRibbonPath` в `sankeyLayout.ts`.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Легенды у этой карточки нет, и это не пропуск
 * ═══════════════════════════════════════════════════════════════════
 *
 * У остальных карточек волны легенда обязательна: краски донора в светлой
 * теме порог не берут, поэтому величину обязана нести напечатанная подпись.
 * Здесь подпись уже напечатана — у КАЖДОГО узла стоит имя и число, а
 * у приёмника ещё и доля. Плитки легенды повторили бы ровно те же пары,
 * заняв 124 точки бюджета и отняв их у поля потока.
 *
 * Донор легенды тоже не рисует: вместо неё внизу две подписи полей
 * («Tracked time» слева, «Share of tracked time» справа) — они говорят, что
 * означает левая колонка и что правая. Это `axisLabels`.
 *
 * ═══════════════════════════════════════════════════════════════════
 * Замер собранной карточки (1:1, донорские данные, с подписями полей)
 * ═══════════════════════════════════════════════════════════════════
 *
 *   карточка          1680 × 604, поле 36, радиус 48
 *   поле графика      1608 × 408
 *   полоса потока     1608 × 356  (408 − 28 строка подписей − 24 просвет)
 *   колонка подписи   146.66 слева · 205.98 справа при потолке 402
 *   полоса лент       1175.36, начинается на 186.66
 *   столбик           24 шириной, радиус «12 0 0 12» и «0 12 12 0»
 *   столбики-источники 96.73 · 54.41 · 36.27 · 42.31 · 30.22
 *   их «честные» доли  96.74 · 54.42 · 36.28 · 42.33 · 30.23
 *
 * Совпадение долей до сотой — не совпадение, а следствие однострочной
 * подписи: минимум 22 при полосе 260 не срабатывает ни на одном источнике.
 *
 * ⚠️ Полоса лент занимает 73% ширины поля против донорских 52%, и это НЕ
 * ошибка переноса. Донор отдавал подписям 16% и 27% при ширине 550; у нас
 * карточка шире в 2.9 раза, а имена узлов те же самые — колонки съедают
 * 11.6% и 15.3%. Потолок в четверть поля к донорским данным не имеет
 * отношения вовсе: он держит длинные имена, и там полоса падает до 45%.
 *
 * ⚠️ На донорских данных блок выдаёт ОДНО предупреждение, и это правда,
 * а не шум: самый мелкий приёмник (Email, 8%) просит 20.8 точки, а подпись
 * требует 22 — узел выглядит крупнее своей доли в 1.06 раза. Убрать это
 * можно только уменьшив кегль подписи ниже пола шкалы или подняв карточку
 * выше бюджета слайда; и то и другое хуже, чем 6% на одном узле из
 * двенадцати.
 */

export interface SankeyCardProps {
  /** Подпись серии сверху слева: «Tracked time» */
  label: string;
  /** Источники. Порядок сверху вниз — тот, в котором они переданы */
  sources: readonly SankeyCardNode[];
  /** Приёмники. Порядок сверху вниз — тот, в котором они переданы */
  targets: readonly SankeyCardNode[];
  /** Связи. Величины во всех связях в одних единицах */
  links: readonly SankeyCardLink[];
  /** Крупное число шапки. Не задано — сумма всех связей */
  value?: string;
  /** Плашка изменения в шапке */
  delta?: CardDelta;
  /** Ярлык периода справа сверху. Подпись, а не переключатель */
  period?: CardPeriod;
  /**
   * Две подписи полей внизу: слева и справа. Донорские — «Tracked time»
   * и «Share of tracked time». Не переданы — строки нет, и полю потока
   * достаётся на 52 точки больше.
   */
  axisLabels?: readonly [string, string];
  /**
   * Ключ источника, чей поток оставить в полную силу. Остальные гаснут.
   * Статический кадр донорского наведения — включать тогда, когда заголовок
   * слайда формулирует вывод именно про этот поток.
   */
  highlight?: string;
  /** `full` — во всю рабочую ширину 1680, `half` — колонка 828 */
  size?: CardShellSize;
  /**
   * Ширина карточки.
   *
   * ⚠️ Должна совпадать с фактической шириной места, куда карточка ставится:
   * от неё считаются колонки подписей и полоса лент. Расхождение не обрежется
   * и не оставит пустоту — геометрия просто будет посчитана не от той ширины.
   * Для `size="half"` передавать 828.
   */
  width?: number;
  /** Высота карточки. По умолчанию весь бюджет блока — 604 */
  height?: number;
  /** `m` — число `headline-l` 56 (по умолчанию), `l` — `display-s` 72 */
  valueSize?: CardValueSize;
  /** Краски источников по порядку. Меняются только целиком и с новым замером */
  colors?: readonly string[];
  /** Как печатать величину источника */
  formatValue?: (value: number) => string;
  /** Как печатать долю приёмника в процентах */
  formatShare?: (percent: number) => string;
  /**
   * Ширины колонок подписей: слева и справа. Не заданы — считаются замером
   * по самой длинной подписи и ограничены четвертью поля. Задавать вручную
   * стоит только чтобы выровнять две карточки в одном ряду.
   */
  labelWidth?: readonly [number, number];
  /** Вложенная тема: светлая карточка на тёмном слайде и наоборот */
  theme?: SlideTheme;
}

/**
 * Доля печатается целым числом, как у донора, но ноль на существующем узле
 * запрещён: узел в 0.3% округлился бы в «0%», и подпись утверждала бы, что
 * приёмника нет, при том что столбик нарисован. Ровно ноль остаётся нулём —
 * там и узла нет. Тот же приём и по той же причине стоит в `funnelCard.tsx`.
 */
const defaultShare = (p: number) => (p > 0 && p < 0.5 ? "<1%" : `${Math.round(p)}%`);

export default function SankeyCard({
  label,
  sources,
  targets,
  links,
  value,
  delta,
  period,
  axisLabels,
  highlight,
  size = "full",
  width = 1680,
  height = CARD_BUDGET,
  valueSize = "m",
  colors = SANKEY_CARD_COLORS,
  formatValue = (v: number) => v.toLocaleString("ru-RU"),
  formatShare = defaultShare,
  labelWidth,
  theme,
}: SankeyCardProps) {
  useRemeasureOnFont();

  const gradientId = `sankey-card-${useId().replace(/:/g, "")}`;

  const W = cardChartWidth(width, size);
  const H = cardChartHeight({ height, size, valueSize, legend: false });

  const layout = layoutSankeyCard({
    sources,
    targets,
    links,
    chartWidth: W,
    chartHeight: H,
    hasCaptions: Boolean(axisLabels),
    formatValue,
    formatShare,
    labelWidth,
    highlight,
  });

  const { keptSources, keptTargets, bandH, bandW, bandX, fromW, toW } = layout;

  if (import.meta.env.DEV) {
    for (const warning of layout.warnings) console.warn(`SankeyCard: ${warning}`);
  }

  if (!layout.ribbons.length) return null;

  const paint = (si: number) => keptSources[si].color ?? colors[si % colors.length];

  const alphaFor = (si: number) => {
    if (!highlight) return RIBBON_ALPHA;
    return keptSources[si].key === highlight ? HIGHLIGHT_ON : HIGHLIGHT_OFF;
  };

  const nodeLabel = (
    node: SankeyCardNode,
    meta: string,
    top: number,
    barH: number,
    side: "from" | "to",
  ) => (
    <div
      className={`absolute flex items-baseline ${
        side === "from" ? "justify-end text-right" : "justify-start text-left"
      }`}
      style={{
        top: top + barH / 2 - LINE / 2,
        left: side === "from" ? 0 : undefined,
        right: side === "to" ? 0 : undefined,
        width: side === "from" ? fromW : toW,
        height: LINE,
        gap: INLINE_GAP,
      }}
    >
      <span className="text-body-l text-ink min-w-0 truncate">{node.label}</span>
      {/*
       * Число — `text-ink-secondary`, а не третичным. Кегль 18 мельче 24,
       * а третичный в светлой теме даёт 3.79:1 при пороге 4.5 для мелкого
       * текста; вторичный даёт 5.41 в светлой и 6.00 в тёмной.
       */}
      <span className="text-label text-ink-secondary shrink-0 tabular-nums">{meta}</span>
    </div>
  );

  return (
    <CardShell
      label={label}
      value={value ?? formatValue(layout.total)}
      valueSize={valueSize}
      delta={delta}
      period={period}
      size={size}
      height={height}
      theme={theme}
    >
      <div className="flex h-full flex-col" style={{ gap: axisLabels ? CAPTION_GAP : 0 }}>
        <div className="relative" style={{ width: W, height: bandH }}>
          {/*
           * Ленты. Все величины до одной продублированы подписями узлов,
           * поэтому для чтения с экрана слой ничего не добавляет.
           */}
          <svg
            width={bandW}
            height={bandH}
            viewBox={`0 0 ${bandW} ${bandH}`}
            className="absolute top-0"
            style={{ left: bandX }}
            aria-hidden="true"
          >
            <defs>
              {keptSources.map((source, si) => (
                <linearGradient
                  key={source.key}
                  id={`${gradientId}-${si}`}
                  gradientUnits="userSpaceOnUse"
                  x1={0}
                  y1={0}
                  x2={bandW}
                  y2={0}
                >
                  {/*
                   * Градиент идёт от краски ИСТОЧНИКА к краске ПРИЁМНИКА,
                   * то есть лента на глазах теряет принадлежность и приходит
                   * нейтральной — ровно то, что у донора закодировано
                   * нейтральной заливкой столбиков-приёмников.
                   *
                   * Это не затухание в прозрачность, поэтому запрет «гаснуть
                   * в свой цвет, а не в transparent» тут ни при чём: оба
                   * конца — настоящие краски, а непрозрачность живёт отдельным
                   * атрибутом `stop-opacity`. В SVG хвост может быть
                   * `var(--t-ink-tertiary)`; в CSS-градиенте не мог бы —
                   * `rgba()` разобрала бы `var()` в NaN.
                   *
                   * Непрозрачность вдоль ленты ПОСТОЯННА, как у донора.
                   * Затухать к приёмнику незачем: в приёмник ленты приходят
                   * не стопкой, а встык, каждая на своей доле столбика, —
                   * пересечения бывают в середине полосы, и именно там
                   * стопка замерена (разбор у `RIBBON_ALPHA`).
                   */}
                  <stop offset={0} stopColor={paint(si)} stopOpacity={alphaFor(si)} />
                  <stop offset={1} stopColor={TARGET_PAINT} stopOpacity={alphaFor(si)} />
                </linearGradient>
              ))}
            </defs>

            {layout.drawOrder.map((r) => (
              <path
                key={r.key}
                d={sankeyRibbonPath(r, bandW)}
                fill={`url(#${gradientId}-${r.si})`}
              />
            ))}
          </svg>

          {/* Источники: столбик скруглён слева, подпись слева от него */}
          {keptSources.map((source, si) => (
            <Fragment key={source.key}>
              <div
                className="absolute"
                style={{
                  left: fromW + LABEL_GAP,
                  top: layout.sourceTop[si],
                  width: NODE_W,
                  height: layout.sourceH[si],
                  borderRadius: `${NODE_RADIUS} 0 0 ${NODE_RADIUS}`,
                  background: paint(si),
                }}
              />
              {nodeLabel(
                source,
                layout.sourceMeta[si],
                layout.sourceTop[si],
                layout.sourceH[si],
                "from",
              )}
            </Fragment>
          ))}

          {/* Приёмники: столбик скруглён справа, подпись справа от него */}
          {keptTargets.map((target, ti) => (
            <Fragment key={target.key}>
              <div
                className="bg-ink-tertiary absolute"
                style={{
                  left: W - toW - LABEL_GAP - NODE_W,
                  top: layout.targetTop[ti],
                  width: NODE_W,
                  height: layout.targetH[ti],
                  borderRadius: `0 ${NODE_RADIUS} ${NODE_RADIUS} 0`,
                }}
              />
              {nodeLabel(
                target,
                layout.targetMeta[ti],
                layout.targetTop[ti],
                layout.targetH[ti],
                "to",
              )}
            </Fragment>
          ))}
        </div>

        {axisLabels ? (
          <div
            className="text-body-m text-ink-secondary flex shrink-0 items-center justify-between gap-6"
            style={{ height: CAPTION_LINE }}
          >
            <span className="min-w-0 truncate">{axisLabels[0]}</span>
            <span className="min-w-0 truncate">{axisLabels[1]}</span>
          </div>
        ) : null}
      </div>
    </CardShell>
  );
}
