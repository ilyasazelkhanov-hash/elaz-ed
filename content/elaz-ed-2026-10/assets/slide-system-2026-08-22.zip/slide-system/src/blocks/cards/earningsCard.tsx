import type { CSSProperties } from "react";
import CardShell, {
  cardChartHeight,
  cardChartWidth,
  type CardDelta,
  type CardPeriod,
  type CardShellSize,
  type CardValueSize,
  type LegendTile,
} from "./shell";
import { X_GAP, Y_GAP, axisTextWidth, useRemeasureOnFont } from "./axis";
import { BOARD_CHART, BOARD_SERIES, BOARD_SERIES_ACTIVE } from "../../lib/boardPalette";
import type { SlideTheme } from "../../slide/Slide";

/**
 * Карточка «Доход» — графика поступлений донора.
 *
 * Спецификация замеров донора — во внутреннем разборе. Обвязка (шапка, число, чип,
 * подпись периода, легенда) — общая, из `./shell`; здесь только форма
 * графика и её геометрия.
 *
 *   ┌─ карточка ─────────────────────────────────────────────────┐
 *   │  December                          Weekly  Monthly  Yearly │
 *   │  $8 210  [+14,8%]                                          │
 *   │                                                            │
 *   │  $10K ┤ ▓ ▓ ▓ ▓ ▓ ▓ ▓ ▓ ▓ ▓ ▓ ╔▓╗   ▓ — столбик в «стакане»│
 *   │   $5K ┤ █ █ █ █ █ █ █ █ █ █ █ ║█║   █ — залитая часть      │
 *   │   $3K ┤ █ █ █ █ █ █ █ █ █ █ █ ║█║   ╔╗ — кольцо выделения  │
 *   │    $0 ┤ █ █ █ █ █ █ █ █ █ █ █ ╚█╝                          │
 *   │         Jan Feb Mar … Dec                                  │
 *   └────────────────────────────────────────────────────────────┘
 *
 * === Что такое «стакан» ===
 *
 * За каждым столбиком стоит трек полной высоты области построения. Он
 * показывает ПОТОЛОК шкалы, а не значение: без него столбик в 20% высоты
 * висит в пустоте и глазу не с чем его сравнить. У донора трек — это
 * `--color-chart-track` (#ebebeb светлая, #262626 тёмная); у нас это роль
 * `bg-fill-strong` (#ebebeb / #2f2f2f) — светлая совпала с донором
 * посимвольно, тёмная взята наша, потому что донорский #262626 равен цвету
 * НАШЕЙ карточки и трек на ней исчез бы (замер: 1.00).
 *
 * === ⚠️ ЧЕСТНЫЙ ЗАМЕР: светлая тема у этой карточки слабая ===
 *
 * Краска столбика — донорский салат lime-400 #9ae600, как просил заказчик
 * (обоснование и общий замер — в шапке `lib/boardPalette.ts`). Здесь важен
 * не контраст к карточке, а контраст к ТРЕКУ: столбик лежит на треке, а не
 * на фоне карточки. Замеры (формула WCAG, `contrast` из `lib/color.ts`):
 *
 *   пара                                    светлая   тёмная
 *   столбик #9ae600 к треку                   1.29      8.73
 *   столбик #9ae600 к карточке                1.53      9.87
 *   выделенный #7ccf00 к треку                1.63      6.87
 *   обычный #9ae600 к выделенному #7ccf00     1.27      1.27
 *   трек к карточке                           1.19      1.13
 *
 * Читать это надо так: в ТЁМНОЙ теме карточка работает с запасом (8.73 при
 * пороге 3:1 для нетекстовой графики, WCAG 1.4.11). В СВЕТЛОЙ салат от
 * своего трека почти неотличим — 1.29. На проекторе с засветкой светлая
 * версия этой карточки превратится в ряд серых стаканов.
 *
 * Отсюда три следствия, и все три уже зашиты в код:
 *
 *   1. Величину несёт ПОДПИСЬ, а не цвет: ось Y с тиками обязательна,
 *      выделенный месяц назван в шапке словами и числом («December»,
 *      «$8 210»). Убрать ось = сделать карточку нечитаемой.
 *   2. Выделение держит КОЛЬЦО, а не заливка: разница обычного и
 *      выделенного столбика 1.27 — этого не видно нигде, ни в одной теме.
 *   3. Если карточка едет на проектор — ставить `theme="dark"`.
 *
 * === Кольцо выделения: почему не донорский цвет ===
 *
 * У донора рамка появляется по НАВЕДЕНИЮ и красится в `--color-chart-cursor`
 * (#d4d4d4 светлая, #404040 тёмная). На слайде наведения нет, поэтому рамка
 * из состояния превращается в постоянное выделение одного месяца — того,
 * что назван в шапке. Раз она теперь смысловая, она обязана быть видимой,
 * а донорские цвета видимыми не являются:
 *
 *   #d4d4d4 к треку #ebebeb  →  1.24   (светлая)
 *   #404040 к треку #2f2f2f  →  1.29   (тёмная)
 *
 * Берётся роль `--t-ink-tertiary` (#838383 / #7d7d7d): 3.18 к треку в
 * светлой и 3.25 в тёмной — порог 3:1 для нетекстовой графики взят в обеих.
 * Это ЕДИНСТВЕННОЕ расхождение с донорскими красками в этом файле, и оно
 * не про вкус: донорское значение измерено и не читается.
 *
 * Роль текстовая, а красится ею рамка. Так сделано сознательно: между
 * `--t-line` (#ebebeb — равен треку, кольца не будет вовсе) и `--t-ink`
 * (#0a0a0a — чёрная рамка вокруг светлого стакана читается как ошибка)
 * в системе нет ступени, а подбирать своё значение запрещено.
 *
 * === Сегмент-контрол — подпись, а не орган управления ===
 *
 * «Weekly / Monthly / Yearly» рисуется рядом слов через `period.segments`
 * обвязки: без дорожки, без подложки-таблетки, без теней. Нажать в PDF
 * нельзя ни одну кнопку, а нарисованная кнопка читается как недоделанный
 * интерфейс (`.claude/rules/slide-anatomy.md`). Выбранное — основным
 * цветом, остальные — вторичным. Не нужны совсем — не передавать
 * `segments`, останется плашка с календарём.
 *
 * === Анимация ===
 *
 * Ни роста столбиков, ни счётчика числа, ни проявления рамки. В PDF
 * остаётся один кадр, и он должен быть финальным. Ничего не теряется:
 * у донора анимация не несла данных.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface EarningsBar {
  /** Подпись под столбиком: «Jan», «Янв», «Q1» */
  label: string;
  /** Значение в единицах шкалы. 0 рисуется пустым стаканом, а не обрубком */
  value: number;
}

export interface EarningsTick {
  /** Значение, на котором стоит подпись */
  value: number;
  /** Готовая подпись: «$3K». Форматирование — забота слайда, не блока */
  label: string;
}

/* ═══════════════  Геометрия  ═══════════════ */

/*
 * === Ось Y: ширина колонки ЗАМЕРЯЕТСЯ, а не задаётся числом ===
 *
 * `axisTextWidth` из общего модуля `./axis` меряет строку тем же шрифтом,
 * весом, трекингом и моноширинными цифрами, какими она будет нарисована —
 * скрытым узлом DOM, а не холстом (у холста нет `font-variant-numeric`,
 * и он занижает ширину узких цифр; разбор — в шапке `axis.ts`).
 *
 * Так решаются сразу две вещи. Первая: «$10K» занимает 47.5, а
 * «$1 250 000» — 104, и фиксированное число под них обоих не подобрать —
 * либо пустая колонка, либо подпись, вылезающая ВЛЕВО за поле карточки.
 * Причём второе автопроверка ширины не увидит: `scrollWidth` левый вылет
 * не считает. Вторая: карточки волны обязаны совпадать по осям, а у
 * соседних карточек (линия, площадь, комбо) жёлоб считается тем же
 * замерщиком.
 *
 * Просветы тоже общие: `Y_GAP` 16 между подписью и полем построения,
 * `X_GAP` 14 между полем и строкой подписей снизу.
 *
 * ⚠️ Совпадение с SVG-карточками волны — по ЧИСЛАМ, но не по пикселю:
 * там подпись это `<text>` с якорем, здесь — текстовый бокс `body-m`
 * 20/28, и он выше строки на величину интерлиньяжа. Полное совпадение
 * потребовало бы рисовать эту карточку в SVG, а тогда пришлось бы
 * задавать кегли и радиусы числами — что в проекте запрещено.
 */

/** Строка подписей месяцев: `body-m` 20/28 */
const LABEL_ROW = 28;
/** Вся полоса под подписями: от неё отсчитываются тики оси */
const LABEL_BAND = LABEL_ROW + X_GAP;

/**
 * Доля ширины шага, которую занимает стакан. Донор: 32 из 49.75 = 0.643.
 *
 * Держится ДОЛЕЙ, а не пикселями: карточка бывает 1680 и 828 точек, а
 * столбиков — от 4 до 12. Абсолютное число донора при 12 столбиках на
 * половинной карточке дало бы стаканы вплотную.
 */
const TRACK_SHARE = 0.643;

/**
 * Лестница скруглений столбика.
 *
 * Донор: стакан 32 шириной, rx 10 — то есть 31% ширины; рамка наведения
 * отступает на 3 (9.4%) и имеет rx 13 = 10 + 3.
 *
 * У нас скругления — токены, и лестница подобрана так, чтобы КОНЦЕНТРИЧНОСТЬ
 * сходилась на существующих ступенях: радиус кольца = радиус столбика плюс
 * отступ, и оба конца попадают в токен.
 *
 *   стакан ≥96 → `rounded-panel` 32 + 16 = 48 `rounded-hero`   (33% ширины)
 *   стакан ≥64 → `rounded-card`  20 + 12 = 32 `rounded-panel`  (25…31%)
 *   стакан ≥32 → `rounded-tile`  12 +  8 = 20 `rounded-card`   (30…37%)
 *   стакан  <32 → `rounded-micro` 6 +  6 = 12 `rounded-tile`
 *
 * Толщина кольца: донорские 2 при стакане 32 — это 6% ширины. При стакане
 * 80 те же 6% дают 4.8, поэтому широкие стаканы получают `outline-4`,
 * узкие — `outline-2`. Своего токена толщины обводки в системе нет.
 */
/*
 * ⚠️ Лестница ЭКСПОРТИРУЕТСЯ, потому что стаканы рисует не одна карточка.
 * `stepsCard.tsx` строит те же колодцы, и два независимых списка ступеней
 * разошлись бы при первой же правке — на одном слайде оказались бы стаканы
 * с разным скруглением при одинаковой ширине. Источник правды один, здесь.
 */
export const RADIUS_LADDER = [
  {
    minTrack: 96,
    radius: 32,
    barClass: "rounded-panel",
    ringClass: "rounded-hero",
    ringGap: 16,
    ringClassWidth: "outline-4",
  },
  {
    minTrack: 64,
    radius: 20,
    barClass: "rounded-card",
    ringClass: "rounded-panel",
    ringGap: 12,
    ringClassWidth: "outline-4",
  },
  {
    minTrack: 32,
    radius: 12,
    barClass: "rounded-tile",
    ringClass: "rounded-card",
    ringGap: 8,
    ringClassWidth: "outline-2",
  },
  {
    minTrack: 0,
    radius: 6,
    barClass: "rounded-micro",
    ringClass: "rounded-tile",
    ringGap: 6,
    ringClassWidth: "outline-2",
  },
] as const;

/** Ступень лестницы по ширине стакана. Общая для всех карточек со стаканами */
export function trackRung(track: number) {
  return RADIUS_LADDER.find((r) => track >= r.minTrack) ?? RADIUS_LADDER[RADIUS_LADDER.length - 1];
}

/** Стандартная ширина карточки для своего размера — на ней считается геометрия */
const DEFAULT_WIDTH = { full: 1680, half: 828 } as const;

export interface EarningsGeometry {
  /** Поле графика внутри карточки */
  chartWidth: number;
  chartHeight: number;
  /** Ось и её просвет */
  axis: number;
  axisGap: number;
  /** Область построения: ширина без оси, высота без строки подписей */
  plotWidth: number;
  plotHeight: number;
  /** Шаг по столбикам и ширина стакана */
  step: number;
  track: number;
  /** Скругления и кольцо */
  radius: number;
  barClass: string;
  ringClass: string;
  ringGap: number;
  ringClassWidth: string;
  /**
   * Пол высоты столбика с ненулевым значением, в точках. Равен радиусу:
   * ниже него столбик превращается в срезанную полоску без круглых концов.
   */
  minBar: number;
}

/**
 * Считает геометрию карточки — числами, а не на глаз.
 *
 * Нужна и самому блоку, и историям: они печатают эти числа рядом с
 * карточкой, чтобы пропорции можно было сверить, а не оценивать.
 */
export function earningsGeometry({
  size = "full",
  width,
  height,
  valueSize = "m",
  legend = false,
  bars = 12,
  ticks,
  axisWidth,
}: {
  size?: CardShellSize;
  width?: number;
  height?: number;
  valueSize?: CardValueSize;
  legend?: boolean;
  bars?: number;
  /** Подписи оси: по ним замеряется ширина колонки */
  ticks?: readonly EarningsTick[];
  /** Ширина колонки оси вручную. Передаётся только когда замер не годится */
  axisWidth?: number;
} = {}): EarningsGeometry {
  const cardWidth = width ?? DEFAULT_WIDTH[size];
  const chartWidth = cardChartWidth(cardWidth, size);
  const chartHeight = cardChartHeight({ height, size, valueSize, legend });
  /*
   * Подписей не передали — оси нет вовсе, и колонка получает НОЛЬ: пустой
   * жёлоб отодвинул бы столбики от края карточки без всякой причины.
   * Просвет тоже снимается, иначе он остался бы висеть слева.
   */
  const measured = ticks?.length
    ? Math.ceil(Math.max(...ticks.map((t) => axisTextWidth(t.label))))
    : 0;
  const axis = axisWidth ?? measured;
  const axisGap = axis > 0 ? Y_GAP : 0;
  const plotWidth = chartWidth - axis - axisGap;
  const plotHeight = chartHeight - LABEL_BAND;
  const step = plotWidth / Math.max(bars, 1);
  const track = step * TRACK_SHARE;
  const rung = trackRung(track);

  return {
    chartWidth,
    chartHeight,
    axis,
    axisGap,
    plotWidth,
    plotHeight,
    step,
    track,
    radius: rung.radius,
    barClass: rung.barClass,
    ringClass: rung.ringClass,
    ringGap: rung.ringGap,
    ringClassWidth: rung.ringClassWidth,
    minBar: rung.radius,
  };
}

/* ═══════════════  График  ═══════════════ */

export interface EarningsPlotProps {
  bars: readonly EarningsBar[];
  /** Подписи оси Y. Донор задаёт их СПИСКОМ и неравномерно: $0 · $3K · $5K · $10K */
  ticks?: readonly EarningsTick[];
  /**
   * Потолок шкалы. У донора 12000 при верхнем тике 10K — то есть над
   * подписанным потолком остаётся запас, и столбик может его перерасти.
   * Не передан — берётся максимум из значений и тиков, то есть запаса нет.
   */
  max?: number;
  /** Индекс выделенного столбика. Он же назван в шапке карточки */
  highlight?: number;
  /** Краска столбиков. По умолчанию донорский салат lime-400 */
  color?: string;
  /** Краска выделенного столбика. По умолчанию lime-500 */
  activeColor?: string;
  /**
   * Ширина колонки оси вручную. По умолчанию замеряется по самой длинной
   * подписи — передавать нужно только тогда, когда замер не годится.
   */
  axisWidth?: number;
  /** Ширина карточки и её размер — от них считаются скругления */
  size?: CardShellSize;
  width?: number;
}

/**
 * Столбики в стаканах с осью Y и подписями снизу.
 *
 * Разметкой, а не SVG. Причина: подписи должны быть настоящим текстом
 * системными кеглями (`body-m` 20/28), скругления — токенами, а роли
 * цветов — переключаться темой. В SVG всё это пришлось бы задавать
 * числами и атрибутами, то есть ровно тем, что в проекте запрещено.
 *
 * Высоты столбиков — ПРОЦЕНТЫ от области построения, поэтому карточка
 * переживает любую ширину и высоту слота без пересчёта.
 */
export function EarningsPlot({
  bars,
  ticks,
  max,
  highlight,
  color = BOARD_SERIES[BOARD_CHART.lime],
  activeColor = BOARD_SERIES_ACTIVE[BOARD_CHART.lime],
  axisWidth,
  size = "full",
  width,
}: EarningsPlotProps) {
  /*
   * Пересчёт после загрузки шрифта. До неё замерщик отвечает по запасному
   * шрифту, и жёлоб оси получается чужой. Для экрана это незаметно —
   * кадров много; выгрузка же снимает РОВНО ОДИН кадр, и в него попала бы
   * ось, посчитанная не тем шрифтом.
   */
  useRemeasureOnFont();

  const scaleTicks = ticks ?? [];
  const ceiling =
    max ?? Math.max(1, ...bars.map((b) => b.value), ...scaleTicks.map((t) => t.value));
  const geom = earningsGeometry({
    size,
    width,
    bars: bars.length,
    ticks: scaleTicks,
    axisWidth,
  });

  return (
    <div className="flex h-full w-full" style={{ gap: geom.axisGap }}>
      {/*
       * Ось Y. Тики стоят ПО ЗНАЧЕНИЮ, а не поровну: у донора список
       * [0, 3K, 5K, 10K] неравномерный, и раскладывать их через
       * `justify-between` было бы враньём про шкалу.
       *
       * `translate-y-1/2` опускает подпись на половину строки, чтобы её
       * середина совпала с уровнем значения, а не с его низом.
       *
       * ⚠️ Колонка оси высотой во ВЕСЬ график, а не только в область
       * построения, и отсчёт ведётся от `LABEL_BAND` — полосы под
       * подписями месяцев. Иначе нижняя подпись («$0») свисает половиной
       * строки за низ своей колонки, и автопроверка высоты видит
       * переполнение 14 при пороге 16 — замер до правки. Формально порог
       * не превышен, но запас в две точки исчезает от любого изменения
       * кегля, а ложное срабатывание автопроверки хуже её отсутствия.
       */}
      <div className="relative shrink-0" style={{ width: geom.axis }} aria-hidden="true">
        {scaleTicks.map((tick) => (
          <span
            key={tick.label}
            className="text-body-m text-ink-secondary absolute right-0 translate-y-1/2 whitespace-nowrap tabular-nums"
            style={{
              bottom: `calc(${LABEL_BAND}px + (100% - ${LABEL_BAND}px) * ${tick.value / ceiling})`,
            }}
          >
            {tick.label}
          </span>
        ))}
      </div>

      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex min-h-0 flex-1">
          {bars.map((bar, index) => {
            const on = index === highlight;
            const share = Math.min(Math.max(bar.value / ceiling, 0), 1);

            return (
              <div key={bar.label} className="flex min-w-0 flex-1 justify-center">
                {/*
                 * Стакан: потолок шкалы, а не значение.
                 *
                 * Кольцо выделения — `outline` на самом стакане, а не
                 * отдельный элемент с рамкой. Причина измеримая: элемент
                 * с `inset: -12` увеличивает `scrollWidth` стакана на 12,
                 * и автопроверка ширины (`npm run check`, порог 4) начинает
                 * ругаться на каждый слайд с этой карточкой. Постоянное
                 * ложное срабатывание хуже отсутствия проверки — его
                 * начинают пролистывать. `outline` рисуется вне потока и
                 * на scrollWidth не влияет: замер после правки — 0.
                 *
                 * Скругление кольца браузер считает сам: радиус стакана
                 * плюс отступ, то есть ровно концентрично (замер в Chromium
                 * подтверждает; ступень совпадает с токеном
                 * `${geom.ringClass}` = ${geom.radius + geom.ringGap}).
                 */}
                <div
                  className={[
                    "bg-fill-strong relative h-full",
                    geom.barClass,
                    on ? `outline-ink-tertiary ${geom.ringClassWidth}` : "",
                  ]
                    .filter(Boolean)
                    .join(" ")}
                  style={{
                    width: `${TRACK_SHARE * 100}%`,
                    ...(on ? { outlineOffset: geom.ringGap } : null),
                  }}
                >
                  {bar.value > 0 ? (
                    <div
                      className={`absolute inset-x-0 bottom-0 ${geom.barClass}`}
                      style={{
                        height: `${share * 100}%`,
                        minHeight: geom.minBar,
                        background: on ? activeColor : color,
                      }}
                    />
                  ) : null}
                </div>
              </div>
            );
          })}
        </div>

        {/*
         * Подписи месяцев. Колонка подписей — сестра области построения
         * внутри одной колонки-обёртки, поэтому подпись стоит ровно под
         * своим стаканом без пересчёта полей.
         *
         * Выделенный месяц набран основным цветом — тем же приёмом, что и
         * выбранный период в шапке: заливка выделение не держит (замер
         * обычного столбика к выделенному — 1.27).
         */}
        <div className="flex shrink-0" style={{ height: LABEL_ROW, marginTop: X_GAP }}>
          {bars.map((bar, index) => (
            <span
              key={bar.label}
              className={`text-body-m min-w-0 flex-1 truncate text-center ${
                index === highlight ? "text-ink" : "text-ink-secondary"
              }`}
            >
              {bar.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════  Карточка  ═══════════════ */

export interface EarningsCardProps extends EarningsPlotProps {
  /** Подпись сверху слева. На скриншоте это ВЫДЕЛЕННЫЙ месяц: «December» */
  label: string;
  /** Крупное число: «$8 210» */
  value: string;
  /** `m` — `headline-l` 56 (по умолчанию), `l` — `display-s` 72 */
  valueSize?: CardValueSize;
  /** Плашка изменения */
  delta?: CardDelta;
  /** Подпись периода: `{ label: "Weekly", segments: [...] }` */
  period?: CardPeriod;
  /** Плитки легенды. У донора этой карточки легенды нет — но слот есть */
  legend?: readonly LegendTile[];
  /** Высота карточки. По умолчанию весь бюджет блока — 604 */
  height?: number;
  /** Вложенная тема: светлая карточка на тёмном слайде и наоборот */
  theme?: SlideTheme;
  className?: string;
  style?: CSSProperties;
}

export default function EarningsCard({
  label,
  value,
  valueSize = "m",
  delta,
  period,
  legend,
  size = "full",
  width,
  height,
  theme,
  className,
  style,
  ...plot
}: EarningsCardProps) {
  return (
    <CardShell
      label={label}
      value={value}
      valueSize={valueSize}
      delta={delta}
      period={period}
      legend={legend}
      size={size}
      height={height}
      theme={theme}
      className={className}
      style={style}
    >
      <EarningsPlot {...plot} size={size} width={width} />
    </CardShell>
  );
}
