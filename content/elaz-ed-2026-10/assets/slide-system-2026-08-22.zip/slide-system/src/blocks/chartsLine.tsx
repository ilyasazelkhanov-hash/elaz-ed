import { useEffect, useLayoutEffect, useRef, useState } from "react";

import { CHART_EMPHASIS, CHART_SERIES } from "../lib/chartPalette";

/**
 * Линейные графики: динамика и прогноз.
 *
 * === Почему SVG в натуральную величину, а не резиновый ===
 *
 * График рисуется в тех же координатах, что и холст слайда: ширина приходит
 * числом, viewBox равен ей же. Резиновый SVG с preserveAspectRatio="none"
 * растянул бы вместе с геометрией и толщину линий — на широком графике они
 * стали бы жирнее, чем на узком, и два графика в одной презентации перестали
 * бы выглядеть одной системой.
 *
 * === Чего здесь нет ===
 *
 * Второй оси Y. Никогда. Два показателя разного масштаба — это два графика
 * или приведение к общей базе: двойная ось позволяет нарисовать любой вывод
 * выбором масштабов.
 */

export interface Series {
  key: string;
  label: string;
  values: number[];
}

interface Geometry {
  width: number;
  height: number;
  padTop: number;
  padBottom: number;
  padLeft: number;
  padRight: number;
}

const DEFAULT_GEOMETRY: Geometry = {
  width: 1680,
  height: 460,
  padTop: 40,
  /* Место под подписи месяцев */
  padBottom: 56,
  /* Место под подписи значений слева */
  padLeft: 130,
  /*
   * Место под прямую подпись ряда справа от последней точки.
   *
   * Это МИНИМУМ, а не окончательное значение: если подпись шире, поле
   * расширяется под неё (см. `rightPadFor`). Раньше число было жёстким,
   * и подпись, которая в него не влезала, обрезалась краем SVG —
   * «Партнёрская доставка» на кегле 22 уходила за границу на 65.3px.
   */
  padRight: 200,
};

/* ═══════════════  Размеры подписей  ═══════════════ */

/*
 * Кегли и веса подписей вынесены в константы, потому что от них считается
 * геометрия: ширина поля справа, шаг прореживания оси и разведение подписей
 * по вертикали. Пока числа стояли по месту, посчитать это было нечем.
 *
 * Значения те же, что были в разметке до правки, — вид графиков не изменился.
 */
const NAME_SIZE = 22;
const NAME_WEIGHT = 600;
const VALUE_SIZE = 18;
const VALUE_WEIGHT = 500;
const AXIS_SIZE = 20;
const AXIS_WEIGHT = 500;

/** Отступ прямой подписи от последней точки ряда */
const LABEL_OFFSET = 24;
/** Значение стоит под именем ряда */
const VALUE_DROP = 28;
/** Просвет между подписью и краем SVG: вплотную к краю подпись читается как обрезанная */
const EDGE_GAP = 8;

/*
 * Бокс прямой подписи относительно её якоря. Замер в 1:1 на витрине
 * «Блоки/Графики данных → Динамика»: у имени (22px, dominant-baseline middle)
 * верх бокса на 15.89px выше якоря, у значения (18px, якорь +28) низ бокса
 * на 37.59px ниже. Итого блок высотой 53.5px.
 */
const LABEL_ABOVE = 16;
const LABEL_BELOW = 38;

/**
 * Минимальное расстояние между якорями соседних подписей.
 *
 * 54 — высота блока по замеру выше, 6 — просвет. Без разведения два ряда
 * с близкими последними значениями кладут подписи друг на друга: на витрине
 * при расхождении рядов в 35 единиц на шкале 4000 имена перекрывались
 * на 241.3×24.5px, а значения — на 43.4×19px.
 */
const LABEL_MIN_GAP = 60;

/**
 * С какого сдвига подписи к ней рисуется выноска.
 *
 * Пока подпись отъехала меньше чем на 10px, её якорь остаётся внутри бокса
 * имени (замер: полвысоты бокса — 14px), и подпись всё ещё читается стоящей
 * на своей линии. Выноска в этом случае была бы лишней чертой на графике.
 */
const LEADER_MIN = 10;

/**
 * Просвет между соседними подписями оси X.
 *
 * 10px при кегле 20 — это чуть больше двух пробелов (пробел Google Sans
 * на 20px замерен в 4.66px). Меньше — подписи читаются как одно слово,
 * больше — начинают выпадать те, что на самом деле помещались: при 16px
 * с графика трафика в реальном деке пропадала подпись «Фев», между которой
 * и «Мар» по замеру 15.6px чистого просвета.
 */
const AXIS_GUTTER = 10;

/**
 * Шаг прореживания подписей оси X считается от этой ширины.
 *
 * 92px — ширина самой длинной подписи вида «Янв 26» на кегле 20 (замер 61.7px)
 * плюс просвет. Число оставлено прежним намеренно: на нём выверены все
 * действующие деки, и пересчёт шага сдвинул бы подписи на уже сданных слайдах.
 * Точная проверка на столкновение идёт отдельно, по замеренной ширине каждой
 * подписи, — см. `axisIndices`.
 */
const AXIS_STEP_WIDTH = 92;

/* ═══════════════  Замер ширины текста  ═══════════════ */

/*
 * === Зачем мерить, а не прикидывать по числу знаков ===
 *
 * Ширина подписи нужна до отрисовки: от неё зависят поле справа и то, какие
 * подписи оси помещаются рядом. Прикидка «знаков × кегль × коэффициент» здесь
 * не годится — разброс по замеру от 0.27 (римская «I») до 0.70 («Июн») ширины
 * кегля на знак, то есть в два с половиной раза.
 *
 * `canvas.measureText` тем же шрифтом даёт то же число, что `getComputedTextLength`
 * у уже нарисованного текста: проверено на восьми строках витрины, расхождение
 * не превысило 0.01px («Партнёрская доставка» — 241.28 и там и там).
 */

/** Запасной коэффициент на случай, когда DOM недоступен (сборка вне браузера) */
const FALLBACK_RATIO = 0.62;

const measureCache = new Map<string, number>();
let measureCtx: CanvasRenderingContext2D | null | undefined;

function fontStack() {
  /* Стек берётся из токена --font-app, чтобы не заводить вторую копию списка */
  const token = getComputedStyle(document.documentElement).getPropertyValue("--font-app").trim();
  return token || "sans-serif";
}

function textWidth(text: string, size: number, weight: number) {
  const key = `${weight} ${size} ${text}`;
  const cached = measureCache.get(key);
  if (cached !== undefined) return cached;

  if (measureCtx === undefined) {
    measureCtx =
      typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  }

  let width: number;
  if (measureCtx) {
    measureCtx.font = `${weight} ${size}px ${fontStack()}`;
    width = measureCtx.measureText(text).width;
  } else {
    width = text.length * size * FALLBACK_RATIO;
  }

  measureCache.set(key, width);
  return width;
}

/** Дождались ли мы загрузки шрифта хотя бы раз за жизнь страницы */
let fontsSettled = false;

/**
 * Перерисовка после того, как догрузился шрифт.
 *
 * До загрузки Google Sans `measureText` отвечает по ЗАПАСНОМУ шрифту, и числа
 * получаются чужие. Для экрана это не страшно — кадров много, — но выгрузка
 * в PDF снимает РОВНО ОДИН кадр, причём сразу после `document.fonts.ready`
 * (scripts/export-pdf.ts:143, scripts/check-slides.mts:172). Без пересчёта
 * в этот единственный кадр попало бы поле справа, посчитанное по метрикам Arial.
 *
 * Ожидание безусловное, а не по `document.fonts.status`: статус бывает
 * «loaded» и до того, как шрифт вообще запрошен — файл грузится лениво, когда
 * до него доходит вёрстка. Проверка статуса на первом кадре пропустила бы
 * ровно тот случай, ради которого хук и написан.
 *
 * Цена — одна лишняя перерисовка первого графика страницы. Замер после
 * `ready` возвращает те же числа, что `getComputedTextLength` у нарисованного
 * текста, так что второго пересчёта не требуется.
 */
function useRemeasureOnFont() {
  const [, remeasured] = useState(0);

  useEffect(() => {
    if (fontsSettled) return;
    let alive = true;
    void document.fonts?.ready.then(() => {
      if (!alive) return;
      fontsSettled = true;
      /* Кэш мог собраться по запасному шрифту — он больше не верен */
      measureCache.clear();
      remeasured((n) => n + 1);
    });
    return () => {
      alive = false;
    };
  }, []);
}

/* ═══════════════  Определение темы  ═══════════════ */

/**
 * Активная тема по ближайшему предку с data-theme.
 *
 * Тот же приём, что в `blocks/lattice.tsx`: от темы зависит плотность заливки
 * коридора, а SVG-атрибут `opacity` темой не переключается — CSS-переменных
 * с числом прозрачности в системе нет, и заводить их ради одного блока нельзя.
 *
 * useLayoutEffect, а не useEffect: он отрабатывает до отрисовки, поэтому
 * первого кадра со светлой плотностью на тёмном слайде не бывает. Для PDF
 * это существенно — там кадр ровно один. Эффект намеренно без массива
 * зависимостей: тема меняется атрибутом предка, а не свойством блока.
 */
function useChartTheme() {
  const ref = useRef<SVGSVGElement>(null);
  const [theme, setTheme] = useState<"light" | "dark">("light");

  useLayoutEffect(() => {
    const host = ref.current?.closest("[data-theme]");
    setTheme(host?.getAttribute("data-theme") === "dark" ? "dark" : "light");
  });

  return { ref, theme };
}

/* ═══════════════  Общая геометрия  ═══════════════ */

/** Красивый шаг сетки: 1, 2 или 5 на нужном порядке */
function niceStep(range: number, targetLines: number) {
  const raw = range / targetLines;
  const magnitude = 10 ** Math.floor(Math.log10(raw));
  const normalized = raw / magnitude;
  const step = normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10;
  return step * magnitude;
}

/**
 * Поле справа под самую широкую из прямых подписей.
 *
 * Возвращается МАКСИМУМ из заказанного поля и needed: сузить поле замер
 * не может, только расширить. Иначе правка ширины поля в деке перестала бы
 * что-либо значить.
 */
function rightPadFor(requested: number, blocks: { name: string; value: string }[]) {
  const widest = blocks.reduce(
    (acc, b) =>
      Math.max(
        acc,
        textWidth(b.name, NAME_SIZE, NAME_WEIGHT),
        textWidth(b.value, VALUE_SIZE, VALUE_WEIGHT),
      ),
    0,
  );
  return Math.max(requested, LABEL_OFFSET + widest + EDGE_GAP);
}

/**
 * Разведение прямых подписей по вертикали.
 *
 * Подпись хочет стоять на высоте своей последней точки. Если соседние точки
 * ближе, чем LABEL_MIN_GAP, блоки налезают друг на друга — и вместо двух
 * подписей получается каша из четырёх строк в одной зоне.
 *
 * Порядок: сортировка сверху вниз, проход с расталкиванием вниз, затем —
 * если стопка вылезла за нижний край SVG — сдвиг всей стопки вверх и повторное
 * расталкивание уже сверху. Так подписи не уезжают за холст: там их обрежет
 * `overflow: hidden`, и потеря будет молчаливой.
 *
 * Связь подписи со своим рядом сохраняется выноской (см. LineChart): без неё
 * сдвинутая подпись начинает читаться как подпись к чужой линии.
 */
function stackLabels(targets: number[], height: number) {
  const order = targets.map((y, i) => ({ i, y })).sort((a, b) => a.y - b.y);

  for (let k = 1; k < order.length; k++) {
    order[k].y = Math.max(order[k].y, order[k - 1].y + LABEL_MIN_GAP);
  }

  const bottom = order.length ? order[order.length - 1].y + LABEL_BELOW : 0;
  const overflow = bottom - (height - EDGE_GAP);
  if (overflow > 0) {
    for (const o of order) o.y -= overflow;
    for (let k = 0; k < order.length; k++) {
      const floor = k === 0 ? LABEL_ABOVE + EDGE_GAP : order[k - 1].y + LABEL_MIN_GAP;
      order[k].y = Math.max(order[k].y, floor);
    }
  }

  const out = targets.slice();
  for (const o of order) out[o.i] = o.y;
  return out;
}

/**
 * Какие подписи оси X показывать.
 *
 * Прореживание по шагу обязательно: при 12 точках на узком графике соседние
 * подписи слипаются в «Апр 25Май 25». Но одного шага мало — ПЕРВАЯ и
 * ПОСЛЕДНЯЯ подписи показываются всегда, потому что без них непонятно,
 * чем период начинается и заканчивается, а последняя в шаг обычно не попадает.
 *
 * Раньше последняя просто дорисовывалась поверх прореженного ряда и с соседкой
 * не сверялась: на витрине «Дек 25» налезала на «Окт 25» на 7.5px.
 *
 * Поэтому проход идёт СПРАВА НАЛЕВО от последней подписи: каждая следующая
 * влево принимается, только если её бокс не достаёт до уже принятой. В конце
 * так же проверяется первая — если ближайшая принятая с ней сталкивается,
 * убирается принятая, а не первая: край периода важнее середины.
 *
 * Боксы считаются по замеренной ширине и с учётом выключки: у первой подписи
 * якорь слева, у последней справа, у остальных по центру.
 */
function axisIndices(labels: string[], x: (i: number) => number, step: number) {
  const last = labels.length - 1;
  if (last <= 0) return [0];

  const box = (i: number) => {
    const w = textWidth(labels[i], AXIS_SIZE, AXIS_WEIGHT);
    if (i === 0) return { left: x(i), right: x(i) + w };
    if (i === last) return { left: x(i) - w, right: x(i) };
    return { left: x(i) - w / 2, right: x(i) + w / 2 };
  };

  const kept: number[] = [];
  let limit = box(last).left;
  for (let i = Math.floor((last - 1) / step) * step; i >= step; i -= step) {
    const b = box(i);
    if (b.right + AXIS_GUTTER <= limit) {
      kept.push(i);
      limit = b.left;
    }
  }
  kept.reverse();

  const firstRight = box(0).right;
  while (kept.length && firstRight + AXIS_GUTTER > box(kept[0]).left) kept.shift();

  return [0, ...kept, last];
}

/**
 * Выноска от линии к отодвинутой подписи.
 *
 * Разведение подписей по вертикали чинит наложение, но создаёт новую беду:
 * подпись, стоящая не на своей высоте, начинает читаться как подпись к чужой
 * линии. Выноска возвращает привязку.
 *
 * Цветом ряда, а не текстовым токеном: это графика, а не текст, и именно
 * цвет здесь называет линию. Правило «текст носит текстовые токены»
 * (dataviz.md) осталось при этом целым — само имя ряда набрано `--t-ink`.
 *
 * Ступенькой, а не прямой диагональю: горизонтальные хвосты у линии и
 * у подписи показывают, откуда и куда, и не пересекают соседние точки.
 */
function Leader({ x, from, to, color }: { x: number; from: number; to: number; color: string }) {
  if (Math.abs(to - from) < LEADER_MIN) return null;
  return (
    <path
      d={`M ${x} ${from} L ${x + 4} ${from} L ${x + 8} ${to} L ${x + 12} ${to}`}
      fill="none"
      stroke={color}
      strokeWidth={2}
    />
  );
}

/** Выключка подписи оси: края прижаты, середина по центру */
function axisAnchor(i: number, last: number) {
  return i === 0 ? "start" : i === last ? "end" : "middle";
}

/* ═══════════════  Динамика  ═══════════════ */

/**
 * График динамики: одна или несколько линий во времени.
 *
 * === Про отметку события ===
 *
 * Вертикальная линия с подписью — самая ценная часть графика падения.
 * Без неё зритель видит, ЧТО трафик упал; с ней — КОГДА и относительно чего.
 * Ступенька на графике всегда означает, что что-то сломали одномоментно,
 * и отметка превращает наблюдение в довод.
 */
export function LineChart({
  series,
  labels,
  marker,
  emphasisKey,
  formatValue = (v) => v.toLocaleString("ru-RU"),
  geometry,
}: {
  series: Series[];
  /** Подписи оси X, по одной на точку */
  labels: string[];
  /** Вертикальная отметка события: индекс точки и подпись */
  marker?: { at: number; label: string };
  /** Ключ ряда, который выделяется цветом. Остальные приглушаются */
  emphasisKey?: string;
  formatValue?: (value: number) => string;
  geometry?: Partial<Geometry>;
}) {
  useRemeasureOnFont();

  const g = { ...DEFAULT_GEOMETRY, ...geometry };

  const lastValue = series.map((s) => s.values[s.values.length - 1]);
  const padRight = rightPadFor(
    g.padRight,
    series.map((s, si) => ({ name: s.label, value: formatValue(lastValue[si]) })),
  );

  const plotW = g.width - g.padLeft - padRight;
  const plotH = g.height - g.padTop - g.padBottom;

  const all = series.flatMap((s) => s.values);
  const max = Math.max(...all);
  /* Ноль в основании обязателен: график динамики с обрезанным низом
     преувеличивает падение, и на клиентской презентации это обман */
  const min = 0;
  const step = niceStep(max - min, 4);
  const top = Math.ceil(max / step) * step;

  const x = (i: number) => g.padLeft + (i * plotW) / (labels.length - 1);
  const y = (v: number) => g.padTop + plotH - ((v - min) / (top - min)) * plotH;

  const gridValues = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => i * step);

  const spacing = plotW / (labels.length - 1);
  const labelStep = Math.max(1, Math.ceil(AXIS_STEP_WIDTH / spacing));
  const shownLabels = axisIndices(labels, x, labelStep);

  /* Высота каждой прямой подписи: хочет стоять у своей точки, но не поверх соседки */
  const labelY = stackLabels(
    lastValue.map((v) => y(v)),
    g.height,
  );

  return (
    <svg width={g.width} height={g.height} viewBox={`0 0 ${g.width} ${g.height}`} role="img">
      {/* Сетка. Приглушённая: она опора, а не содержание */}
      {gridValues.map((v) => (
        <g key={v}>
          <line
            x1={g.padLeft}
            x2={g.padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={2}
          />
          <text
            x={g.padLeft - 24}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {formatValue(v)}
          </text>
        </g>
      ))}

      {/* Отметка события — под линиями, чтобы их не перечёркивать */}
      {marker ? (
        <g>
          <line
            x1={x(marker.at)}
            x2={x(marker.at)}
            y1={g.padTop - 16}
            y2={g.padTop + plotH}
            stroke="var(--color-error)"
            strokeWidth={3}
            strokeDasharray="10 8"
          />
          <text
            x={x(marker.at) + 16}
            y={g.padTop - 12}
            fill="var(--t-error-fg)"
            style={{ fontSize: AXIS_SIZE, fontWeight: 600 }}
          >
            {marker.label}
          </text>
        </g>
      ) : null}

      {/* Линии */}
      {series.map((s, si) => {
        const muted = emphasisKey !== undefined && s.key !== emphasisKey;
        const color = muted
          ? "var(--t-fill-strong)"
          : emphasisKey !== undefined
            ? CHART_EMPHASIS
            : CHART_SERIES[si % CHART_SERIES.length];

        const d = s.values.map((v, i) => `${i ? "L" : "M"} ${x(i)} ${y(v)}`).join(" ");
        const lastIndex = s.values.length - 1;
        const px = x(lastIndex);
        const py = y(lastValue[si]);
        const ly = labelY[si];

        return (
          <g key={s.key}>
            <path d={d} fill="none" stroke={color} strokeWidth={5} strokeLinejoin="round" />

            {/* Точка на последнем значении: якорь для прямой подписи */}
            <circle cx={px} cy={py} r={9} fill={color} />

            <Leader from={py} to={ly} x={px + 11} color={color} />

            {/*
             * Прямая подпись у конца линии вместо легенды-коробки.
             * Читается без перевода взгляда: имя ряда стоит там же, где
             * его линия. Легенда сбоку заставляет сопоставлять цвета.
             */}
            <text
              x={px + LABEL_OFFSET}
              y={ly}
              dominantBaseline="middle"
              fill="var(--t-ink)"
              style={{ fontSize: NAME_SIZE, fontWeight: NAME_WEIGHT }}
            >
              {s.label}
            </text>
            <text
              x={px + LABEL_OFFSET}
              y={ly + VALUE_DROP}
              dominantBaseline="middle"
              fill="var(--t-ink-secondary)"
              style={{ fontSize: VALUE_SIZE, fontWeight: VALUE_WEIGHT }}
            >
              {formatValue(lastValue[si])}
            </text>
          </g>
        );
      })}

      {/* Подписи оси X. Какие именно — считает axisIndices */}
      {shownLabels.map((i) => (
        <text
          key={i}
          x={x(i)}
          y={g.padTop + plotH + 36}
          textAnchor={axisAnchor(i, labels.length - 1)}
          fill="var(--t-ink-secondary)"
          style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
        >
          {labels[i]}
        </text>
      ))}
    </svg>
  );
}

/* ═══════════════  Прогноз  ═══════════════ */

/**
 * Плотность заливки коридора по темам.
 *
 * ⚠️ ЗДЕСЬ ЧИСЛА БОЛЬШЕ НЕ ДОКАЗЫВАЮТ КОД. Пересчёт на действующей
 * краске коридора CHART_EMPHASIS #2b7fff (холсты скина board):
 *
 *   16% на светлом холсте #f7f7f7 → #d6e4f8, контраст к холсту 1.20:1, ΔL* 7.1
 *   16% на тёмном  холсте #121212 → #162338, 1.19:1, ΔL* 8.1
 *   20% на тёмном  холсте #121212 → #172841, 1.26:1, ΔL* 10.4
 *
 * То есть на синей краске тёмная тема при ТЕХ ЖЕ 16% уже идёт вровень со
 * светлой (1.19 против 1.20) и даже чуть впереди по светлоте (ΔL* 8.1
 * против 7.1). Поднятие до 20% теперь делает тёмный коридор ЗАМЕТНО
 * плотнее светлого, а не выравнивает его.
 *
 * Летопись довода, потому что он переписывался при каждой смене палитры:
 *
 *   палитра до скина board — разрыв держался на пунктирной границе: она
 *       давала 5.36:1 на тёмном против 3.52:1 на белом, заливка
 *       проваливалась относительно собственной границы
 *   фиолетовый акцент донора #8e51ff — асимметрии границы нет (4.11 и
 *       4.26), зато заливка при 16% была слабее в тёмной (1.16 против
 *       1.22), и 20% её выравнивали. Это и есть текст, который тут стоял
 *   синяя шкала заказчика — граница 3.51:1 в светлой и 4.98:1 в тёмной,
 *       заливка при 16% уже вровень
 *
 * Код НЕ тронут: BAND_OPACITY.dark остаётся 0.2, потому что менять
 * плотность заливки — значит менять вид уже сданных слайдов, а это
 * решение о виде, а не правка комментария. Но обоснования «выравнивание»
 * у этого числа больше нет, и при следующем разговоре о коридоре 0.16
 * в тёмной теме — законный кандидат.
 *
 * История про источник числа 20%: оно было взято не с потолка, а из
 * themes.css, где система уплотняла полупрозрачные заливки в тёмной теме
 * (`--t-warning-fill` 0.16 → 0.20). В скине board этого прецедента больше
 * нет — светлые статусные заливки стали сплошными, тёмные стоят на
 * 0.16–0.18. И замер, который число подтверждал, тоже больше его
 * не подтверждает — см. предупреждение выше.
 *
 * Светлая тема оставлена как была — иначе поехали бы уже сданные слайды.
 */
const BAND_OPACITY = { light: 0.16, dark: 0.2 };

/** Подписи границ коридора по умолчанию. Дек может дать свои, пустая строка — не рисовать */
const DEFAULT_BOUND_LABELS = { actual: "Факт", high: "Верхняя", low: "Нижняя" };

/** Насколько подпись факта поднята над своей точкой и отставлена вбок */
const FACT_RISE = 30;
const FACT_SHIFT = 18;

/**
 * График прогноза: сплошная линия факта и пунктирный коридор ожидания.
 *
 * === Почему коридор, а не одна линия ===
 *
 * Прогноз одной линией читается как обещание. Коридор честнее: он сразу
 * говорит, что это диапазон, и снимает половину будущих претензий
 * «вы обещали 97 тысяч». Границы коридора — те же числа, что названы
 * в плане работ, просто нарисованные.
 */
export function ForecastChart({
  labels,
  actual,
  low,
  high,
  boundLabels,
  formatValue = (v) => v.toLocaleString("ru-RU"),
  geometry,
}: {
  labels: string[];
  /** Факт. Короче labels — остальное считается прогнозом */
  actual: number[];
  /** Нижняя граница прогноза, продолжает факт */
  low: number[];
  /** Верхняя граница прогноза */
  high: number[];
  /**
   * Что написать у линий. Раньше подписей не было вовсе, и что означает
   * верхний пунктир, зритель узнавал только из текста рядом со слайдом —
   * то есть принцип «подпись рядом с линией вместо легенды» соблюдался
   * в графике динамики и нарушался здесь.
   */
  boundLabels?: Partial<typeof DEFAULT_BOUND_LABELS>;
  formatValue?: (value: number) => string;
  geometry?: Partial<Geometry>;
}) {
  useRemeasureOnFont();
  const { ref, theme } = useChartTheme();

  const g = { ...DEFAULT_GEOMETRY, ...geometry };
  const names = { ...DEFAULT_BOUND_LABELS, ...boundLabels };

  const highLast = high[high.length - 1];
  const lowLast = low[low.length - 1];
  const padRight = rightPadFor(g.padRight, [
    { name: names.high, value: formatValue(highLast) },
    { name: names.low, value: formatValue(lowLast) },
  ]);

  const plotW = g.width - g.padLeft - padRight;
  const plotH = g.height - g.padTop - g.padBottom;

  const max = Math.max(...high, ...actual);
  const step = niceStep(max, 4);
  const top = Math.ceil(max / step) * step;

  const x = (i: number) => g.padLeft + (i * plotW) / (labels.length - 1);
  const y = (v: number) => g.padTop + plotH - (v / top) * plotH;

  const offset = actual.length - 1;
  const gridValues = Array.from({ length: Math.round(top / step) + 1 }, (_, i) => i * step);

  const labelStep = Math.max(1, Math.ceil(AXIS_STEP_WIDTH / (plotW / (labels.length - 1))));
  const shownLabels = axisIndices(labels, x, labelStep);

  /*
   * Контур коридора: вперёд по верхней границе, назад по нижней, замкнуть.
   * Нижняя обходится с конца — иначе фигура получится «бабочкой»
   * с самопересечением в середине.
   */
  const area = [
    ...high.map((v, i) => `${i ? "L" : "M"} ${x(offset + i)} ${y(v)}`),
    ...low
      .slice()
      .reverse()
      .map((v, i) => `L ${x(offset + low.length - 1 - i)} ${y(v)}`),
    "Z",
  ].join(" ");

  /*
   * Подписи границ стоят у конца своего пунктира и разводятся тем же
   * механизмом, что в графике динамики: у схлопнувшегося коридора границы
   * расходятся на десяток пикселей, и без разведения подписи легли бы одна
   * на другую. Высота SVG от этого не меняется — стопка при нехватке места
   * сдвигается вверх, а не наращивает холст.
   */
  const boundX = x(offset + high.length - 1) + LABEL_OFFSET;
  const [highY, lowY] = stackLabels([y(highLast), y(lowLast)], g.height);

  /*
   * Подпись факта. Когда фактическая точка одна (offset 0), она стоит
   * на левом краю: подпись уходит вправо, иначе налезла бы на подписи шкалы.
   * Поднята над точкой, а не опущена под неё, — под точкой начинается коридор.
   */
  const factAnchor = offset === 0 ? "start" : "end";
  const factX = offset === 0 ? x(offset) + FACT_SHIFT : x(offset) - FACT_SHIFT;
  const factY = Math.max(LABEL_ABOVE + EDGE_GAP, y(actual[offset]) - FACT_RISE);

  return (
    <svg
      ref={ref}
      width={g.width}
      height={g.height}
      viewBox={`0 0 ${g.width} ${g.height}`}
      role="img"
    >
      {gridValues.map((v) => (
        <g key={v}>
          <line
            x1={g.padLeft}
            x2={g.padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={2}
          />
          <text
            x={g.padLeft - 24}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {formatValue(v)}
          </text>
        </g>
      ))}

      {/* Коридор прогноза заливкой, границы пунктиром */}
      <path d={area} fill={CHART_EMPHASIS} opacity={BAND_OPACITY[theme]} />
      <path
        d={high.map((v, i) => `${i ? "L" : "M"} ${x(offset + i)} ${y(v)}`).join(" ")}
        fill="none"
        stroke={CHART_EMPHASIS}
        strokeWidth={4}
        strokeDasharray="12 10"
      />
      <path
        d={low.map((v, i) => `${i ? "L" : "M"} ${x(offset + i)} ${y(v)}`).join(" ")}
        fill="none"
        stroke={CHART_EMPHASIS}
        strokeWidth={4}
        strokeDasharray="12 10"
      />

      {/* Факт — сплошной и толще: он единственное, что здесь измерено */}
      <path
        d={actual.map((v, i) => `${i ? "L" : "M"} ${x(i)} ${y(v)}`).join(" ")}
        fill="none"
        stroke="var(--t-ink)"
        strokeWidth={5}
        strokeLinejoin="round"
      />
      <circle cx={x(offset)} cy={y(actual[offset])} r={10} fill="var(--t-ink)" />

      {names.actual ? (
        <text
          x={factX}
          y={factY}
          textAnchor={factAnchor}
          dominantBaseline="middle"
          fill="var(--t-ink)"
          style={{ fontSize: NAME_SIZE, fontWeight: NAME_WEIGHT }}
        >
          {names.actual}
        </text>
      ) : null}

      {/* Прямые подписи границ: без них верхний и нижний пунктир неразличимы по смыслу */}
      {[
        { name: names.high, value: highLast, at: highY, from: y(highLast) },
        { name: names.low, value: lowLast, at: lowY, from: y(lowLast) },
      ].map((b) =>
        b.name ? (
          <g key={b.name}>
            <Leader x={boundX - 13} from={b.from} to={b.at} color={CHART_EMPHASIS} />
            <text
              x={boundX}
              y={b.at}
              dominantBaseline="middle"
              fill="var(--t-ink)"
              style={{ fontSize: NAME_SIZE, fontWeight: NAME_WEIGHT }}
            >
              {b.name}
            </text>
            <text
              x={boundX}
              y={b.at + VALUE_DROP}
              dominantBaseline="middle"
              fill="var(--t-ink-secondary)"
              style={{ fontSize: VALUE_SIZE, fontWeight: VALUE_WEIGHT }}
            >
              {formatValue(b.value)}
            </text>
          </g>
        ) : null,
      )}

      {shownLabels.map((i) => (
        <text
          key={i}
          x={x(i)}
          y={g.padTop + plotH + 36}
          textAnchor={axisAnchor(i, labels.length - 1)}
          fill="var(--t-ink-secondary)"
          style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
        >
          {labels[i]}
        </text>
      ))}
    </svg>
  );
}
