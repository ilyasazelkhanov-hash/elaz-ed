import type { ReactNode } from "react";
import { shiftLightness } from "../lib/color";

/**
 * Папка macOS. Перенесена из донорского мобильного проекта (macFolder.tsx) без изменений формы.
 *
 * === Откуда взяты пропорции ===
 *
 * Ничего не подобрано на глаз: и форма, и цвета сняты с системной иконки
 * GenericFolderIcon.icns (CoreTypes.bundle). Иконка распакована в PNG 512×512
 * и разобрана попиксельно. Что показал разбор:
 *
 *   — сама папка занимает 485×383, то есть она НЕ квадратная, отношение 1.266.
 *     Квадратный там холст иконки, а не папка. Плашку делаем квадратной,
 *     поэтому вертикальные доли считаются от высоты плашки;
 *   — язычок: ровное плато на 30.6% ширины, дальше плавный скос до 37.4%.
 *     Скос — главная примета формы, вертикальной ступеньки там нет;
 *   — язычок выступает над корпусом на 9.9% высоты;
 *   — верх передней стенки — на 15.7% высоты, то есть передняя закрывает 84%;
 *   — радиусы: у язычка 3.7% ширины, у корпуса 4.1%;
 *   — задняя стенка ровная #93dcff, БЕЗ градиента;
 *   — передняя темнее задней и светлеет книзу: #65c9f8 сверху, #7ad5fb к низу.
 *
 * Последнее — главная неожиданность: обычно рисуют наоборот, переднюю стенку
 * светлее задней.
 *
 * === Зачем это в презентации ===
 *
 * Узнаваемый предмет вместо абстрактной плитки. Слайд про структуру
 * материалов, состав поставки или организацию файлов читается мгновенно,
 * если на нём папка, а не прямоугольник с подписью «папка».
 */

const MAC = {
  back: "#93dcff",
  frontTop: "#65c9f8",
  frontBottom: "#7ad5fb",
} as const;

/** Доли от ширины и высоты плашки */
const K = {
  tab: 0.306,
  ramp: 0.374,
  bodyTop: 0.099,
  frontTop: 0.157,
  rTab: 0.037,
  rBody: 0.041,
  rFront: 0.03,
};

/**
 * Палитра папки, углублённая на `depth` пунктов светлоты.
 *
 * Углубление нужно из-за белого текста: на настоящих цветах иконки белый даёт
 * 1.51 на задней стенке и 1.87 на передней при норме 4.5 — текст практически
 * не виден. Тон и насыщенность при сдвиге не трогаются, поэтому папка
 * остаётся той же папкой, только глубже.
 */
export function folderPalette(depth: number) {
  return {
    back: shiftLightness(MAC.back, -depth),
    frontTop: shiftLightness(MAC.frontTop, -depth),
    frontBottom: shiftLightness(MAC.frontBottom, -depth),
  };
}

/**
 * Задняя стенка с язычком.
 *
 * Рисуется SVG, а не div с clip-path: скос язычка нужен со скруглениями
 * на обоих концах, а clip-path режет border-radius и превращает скругления
 * в острые углы.
 */
function FolderBack({ size, color }: { size: number; color: string }) {
  const W = size;
  const top = W * K.bodyTop;
  const tab = W * K.tab;
  const ramp = W * K.ramp;
  const rT = W * K.rTab;
  const rB = W * K.rBody;
  /* Скос задан кубической кривой: у иконки он начинается полого, в середине
     круче всего и снова выполаживается — ровная диагональ так не выглядит */
  const ease = (ramp - tab) * 0.42;

  const d = [
    `M ${rT} 0`,
    `H ${tab}`,
    `C ${tab + ease} 0, ${ramp - ease} ${top}, ${ramp} ${top}`,
    `H ${W - rB}`,
    `A ${rB} ${rB} 0 0 1 ${W} ${top + rB}`,
    `V ${W - rB}`,
    `A ${rB} ${rB} 0 0 1 ${W - rB} ${W}`,
    `H ${rB}`,
    `A ${rB} ${rB} 0 0 1 0 ${W - rB}`,
    `V ${rT}`,
    `A ${rT} ${rT} 0 0 1 ${rT} 0`,
    "Z",
  ].join(" ");

  return (
    <svg
      className="absolute"
      style={{ left: 0, top: 0 }}
      width={W}
      height={W}
      viewBox={`0 0 ${W} ${W}`}
      aria-hidden="true"
    >
      <path d={d} fill={color} />
    </svg>
  );
}

/**
 * Передняя стенка. Обычный div: она прямоугольная, скругления обычные.
 *
 * Световая грань по верхнему краю и мягкая тень ВВЕРХ от него — это и есть
 * «стенка стоит перед задней». Без тени два слоя читаются как две плоские
 * заливки, приставленные друг к другу.
 */
function FolderFront({
  size,
  top,
  from,
  to,
}: {
  size: number;
  top: number;
  from: string;
  to: string;
}) {
  return (
    <div
      className="absolute"
      style={{
        left: 0,
        right: 0,
        top,
        bottom: 0,
        borderRadius: `${size * K.rFront}px ${size * K.rFront}px ${size * K.rBody}px ${size * K.rBody}px`,
        background: `linear-gradient(180deg, ${from} 0%, ${to} 100%)`,
        boxShadow:
          "inset 0 1px 0 rgba(255,255,255,0.5), inset 0 0 0 1px rgba(255,255,255,0.18), 0 -8px 18px rgba(0,40,80,0.22)",
      }}
    />
  );
}

export interface FolderProps {
  size?: number;
  /**
   * Насколько углубить цвет. 0 — настоящие цвета системной иконки,
   * 0.2 и глубже — если поверх папки идёт белый текст.
   */
  depth?: number;
  /** Содержимое поверх передней стенки: подпись, счётчик */
  children?: ReactNode;
}

export default function Folder({ size = 280, depth = 0, children }: FolderProps) {
  const palette = folderPalette(depth);

  return (
    <div className="relative shrink-0" style={{ width: size, height: size }}>
      <FolderBack size={size} color={palette.back} />
      <FolderFront
        size={size}
        top={size * K.frontTop}
        from={palette.frontTop}
        to={palette.frontBottom}
      />
      {children ? (
        <div
          className="absolute inset-x-0 bottom-0 flex flex-col justify-end"
          style={{ top: size * K.frontTop, padding: size * 0.09 }}
        >
          {children}
        </div>
      ) : null}
    </div>
  );
}
