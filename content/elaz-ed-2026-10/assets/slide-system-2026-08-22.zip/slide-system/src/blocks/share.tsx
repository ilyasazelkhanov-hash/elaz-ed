import { CHART_MUTED, CHART_SERIES } from "../lib/chartPalette";

/**
 * Лента долей со скобой над группой.
 *
 * === Какую задачу решает ===
 *
 * Не «из чего состоит целое» — для этого есть StackedBar, — а «НАСКОЛЬКО
 * целое держится на нескольких первых частях». Это разные выводы, и второй
 * обычной полосой состава не читается: зритель видит пять сегментов и
 * должен сам сложить первые три.
 *
 * Скоба складывает их за него и подписывает результат. Ровно этот приём
 * превращает наблюдение «есть большие и маленькие страницы» в довод
 * «93% трафика висит на трёх адресах».
 *
 * === Почему не круговая диаграмма ===
 *
 * Длины вдоль общей линии человек сравнивает точнее, чем углы секторов.
 * И скобу над сектором пирога поставить некуда: у него нет края, вдоль
 * которого её натянуть.
 */

export interface RibbonItem {
  label: string;
  /** Доля в процентах. Ширина сегмента считается от суммы всех долей */
  value: number;
  /** Второе число в легенде: клики, показы, CTR */
  caption?: string;
}

/**
 * === Про двухуровневую вёрстку ===
 *
 * Сегменты разложены по ДВУМ группам («лидеры» и «хвост»), а не лежат
 * одним рядом, и скоба построена по такой же паре групп. Это не украшение
 * разметки, а единственный способ добиться того, чтобы скоба заканчивалась
 * ровно на границе третьего сегмента.
 *
 * Плоским рядом это не сходится: между сегментами есть просветы, и группа
 * из трёх сегментов шире, чем один элемент той же доли, ровно на два
 * просвета. Скоба промахнулась бы на 8px — при 1680px это заметно.
 * С парой групп обе строки делят ширину по одному и тому же правилу.
 */
export function ShareRibbon({
  items,
  groupCount,
  groupLabel,
  height = 84,
  gap = 4,
}: {
  items: RibbonItem[];
  /** Сколько первых сегментов накрывает скоба */
  groupCount: number;
  /** Подпись над скобой — вывод, а не название группы */
  groupLabel: string;
  height?: number;
  gap?: number;
}) {
  const head = items.slice(0, groupCount);
  const tail = items.slice(groupCount);

  const sum = (list: RibbonItem[]) => list.reduce((acc, i) => acc + i.value, 0);
  const headWeight = sum(head);
  const tailWeight = sum(tail);

  const colorOf = (index: number, inHead: boolean) =>
    inHead ? CHART_SERIES[index % CHART_SERIES.length] : CHART_MUTED;

  return (
    <div className="flex flex-col gap-8">
      {/* ───── Скоба ───── */}
      <div className="flex items-end" style={{ gap }}>
        <div className="flex flex-col items-center gap-3" style={{ flex: `${headWeight} 0 0` }}>
          <span className="text-title-l text-ink text-center">{groupLabel}</span>

          {/*
           * Размерная скоба: линия с двумя засечками вниз, к ленте.
           * Фигурной скобы намеренно нет — она рисуется кривыми, при
           * растяжении на 900px её завиток раздувается и начинает
           * выглядеть декоративным элементом, а не указателем границ.
           *
           * Цвет — третичный текст: 3.27:1, то есть порог WCAG 1.4.11
           * для нетекстовой графики. Токен line (14%) для указателя
           * слишком слаб, он предназначен разделителям.
           */}
          <div className="relative w-full" style={{ height: 18 }} aria-hidden="true">
            <div
              className="bg-ink-tertiary absolute right-0 left-0"
              style={{ top: 0, height: 2 }}
            />
            <div
              className="bg-ink-tertiary absolute left-0"
              style={{ top: 0, width: 2, bottom: 0 }}
            />
            <div
              className="bg-ink-tertiary absolute right-0"
              style={{ top: 0, width: 2, bottom: 0 }}
            />
          </div>
        </div>

        {/* Пустая половина: держит ширину, чтобы скоба кончалась там же,
            где кончается третий сегмент ленты */}
        <div style={{ flex: `${tailWeight} 0 0` }} />
      </div>

      {/* ───── Лента ───── */}
      <div className="flex" style={{ height, gap }}>
        <div className="flex" style={{ flex: `${headWeight} 0 0`, gap }}>
          {head.map((item, i) => (
            <div
              key={item.label}
              style={{
                flex: `${item.value} 0 0`,
                background: colorOf(i, true),
                /* Скругление только у крайних сегментов ленты: внутренние
                   края остаются прямыми, иначе полоса рассыпается на плитки */
                borderRadius: i === 0 ? "10px 0 0 10px" : 0,
              }}
            />
          ))}
        </div>

        <div className="flex" style={{ flex: `${tailWeight} 0 0`, gap }}>
          {tail.map((item, i) => (
            <div
              key={item.label}
              style={{
                flex: `${item.value} 0 0`,
                background: colorOf(i, false),
                borderRadius: i === tail.length - 1 ? "0 10px 10px 0" : 0,
              }}
            />
          ))}
        </div>
      </div>

      {/* ───── Легенда ───── */}
      {/*
       * Легенда обязательна: цвет не должен быть единственным носителем
       * смысла, а по ширине сегмента долю точно не восстановить. Доля
       * подписана числом у каждой строки.
       */}
      <div className="flex flex-col">
        {items.map((item, i) => {
          const inHead = i < groupCount;
          return (
            <div
              key={item.label}
              className={`flex items-center gap-6 py-4 ${i ? "border-line border-t" : ""}`}
            >
              <span
                className="shrink-0 rounded-full"
                style={{
                  width: 20,
                  height: 20,
                  background: colorOf(inHead ? i : i - groupCount, inHead),
                }}
              />
              <span
                className={`text-body-l min-w-0 flex-1 ${inHead ? "text-ink" : "text-ink-secondary"}`}
              >
                {item.label}
              </span>
              {item.caption ? (
                <span className="text-body-m text-ink-secondary shrink-0 tabular-nums">
                  {item.caption}
                </span>
              ) : null}
              <span
                className={`text-title-m shrink-0 text-right tabular-nums ${inHead ? "text-ink" : "text-ink-secondary"}`}
                style={{ width: 120 }}
              >
                {item.value.toLocaleString("ru-RU")}%
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
