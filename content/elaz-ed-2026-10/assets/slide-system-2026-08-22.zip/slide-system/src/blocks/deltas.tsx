import type { ReactNode } from "react";
import { ArrowRight } from "@solar-icons/react";
import { CHART_SERIES } from "../lib/chartPalette";

/**
 * Изменение показателя: три формы под три разных вопроса.
 *
 *   DivergingBars — два показателя РАЗОШЛИСЬ. Один вверх, другой вниз
 *                   от общей нулевой линии. Форма и есть вывод слайда
 *   TransitionRows — «было → стало». Когда важна не величина изменения,
 *                   а то, что значение перешло в другое состояние
 *   SplitVerdict  — у ОДНОЙ сущности две противоположные оценки:
 *                   по одному признаку хорошо, по другому плохо
 *
 * === Чего здесь нет ===
 *
 * Второй оси Y. Все три формы показывают величины ОДНОЙ природы: проценты
 * с процентами, значения показателя с значениями того же показателя.
 * Как только рядом просятся две разные единицы — это два блока, а не один
 * с двумя шкалами.
 */

/* ═══════════════  Расхождение  ═══════════════ */

export interface DivergingItem {
  /** Название показателя */
  label: string;
  /** Абсолютное значение за период: «4 618» */
  value: string;
  /** Изменение в процентах. Знак задаёт сторону: плюс вверх, минус вниз */
  delta: number;
  /** Уточнение под подписью: период, источник */
  note?: string;
}

/**
 * Столбики в разные стороны от общей нулевой линии.
 *
 * === Зачем отдельная форма, если есть BarChart ===
 *
 * Обычный столбчатый график ставит все столбцы на одну базу и показывает,
 * что одно больше другого. Здесь смысл другой: показатели разошлись
 * в РАЗНЫЕ СТОРОНЫ, и это единственное, что нужно унести со слайда.
 * Нулевая линия посередине делает вывод формой, а не подписью.
 *
 * === Про честный масштаб ===
 *
 * Высота считается от НАИБОЛЬШЕГО по модулю изменения, а не нормируется
 * по каждому столбцу отдельно. Поэтому −7,8% рядом с +55,9% выглядит
 * действительно маленьким — и это правда: клики выросли сильно, показы
 * просели чуть-чуть.
 *
 * Соблазн «подтянуть» короткий столбец ради выразительности здесь
 * недопустим: масштаб, подобранный под вывод, — это способ нарисовать
 * любой вывод, и на клиентской презентации это прямой обман.
 */
export function DivergingBars({
  items,
  height = 420,
  formatDelta = (d: number) => `${d > 0 ? "+" : "−"}${Math.abs(d).toString().replace(".", ",")}%`,
}: {
  items: DivergingItem[];
  height?: number;
  formatDelta?: (delta: number) => string;
}) {
  const half = Math.round(height / 2);
  const max = Math.max(...items.map((i) => Math.abs(i.delta))) || 1;

  /*
   * Место под подпись изменения у вершины столбца. 52px — строка headline-s
   * (кегль 36, межстрочный 40) плюс просвет 12. Без резерва подпись самого
   * высокого столбца упирается в край блока и обрезается.
   */
  const labelRoom = 52;
  const barRoom = half - labelRoom;

  return (
    <div className="flex flex-col gap-8">
      <div className="relative flex gap-6" style={{ height }}>
        {/*
         * Нулевая линия — сплошная и через всю ширину, а не отрезок под
         * каждым столбцом. Разорванная база перестаёт читаться как общий
         * ноль, и столбцы превращаются в два независимых показателя.
         */}
        <div
          className="bg-line absolute right-0 left-0"
          style={{ top: half - 1, height: 2 }}
          aria-hidden="true"
        />

        {items.map((item, i) => {
          const up = item.delta > 0;
          const barHeight = Math.round((Math.abs(item.delta) / max) * barRoom);
          const color = CHART_SERIES[i % CHART_SERIES.length];

          return (
            <div key={item.label} className="relative flex flex-1 flex-col">
              {/* Верхняя половина: содержимое прижато к нулевой линии снизу */}
              <div className="flex flex-col items-center justify-end" style={{ height: half }}>
                {up ? (
                  <>
                    <span className="text-headline-s text-ink mb-3 tabular-nums">
                      {formatDelta(item.delta)}
                    </span>
                    <span
                      style={{
                        width: "56%",
                        maxWidth: 220,
                        height: barHeight,
                        /* Скругление только у вершины: основание стоит
                           на нулевой линии, круглый низ оторвал бы его от неё */
                        borderRadius: "10px 10px 0 0",
                        background: color,
                      }}
                    />
                  </>
                ) : null}
              </div>

              {/* Нижняя половина: содержимое растёт от нулевой линии вниз */}
              <div className="flex flex-col items-center" style={{ height: half }}>
                {!up ? (
                  <>
                    <span
                      style={{
                        width: "56%",
                        maxWidth: 220,
                        height: barHeight,
                        borderRadius: "0 0 10px 10px",
                        background: color,
                      }}
                    />
                    <span className="text-headline-s text-ink mt-3 tabular-nums">
                      {formatDelta(item.delta)}
                    </span>
                  </>
                ) : null}
              </div>
            </div>
          );
        })}
      </div>

      {/*
       * Подписи вынесены под график отдельным рядом, а не поставлены у
       * столбцов. Причина: столбцы стоят по разные стороны нулевой линии,
       * и подпись у каждого оказалась бы на своей высоте — ряд выглядел бы
       * разъехавшимся. Общая строка внизу возвращает им общую базу.
       */}
      <div className="flex gap-6">
        {items.map((item) => (
          <div key={item.label} className="flex flex-1 flex-col items-center gap-1 text-center">
            <span className="text-title-l text-ink">{item.label}</span>
            <span className="text-body-l text-ink-secondary tabular-nums">{item.value}</span>
            {item.note ? <span className="text-body-m text-ink-secondary">{item.note}</span> : null}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════  Было → стало  ═══════════════ */

export interface TransitionItem {
  label: string;
  from: string;
  to: string;
  /** Чем это изменение объясняется */
  note?: string;
}

/**
 * Строки «было → стало».
 *
 * === Почему не две колонки таблицы ===
 *
 * Таблица «Показатель | Было | Стало» заставляет читать три ячейки и
 * самому связать вторую с третьей. Стрелка между значениями делает связь
 * формой: пара читается за один взгляд, а не собирается в голове.
 *
 * === Про цвет старого значения ===
 *
 * «Было» набрано третичным цветом, и это разрешено ровно потому, что кегль
 * здесь headline-m (44px): третичный в светлой теме даёт 3.27:1 и допустим
 * только от 24px. На мелком кегле такая же пара потребовала бы вторичного —
 * иерархию тогда держал бы размер, а не цвет.
 */
export function TransitionRows({
  items,
  labelWidth = 340,
}: {
  items: TransitionItem[];
  labelWidth?: number;
}) {
  return (
    <div className="flex flex-col">
      {items.map((item, i) => (
        <div
          key={item.label}
          className={`flex items-center gap-8 py-8 ${i ? "border-line border-t" : ""}`}
        >
          <span className="text-title-l text-ink shrink-0" style={{ width: labelWidth }}>
            {item.label}
          </span>

          <span className="text-headline-m text-ink-tertiary shrink-0 tabular-nums">
            {item.from}
          </span>

          <ArrowRight size={44} weight="Linear" color="var(--t-ink-tertiary)" />

          <span className="text-headline-m text-ink shrink-0 tabular-nums">{item.to}</span>

          {item.note ? (
            <span className="text-body-l text-ink-secondary min-w-0 flex-1 text-right">
              {item.note}
            </span>
          ) : null}
        </div>
      ))}
    </div>
  );
}

/* ═══════════════  Две оценки одной сущности  ═══════════════ */

export interface VerdictSide {
  /** Короткая метка стороны: «Спрос есть», «Клик не случается» */
  caption: string;
  value: string;
  note: ReactNode;
}

/**
 * Одна сущность, две противоположные оценки.
 *
 * Нужна там, где вывод слайда — противоречие: позиция хорошая, а кликов
 * нет. Два отдельных числа рядом такое противоречие не показывают, их
 * читают как два независимых факта. Общая рамка и общий заголовок делают
 * из них одно наблюдение.
 *
 * === Про заливки ===
 *
 * Стороны различаются статусной заливкой, а не только текстом: с четырёх
 * метров цвет половины читается раньше, чем подпись. Заливка при этом
 * очень слабая (14–18% краски), поэтому основной текст на ней остаётся
 * тем же токеном text-ink и контраст не падает.
 */
export function SplitVerdict({
  title,
  good,
  bad,
}: {
  title?: ReactNode;
  good: VerdictSide;
  bad: VerdictSide;
}) {
  return (
    <div className="flex flex-col gap-6">
      {title ? <p className="text-title-l text-ink">{title}</p> : null}

      <div className="rounded-panel border-line grid grid-cols-2 overflow-hidden border">
        <Half side={good} tone="good" />
        {/* Разделитель — левая граница правой половины, а не отдельный
            элемент: так он гарантированно во всю высоту обеих сторон */}
        <Half side={bad} tone="bad" divided />
      </div>
    </div>
  );
}

function Half({
  side,
  tone,
  divided = false,
}: {
  side: VerdictSide;
  tone: "good" | "bad";
  divided?: boolean;
}) {
  /* Классы полными литералами: Tailwind сканирует исходники как текст
     и собранных из кусков имён не видит */
  const fill = tone === "good" ? "bg-success-fill" : "bg-error-fill";
  const captionColor = tone === "good" ? "text-success-fg" : "text-error-fg";

  return (
    <div className={`flex flex-col gap-4 p-10 ${fill} ${divided ? "border-line border-l" : ""}`}>
      <span className={`text-label ${captionColor}`}>{side.caption}</span>
      <span className="text-display-s text-ink tabular-nums">{side.value}</span>
      <span className="text-body-l text-ink-secondary">{side.note}</span>
    </div>
  );
}
