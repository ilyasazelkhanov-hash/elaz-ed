import { AltArrowRight } from "@solar-icons/react";

/**
 * Сетка соответствий и нумерованный стандарт.
 *
 *   ClusterGrid — «этому запросу отвечает эта страница». Карточка на пару
 *   SpecList    — пронумерованный перечень требований в две колонки
 */

/* ═══════════════  Кластер → страница  ═══════════════ */

export interface ClusterItem {
  /** Название кластера */
  name: string;
  /** Пример интента: как человек ищет */
  intent: string;
  /** Тип страницы, которая должна этот интент закрывать */
  page: string;
}

/**
 * Карта «кластер запросов → основная страница».
 *
 * === Зачем карточками, а не таблицей на три колонки ===
 *
 * Содержание карты — не восемь строк, а восемь ПАР: у каждого кластера
 * ровно одна страница-владелец. Именно единственность владельца лечит
 * каннибализацию, о которой говорит предыдущий раздел, и её надо показать.
 *
 * В таблице третья колонка выглядит как ещё одно свойство строки.
 * В карточке она отделена чертой и стрелкой — то есть прочитывается как
 * вывод из первых двух, а не как их сосед.
 *
 * === Про равную высоту ===
 *
 * Сетка идёт с items-stretch (значение по умолчанию), и карточки в ряду
 * равняются по самой высокой. Разновысокие карточки в ряду читаются как
 * ошибка вёрстки, даже когда текста в них правда разное количество.
 */
export function ClusterGrid({ items, columns = 4 }: { items: ClusterItem[]; columns?: 3 | 4 }) {
  /* Классы полными литералами — Tailwind не видит собранных из кусков имён */
  const cols = columns === 3 ? "grid-cols-3" : "grid-cols-4";

  return (
    <div className={`grid gap-6 ${cols}`}>
      {items.map((item) => (
        <div key={item.name} className="bg-surface rounded-card flex flex-col gap-4 p-7">
          <span className="text-title-l text-ink">{item.name}</span>

          {/*
           * Пример запроса набран как есть, без кавычек и без курсива.
           * Кавычки на слайде добавляют шум в каждую карточку, а курсив
           * в этой типографике не заведён: в системе два начертания
           * и ни одного наклонного.
           *
           * flex-1 прижимает нижнюю пару к низу карточки — при разной
           * длине примера строки «страница» у всех карточек ряда встают
           * на одну линию.
           */}
          <span className="text-body-m text-ink-secondary flex-1">{item.intent}</span>

          <span className="border-line flex items-center gap-3 border-t pt-4">
            <AltArrowRight size={22} weight="Linear" color="var(--t-ink-tertiary)" />
            <span className="text-body-m text-ink min-w-0">{item.page}</span>
          </span>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════  Нумерованный стандарт  ═══════════════ */

/**
 * Перечень требований в две колонки с сквозной нумерацией.
 *
 * === Почему нумерация, а не галочки ===
 *
 * Галочка означает «выполнено» и на списке требований к БУДУЩЕЙ странице
 * врёт: ничего из этого ещё не сделано. Номер нейтрален и вдобавок даёт
 * то, чего у галочек нет, — возможность сослаться на пункт в переписке
 * («по пункту 4 вопрос»).
 *
 * === Про порядок колонок ===
 *
 * Нумерация идёт СВЕРХУ ВНИЗ по колонкам: 1–4 в левой, 5–8 в правой.
 * Змейкой (1–2 в первой строке, 3–4 во второй) список читался бы поперёк,
 * и на восьми пунктах глаз сбивается уже на третьем.
 */
export function SpecList({ items, columns = 2 }: { items: string[]; columns?: 2 | 3 }) {
  const cols = columns === 3 ? "grid-cols-3" : "grid-cols-2";
  const perColumn = Math.ceil(items.length / columns);

  const chunks = Array.from({ length: columns }, (_, c) =>
    items.slice(c * perColumn, (c + 1) * perColumn).map((text, i) => ({
      text,
      no: c * perColumn + i + 1,
    })),
  );

  return (
    <div className={`grid gap-x-12 ${cols}`}>
      {chunks.map((chunk, c) => (
        <ol key={c} className="flex flex-col">
          {chunk.map((item, i) => (
            <li
              key={item.no}
              className={`flex items-start gap-5 py-5 ${i ? "border-line border-t" : ""}`}
            >
              <span
                className="bg-fill text-ink text-label rounded-capsule grid shrink-0 place-items-center tabular-nums"
                style={{ width: 44, height: 44 }}
              >
                {item.no}
              </span>
              {/*
               * pt-2 ставит текст на оптический центр кружка: кружок
               * высотой 44, строка body-l высотой 32, разница пополам — 6.
               * Ближайший шаг сетки 4px — это pt-2 (8px), и на глаз
               * он точнее, чем pt-1: строка выше своей середины из-за
               * места под нижние выносные элементы шрифта.
               */}
              <span className="text-body-l text-ink min-w-0 pt-2">{item.text}</span>
            </li>
          ))}
        </ol>
      ))}
    </div>
  );
}
