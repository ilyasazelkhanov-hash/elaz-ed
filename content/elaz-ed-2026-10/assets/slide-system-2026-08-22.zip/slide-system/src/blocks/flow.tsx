import type { ReactNode } from "react";
import { CHART_EMPHASIS } from "../lib/chartPalette";

/**
 * Схема склейки: две страницы, конкурирующие за один запрос, сводятся
 * в одну основную.
 *
 * === Зачем схема, если есть таблица ===
 *
 * Каннибализация — это отношение между страницами, а не свойство каждой
 * из них. Таблица «Тема | Страница | Интент | Клики» показывает четыре
 * независимые строки, и то, что вторая строка отбирает трафик у первой,
 * зрителю приходится вывести самому.
 *
 * Схема показывает отношение формой: две ветки сходятся в одну. Решение
 * («оставить /site, перенаправить /blog») перестаёт быть текстом
 * рекомендации и становится картинкой.
 *
 * === Про направление ===
 *
 * Ветки сходятся СЛЕВА НАПРАВО, к результату. Обратное направление —
 * от одной страницы к двум — читалось бы как разделение, то есть ровно
 * как противоположная рекомендация.
 */

/* Геометрия рейки. Числа связаны между собой, поэтому лежат рядом:
   высота рейки выводится из высоты строк и просвета, а не задаётся
   отдельно — иначе кривые перестанут попадать в центры строк. */
const ROW_H = 92;
const ROW_GAP = 14;
const RAIL_W = 104;
const RAIL_H = ROW_H * 2 + ROW_GAP;

export interface FlowBranch {
  /** Адрес страницы */
  url: string;
  /** Что она даёт сейчас: клики, показы */
  result: string;
}

export interface FlowPair {
  /** Тема, за которую конкурируют страницы */
  topic: string;
  /** Пересекающийся интент */
  intent: string;
  /** Страница, которая остаётся основной */
  keep: FlowBranch;
  /** Страница, которую объединяют или перенаправляют */
  merge: FlowBranch;
  /** Что получается в итоге */
  outcome: ReactNode;
}

/**
 * Рейка со сходящимися ветками.
 *
 * Кривые Безье, а не ломаные под прямым углом: прямой угол на схеме
 * читается как «здесь развилка, можно свернуть», а плавное схождение —
 * как слияние. Обе ветки приходят в одну точку, из неё выходит одна
 * линия со стрелкой.
 */
function MergeRail() {
  const y1 = ROW_H / 2;
  const y2 = ROW_H + ROW_GAP + ROW_H / 2;
  const mid = RAIL_H / 2;
  const join = 62;
  const tip = RAIL_W - 6;

  return (
    <svg
      width={RAIL_W}
      height={RAIL_H}
      viewBox={`0 0 ${RAIL_W} ${RAIL_H}`}
      className="shrink-0"
      aria-hidden="true"
    >
      {/* Ветка страницы, которая остаётся: в акцентном цвете — по ней
          пойдёт весь трафик темы */}
      <path
        d={`M 0 ${y1} C ${join * 0.5} ${y1}, ${join * 0.4} ${mid}, ${join} ${mid}`}
        fill="none"
        stroke={CHART_EMPHASIS}
        strokeWidth={4}
      />
      {/* Ветка, которую сводят: приглушена и пунктиром — она перестаёт
          существовать как отдельная страница */}
      <path
        d={`M 0 ${y2} C ${join * 0.5} ${y2}, ${join * 0.4} ${mid}, ${join} ${mid}`}
        fill="none"
        stroke="var(--t-ink-tertiary)"
        strokeWidth={4}
        strokeDasharray="10 8"
      />
      <line x1={join} x2={tip - 14} y1={mid} y2={mid} stroke={CHART_EMPHASIS} strokeWidth={4} />
      <path
        d={`M ${tip} ${mid} L ${tip - 16} ${mid - 10} L ${tip - 16} ${mid + 10} Z`}
        fill={CHART_EMPHASIS}
      />
    </svg>
  );
}

function Branch({ branch, kept }: { branch: FlowBranch; kept: boolean }) {
  return (
    <div
      className={`rounded-card flex flex-col justify-center px-7 ${
        kept ? "bg-surface" : "border-line border border-dashed"
      }`}
      style={{ height: ROW_H }}
    >
      <span className={`text-body-l ${kept ? "text-ink" : "text-ink-secondary"}`}>
        {branch.url}
      </span>
      <span className="text-body-m text-ink-secondary mt-1 tabular-nums">{branch.result}</span>
    </div>
  );
}

export function MergeFlow({ pairs }: { pairs: FlowPair[] }) {
  return (
    <div className="flex flex-col gap-6">
      {pairs.map((pair) => (
        <div key={pair.topic} className="border-line rounded-panel border p-7">
          <div className="mb-5 flex items-baseline gap-5">
            <span className="text-title-l text-ink">{pair.topic}</span>
            <span className="text-body-m text-ink-secondary">{pair.intent}</span>
          </div>

          <div className="flex items-center gap-5">
            <div className="flex min-w-0 flex-1 flex-col" style={{ gap: ROW_GAP }}>
              <Branch branch={pair.keep} kept />
              <Branch branch={pair.merge} kept={false} />
            </div>

            <MergeRail />

            {/*
             * Итог берёт фиксированную долю ширины, а не flex-1: иначе при
             * длинном адресе в левой колонке он сжимался бы до одной буквы
             * в строке. Схема должна выглядеть одинаково для всех пар.
             */}
            <div
              className="rounded-card bg-fill flex flex-col justify-center px-7"
              style={{ height: ROW_H, width: 420 }}
            >
              <span className="text-body-l text-ink">{pair.outcome}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
