import { useEffect, useState } from "react";

import { CHART_EMPHASIS, CHART_SERIES_SCATTER } from "../lib/chartPalette";

/**
 * Точечная и пузырьковая диаграмма — ScatterChart.
 *
 * Перенос приёма «Scatter Chart» из донорского админского дашборда
 * («Correlation dots, bubbles when sized», пример «Revenue per account»).
 *
 * === Зачем эта форма нужна, если в системе уже есть пять графиков ===
 *
 * Все действующие формы проекта отвечают на вопрос об ОДНОЙ величине:
 * столбики и `HBarChart` — «кто больше», линия — «как менялось», стопка и
 * лента — «из чего состоит», воронка — «где отваливается». Вопрос «связаны
 * ли ДВА показателя между собой» ни одна из них не берёт: чтобы увидеть
 * связь, надо положить показатели на две оси и посмотреть на форму облака.
 *
 * Типичные вопросы клиентского слайда, на которые отвечает только эта форма:
 *
 *   · крупные клиенты приносят пропорционально больше — или дают скидку?
 *   · дорогие каналы окупаются — или платим за объём без качества?
 *   · длинные страницы держат внимание — или связи нет вовсе?
 *
 * === Оси здесь ОБЯЗАТЕЛЬНЫ, и это исключение из правила системы ===
 *
 * В [`dataviz.md`](../../.claude/rules/dataviz.md) записано: подписи вместо
 * осей, ось Y на слайде не рисуется. Правило верное для столбиков — там
 * каждая величина подписана числом у своего столбца, и ось дублировала бы
 * подписи.
 *
 * Здесь оно не работает. У точки нет собственной длины: её значение — это
 * ПОЛОЖЕНИЕ, а положение измеряется только относительно шкалы. Точечная
 * диаграмма без осей — это набор кружков, и подписать каждый двумя числами
 * значит закрыть подписями весь график: двадцать точек дают сорок чисел.
 *
 * Поэтому: сетка есть, деления подписаны, обе оси названы.
 *
 * === Ноль в основании: здесь его НЕ требуют ===
 *
 * У столбиков и линии обрезанный низ запрещён (см. `LineChart`): длина
 * столбца кодирует величину, и обрезав основание, мы преувеличиваем
 * разницу. У точки длины нет — сравниваются РАССТОЯНИЯ между точками,
 * а они от положения нуля не зависят. Требование нуля здесь сожрало бы
 * весь график: показатели вроде «конверсия 3,1–4,4%» превратились бы
 * в горизонтальную полоску у самого края.
 *
 * Поэтому границы считаются от данных и округляются до красивого шага,
 * а честность держится на подписанных делениях: читатель видит, что шкала
 * начинается не с нуля, потому что там написано число.
 *
 * === Пузырьки: величина кодируется ПЛОЩАДЬЮ ===
 *
 * Радиус пропорциональным величине делать нельзя. Площадь круга растёт
 * как квадрат радиуса: при r ∝ v вдвое большее значение занимает вчетверо
 * большее пятно, и глаз, который читает именно пятно, завышает разницу
 * в квадрате. Ровно за это в системе уже отвергнута трапеция воронки
 * (см. [`stages.tsx`](./stages.tsx)) и круговая диаграмма.
 *
 * Формула — в `bubbleRadius` ниже.
 *
 * === Чего здесь нет ===
 *
 * · Линии тренда. Она превращает наблюдение «облако вытянуто» в утверждение
 *   «зависимость такая-то», а коэффициент при этом не показан и не проверен.
 *   Если связь есть и она посчитана — это `guides` плюс текст на слайде,
 *   а не подрисованная прямая.
 * · Второй оси Y — по общему запрету системы.
 * · Наведения с всплывающей подсказкой: выдача в PDF, наведения там нет,
 *   поэтому всё, что нужно прочитать, подписано на самом графике.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface ScatterPoint {
  /** Подпись точки: клиент, канал, страница */
  label: string;
  x: number;
  y: number;
  /**
   * Третья величина — размер пузырька. Кодируется ПЛОЩАДЬЮ, см. `bubbleRadius`.
   *
   * Либо задана у ВСЕХ точек, либо ни у одной: график с половиной пузырьков
   * и половиной точек читается как ошибка данных. Смешение ловится
   * предупреждением в разработке.
   */
  size?: number;
}

export interface ScatterSeries {
  key: string;
  /** Имя ряда для легенды */
  label: string;
  points: ScatterPoint[];
}

/**
 * Потолок числа рядов — ТРИ, и это не осторожность.
 *
 * На точечной сравниваются ВСЕ пары цветов сразу, а не соседние, как
 * у столбиков. Прогон пятёрки в этом режиме валидатором даёт два провала
 * (зелёный↔оранжевый ΔE 4.8 при протанопии, зелёный↔бирюзовый ΔE 13.8 при
 * нормальном зрении) — подробности в шапке
 * [`chartPalette.ts`](../lib/chartPalette.ts). Поэтому в наборе
 * CHART_SERIES_SCATTER ровно три цвета, и четвёртому ряду взять цвет неоткуда.
 */
const MAX_SERIES = CHART_SERIES_SCATTER.length;

/* ═══════════════  Геометрия  ═══════════════ */

export interface ScatterGeometry {
  width: number;
  height: number;
  padTop: number;
  padBottom: number;
  padLeft: number;
  padRight: number;
}

/*
 * Поля рассчитаны, а не подобраны:
 *
 *   padTop 56    — самый крупный пузырёк (radius 40) на верхней границе
 *                  шкалы выступает вверх на 40; плюс 16 на просвет, чтобы
 *                  он не касался края SVG.
 *   padBottom 76 — строка подписей делений (якорь на +36 от низа поля,
 *                  кегль 20) и под ней название оси X (якорь на +68).
 *   padLeft 140  — подписи делений оси Y с отбивкой 24 от сетки. Это
 *                  МИНИМУМ: если числа шире, поле расширяется (`leftPadFor`).
 *   padRight 56  — просвет для крайнего справа пузырька. Тоже минимум:
 *                  ключ размеров занимает поле справа целиком (`rightPadFor`).
 */
export const DEFAULT_SCATTER_GEOMETRY: ScatterGeometry = {
  width: 1680,
  height: 520,
  padTop: 56,
  padBottom: 76,
  padLeft: 140,
  padRight: 56,
};

/* ═══════════════  Кегли  ═══════════════ */

/*
 * Кегли подписей осей взяты те же, что у линейного графика
 * ([`chartsLine.tsx`](./chartsLine.tsx): AXIS_SIZE 20 / вес 500). Совпадение
 * не косметическое: два графика в одном деке с осями разного кегля читаются
 * как два разных инструмента.
 *
 * 20 — предпоследняя ступень шкалы. Ниже 16 в проекте нельзя вовсе (пол
 * шкалы), а 18 оставлено пилюле: подпись деления читают с той же дистанции,
 * что и текст слайда, и она не должна требовать усилия.
 *
 * Подпись точки крупнее делений и весом 600: это содержание графика,
 * а деление — разметка под ним. Отношение 20/600 к 20/500 — тот же приём,
 * что у прямых подписей рядов в LineChart (22/600 против 20/500), только
 * без прибавки кегля: подписей точек на графике втрое больше, чем рядов,
 * и лишние 2 точки кегля здесь превращаются в потерянные подписи.
 */
const AXIS_SIZE = 20;
const AXIS_WEIGHT = 500;
const TITLE_SIZE = 20;
const TITLE_WEIGHT = 600;
const LABEL_SIZE = 20;
const LABEL_WEIGHT = 600;

/** Отбивка подписей делений оси Y от сетки */
const AXIS_GAP = 24;
/** Просвет до края SVG: вплотную к краю подпись читается как обрезанная */
const EDGE_GAP = 8;

/**
 * Сколько делений на оси.
 *
 * ЧЕТЫРЕ интервала — это ЦЕЛЬ, а не точное число: границы округляются
 * наружу до красивого шага, поэтому на выходе получается 4–7 подписанных
 * линий. Замер по витрине: 6 линий у «Пузырьков» по обеим осям, 5 по X
 * и 5 по Y у «Потолка».
 *
 * Цель считана, а не взята на глаз. При высоте поля 388 (геометрия по
 * умолчанию) пять линий дают шаг 97 точек — подпись кеглем 20 занимает
 * по высоте 25, то есть четверть просвета, и сетка остаётся разметкой.
 * Восемь линий дают шаг 55: подписи начинают читаться сплошным столбцом
 * чисел, а сетка — штриховкой поверх данных. Три линии (два интервала) —
 * обратная беда: положение точки между делениями приходится прикидывать
 * на глаз.
 *
 * По X при ширине поля ~1480 пять делений дают шаг 370 — с запасом больше
 * самой длинной подписи. Число делений там могло быть и больше, но оси
 * с разной плотностью сетки образуют клетку неквадратной формы, и облако
 * точек в ней кажется вытянутым по той оси, где линий реже.
 */
const TICKS = 4;

/* ═══════════════  Круги  ═══════════════ */

/** Радиус простой точки, когда третьей величины нет */
const DOT_R = 10;

/**
 * Кольцо-просвет вокруг простой точки — цветом холста.
 *
 * Тот же приём, что у `IconSquare` в стопке (см. `ui-craft.md`): без него
 * две близкие точки одного ряда слипаются в восьмёрку, и вместо двух
 * наблюдений читается одно.
 *
 * ⚠️ Кольцо цветом ФОНА. Если график стоит не на холсте слайда, а на
 * карточке или приглушённой подложке, цвет надо передать (`ring`), иначе
 * просвет превращается в белую обводку на сером.
 */
const RING = 3;

/**
 * Границы радиуса пузырька.
 *
 * 40 — потолок: пузырёк не должен перекрывать деление сетки целиком,
 * а шаг сетки по вертикали 97. 8 — пол: круг меньше 16 точек в поперечнике
 * с трёх метров перестаёт отличаться от точки.
 *
 * Отношение площадей 25:1 — это и есть весь запас различимости. Данные
 * с разбросом больше (крупнейший клиент в сто раз больше мелкого) этой
 * формой не показываются: см. предупреждение о полу в `bubbleRadius`.
 */
const BUBBLE_MIN = 8;
const BUBBLE_MAX = 40;

/**
 * Прозрачность заливки пузырька — одна на обе темы, и это осознанно.
 *
 * Заливка полупрозрачна, чтобы наложенные пузырьки читались как два, а не
 * как один силуэт. Но носителем ФОРМЫ она при этом не является — форму
 * держит контур в полную силу цвета. Замер (порог WCAG 1.4.11 для
 * нетекстовой графики — 3:1):
 *
 *   контур, светлая тема   синий 3.52 · оранжевый 3.19 · бирюзовый 3.80
 *   контур, тёмная тема    синий 5.36 · оранжевый 5.92 · бирюзовый 4.96
 *
 *   заливка 0.62 к холсту  светлая 2.19 / 2.02 / 2.24
 *                          тёмная  2.73 / 2.96 / 2.60
 *
 * Ни одна заливка не дотягивает до 3:1 ни при какой прозрачности: даже
 * 0.8 даёт в светлой теме максимум 2.88. Это не дефект — это причина,
 * по которой контур обязателен, а не украшение. И это же причина, по
 * которой прозрачность НЕ разведена по темам, в отличие от коридора
 * прогноза (`BAND_OPACITY` в chartsLine.tsx): там заливка была
 * единственным носителем, здесь она вспомогательная.
 */
const BUBBLE_FILL_OPACITY = 0.62;
const BUBBLE_STROKE = 3;

/* ═══════════════  Замер ширины текста  ═══════════════ */

/*
 * === Почему копия, а не общий модуль ===
 *
 * Тот же замер уже написан в [`chartsLine.tsx`](./chartsLine.tsx), но
 * не экспортирован. Вынести его в общий модуль — правильная правка, только
 * она трогает файл действующих графиков, а он выверен на сданных деках.
 * Поэтому здесь копия, а вынос — отдельной задачей.
 *
 * === Почему вообще мерить ===
 *
 * Ширина подписи нужна ДО отрисовки: от неё зависит, куда поставить подпись
 * точки, чтобы она не легла на соседнюю. Прикидка «знаков × кегль» не
 * годится: разброс ширины знака по замеру — от 0.27 до 0.70 кегля.
 */

/** Запасной коэффициент, когда DOM недоступен (сборка вне браузера) */
const FALLBACK_RATIO = 0.62;

const measureCache = new Map<string, number>();
let measureCtx: CanvasRenderingContext2D | null | undefined;

function fontStack() {
  const token = getComputedStyle(document.documentElement).getPropertyValue("--font-app").trim();
  return token || "sans-serif";
}

function textWidth(text: string, size: number, weight: number) {
  const key = `${weight} ${size} ${text}`;
  const cached = measureCache.get(key);
  if (cached !== undefined) return cached;

  if (measureCtx === undefined) {
    measureCtx =
      typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  }

  let width: number;
  if (measureCtx) {
    measureCtx.font = `${weight} ${size}px ${fontStack()}`;
    width = measureCtx.measureText(text).width;
  } else {
    width = text.length * size * FALLBACK_RATIO;
  }

  measureCache.set(key, width);
  return width;
}

let fontsSettled = false;

/**
 * Перерисовка после загрузки шрифта.
 *
 * До загрузки Google Sans `measureText` отвечает по запасному шрифту, и
 * раскладка подписей считается по чужим метрикам. Для экрана это неважно —
 * кадров много; выгрузка в PDF снимает РОВНО ОДИН кадр сразу после
 * `document.fonts.ready`, и без пересчёта в него попала бы раскладка,
 * посчитанная по Arial.
 */
function useRemeasureOnFont() {
  const [, remeasured] = useState(0);

  useEffect(() => {
    if (fontsSettled) return;
    let alive = true;
    void document.fonts?.ready.then(() => {
      if (!alive) return;
      fontsSettled = true;
      measureCache.clear();
      remeasured((n) => n + 1);
    });
    return () => {
      alive = false;
    };
  }, []);
}

/* ═══════════════  Шкалы  ═══════════════ */

/**
 * Красивый шаг сетки: 1 · 2 · 2.5 · 5 на нужном порядке.
 *
 * ⚠️ Лестница НЕ та же, что у линейного графика: в
 * [`chartsLine.tsx`](./chartsLine.tsx) ступени 1 · 2 · 5 · 10, без 2.5.
 * Расхождение намеренное, и вот его причина.
 *
 * У линии нижняя граница шкалы всегда ноль, округляется только верх, и шаг
 * покрупнее просто добавляет немного воздуха сверху. Здесь округляются ОБЕ
 * границы и по ОБЕИМ осям, поэтому промах шага бьёт вчетверо. Замер на
 * витрине «Потолок» до правки: данные 1 200…9 400, шаг вышел 5 000, границы
 * 0…10 000 — три линии сетки на всю ширину и пустая треть поля справа,
 * в которую сжалось облако точек. С 2.5 в лестнице шаг 2 500 даёт пять
 * линий на тех же данных.
 *
 * 2.5 — не самодеятельность: та же ступень стоит в лестнице `d3.ticks`,
 * там она вводится ровно из тех же соображений.
 */
function niceStep(range: number, targetLines: number) {
  const raw = range / targetLines;
  const magnitude = 10 ** Math.floor(Math.log10(raw));
  const normalized = raw / magnitude;
  const step =
    normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 2.5 ? 2.5 : normalized <= 5 ? 5 : 10;
  return step * magnitude;
}

export interface ScatterDomain {
  lo: number;
  hi: number;
  step: number;
}

/**
 * Границы шкалы по данным, округлённые до красивого шага.
 *
 * Вырожденный случай — все значения совпали (одна точка либо ряд с одним
 * и тем же X) — разводится искусственно на ±10%: иначе диапазон нулевой,
 * `niceStep` уходит в логарифм нуля, и весь график превращается в NaN.
 * Точка при этом встаёт по центру шкалы, что для единственного наблюдения
 * и верно.
 */
function niceDomain(min: number, max: number, ticks: number): ScatterDomain {
  let lo = min;
  let hi = max;
  if (!(hi > lo)) {
    const pad = Math.abs(hi) * 0.1 || 1;
    lo = hi - pad;
    hi = hi + pad;
  }
  const step = niceStep(hi - lo, ticks);
  return { lo: Math.floor(lo / step) * step, hi: Math.ceil(hi / step) * step, step };
}

function tickValues({ lo, hi, step }: ScatterDomain) {
  const count = Math.round((hi - lo) / step) + 1;
  /*
   * Значение считается умножением, а не накоплением суммы: складывая шаг
   * 0.1 десять раз, получаем 0.9999999999999999, и подпись деления
   * превращается в «1,0000000000000002».
   */
  return Array.from({ length: count }, (_, i) => lo + i * step);
}

/**
 * Радиус пузырька по величине.
 *
 *   r(v) = R_MAX · √(v / v_max),  но не меньше R_MIN
 *
 * Корень здесь — не сглаживание, а единственный способ не соврать. Глаз
 * читает ПЯТНО, то есть площадь: S = π·r². Если положить радиус
 * пропорциональным величине (r ∝ v), то площадь пойдёт как квадрат:
 * вдвое большее значение займёт вчетверо большее пятно, втрое большее —
 * вдевятеро. Корень возвращает пропорцию площади самой величине:
 *
 *   S(v) / S(v_max) = π·r(v)² / π·R_MAX² = v / v_max
 *
 * Отсчёт ведётся от НУЛЯ, а не от наименьшего значения в наборе. Растянуть
 * шкалу радиусов между min и max набора выглядит нагляднее, но тогда
 * площадь перестаёт быть долей: клиент с выручкой 0,4 млн и клиент
 * с 0,8 млн получили бы пятна, отличающиеся не вдвое, а на сколько
 * получится. Для положения точки нулевое основание не требуется (см. шапку
 * файла), для площади — обязательно: у площади нет «расстояний между»,
 * она читается только как доля целого.
 *
 * ⚠️ Пол R_MIN пропорцию нарушает: пятно точки, попавшей под пол, больше
 * своей доли. Это осознанный размен на различимость, и он ловится
 * предупреждением — если под пол ушла заметная часть набора, разброс
 * данных для пузырьков слишком велик и показывать их надо иначе.
 */
function bubbleRadius(value: number, maxValue: number) {
  if (!(maxValue > 0)) return BUBBLE_MIN;
  return Math.max(BUBBLE_MIN, BUBBLE_MAX * Math.sqrt(Math.max(0, value) / maxValue));
}

/* ═══════════════  Раскладка подписей  ═══════════════ */

/**
 * Бокс подписи относительно её якоря по вертикали.
 *
 * Замер в 1:1 на витрине «Блоки/Точечная диаграмма → Пузырьки», подпись
 * «Поиск» кеглем 20 с `dominantBaseline="middle"`: якорь на 3182.1, бокс
 * 3167.7…3192.7. То есть верх на 14.4px выше якоря, низ на 10.6px ниже,
 * высота бокса 25. Асимметрия нормальна: бокс строки считается от метрик
 * шрифта, а не от чернил конкретного слова.
 *
 * Константы округлены ВВЕРХ (15 и 11): бокс, посчитанный меньше настоящего,
 * пропустил бы наложение на пару точек, а лишняя точка просвета не стоит
 * ничего.
 */
const LABEL_UP = 15;
const LABEL_DOWN = 11;

/** Просвет между краем круга и подписью */
const LABEL_GAP = 10;
/** Просвет между двумя подписями: меньше — читаются как одна строка */
const LABEL_CLEAR = 8;

interface Box {
  left: number;
  right: number;
  top: number;
  bottom: number;
}

function hits(a: Box, b: Box, gap: number) {
  return (
    a.left - gap < b.right &&
    b.left - gap < a.right &&
    a.top - gap < b.bottom &&
    b.top - gap < a.bottom
  );
}

function inside(a: Box, bounds: Box) {
  return (
    a.left >= bounds.left &&
    a.right <= bounds.right &&
    a.top >= bounds.top &&
    a.bottom <= bounds.bottom
  );
}

interface Mark {
  cx: number;
  cy: number;
  r: number;
  text: string;
}

export interface LabelPlacement {
  x: number;
  y: number;
  anchor: "start" | "end" | "middle";
}

/**
 * Куда поставить подпись каждой точки.
 *
 * === Почему это не «просто справа от точки» ===
 *
 * Подпись хочет стоять справа от своего круга. Но на точечной диаграмме
 * точки лежат где угодно, в том числе вплотную: подпись, поставленная без
 * проверки, ложится на соседнюю подпись или на чужой пузырёк. Первое даёт
 * кашу из двух слов, второе — тёмный текст на цветной заливке, то есть
 * ещё и провал контраста, который замер в браузере не покажет, потому
 * что цвет фона у текста при этом формально остаётся холстом.
 *
 * Та же задача уже решена в `LineChart` (`stackLabels`, `axisIndices`
 * в [`chartsLine.tsx`](./chartsLine.tsx)), но другим способом, и разница
 * не в реализации, а в постановке. Там подписи стоят СТОЛБЦОМ у правого
 * края: свободна одна степень свободы — высота, — поэтому годится
 * расталкивание вниз с выноской обратно к линии. Здесь свободны обе
 * координаты и занято всё поле, поэтому расталкивать некуда: подпись
 * либо находит свободное место рядом со своей точкой, либо не ставится.
 *
 * === Порядок ===
 *
 * 1. Точки обходятся от крупной к мелкой. Крупный пузырёк — это, как
 *    правило, то, ради чего слайд и сделан, и подпись ему нужнее.
 * 2. Для каждой пробуются четыре места: справа, слева, сверху, снизу.
 *    Справа первым, потому что подпись, начинающаяся у точки, читается
 *    как её продолжение; выключка вправо (слева от точки) требует
 *    возврата взгляда.
 * 3. Место принимается, если бокс подписи целиком внутри поля графика
 *    и не пересекается ни с одной уже поставленной подписью, ни с одним
 *    кругом. Круг проверяется описанным прямоугольником — проверка чуть
 *    строже настоящей формы (углы прямоугольника пусты), и это сознательно:
 *    просвет у скруглённой формы всё равно нужен больше нуля.
 * 4. Не нашлось места — подпись не ставится. Молча этого не происходит:
 *    в разработке пишется предупреждение со списком.
 *
 * Отказ от подписи — честный исход. Альтернатива (нарисовать поверх) —
 * это нечитаемый график, который на экране выглядит как замысел.
 *
 * `reserved` — занятые места, которые подписи точек не рисуют, но обязаны
 * обходить: подписи ориентиров. Они стоят на фиксированных местах у своих
 * пунктирных черт, и подпись точки, положенная на них, портит обе.
 */
function placeLabels(marks: Mark[], bounds: Box, reserved: Box[] = []): (LabelPlacement | null)[] {
  const out: (LabelPlacement | null)[] = marks.map(() => null);
  const taken: Box[] = [...reserved];
  const circles: Box[] = marks.map((m) => ({
    left: m.cx - m.r,
    right: m.cx + m.r,
    top: m.cy - m.r,
    bottom: m.cy + m.r,
  }));

  const order = marks
    .map((m, i) => ({ i, r: m.r }))
    .sort((a, b) => b.r - a.r || a.i - b.i)
    .map((o) => o.i);

  for (const i of order) {
    const m = marks[i];
    if (!m.text) continue;
    const w = textWidth(m.text, LABEL_SIZE, LABEL_WEIGHT);

    const candidates: { place: LabelPlacement; box: Box }[] = [
      {
        place: { x: m.cx + m.r + LABEL_GAP, y: m.cy, anchor: "start" },
        box: {
          left: m.cx + m.r + LABEL_GAP,
          right: m.cx + m.r + LABEL_GAP + w,
          top: m.cy - LABEL_UP,
          bottom: m.cy + LABEL_DOWN,
        },
      },
      {
        place: { x: m.cx - m.r - LABEL_GAP, y: m.cy, anchor: "end" },
        box: {
          left: m.cx - m.r - LABEL_GAP - w,
          right: m.cx - m.r - LABEL_GAP,
          top: m.cy - LABEL_UP,
          bottom: m.cy + LABEL_DOWN,
        },
      },
      {
        place: { x: m.cx, y: m.cy - m.r - LABEL_GAP - LABEL_DOWN, anchor: "middle" },
        box: {
          left: m.cx - w / 2,
          right: m.cx + w / 2,
          top: m.cy - m.r - LABEL_GAP - LABEL_DOWN - LABEL_UP,
          bottom: m.cy - m.r - LABEL_GAP,
        },
      },
      {
        place: { x: m.cx, y: m.cy + m.r + LABEL_GAP + LABEL_UP, anchor: "middle" },
        box: {
          left: m.cx - w / 2,
          right: m.cx + w / 2,
          top: m.cy + m.r + LABEL_GAP,
          bottom: m.cy + m.r + LABEL_GAP + LABEL_UP + LABEL_DOWN,
        },
      },
    ];

    for (const c of candidates) {
      if (!inside(c.box, bounds)) continue;
      if (taken.some((t) => hits(c.box, t, LABEL_CLEAR))) continue;
      if (circles.some((circle, ci) => ci !== i && hits(c.box, circle, LABEL_GAP))) continue;
      out[i] = c.place;
      taken.push(c.box);
      break;
    }
  }

  return out;
}

/**
 * Место для подписи ориентира.
 *
 * Подпись пунктирной черты стоит на фиксированном месте — и попадает под
 * пузырёк. Замер на витрине «Пузырьки» до правки: «Порог окупаемости»
 * налезала на круг канала «Поиск» на 31.2×9.1px. Тёмный текст поверх
 * цветной заливки — это не только неопрятно: он проваливает контраст,
 * причём незаметно для обычной проверки, потому что фоном текста
 * формально остаётся холст.
 *
 * Поэтому у подписи ориентира тоже перебираются места — по обе стороны
 * черты и у обоих её концов, — и берётся первое свободное. Кругов при этом
 * четыре кандидата, а не два: черта делит поле, и «уйти в другой конец»
 * для неё так же законно, как «встать с другой стороны».
 *
 * Если свободного места нет ни одного, подпись всё равно рисуется на первом
 * кандидате. Это осознанный размен: черта без подписи читается как лишняя
 * линия сетки, то есть теряется утверждение автора слайда, — а наложение
 * хотя бы видно.
 */
function placeGuideLabel(
  candidates: { place: LabelPlacement; box: Box }[],
  blockers: Box[],
  bounds: Box,
) {
  for (const c of candidates) {
    if (!inside(c.box, bounds)) continue;
    if (blockers.some((b) => hits(c.box, b, LABEL_GAP))) continue;
    return c;
  }
  return candidates[0];
}

/* ═══════════════  Бюджет высоты  ═══════════════ */

/**
 * Всё, что `ContentSlide` отдаёт содержимому при заголовке в ОДНУ строку
 * и лиде. При заголовке в две строки доступно 544 — то же число, что
 * у `METRIC_PANEL_BUDGET_PLAIN` в [`panel.tsx`](./panel.tsx).
 */
export const SCATTER_BUDGET_PLAIN = 604;

/**
 * Высота строки легенды рядов вместе с отбивкой до графика.
 *
 * 24 — строка `text-label`, 24 — отбивка (`mb-6`). ЗАМЕРЕНО в 1:1, а не
 * сложено из токенов: значок ряда 16×16 выровнен по центру строки и её
 * высоту не увеличивает.
 */
export const SCATTER_LEGEND_ROW = 48;

/**
 * Полная высота блока. Считать, а не подставлять число руками: сырое
 * значение в слайде разойдётся с блоком при первой правке.
 *
 *   scatterChartHeight(520, true) → 568   при бюджете 604
 */
export function scatterChartHeight(
  svgHeight: number = DEFAULT_SCATTER_GEOMETRY.height,
  hasLegend = false,
) {
  return svgHeight + (hasLegend ? SCATTER_LEGEND_ROW : 0);
}

/* ═══════════════  Ключ размеров  ═══════════════ */

/*
 * Ключ пузырьков — не легенда «какой цвет что значит», а шкала: два круга
 * с числами, наибольший и наименьший в наборе.
 *
 * Без него площадь не значит ничего: читатель видит, что один пузырёк
 * больше другого, но не знает, во сколько раз и в чём измерено. Это ровно
 * та же беда, что у графика без осей.
 *
 * Круги концентричны и совмещены по НИЗУ, а не поставлены рядом: так
 * разница читается вложением, а не сравнением двух пятен на расстоянии.
 * Приём стандартный для пузырьковых карт и переносится без изменений —
 * он про восприятие, а не про носитель.
 *
 * Место — правое поле SVG. Оно всё равно пустует (там только просвет под
 * крайний пузырёк), а любое другое место стоило бы высоты: 80 точек
 * ключа — это пятая часть поля графика.
 */
const KEY_GAP = 12;
const KEY_TEXT_GAP = 8;

/**
 * Отступ ключа от правого края поля графика.
 *
 * Входит в ширину ключа, а не прибавляется к ней снаружи. Первая версия
 * считала ширину без него, и подпись «Площадь — клиентов за год» вылезала
 * за правый край SVG ровно на эти 16 точек (замер в 1:1: правый край
 * подписи 1752 при краю SVG 1744). Обрезка краем SVG молчит — ни ошибки,
 * ни предупреждения, просто половина слова.
 */
const KEY_OFFSET = EDGE_GAP * 2;

function sizeKeyWidth(maxLabel: string, minLabel: string, caption: string) {
  const text = Math.max(
    textWidth(maxLabel, AXIS_SIZE, AXIS_WEIGHT),
    textWidth(minLabel, AXIS_SIZE, AXIS_WEIGHT),
  );
  const circles = BUBBLE_MAX * 2 + KEY_GAP + KEY_TEXT_GAP + text;
  return KEY_OFFSET + Math.max(circles, textWidth(caption, AXIS_SIZE, AXIS_WEIGHT)) + EDGE_GAP;
}

function SizeKey({
  x,
  y,
  rMin,
  maxLabel,
  minLabel,
  caption,
}: {
  x: number;
  y: number;
  rMin: number;
  maxLabel: string;
  minLabel: string;
  caption: string;
}) {
  const cx = x + BUBBLE_MAX;
  const bottom = y + BUBBLE_MAX * 2;
  const textX = x + BUBBLE_MAX * 2 + KEY_GAP;

  return (
    <g>
      <text
        x={x}
        y={y - 22}
        fill="var(--t-ink-secondary)"
        style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
      >
        {caption}
      </text>

      <circle
        cx={cx}
        cy={bottom - BUBBLE_MAX}
        r={BUBBLE_MAX}
        fill="none"
        stroke="var(--t-line)"
        strokeWidth={2}
      />
      <circle
        cx={cx}
        cy={bottom - rMin}
        r={rMin}
        fill="none"
        stroke="var(--t-line)"
        strokeWidth={2}
      />

      {/* Выноски от верхней точки каждого круга к его числу */}
      <line x1={cx} x2={textX} y1={y} y2={y} stroke="var(--t-line)" strokeWidth={2} />
      <line
        x1={cx}
        x2={textX}
        y1={bottom - rMin * 2}
        y2={bottom - rMin * 2}
        stroke="var(--t-line)"
        strokeWidth={2}
      />

      <text
        x={textX + KEY_TEXT_GAP}
        y={y}
        dominantBaseline="middle"
        fill="var(--t-ink-secondary)"
        style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
      >
        {maxLabel}
      </text>
      <text
        x={textX + KEY_TEXT_GAP}
        y={bottom - rMin * 2}
        dominantBaseline="middle"
        fill="var(--t-ink-secondary)"
        style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
      >
        {minLabel}
      </text>
    </g>
  );
}

/* ═══════════════  Ориентиры  ═══════════════ */

export interface ScatterGuide {
  /** Значение на своей оси: среднее по базе, план, порог окупаемости */
  at: number;
  /** Что это за черта. Без подписи ориентир читается как ошибка сетки */
  label: string;
}

/* ═══════════════  График  ═══════════════ */

export interface ScatterChartProps {
  series: ScatterSeries[];
  /** Что отложено по горизонтали. Без названия положение точки не значит ничего */
  xTitle: string;
  /** Что отложено по вертикали */
  yTitle: string;
  /** Что означает ПЛОЩАДЬ пузырька. Обязательно, если у точек есть size */
  sizeTitle?: string;
  formatX?: (value: number) => string;
  formatY?: (value: number) => string;
  formatSize?: (value: number) => string;
  /** Вертикальная черта: норма, план, порог по оси X */
  guideX?: ScatterGuide;
  /** Горизонтальная черта по оси Y */
  guideY?: ScatterGuide;
  /**
   * Подписывать точки. Выключать, когда точек столько, что имена
   * не помещаются, а вывод слайда — в форме облака, а не в отдельных
   * наблюдениях.
   */
  showLabels?: boolean;
  /**
   * Цвет кольца-просвета вокруг точки. По умолчанию холст слайда;
   * передавать, если график лежит на карточке или приглушённой подложке.
   */
  ring?: string;
  geometry?: Partial<ScatterGeometry>;
}

export function ScatterChart({
  series,
  xTitle,
  yTitle,
  sizeTitle,
  formatX = (v) => v.toLocaleString("ru-RU"),
  formatY = (v) => v.toLocaleString("ru-RU"),
  formatSize = (v) => v.toLocaleString("ru-RU"),
  guideX,
  guideY,
  showLabels = true,
  ring = "var(--t-canvas)",
  geometry,
}: ScatterChartProps) {
  useRemeasureOnFont();

  const g = { ...DEFAULT_SCATTER_GEOMETRY, ...geometry };

  /*
   * Лишние ряды отбрасываются, а не красятся по кругу: четвёртый ряд цветом
   * первого — это график, который врёт про принадлежность точек. Отброс
   * громкий, см. предупреждение ниже.
   */
  const shown = series.slice(0, MAX_SERIES);
  const points = shown.flatMap((s) => s.points);

  const sized = points.filter((p) => p.size !== undefined);
  const isBubble = sized.length > 0;
  const maxSize = isBubble ? Math.max(...sized.map((p) => p.size ?? 0)) : 0;
  const minSize = isBubble ? Math.min(...sized.map((p) => p.size ?? 0)) : 0;

  if (import.meta.env.DEV) {
    if (series.length > MAX_SERIES) {
      console.warn(
        `ScatterChart: рядов ${series.length}, показаны первые ${MAX_SERIES} ` +
          `(${shown.map((s) => s.label).join(", ")}). На точечной сравниваются все пары цветов, ` +
          "и проверенный набор CHART_SERIES_SCATTER состоит из трёх — четвёртому взять цвет неоткуда. " +
          "Сводите ряды в один либо разбивайте на два графика.",
      );
    }
    if (isBubble && sized.length !== points.length) {
      console.warn(
        `ScatterChart: size задан у ${sized.length} точек из ${points.length}. ` +
          "Точки без размера получат минимальный радиус и будут читаться как самые мелкие. " +
          "Либо задать size всем, либо не задавать никому.",
      );
    }
    if (isBubble && !sizeTitle) {
      console.warn(
        "ScatterChart: у точек есть size, но sizeTitle не передан. Площадь пузырька " +
          "без подписи не значит ничего — это то же самое, что график без осей.",
      );
    }
    if (isBubble && maxSize > 0) {
      const clamped = sized.filter(
        (p) => BUBBLE_MAX * Math.sqrt((p.size ?? 0) / maxSize) < BUBBLE_MIN,
      );
      if (clamped.length) {
        console.warn(
          `ScatterChart: ${clamped.length} точек упёрлись в минимальный радиус ${BUBBLE_MIN}. ` +
            `Разброс ${formatSize(minSize)}…${formatSize(maxSize)} шире, чем 25:1 по площади: ` +
            "их пятна больше своей доли, то есть мелкие значения преувеличены. " +
            "Сворачивайте хвост в «прочее» либо берите другую форму.",
        );
      }
    }
  }

  const xDomain = niceDomain(
    Math.min(...points.map((p) => p.x)),
    Math.max(...points.map((p) => p.x)),
    TICKS,
  );
  const yDomain = niceDomain(
    Math.min(...points.map((p) => p.y)),
    Math.max(...points.map((p) => p.y)),
    TICKS,
  );

  const xTicks = tickValues(xDomain);
  const yTicks = tickValues(yDomain);

  /*
   * Поля пересчитываются под фактическую ширину текста — сузить замер их
   * не может, только расширить. Иначе значение поля в геометрии перестало
   * бы что-либо значить, а подпись, не влезшая в поле, обрезалась бы краем
   * SVG: та же грабля, что была у прямых подписей LineChart.
   */
  const padLeft = Math.max(
    g.padLeft,
    yTicks.reduce((acc, v) => Math.max(acc, textWidth(formatY(v), AXIS_SIZE, AXIS_WEIGHT)), 0) +
      AXIS_GAP +
      EDGE_GAP,
  );

  const keyCaption = sizeTitle ? `Площадь — ${sizeTitle.toLowerCase()}` : "";
  const padRight = isBubble
    ? Math.max(g.padRight, sizeKeyWidth(formatSize(maxSize), formatSize(minSize), keyCaption))
    : g.padRight;

  const plotW = g.width - padLeft - padRight;
  const plotH = g.height - g.padTop - g.padBottom;

  const x = (v: number) => padLeft + ((v - xDomain.lo) / (xDomain.hi - xDomain.lo)) * plotW;
  const y = (v: number) =>
    g.padTop + plotH - ((v - yDomain.lo) / (yDomain.hi - yDomain.lo)) * plotH;

  /* Круги в порядке отрисовки: крупные позади, мелкие поверх — иначе
     мелкий пузырёк исчезает под крупным целиком */
  const marks = shown.flatMap((s, si) =>
    s.points.map((p) => ({
      key: `${s.key}:${p.label}`,
      color: shown.length === 1 ? CHART_EMPHASIS : CHART_SERIES_SCATTER[si],
      cx: x(p.x),
      cy: y(p.y),
      r: isBubble ? bubbleRadius(p.size ?? 0, maxSize) : DOT_R,
      text: p.label,
    })),
  );
  const drawOrder = marks.map((_, i) => i).sort((a, b) => marks[b].r - marks[a].r);

  const bounds: Box = {
    left: padLeft,
    right: padLeft + plotW,
    top: g.padTop,
    bottom: g.padTop + plotH,
  };

  const circleBoxes: Box[] = marks.map((m) => ({
    left: m.cx - m.r,
    right: m.cx + m.r,
    top: m.cy - m.r,
    bottom: m.cy + m.r,
  }));

  /*
   * Подписи ориентиров раскладываются ПЕРВЫМИ и занимают место: черта
   * с подписью — утверждение автора слайда, и уступать его подписи точки
   * нельзя. Порядок кандидатов задаёт предпочтение: у вертикальной черты
   * подпись хочет стоять справа сверху, у горизонтальной — справа над
   * чертой, то есть там, где её ищут глазами.
   */
  const hGap = 12;
  const guideBoxes: Box[] = [];

  const guideXPlace = guideX
    ? placeGuideLabel(
        (() => {
          const w = textWidth(guideX.label, AXIS_SIZE, AXIS_WEIGHT);
          const gx = x(guideX.at);
          const rows = [g.padTop + 16, g.padTop + plotH - 14];
          return rows.flatMap((row) => [
            {
              place: { x: gx + hGap, y: row, anchor: "start" as const },
              box: {
                left: gx + hGap,
                right: gx + hGap + w,
                top: row - LABEL_UP,
                bottom: row + LABEL_DOWN,
              },
            },
            {
              place: { x: gx - hGap, y: row, anchor: "end" as const },
              box: {
                left: gx - hGap - w,
                right: gx - hGap,
                top: row - LABEL_UP,
                bottom: row + LABEL_DOWN,
              },
            },
          ]);
        })(),
        circleBoxes,
        bounds,
      )
    : null;
  if (guideXPlace) guideBoxes.push(guideXPlace.box);

  const guideYPlace = guideY
    ? placeGuideLabel(
        (() => {
          const w = textWidth(guideY.label, AXIS_SIZE, AXIS_WEIGHT);
          const gy = y(guideY.at);
          const rows = [gy - hGap, gy + hGap + LABEL_UP];
          return rows.flatMap((row) => [
            {
              place: { x: padLeft + plotW, y: row, anchor: "end" as const },
              box: {
                left: padLeft + plotW - w,
                right: padLeft + plotW,
                top: row - LABEL_UP,
                bottom: row + LABEL_DOWN,
              },
            },
            {
              place: { x: padLeft, y: row, anchor: "start" as const },
              box: {
                left: padLeft,
                right: padLeft + w,
                top: row - LABEL_UP,
                bottom: row + LABEL_DOWN,
              },
            },
          ]);
        })(),
        [...circleBoxes, ...guideBoxes],
        bounds,
      )
    : null;
  if (guideYPlace) guideBoxes.push(guideYPlace.box);

  const placements = showLabels ? placeLabels(marks, bounds, guideBoxes) : marks.map(() => null);

  if (import.meta.env.DEV && showLabels) {
    const lost = marks.filter((_, i) => placements[i] === null).map((m) => m.text);
    if (lost.length) {
      console.warn(
        `ScatterChart: не поместились подписи (${lost.length} из ${marks.length}): ` +
          `${lost.join(", ")}. Свободного места рядом с точкой нет — подписи не нарисованы, ` +
          "чтобы не лечь поверх соседних. Увеличьте высоту, сократите подписи " +
          "либо выключите showLabels и назовите наблюдения текстом слайда.",
      );
    }
  }

  return (
    <svg width={g.width} height={g.height} viewBox={`0 0 ${g.width} ${g.height}`} role="img">
      {/*
       * Название оси Y стоит НАД шкалой горизонтально, а не повёрнуто на 90°.
       * Повёрнутая подпись требует наклонить голову — на слайде, который
       * смотрят с трёх метров и полторы минуты, это цена выше, чем место.
       */}
      <text
        x={0}
        y={22}
        fill="var(--t-ink-secondary)"
        style={{ fontSize: TITLE_SIZE, fontWeight: TITLE_WEIGHT }}
      >
        {yTitle}
      </text>

      {/* Горизонтальная сетка и подписи делений оси Y */}
      {yTicks.map((v) => (
        <g key={`y${v}`}>
          <line
            x1={padLeft}
            x2={padLeft + plotW}
            y1={y(v)}
            y2={y(v)}
            stroke="var(--t-line)"
            strokeWidth={2}
          />
          <text
            x={padLeft - AXIS_GAP}
            y={y(v)}
            textAnchor="end"
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {formatY(v)}
          </text>
        </g>
      ))}

      {/*
       * Вертикальная сетка. Она нужна ровно так же, как горизонтальная:
       * без неё положение точки по X читается только у самого края поля.
       */}
      {xTicks.map((v) => (
        <g key={`x${v}`}>
          <line
            x1={x(v)}
            x2={x(v)}
            y1={g.padTop}
            y2={g.padTop + plotH}
            stroke="var(--t-line)"
            strokeWidth={2}
          />
          <text
            x={x(v)}
            y={g.padTop + plotH + 36}
            textAnchor={v === xDomain.lo ? "start" : v === xDomain.hi ? "end" : "middle"}
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {formatX(v)}
          </text>
        </g>
      ))}

      <text
        x={padLeft + plotW}
        y={g.padTop + plotH + 68}
        textAnchor="end"
        fill="var(--t-ink-secondary)"
        style={{ fontSize: TITLE_SIZE, fontWeight: TITLE_WEIGHT }}
      >
        {xTitle}
      </text>

      {/*
       * Ориентиры — норма, план, порог. Пунктиром и заметно темнее сетки:
       * это не разметка, а утверждение о данных, и путать его с сеткой
       * нельзя. Подпись обязательна — черта без подписи читается как
       * лишняя линия сетки, попавшая не туда.
       *
       * Цвет черты — роль `ink-tertiary`, и это законно: порог для
       * нетекстовой графики 3:1, замер даёт 3.29 в светлой теме и 4.98
       * в тёмной. Запрет «не набирать третичным текст мельче 24px»
       * к линии не относится — он про ЧТЕНИЕ, а подпись самой черты
       * набрана вторичным (4.99 и 9.23). Сетка тем же цветом была бы
       * ошибкой: она разметка и обязана быть тише данных, поэтому
       * у неё роль `line` (1.26 к холсту).
       */}
      {guideX ? (
        <g>
          <line
            x1={x(guideX.at)}
            x2={x(guideX.at)}
            y1={g.padTop}
            y2={g.padTop + plotH}
            stroke="var(--t-ink-tertiary)"
            strokeWidth={2}
            strokeDasharray="10 8"
          />
          <text
            x={guideXPlace?.place.x}
            y={guideXPlace?.place.y}
            textAnchor={guideXPlace?.place.anchor}
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {guideX.label}
          </text>
        </g>
      ) : null}

      {guideY ? (
        <g>
          <line
            x1={padLeft}
            x2={padLeft + plotW}
            y1={y(guideY.at)}
            y2={y(guideY.at)}
            stroke="var(--t-ink-tertiary)"
            strokeWidth={2}
            strokeDasharray="10 8"
          />
          <text
            x={guideYPlace?.place.x}
            y={guideYPlace?.place.y}
            textAnchor={guideYPlace?.place.anchor}
            dominantBaseline="middle"
            fill="var(--t-ink-secondary)"
            style={{ fontSize: AXIS_SIZE, fontWeight: AXIS_WEIGHT }}
          >
            {guideY.label}
          </text>
        </g>
      ) : null}

      {/* Ключ размеров в правом поле */}
      {isBubble ? (
        <SizeKey
          x={padLeft + plotW + KEY_OFFSET}
          y={g.padTop}
          rMin={bubbleRadius(minSize, maxSize)}
          maxLabel={formatSize(maxSize)}
          minLabel={formatSize(minSize)}
          caption={keyCaption}
        />
      ) : null}

      {/* Точки */}
      {drawOrder.map((i) => {
        const m = marks[i];
        return isBubble ? (
          <circle
            key={m.key}
            cx={m.cx}
            cy={m.cy}
            r={m.r}
            fill={m.color}
            fillOpacity={BUBBLE_FILL_OPACITY}
            stroke={m.color}
            strokeWidth={BUBBLE_STROKE}
          />
        ) : (
          <circle
            key={m.key}
            cx={m.cx}
            cy={m.cy}
            r={m.r}
            fill={m.color}
            stroke={ring}
            strokeWidth={RING}
          />
        );
      })}

      {/* Подписи точек — поверх всего, но по построению ни на что не легли */}
      {marks.map((m, i) => {
        const place = placements[i];
        if (!place) return null;
        return (
          <text
            key={`t${m.key}`}
            x={place.x}
            y={place.y}
            textAnchor={place.anchor}
            dominantBaseline="middle"
            fill="var(--t-ink)"
            style={{ fontSize: LABEL_SIZE, fontWeight: LABEL_WEIGHT }}
          >
            {m.text}
          </text>
        );
      })}
    </svg>
  );
}

/* ═══════════════  Легенда рядов  ═══════════════ */

/**
 * Легенда рядов.
 *
 * Отдельным блоком над графиком, а не внутри SVG: подписи легенды — это
 * текст интерфейса, и он должен носить типографические токены системы
 * (`text-label`), а не кегль числом. Внутри SVG токены применялись бы
 * тоже, но тогда пришлось бы вести вторую вёрстку флекс-ряда руками.
 *
 * Прямая подпись у последней точки, как в `LineChart`, здесь невозможна:
 * у ряда точек нет «последней» — они не упорядочены. Легенда — вынужденный,
 * но здесь единственный способ назвать цвет.
 *
 * Рендерится только при двух и более рядах: подписывать единственный ряд
 * значит объяснять читателю, что синий — это синий.
 */
export function ScatterLegend({ series }: { series: ScatterSeries[] }) {
  if (series.length < 2) return null;

  return (
    <div className="mb-6 flex flex-wrap items-center gap-8">
      {series.slice(0, MAX_SERIES).map((s, si) => (
        <span key={s.key} className="text-label text-ink-secondary flex items-center gap-3">
          <svg width={16} height={16} aria-hidden="true">
            <circle cx={8} cy={8} r={7} fill={CHART_SERIES_SCATTER[si]} />
          </svg>
          {s.label}
        </span>
      ))}
    </div>
  );
}
