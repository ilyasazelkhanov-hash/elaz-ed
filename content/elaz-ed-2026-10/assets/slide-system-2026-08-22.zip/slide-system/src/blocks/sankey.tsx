import { Fragment, useEffect, useId, useState } from "react";

import { CHART_SERIES } from "../lib/chartPalette";
import type { GradientStop } from "../lib/color";
import { barFill } from "../lib/color";

/**
 * Диаграмма потоков (Sankey): что во что перетекает.
 *
 * === Какой вопрос она закрывает ===
 *
 * «Куда уходит бюджет / трафик / время». У этого вопроса ДВА измерения
 * сразу — из чего состоит целое и во что каждая часть превращается, — и ни
 * одна из уже собранных форм их вместе не показывает:
 *
 *   StackedBar (blocks/chartsParts) — состав целого. Одно измерение.
 *   ShareRibbon (blocks/share)      — насколько целое держится на первых частях.
 *   HBarChart                       — сравнение участников между собой.
 *   Таблица «Источник | Назначение | Сумма» — оба измерения есть, но связь
 *       между ними зритель должен собрать в голове из 20–30 строк.
 *
 * Sankey делает связь ФОРМОЙ: ширина ленты и есть величина потока, и видно,
 * что «Контекст» уходит в основном на новых клиентов, а «Наружная» — почти
 * целиком в узнаваемость. На таблице тот же вывод занимает абзац текста.
 *
 * === Чего эта форма НЕ делает ===
 *
 * Она не сравнивает величины точно. Толщина ленты читается хуже длины
 * столбика: на глаз разница 18% и 22% на лентах не видна. Поэтому величина
 * И доля подписаны у каждого узла числом — точное сравнение делает подпись,
 * а лента показывает направление и порядок величин.
 *
 * Если у слайда вопрос «какая статья больше» — это HBarChart, а не Sankey.
 * Sankey берут, когда вопрос про ПЕРЕХОД.
 *
 * === Почему потолок 5 источников и 7 приёмников ===
 *
 * Два разных довода, и оба жёсткие:
 *
 *   5 источников — это ровно длина CHART_SERIES. Цвет здесь кодирует
 *       источник, а палитра проверена валидатором на пять красок и по кругу
 *       не назначается (см. .claude/rules/dataviz.md). Шестой источник — это
 *       не шестая краска, а строка «Прочее» на стороне данных.
 *
 *   7 приёмников — предел читаемости. Число связей растёт как произведение:
 *       5×7 = 35 лент на 884 точки ширины. Дальше это не диаграмма, а лапша,
 *       в которой отдельную ленту глазом не проследить. Ровно этот случай
 *       показан в витрине историей «Опасный случай» — специально, чтобы
 *       потолок не выглядел придиркой.
 *
 * Превышение потолка — не молчаливая обрезка: узлы сверх потолка отбрасывают
 * вместе с их связями, а в DEV печатается предупреждение со списком того, что
 * выпало, и с указанием свернуть остаток в «Прочее» на стороне данных.
 */

/* ═══════════════  Данные  ═══════════════ */

export interface SankeyNode {
  /** Ключ, по которому на узел ссылаются связи */
  key: string;
  /** Подпись узла */
  label: string;
}

export interface SankeyLink {
  /** Ключ источника */
  from: string;
  /** Ключ приёмника */
  to: string;
  /** Величина потока в тех же единицах, что и у всех остальных связей */
  value: number;
}

/**
 * Потолки. SOURCE_CAP выведен из палитры, а не задан числом: если в
 * CHART_SERIES когда-нибудь станет другое количество красок, потолок
 * поедет за ней сам, а не разойдётся с ней молча.
 */
const SOURCE_CAP = CHART_SERIES.length;
const TARGET_CAP = 7;

/* ═══════════════  Геометрия  ═══════════════ */

/**
 * Толщина столбика узла.
 *
 * Столбик здесь — та же фигура, что столбец BarChart, положенная в колонку:
 * высота кодирует величину, заливка идёт через `barFill`. 18 точек — чтобы
 * скругление `micro` (6px) читалось скруглением, а не капсулой.
 */
const NODE_W = 18;

/** Просвет между соседними столбиками в колонке */
const NODE_GAP = 18;

/** Просвет между столбиком и его подписью */
const LABEL_GAP = 20;

/** Просвет между названием узла и его числами внутри строки подписи */
const INLINE_GAP = 12;

/**
 * Высота строки подписи и просвет между соседними подписями.
 *
 * LINE — межстрочный интервал `text-body-m` (20/28) из typography.css.
 * Число продублировано здесь потому, что от него считается ГЕОМЕТРИЯ: пока
 * оно стояло только в CSS, посчитать минимальную высоту столбика было нечем.
 * При правке шкалы это место придётся править вместе с ней.
 */
const LINE = 28;

/** Запас, чтобы соседние подписи не касались боксами вплотную */
const LABEL_CLEAR = 6;

/** Кегль и вес подписи — для замера ширины, см. `textWidth` */
const NAME_SIZE = 20;
const NAME_WEIGHT = 500;
const META_SIZE = 18;
const META_WEIGHT = 500;

/**
 * Доля ширины ленты, на которой стоят опорные точки кривой Безье.
 *
 * 0.5 — обе опоры посередине пролёта. Лента выходит из узла ГОРИЗОНТАЛЬНО
 * и так же горизонтально входит в приёмник, то есть примыкает к столбику
 * встык, а не под углом. Меньшее значение выпрямляет ленту в диагональ,
 * и место стыка начинает выглядеть надломом.
 */
const CURVE = 0.5;

/**
 * Ниже этой толщины лента перестаёт читаться и о ней предупреждают в DEV.
 *
 * Не зажим: зажать толщину ленты внутри узла нельзя, не сломав равенство
 * «сумма лент = высота столбика». То есть исправлять это должен автор
 * данных — свернуть мелкие потоки в один, — а не блок молча.
 */
const RIBBON_MIN = 3;

/* ═══════════════  Плотность лент  ═══════════════ */

/**
 * Непрозрачность ленты у источника и у приёмника.
 *
 * === Почему лента полупрозрачная ===
 *
 * Ленты пересекаются — это устройство формы, а не дефект вёрстки. Сплошная
 * заливка означала бы, что верхняя лента просто стирает нижнюю, и поток,
 * который проходит под другим, с диаграммы исчезает.
 *
 * === Откуда числа ===
 *
 * Отправная точка — донорская площадь под линией: 0.55 сверху. Но у площади
 * перекрытий не бывает, а у лент бывают, и потолок здесь задаёт другое
 * условие: СТОПКА ЛЕНТ ОБЯЗАНА ОСТАВАТЬСЯ ТИШЕ САМОГО СЛАБОГО СТОЛБИКА.
 * Слабейший столбик системы — lime-700 #497d00 на тёмной карточке, 3.04:1
 * (то же число, что в chartPalette.ts; пересчитано здесь по всему ходу
 * заливки barFill, а не по одной краске).
 *
 * Замер стопки из трёх лент в середине хода, композитом к своей подложке,
 * по пяти краскам CHART_SERIES и шести поверхностям системы:
 *
 *   голова 0.55   три ленты до 3.31  ✗ плотнее столбика
 *   голова 0.50   три ленты до 3.12  ✗ плотнее столбика
 *   голова 0.45   три ленты до 2.86  ✓ запас 0.18 до 3.04
 *
 * Взято 0.45 — наибольшее значение, на котором тройное пересечение
 * гарантированно читается тише любого столбика, то есть узел из лент не
 * начинает выглядеть данными.
 *
 * Одиночная лента при этом даёт 1.61…1.92 у источника и 1.26…1.33 у
 * приёмника — примерно столько же, сколько донорская площадь под линией
 * (1.92…2.17 сверху, 1.03…1.05 снизу, замер в src/lib/color.ts). Порог 3:1
 * лента не берёт и брать не должна ровно по той же причине, что площадь:
 * носитель величины — столбик узла и подпись у него, а лента показывает
 * направление.
 *
 * ⚠️ Честно про предел. Стопка из четырёх лент доходит до 3.37, из пяти —
 * до 3.73 в середине хода и до 4.78 у самого источника, то есть узел из
 * пяти пересечений выглядит ПЛОТНЕЕ столбика. Опустить плотность так, чтобы
 * и этот случай остался тихим, нельзя: одиночная лента тогда исчезнет.
 * Пятикратное пересечение лечится не прозрачностью, а порядком узлов и
 * потолками — и показано в витрине историей «Опасный случай».
 */
const RIBBON_HEAD = 0.45;

/**
 * Хвост — ровно половина головы.
 *
 * Лента гаснет к приёмнику, а не идёт равномерной плёнкой, по двум причинам:
 * у приёмника сходятся до пяти лент, и там нужнее всего тишина; и подпись
 * приёмника стоит вплотную к столбику, а под ней не должно быть пёстрой каши.
 */
const RIBBON_TAIL = RIBBON_HEAD / 2;

/**
 * Краска приёмника.
 *
 * Приёмники НЕЙТРАЛЬНЫ, и это не экономия, а следствие правила палитры:
 * цвет кодирует ОДНУ сущность. Здесь он кодирует источник — пять источников,
 * пять красок CHART_SERIES. Красить ещё и семь приёмников означало бы либо
 * назначение цветов по кругу (запрещено правилом dataviz), либо вторую
 * цветовую шкалу на одном рисунке — и тогда непонятно, что означает цвет
 * ленты.
 *
 * Взят `--t-ink-tertiary`, а не `--t-fill-strong`. Замер fill-strong к
 * поверхностям: 1.11:1 к светлому холсту и 1.40:1 к тёмному — столбик
 * приёмника был бы не виден вовсе. Третичный проходит порог 3:1 для
 * нетекстовой графики на всех шести поверхностях системы:
 *
 *   светлая: карточка 3.79 · холст 3.54 · подложка 3.33
 *   тёмная:  карточка 3.68 · холст 4.55 · подложка 4.14
 *
 * Тот же выбор и по той же причине сделан у контура «прочего» в
 * chartsParts.tsx и у пустого гнезда в units.tsx.
 *
 * ⚠️ Ограничение «третичным набирать только от 24px» здесь ни при чём: это
 * не текст, а заливка, и порог у неё 3:1, а не 4.5:1.
 *
 * Серый не может быть принят за шестую категорию: у него нет цветности.
 */
const TARGET_PAINT = "var(--t-ink-tertiary)";

/**
 * Стопы ленты: краска источника → краска приёмника.
 *
 * Это НЕ затухание в прозрачность, поэтому запрет «гаснуть в свой цвет,
 * а не в transparent» тут ни при чём: оба конца — настоящие краски, между
 * ними идёт честный переход цвета, а непрозрачность меняется отдельным
 * атрибутом. Ключевого слова `transparent` в рецепте нет вовсе.
 *
 * ⚠️ Стопы годятся ТОЛЬКО для SVG. `cssGradient` их не примет: хвост —
 * `var(--t-ink-tertiary)`, а не hex, и `rgba()` разобрала бы его в NaN.
 * В SVG это законно — `stop-color` принимает `var()`, а прозрачность живёт
 * в отдельном `stop-opacity` (тот же приём, что в slide/SlideSpot.tsx).
 */
function ribbonStops(color: string): GradientStop[] {
  return [
    { offset: 0, color, opacity: RIBBON_HEAD },
    { offset: 1, color: TARGET_PAINT, opacity: RIBBON_TAIL },
  ];
}

/* ═══════════════  Замер ширины текста  ═══════════════ */

/*
 * Тот же приём, что в blocks/chartsLine.tsx и blocks/scatter.tsx: ширина
 * подписи нужна ДО отрисовки, потому что от числа строк подписи зависит
 * минимальная высота столбика — иначе подписи соседних узлов налезут друг
 * на друга. Прикидка «знаков × кегль» не годится: разброс ширины знака по
 * замеру доходит до двух с половиной раз.
 *
 * Помощник продублирован, а не вынесен в общий модуль, намеренно: в проекте
 * он уже существует в двух копиях, и третья копия рядом с местом применения
 * честнее, чем barrel-модуль на три строки (barrel-импорты запрещены).
 */

/** Запасной коэффициент на случай, когда DOM недоступен (сборка вне браузера) */
const FALLBACK_RATIO = 0.62;

const measureCache = new Map<string, number>();
let measureCtx: CanvasRenderingContext2D | null | undefined;

function fontStack() {
  const token = getComputedStyle(document.documentElement).getPropertyValue("--font-app").trim();
  return token || "sans-serif";
}

function textWidth(text: string, size: number, weight: number) {
  const key = `${weight} ${size} ${text}`;
  const cached = measureCache.get(key);
  if (cached !== undefined) return cached;

  if (measureCtx === undefined) {
    measureCtx =
      typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  }

  let width: number;
  if (measureCtx) {
    measureCtx.font = `${weight} ${size}px ${fontStack()}`;
    width = measureCtx.measureText(text).width;
  } else {
    width = text.length * size * FALLBACK_RATIO;
  }

  measureCache.set(key, width);
  return width;
}

let fontsSettled = false;

/**
 * Пересчёт после загрузки шрифта.
 *
 * До загрузки Google Sans `measureText` отвечает по запасному шрифту. Для
 * экрана это незаметно, а выгрузка снимает РОВНО ОДИН кадр — и в него попало
 * бы число строк подписи, посчитанное по чужим метрикам.
 */
function useRemeasureOnFont() {
  const [, remeasured] = useState(0);

  useEffect(() => {
    if (fontsSettled) return;
    let alive = true;
    void document.fonts?.ready.then(() => {
      if (!alive) return;
      fontsSettled = true;
      measureCache.clear();
      remeasured((n) => n + 1);
    });
    return () => {
      alive = false;
    };
  }, []);
}

/**
 * Сколько строк займёт подпись в колонке шириной `width`.
 *
 * Жадный перенос по словам — так же переносит браузер. Слово, которое само
 * шире строки, рвётся по буквам: в разметке у названия стоит `break-words`,
 * и без такого же поведения здесь длинный адрес считался бы одной строкой,
 * а нарисовался бы тремя.
 *
 * ⚠️ Трекинг в замере НЕ учитывается. Во всей типографике он отрицательный,
 * −(кегль × 0.02), то есть настоящая строка чуть УЖЕ замеренной. Ошибка идёт
 * в безопасную сторону: блок иногда насчитает лишнюю строку и оставит лишний
 * просвет, но никогда не насчитает меньше строк, чем встанет на самом деле.
 */
function wrapLines(text: string, width: number, size: number, weight: number) {
  const words = text.split(/\s+/).filter(Boolean);
  if (!words.length) return 1;
  if (width <= 0) return words.length;

  let lines = 1;
  let current = "";

  for (const word of words) {
    const probe = current ? `${current} ${word}` : word;
    if (textWidth(probe, size, weight) <= width) {
      current = probe;
      continue;
    }

    if (current) lines++;
    current = word;

    /* Слово длиннее строки: браузер с break-words рвёт его по буквам */
    while (textWidth(current, size, weight) > width && current.length > 1) {
      let cut = current.length;
      while (cut > 1 && textWidth(current.slice(0, cut), size, weight) > width) cut--;
      lines++;
      current = current.slice(cut);
    }
  }

  return lines;
}

/* ═══════════════  Раскладка колонки  ═══════════════ */

/**
 * Высоты столбиков: пропорция величине, но не тоньше своего минимума.
 *
 * === Зачем минимум ===
 *
 * Высота столбика задаёт шаг между подписями. Узел в 2% от целого дал бы
 * столбик в 10 точек, а его подпись — 28, и подписи соседних узлов налезли
 * бы друг на друга. Минимум считается из ЧИСЛА СТРОК подписи этого узла:
 * `строки × 28 − просвет + запас`. Однострочная подпись просит всего 16
 * точек — то есть в обычном случае минимум не срабатывает вовсе и пропорция
 * остаётся точной.
 *
 * === ⚠️ Чем за это платят ===
 *
 * Когда минимум срабатывает, высота столбика БОЛЬШЕ его доли: узел выглядит
 * крупнее, чем он есть. Это искажение, а не косметика, и поэтому о нём
 * предупреждают в DEV с указанием, на сколько точек раздут узел. Честный
 * выход — свернуть мелкие узлы в «Прочее» или поднять `height`, а не
 * оставлять раздутый узел на клиентском слайде.
 *
 * Раздача идёт «наливом»: узлы, которым не хватает до минимума, закрепляются
 * на минимуме, остаток делится между свободными пропорционально их величинам,
 * и проход повторяется, пока закрепления не кончатся.
 */
function fitHeights(values: number[], mins: number[], barTotal: number) {
  const n = values.length;
  const pinned = new Array<boolean>(n).fill(false);
  const out = new Array<number>(n).fill(0);

  for (let guard = 0; guard <= n; guard++) {
    const pinnedSum = mins.reduce((sum, m, i) => sum + (pinned[i] ? m : 0), 0);
    const rest = Math.max(0, barTotal - pinnedSum);
    const freeValue = values.reduce((sum, v, i) => sum + (pinned[i] ? 0 : v), 0);

    let changed = false;
    for (let i = 0; i < n; i++) {
      if (pinned[i]) {
        out[i] = mins[i];
        continue;
      }
      out[i] = freeValue > 0 ? (values[i] / freeValue) * rest : 0;
      if (out[i] < mins[i]) {
        pinned[i] = true;
        changed = true;
      }
    }
    if (!changed) break;
  }

  return out;
}

/* ═══════════════  Блок  ═══════════════ */

export interface SankeyFlowProps {
  /** Источники. Порядок сверху вниз — тот, в котором они переданы */
  sources: SankeyNode[];
  /** Приёмники. Порядок сверху вниз — тот, в котором они переданы */
  targets: SankeyNode[];
  /** Связи. Величины во всех связях в одних единицах */
  links: SankeyLink[];
  /** Общая ширина блока */
  width?: number;
  /** Высота полосы с потоками, без строки итога */
  height?: number;
  /** Ширина колонки подписи с каждой стороны */
  labelWidth?: number;
  /** Как печатать величину узла */
  formatValue?: (value: number) => string;
  /** Как печатать долю узла в процентах */
  formatShare?: (percent: number) => string;
  /** Подпись итога над потоком. Без неё строка итога не рисуется */
  totalCaption?: string;
}

/**
 * Диаграмма потоков.
 *
 * === Порядок узлов задаётся данными ===
 *
 * Массивы `sources` и `targets` идут сверху вниз ровно так, как переданы.
 * Сортировки по величине внутри блока НЕТ — молчаливая перестановка
 * переписала бы вывод слайда: если «Тесты гипотез» стоят последними, потому
 * что о них речь в конце рассказа, автосортировка утащила бы их наверх.
 *
 * Ленты внутри узла тоже не сортируются по величине: они укладываются в
 * порядке ПРОТИВОПОЛОЖНОЙ колонки. Это правило из данных, а не из чисел, и
 * оно же минимизирует лишние пересечения — соседние по списку приёмники
 * получают соседние ленты.
 *
 * Отсортирован только ПОРЯДОК ОТРИСОВКИ лент — толстые под тонкими, — чтобы
 * тонкая лента не пропадала под толстой. Ни на положение, ни на геометрию
 * это не влияет, только на то, что лежит выше.
 */
export function SankeyFlow({
  sources,
  targets,
  links,
  width = 1680,
  height = 560,
  labelWidth = 360,
  formatValue = (v) => v.toLocaleString("ru-RU"),
  formatShare = (p) => `${p.toFixed(p < 10 ? 1 : 0).replace(".", ",")}%`,
  totalCaption,
}: SankeyFlowProps) {
  useRemeasureOnFont();

  const gradientId = `sankey-${useId().replace(/:/g, "")}`;

  /* ── Потолки ─────────────────────────────────────────────────────────── */

  const keptSources = sources.slice(0, SOURCE_CAP);
  const keptTargets = targets.slice(0, TARGET_CAP);

  const sourceIndex = new Map(keptSources.map((n, i) => [n.key, i]));
  const targetIndex = new Map(keptTargets.map((n, i) => [n.key, i]));

  const liveLinks = links.filter(
    (l) => sourceIndex.has(l.from) && targetIndex.has(l.to) && l.value > 0,
  );

  /* ── Величины узлов считаются ИЗ СВЯЗЕЙ ──────────────────────────────── */

  /*
   * Узел своей величины не хранит. Иначе появились бы два источника правды —
   * подписанное число и сумма лент, — и они разошлись бы при первой же
   * правке данных, причём молча: подпись говорила бы одно, картинка другое.
   */
  const sourceValue = keptSources.map((n) =>
    liveLinks.reduce((sum, l) => (l.from === n.key ? sum + l.value : sum), 0),
  );
  const targetValue = keptTargets.map((n) =>
    liveLinks.reduce((sum, l) => (l.to === n.key ? sum + l.value : sum), 0),
  );

  const total = liveLinks.reduce((sum, l) => sum + l.value, 0);

  /* ── Подписи: сколько строк занимает каждая ──────────────────────────── */

  const share = (v: number) => (total > 0 ? (v / total) * 100 : 0);
  const meta = (v: number) => `${formatValue(v)} · ${formatShare(share(v))}`;

  const nameWidth = (v: number) =>
    labelWidth - INLINE_GAP - textWidth(meta(v), META_SIZE, META_WEIGHT);

  const sourceLines = keptSources.map((n, i) =>
    wrapLines(n.label, nameWidth(sourceValue[i]), NAME_SIZE, NAME_WEIGHT),
  );
  const targetLines = keptTargets.map((n, i) =>
    wrapLines(n.label, nameWidth(targetValue[i]), NAME_SIZE, NAME_WEIGHT),
  );

  const sourceLabelH = sourceLines.map((l) => l * LINE);
  const targetLabelH = targetLines.map((l) => l * LINE);

  /* ── Общая шкала для обеих колонок ───────────────────────────────────── */

  /*
   * Шкала ОДНА на две колонки, иначе лента приходила бы в приёмник другой
   * толщиной, чем вышла из источника, — то есть форма врала бы о величине.
   * Достигается тем, что суммарная высота столбиков у обеих колонок равна:
   * из высоты вычитаются просветы САМОЙ ПЛОТНОЙ колонки, и та же сумма
   * раздаётся в обеих. Колонка, где узлов меньше, получается короче по
   * общему габариту и центрируется.
   */
  const gapCount = Math.max(keptSources.length, keptTargets.length) - 1;
  const barTotal = Math.max(0, height - NODE_GAP * Math.max(0, gapCount));

  const minFor = (labelH: number) => Math.max(0, labelH - NODE_GAP + LABEL_CLEAR);

  const scaleMins = (mins: number[]) => {
    const need = mins.reduce((a, b) => a + b, 0);
    return need > barTotal && need > 0 ? mins.map((m) => (m * barTotal) / need) : mins;
  };

  const sourceMin = scaleMins(sourceLabelH.map(minFor));
  const targetMin = scaleMins(targetLabelH.map(minFor));

  const sourceH = fitHeights(sourceValue, sourceMin, barTotal);
  const targetH = fitHeights(targetValue, targetMin, barTotal);

  const stack = (heights: number[]) => {
    const span = heights.reduce((a, b) => a + b, 0) + NODE_GAP * Math.max(0, heights.length - 1);
    const tops: number[] = [];
    let y = (height - span) / 2;
    for (const h of heights) {
      tops.push(y);
      y += h + NODE_GAP;
    }
    return tops;
  };

  const sourceTop = stack(sourceH);
  const targetTop = stack(targetH);

  /* ── Ленты ───────────────────────────────────────────────────────────── */

  const columnW = labelWidth + LABEL_GAP + NODE_W;
  const bandW = Math.max(0, width - columnW * 2);
  const bandX = columnW;

  /*
   * Смещения внутри узла: лента занимает свою долю высоты столбика. Обход
   * идёт по ПОРЯДКУ ПРОТИВОПОЛОЖНОЙ колонки — см. описание блока.
   */
  const fromOffset = new Array<number>(keptSources.length).fill(0);
  const toOffset = new Array<number>(keptTargets.length).fill(0);

  const ribbons = keptSources.flatMap((source, si) =>
    keptTargets.flatMap((target, ti) => {
      const link = liveLinks.find((l) => l.from === source.key && l.to === target.key);
      if (!link) return [];

      const thickFrom = sourceValue[si] > 0 ? (link.value / sourceValue[si]) * sourceH[si] : 0;
      const thickTo = targetValue[ti] > 0 ? (link.value / targetValue[ti]) * targetH[ti] : 0;

      const y0s = sourceTop[si] + fromOffset[si];
      const y0t = targetTop[ti] + toOffset[ti];
      fromOffset[si] += thickFrom;
      toOffset[ti] += thickTo;

      return [
        {
          key: `${source.key}→${target.key}`,
          si,
          thickest: Math.max(thickFrom, thickTo),
          y0s,
          y1s: y0s + thickFrom,
          y0t,
          y1t: y0t + thickTo,
        },
      ];
    }),
  );

  /* Толстые рисуются первыми и оказываются НИЖЕ тонких */
  const drawOrder = ribbons.slice().sort((a, b) => b.thickest - a.thickest);

  const path = (r: (typeof ribbons)[number]) => {
    const c = bandW * CURVE;
    return [
      `M 0 ${r.y0s}`,
      `C ${c} ${r.y0s}, ${bandW - c} ${r.y0t}, ${bandW} ${r.y0t}`,
      `L ${bandW} ${r.y1t}`,
      `C ${bandW - c} ${r.y1t}, ${c} ${r.y1s}, 0 ${r.y1s}`,
      "Z",
    ].join(" ");
  };

  /* ── Проверки, которые видны только автору ───────────────────────────── */

  if (import.meta.env.DEV) {
    if (!liveLinks.length) {
      console.warn(
        "SankeyFlow: ни одной связи. Пустая диаграмма проходит все автопроверки — " +
          "проверьте ключи from/to и что величины положительные.",
      );
    }

    if (sources.length > SOURCE_CAP) {
      console.warn(
        `SankeyFlow: источников ${sources.length} при потолке ${SOURCE_CAP}. Отброшены: ` +
          `${sources
            .slice(SOURCE_CAP)
            .map((n) => n.label)
            .join(", ")}. Потолок равен длине CHART_SERIES: цвет кодирует источник, ` +
          "а палитра по кругу не назначается. Сверните остаток в «Прочее» на стороне данных.",
      );
    }

    if (targets.length > TARGET_CAP) {
      console.warn(
        `SankeyFlow: приёмников ${targets.length} при потолке ${TARGET_CAP}. Отброшены: ` +
          `${targets
            .slice(TARGET_CAP)
            .map((n) => n.label)
            .join(", ")}. Дальше ленты перестают прослеживаться глазом.`,
      );
    }

    const lost = links.filter((l) => !sourceIndex.has(l.from) || !targetIndex.has(l.to));
    if (lost.length) {
      console.warn(
        `SankeyFlow: ${lost.length} связей ведут к узлам, которых нет в списках или которые ` +
          `отброшены потолком: ${lost.map((l) => `${l.from}→${l.to}`).join(", ")}. ` +
          "Их величины в итог НЕ вошли — итог и доли посчитаны без них.",
      );
    }

    const dead = [...keptSources.filter((_, i) => sourceValue[i] <= 0)].concat(
      keptTargets.filter((_, i) => targetValue[i] <= 0),
    );
    if (dead.length) {
      console.warn(
        `SankeyFlow: узлы без связей — ${dead.map((n) => n.label).join(", ")}. ` +
          "Столбик нулевой высоты выглядит как пропавшая подпись.",
      );
    }

    const blown = [
      ...keptSources.map((n, i) => ({ n, got: sourceH[i], want: sourceMin[i] })),
      ...keptTargets.map((n, i) => ({ n, got: targetH[i], want: targetMin[i] })),
    ].filter((x) => x.got > 0 && x.got - x.want < 0.5 && x.want > 0);
    if (blown.length) {
      console.warn(
        "SankeyFlow: узлы прижаты к минимальной высоте и потому выглядят КРУПНЕЕ своей доли — " +
          `${blown.map((x) => `${x.n.label} (${Math.round(x.got)}px)`).join(", ")}. ` +
          "Пропорция в этих узлах нарушена. Свернуть мелкие узлы в «Прочее» или поднять height.",
      );
    }

    const thin = ribbons.filter((r) => r.thickest > 0 && r.thickest < RIBBON_MIN);
    if (thin.length) {
      console.warn(
        `SankeyFlow: ленты тоньше ${RIBBON_MIN}px — ${thin.map((r) => r.key).join(", ")}. ` +
          "На слайде их не видно, и поток читается как отсутствующий.",
      );
    }
  }

  if (!liveLinks.length) return null;

  /* ── Разметка ────────────────────────────────────────────────────────── */

  const label = (
    node: SankeyNode,
    value: number,
    labelH: number,
    top: number,
    side: "from" | "to",
  ) => (
    <div
      className={`absolute flex items-baseline ${
        side === "from" ? "justify-end text-right" : "justify-start text-left"
      }`}
      style={{
        top,
        left: side === "from" ? 0 : undefined,
        right: side === "to" ? 0 : undefined,
        width: labelWidth,
        height: labelH,
        gap: INLINE_GAP,
      }}
    >
      <span className="text-body-m text-ink min-w-0 break-words">{node.label}</span>
      <span className="text-label text-ink-secondary shrink-0 tabular-nums">{meta(value)}</span>
    </div>
  );

  return (
    <div className="flex flex-col" style={{ width, gap: totalCaption ? 24 : 0 }}>
      {totalCaption ? (
        <div className="flex items-baseline" style={{ gap: INLINE_GAP }}>
          <span className="text-title-l text-ink tabular-nums">{formatValue(total)}</span>
          <span className="text-body-m text-ink-secondary">{totalCaption}</span>
        </div>
      ) : null}

      <div className="relative" style={{ width, height }}>
        {/* Ленты. Значения все до одного продублированы подписями узлов,
            поэтому для чтения с экрана слой ничего не добавляет */}
        <svg
          width={bandW}
          height={height}
          viewBox={`0 0 ${bandW} ${height}`}
          className="absolute top-0"
          style={{ left: bandX }}
          aria-hidden="true"
        >
          <defs>
            {keptSources.map((source, si) => (
              <linearGradient
                key={source.key}
                id={`${gradientId}-${si}`}
                gradientUnits="userSpaceOnUse"
                x1={0}
                y1={0}
                x2={bandW}
                y2={0}
              >
                {ribbonStops(CHART_SERIES[si]).map((stop) => (
                  <stop
                    key={stop.offset}
                    offset={stop.offset}
                    stopColor={stop.color}
                    stopOpacity={stop.opacity}
                  />
                ))}
              </linearGradient>
            ))}
          </defs>

          {drawOrder.map((r) => (
            <path key={r.key} d={path(r)} fill={`url(#${gradientId}-${r.si})`} />
          ))}
        </svg>

        {/* Источники */}
        {keptSources.map((source, si) => (
          <Fragment key={source.key}>
            <div
              className="absolute"
              style={{
                left: labelWidth + LABEL_GAP,
                top: sourceTop[si],
                width: NODE_W,
                height: sourceH[si],
                borderRadius: "var(--radius-micro)",
                /* Та же заливка, что у столбца BarChart: краска — нижний
                   стоп, вверх идёт осветление на 1.8 пункта светлоты.
                   Разбор амплитуды — у BAR_RISE в src/lib/color.ts */
                background: barFill(CHART_SERIES[si]),
              }}
            />
            {label(
              source,
              sourceValue[si],
              sourceLabelH[si],
              sourceTop[si] + sourceH[si] / 2 - sourceLabelH[si] / 2,
              "from",
            )}
          </Fragment>
        ))}

        {/* Приёмники */}
        {keptTargets.map((target, ti) => (
          <Fragment key={target.key}>
            <div
              className="bg-ink-tertiary absolute"
              style={{
                left: width - labelWidth - LABEL_GAP - NODE_W,
                top: targetTop[ti],
                width: NODE_W,
                height: targetH[ti],
                borderRadius: "var(--radius-micro)",
              }}
            />
            {label(
              target,
              targetValue[ti],
              targetLabelH[ti],
              targetTop[ti] + targetH[ti] / 2 - targetLabelH[ti] / 2,
              "to",
            )}
          </Fragment>
        ))}
      </div>
    </div>
  );
}
