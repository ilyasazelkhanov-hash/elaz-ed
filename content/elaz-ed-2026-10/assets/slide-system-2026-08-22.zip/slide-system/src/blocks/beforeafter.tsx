import type { ReactNode } from "react";

/**
 * Сравнение «сейчас → как надо» и каркас страницы.
 *
 *   BeforeAfter — две панели «сейчас» и «как надо»
 *   PageWire    — схема страницы блоками: что где стоит и что добавляется
 *
 * === Зачем каркас, а не скриншот будущей страницы ===
 *
 * Скриншот будущего пришлось бы нарисовать, то есть придумать: шрифты,
 * картинки, цвета — всё то, чего ещё нет и что на согласовании начнут
 * обсуждать вместо структуры. Каркас показывает ровно предмет разговора:
 * какие блоки на странице, в каком порядке и какие из них новые.
 *
 * Это же снимает и ложное обещание. Нарисованный «дизайн будущей страницы»
 * читается как макет к утверждению, а он им не является — верстать будет
 * команда клиента по своим шаблонам.
 */

/* ═══════════════  Две панели  ═══════════════ */

export interface SidePanel {
  /** Метка состояния: «Сейчас», «Как надо» */
  label: string;
  /** Уточнение под меткой: замер, число, дата */
  note?: ReactNode;
  children: ReactNode;
}

/**
 * === Про стрелку, которой здесь больше нет ===
 *
 * Между панелями стояла стрелка в круглой плашке. Убрана правкой
 * от 18.08.2026: «стрелочка должна быть без кружочка, да и в целом
 * стрелочка не нужна».
 *
 * Она ставилась ради того, чтобы панели читались как «было и станет»,
 * а не как варианты на выбор. Эту работу делают метки состояний:
 * «Сейчас» на серой плашке и «Как надо» на зелёной — разница видна
 * до чтения, и глиф между ними был подстраховкой, а не смыслом.
 *
 * Просвет между панелями увеличен с gap-16 до gap-20: без глифа
 * посередине прежнее расстояние читалось как случайно оставшаяся
 * дыра, потому что глазу больше не за что в нём зацепиться.
 */
export function BeforeAfter({ before, after }: { before: SidePanel; after: SidePanel }) {
  return (
    <div className="grid grid-cols-2 gap-20">
      <Панель side={before} tone="before" />
      <Панель side={after} tone="after" />
    </div>
  );
}

function Панель({ side, tone }: { side: SidePanel; tone: "before" | "after" }) {
  /* Классы полными литералами — Tailwind не видит собранных из кусков имён */
  const tag = tone === "before" ? "bg-fill text-ink-secondary" : "bg-success-fill text-success-fg";

  return (
    <div className="flex min-w-0 flex-col gap-5">
      <div className="flex items-baseline gap-4">
        <span className={`text-label rounded-capsule px-4 py-2 ${tag}`}>{side.label}</span>
        {side.note ? <span className="text-body-m text-ink-secondary">{side.note}</span> : null}
      </div>
      {side.children}
    </div>
  );
}

/* ═══════════════  Каркас страницы  ═══════════════ */

export type WireKind = "h1" | "text" | "chips" | "cards" | "media" | "table";

export interface WireRow {
  kind: WireKind;
  /** Что это за блок страницы */
  label: string;
  /**
   * Состояние блока при перевёрстке.
   *
   * `added` — блок появляется, `removed` — уходит, по умолчанию остаётся.
   * Признак задаётся ДАННЫМИ, а не выводится из того, есть ли блок в другой
   * колонке: одинаковый по названию блок может переезжать, а не появляться,
   * и различить это может только человек.
   */
  state?: "added" | "removed";
}

const ROW_TONE = {
  added: "bg-success-fill",
  removed: "bg-error-fill",
  kept: "bg-fill",
} as const;

const MARK_TONE = {
  added: "text-success-fg",
  removed: "text-error-fg",
} as const;

/**
 * Схема страницы: блоки сверху вниз.
 *
 * Порядок строк — порядок блоков на самой странице, а не порядок важности.
 * Поэтому строки не нумеруются: номер читался бы как приоритет.
 */
/**
 * === Про плотность ===
 *
 * Числа не подобраны на глаз, а получены замером слайда страницы бренда,
 * где каркас самый длинный — семь строк.
 *
 * Замер до правки: панель 654px при доступных 600 (рабочая область 656
 * минус 56 под подвал). Переполнение 54px.
 *
 * Что даёт экономию: поля строки 12 → 8 по вертикали освобождают 8px
 * на строке, то есть 56 на семи; штрих таблицы с трёх полос сокращён
 * до двух — ещё 9px на каждой из двух табличных строк. Итого 74px,
 * панель 580 против доступных 600.
 *
 * Семь строк — реальный потолок шаблона из раздела 7 конкурентного
 * анализа, и каркас обязан их вмещать без лида на слайде.
 */
export function PageWire({ rows }: { rows: WireRow[] }) {
  return (
    <div className="flex flex-col gap-2">
      {rows.map((row) => {
        const state = row.state ?? "kept";

        return (
          <div
            key={row.label}
            className={`rounded-card flex flex-col gap-2 px-5 py-2 ${ROW_TONE[state]}`}
          >
            <div className="flex items-baseline gap-3">
              <span className="text-body-m text-ink min-w-0 flex-1">{row.label}</span>
              {row.state ? (
                <span className={`text-label shrink-0 ${MARK_TONE[row.state]}`}>
                  {row.state === "added" ? "новое" : "убрать"}
                </span>
              ) : null}
            </div>
            <Штрих kind={row.kind} />
          </div>
        );
      })}
    </div>
  );
}

/**
 * Штриховое изображение блока — то, чем блок выглядит на странице.
 *
 * Полоски рисуются токеном --t-ink-tertiary: это 3.27:1 в светлой теме,
 * то есть порог WCAG для нетекстовой графики. Токен line (14%) для схемы
 * слишком слаб — он предназначен разделителям и на проекторе пропадает.
 */
function Штрих({ kind }: { kind: WireKind }) {
  const bar = (w: string, h: number) => (
    <span className="bg-ink-tertiary block" style={{ width: w, height: h, borderRadius: h / 2 }} />
  );

  if (kind === "h1") return <div className="flex flex-col gap-2">{bar("58%", 10)}</div>;

  if (kind === "text")
    return (
      <div className="flex flex-col gap-2">
        {bar("100%", 5)}
        {bar("82%", 5)}
      </div>
    );

  if (kind === "chips")
    return (
      <div className="flex gap-2">
        {[64, 92, 76, 58].map((w) => (
          <span
            key={w}
            className="bg-ink-tertiary rounded-capsule block"
            style={{ width: w, height: 12 }}
          />
        ))}
      </div>
    );

  if (kind === "cards")
    return (
      <div className="flex gap-2">
        {[0, 1, 2].map((i) => (
          <span
            key={i}
            className="bg-ink-tertiary rounded-micro block flex-1"
            style={{ height: 22 }}
          />
        ))}
      </div>
    );

  if (kind === "media")
    return <span className="bg-ink-tertiary rounded-micro block w-full" style={{ height: 26 }} />;

  /* Таблица — две полосы, а не три: третья не добавляла смысла штриху,
     но стоила 9px высоты на каждой табличной строке каркаса */
  return (
    <div className="flex flex-col gap-1">
      {[0, 1].map((i) => (
        <span key={i} className="flex gap-2">
          {bar("28%", 5)}
          {bar("46%", 5)}
        </span>
      ))}
    </div>
  );
}
