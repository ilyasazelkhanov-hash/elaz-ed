import type { ReactNode } from "react";
import {
  AltArrowRight,
  CheckCircle,
  CloseCircle,
  DangerTriangle,
  InfoCircle,
} from "@solar-icons/react";
import type { SolarIcon } from "../lib/solar";

/**
 * Две доски: разбор по приоритету и разбор по периодичности.
 *
 * Обе решают одну задачу — показать, что список НЕ однородный, — и делают
 * это одинаково: группа становится колонкой или полосой, а не значением
 * в столбце таблицы.
 *
 * === Почему это не таблица с колонкой «Приоритет» ===
 *
 * В таблице приоритет — такая же ячейка, как остальные, и её надо прочесть
 * у каждой строки. На доске принадлежность задана положением: всё, что
 * лежит в левой колонке, срочное, и это видно до чтения.
 *
 * Цена приёма — потеря сортировки по другим измерениям. Поэтому доска
 * годится, когда группа ОДНА и она главная; для сравнения по нескольким
 * измерениям сразу остаётся DataTable.
 */

/* ═══════════════  Доска приоритетов  ═══════════════ */

export type Priority = "high" | "medium" | "low";

export interface BoardCard {
  level: Priority;
  /** Зона: индексация, sitemap, метаданные */
  zone: string;
  /** Что увидели */
  observation: string;
  /** Что сделать */
  action: string;
}

export interface BoardColumn {
  level: Priority;
  title: string;
}

/*
 * Цвет колонки задан заливкой метки, а не цветом всей карточки. Полностью
 * красная колонка из четырёх карточек на слайде читается как авария, хотя
 * «высокий приоритет» означает «делать первым», а не «горит».
 *
 * Классы полными литералами: Tailwind сканирует исходники как текст, и
 * собранного из кусков имени в сборке не окажется.
 */
const LEVEL_TAG: Record<Priority, string> = {
  high: "bg-error-fill text-error-fg",
  medium: "bg-warning-fill text-warning-fg",
  low: "bg-fill text-ink",
};

export function PriorityBoard({
  columns,
  cards,
  compact = false,
}: {
  columns: BoardColumn[];
  cards: BoardCard[];
  /**
   * Плотнее: для восьми карточек на слайде.
   *
   * === Откуда взялись именно эти два шага ===
   *
   * Замер слайда технических замечаний: доска из 4+4 карточек занимала
   * по вертикали 268–948, а подвал начинается на 972 — до него оставалось
   * 24px, и на пилюлю раздела (40 плюс просвет 24 = 64) места не было.
   * Слайд собирался без пилюли и выпадал из ритма дека: он оказывался
   * единственным без надзаголовка.
   *
   * Поля 20 → 16 экономят 8px на карточке, просветы 8 → 4 ещё 8px.
   * На восьми карточках это ровно 64px — те самые, которых не хватало.
   *
   * Ниже опускаться нельзя: при полях 12 заголовок карточки начинает
   * касаться её края, и карточки перестают читаться как отдельные.
   */
  compact?: boolean;
}) {
  /* Классы полными литералами — Tailwind не видит собранных из кусков имён */
  const cardPadding = compact ? "p-4" : "p-5";
  const cardGap = compact ? "gap-1" : "gap-2";

  return (
    <div className="flex gap-6">
      {columns.map((column) => {
        const own = cards.filter((c) => c.level === column.level);

        return (
          <div key={column.level} className="flex min-w-0 flex-1 flex-col gap-4">
            <div className="flex items-baseline gap-4">
              <span className={`text-label rounded-capsule px-4 py-2 ${LEVEL_TAG[column.level]}`}>
                {column.title}
              </span>
              {/* Счётчик: сколько задач в колонке. Без него две колонки
                  разной длины читаются как «во второй чего-то не хватает» */}
              <span className="text-body-m text-ink-secondary tabular-nums">{own.length}</span>
            </div>

            {own.map((card) => (
              <div
                key={card.zone}
                className={`bg-surface rounded-card flex flex-col ${cardGap} ${cardPadding}`}
              >
                <span className="text-title-m text-ink">{card.zone}</span>
                <span className="text-body-m text-ink-secondary">{card.observation}</span>

                {/*
                 * Стрелка перед действием — направление «наблюдение → что
                 * делать», а не элемент управления: она смотрит вправо,
                 * внутрь строки, и никуда не ведёт. Это допустимо ровно
                 * потому, что она стоит ВНУТРИ пары, а не в конце строки,
                 * где обещала бы переход.
                 */}
                <span className="flex items-start gap-3">
                  <span className="shrink-0 pt-1">
                    <AltArrowRight size={22} weight="Linear" color="var(--t-ink-tertiary)" />
                  </span>
                  <span className="text-body-m text-ink">{card.action}</span>
                </span>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

/* ═══════════════  Доска периодичности  ═══════════════ */

export interface CadenceItem {
  /** Периодичность — по ней items группируются в полосы */
  cadence: string;
  /** Зона наблюдения */
  zone: string;
  /** Что именно смотрим */
  metric: string;
}

/**
 * Полосы по периодичности.
 *
 * === Почему полосы, а не колонки ===
 *
 * Периодичностей четыре, и распределены они неравномерно: в одной три
 * показателя, в двух по одному. Колонками это выглядит как незаконченная
 * работа — три пустых места под одинокой карточкой. Полоса сжимается
 * по содержимому и такого впечатления не создаёт.
 *
 * Порядок полос — порядок первого появления в данных, а не алфавитный:
 * в отчёте показатели идут от самых частых к самым редким, и этот порядок
 * сам по себе рекомендация.
 */
/**
 * Склонение существительного при числе.
 *
 * Правило записано целиком, а не сведено к «один / много»: сокращённый
 * вариант врёт ровно там, где это заметит клиент — «5 показателя» в подписи
 * к своему же отчёту выглядит как машинный перевод.
 *
 * Порядок форм: 1 показатель · 2 показателя · 5 показателей.
 */
function склонение(n: number, [одна, две, пять]: [string, string, string]) {
  const сотня = n % 100;
  if (сотня >= 11 && сотня <= 14) return пять;
  const единица = n % 10;
  if (единица === 1) return одна;
  if (единица >= 2 && единица <= 4) return две;
  return пять;
}

export function CadenceBoard({
  items,
  labelWidth = 300,
}: {
  items: CadenceItem[];
  labelWidth?: number;
}) {
  /* Группировка сохраняет порядок первого появления: Map в JavaScript
     обходится в порядке вставки ключей, и полагаться на это можно —
     это гарантия спецификации, а не особенность движка */
  const groups = new Map<string, CadenceItem[]>();
  for (const item of items) {
    const bucket = groups.get(item.cadence);
    if (bucket) bucket.push(item);
    else groups.set(item.cadence, [item]);
  }

  return (
    <div className="flex flex-col">
      {[...groups.entries()].map(([cadence, own], i) => (
        <div key={cadence} className={`flex gap-8 py-6 ${i ? "border-line border-t" : ""}`}>
          <span className="shrink-0 pt-1" style={{ width: labelWidth }}>
            <span className="text-title-l text-ink block">{cadence}</span>
            <span className="text-body-m text-ink-secondary mt-1 block tabular-nums">
              {own.length} {склонение(own.length, ["показатель", "показателя", "показателей"])}
            </span>
          </span>

          <div className="flex min-w-0 flex-1 flex-wrap gap-4">
            {own.map((item) => (
              <div
                key={item.zone}
                className="bg-surface rounded-card flex min-w-0 flex-1 flex-col gap-1 p-5"
                style={{ minWidth: 300 }}
              >
                <span className="text-title-m text-ink">{item.zone}</span>
                <span className="text-body-m text-ink-secondary">{item.metric}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ═══════════════  Заметка  ═══════════════ */

/**
 * Плашка с выводом под блоком — цветная иконка слева, текст справа.
 *
 * Отдельный компонент, а не абзац в вёрстке слайда, потому что повторяется
 * на большинстве слайдов дека: под каждым разбором стоит одна фраза, ради
 * которой разбор и показан. Одинаковый вид этой фразы на всех слайдах —
 * то, что делает дек цельным.
 *
 * === Почему больше НЕ вертикальная черта ===
 *
 * Прежняя версия отбивала текст вертикальной чертой слева. Убрана по
 * правкам заказчика от 18.08.2026: вертикальная черта в этой системе
 * не используется нигде, и на плашке она читалась как посторонний
 * элемент из чужого набора.
 *
 * Заменена на пару «иконка + текст»: иконка цветная и сразу говорит,
 * какого рода это вывод — наблюдение, польза, риск или проблема, — а
 * заливка плашки берёт тот же цвет в слабом разведении. Смысл виден
 * до чтения, и это ровно то, чего от плашки и ждут.
 *
 * === Почему текст вторичным цветом ===
 *
 * Плашка стоит ПОД разбором и комментирует его. Набранная основным
 * цветом, она спорила с содержимым слайда за первое место; вторичный
 * ставит её на своё — читается второй, но читается.
 *
 * === Про отсутствие синего тона ===
 *
 * Нейтральная заметка идёт на сером `bg-fill` с синим глифом, а не на
 * синей заливке: токена accent-fill в системе нет, а заводить его молча
 * запрещено правилами проекта. Для трёх статусных тонов заливки есть,
 * и там плашка действительно «под цвет иконки».
 */

/** Тон заметки. Выбирается по СМЫСЛУ вывода, а не по желаемому цвету */
export type NoteTone = "info" | "good" | "warn" | "bad";

const NOTE_ICON: Record<NoteTone, SolarIcon> = {
  info: InfoCircle,
  good: CheckCircle,
  warn: DangerTriangle,
  bad: CloseCircle,
};

/* Классы полными литералами — Tailwind не видит собранных из кусков имён */
const NOTE_FILL: Record<NoteTone, string> = {
  info: "bg-fill",
  good: "bg-success-fill",
  warn: "bg-warning-fill",
  bad: "bg-error-fill",
};

/*
 * Цвет глифа берётся ТЕКСТОВЫМ токеном статуса, а не сырой краской:
 * статусный текст переворачивается между темами, сырая краска нет.
 * Тёмно-зелёный #1c7430, верный на белом, на тёмной плашке даёт 2.0:1.
 */
const NOTE_GLYPH: Record<NoteTone, string> = {
  info: "var(--t-accent-fg)",
  good: "var(--t-success-fg)",
  warn: "var(--t-warning-fg)",
  bad: "var(--t-error-fg)",
};

export function Takeaway({ children, tone = "info" }: { children: ReactNode; tone?: NoteTone }) {
  const Icon = NOTE_ICON[tone];

  return (
    <div className={`rounded-card flex items-start gap-5 px-7 py-6 ${NOTE_FILL[tone]}`}>
      {/*
       * pt-1 ставит глиф на оптический центр первой строки. Без него
       * иконка равняется по верху бокса строки, а он выше самих букв —
       * значок кажется приподнятым.
       */}
      <span className="shrink-0 pt-1">
        <Icon size={30} weight="Bold" color={NOTE_GLYPH[tone]} />
      </span>
      <p className="text-body-l text-ink-secondary">{children}</p>
    </div>
  );
}
