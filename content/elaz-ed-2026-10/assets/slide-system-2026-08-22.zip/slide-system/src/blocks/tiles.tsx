import type { ReactNode } from "react";
import { AltArrowRight } from "@solar-icons/react";
import IconSquare from "../components/icons/IconSquare";
import type { SolarIcon } from "../lib/solar";

/**
 * Блоки с иконочным квадратом. Перенесены из донорского мобильного проекта
 * (courseIntroSections.tsx, courseSetupSections.tsx, tools.tsx).
 *
 * Три раскладки одного и того же набора «квадрат + заголовок + пояснение»:
 *
 *   IconTiles — сетка плиток. Пункты равноправны, порядок не важен
 *   IconRows  — строки. Пунктов много, у каждого своя роль
 *   PointsRow — ряд без подложки. Три-четыре тезиса под общим лидом
 *
 * Данные приходят через props: донорский набор (аудитория курса, бонусы,
 * инструменты) не перенесён — это его предметная область.
 */

export interface IconItem {
  /** Иконка Solar. Взаимоисключимо с path */
  Icon?: SolarIcon;
  /** Путь логотипа бренда из BRAND_PATHS */
  path?: string;
  /** Цвет заливки квадрата */
  accent: string;
  title: string;
  note?: string;
}

/* ───────────────  Сетка плиток  ─────────────── */

export function IconTiles({ items, columns = 2 }: { items: IconItem[]; columns?: 2 | 3 | 4 }) {
  /* Классы полными литералами: Tailwind сканирует исходники как текст и
     собранных из кусков имён (`grid-cols-${n}`) не видит */
  const cols = columns === 4 ? "grid-cols-4" : columns === 3 ? "grid-cols-3" : "grid-cols-2";

  return (
    <div className={`grid gap-6 ${cols}`}>
      {items.map(({ Icon, path, accent, title, note }) => (
        <div key={title} className="bg-surface rounded-card p-8">
          {/* ring в цвет подложки: кольцо это ПРОСВЕТ вокруг квадрата, и на
              другом фоне оно превращается в лишнюю обводку */}
          <IconSquare Icon={Icon} path={path} accent={accent} ring="var(--t-surface)" />
          <p className="text-title-m text-ink mt-6">{title}</p>
          {note ? <p className="text-body-m text-ink-secondary mt-2">{note}</p> : null}
        </div>
      ))}
    </div>
  );
}

/* ───────────────  Строки  ─────────────── */

/**
 * Строки с разделителем между ними.
 *
 * Стрелка справа — обещание, что за пунктом что-то есть. В презентации
 * переходить некуда, поэтому по умолчанию её НЕТ: стрелка, которая никуда
 * не ведёт, в PDF выглядит как недоделанный интерфейс.
 */
export function IconRows({
  items,
  arrow = false,
  ring = "var(--t-canvas)",
}: {
  items: IconItem[];
  arrow?: boolean;
  ring?: string;
}) {
  return (
    <div className="flex flex-col">
      {items.map(({ Icon, path, accent, title, note }, i) => (
        <div
          key={title}
          className={`flex items-center gap-6 py-6 ${i ? "border-line border-t" : ""}`}
        >
          <IconSquare Icon={Icon} path={path} accent={accent} ring={ring} />
          <span className="min-w-0 flex-1">
            <span className="text-title-m text-ink block">{title}</span>
            {note ? (
              <span className="text-body-m text-ink-secondary mt-1 block truncate">{note}</span>
            ) : null}
          </span>
          {arrow ? <AltArrowRight size={36} weight="Linear" color="var(--t-ink-tertiary)" /> : null}
        </div>
      ))}
    </div>
  );
}

/* ───────────────  Ряд тезисов  ─────────────── */

/**
 * Без подложки: квадрат, короткий заголовок, одна строка пояснения.
 *
 * Самый тихий из трёх вариантов — годится, когда тезисы дополняют лид,
 * а не заменяют его. Больше четырёх в ряд не ставить: на 1680px пятая
 * колонка становится уже 300px, и заголовок начинает переноситься.
 */
export function PointsRow({ items }: { items: IconItem[] }) {
  return (
    <div className="flex gap-8">
      {items.map(({ Icon, path, accent, title, note }) => (
        <div key={title} className="flex-1">
          <IconSquare Icon={Icon} path={path} accent={accent} ring="var(--t-canvas)" />
          <p className="text-title-l text-ink mt-6">{title}</p>
          {note ? <p className="text-body-m text-ink-secondary mt-2">{note}</p> : null}
        </div>
      ))}
    </div>
  );
}

/* ───────────────  Черта слева  ─────────────── */

/**
 * Самый тихий приём выделения: ни подложки, ни иконки, только акцентная черта.
 *
 * Годится для цитаты и для вводного абзаца, который надо отделить от
 * остального текста, не превращая его в карточку.
 */
export function AccentRule({
  children,
  accent = "var(--color-accent-blue)",
}: {
  children: ReactNode;
  accent?: string;
}) {
  return (
    <div style={{ paddingLeft: 36, borderLeft: `5px solid ${accent}` }}>
      <div className="text-body-l text-ink">{children}</div>
    </div>
  );
}
