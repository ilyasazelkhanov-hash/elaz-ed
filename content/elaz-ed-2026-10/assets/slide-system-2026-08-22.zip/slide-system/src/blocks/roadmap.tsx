import { CHART_EMPHASIS } from "../lib/chartPalette";

/**
 * План работ на шкале недель.
 *
 * === Зачем шкала, если есть таблица со столбцом «Недели» ===
 *
 * В таблице «1–2», «2–4», «3–6», «4–8», «6–12» — это пять строк текста,
 * и то, что четыре задачи идут ОДНОВРЕМЕННО, из них не следует. Клиент
 * читает их как очередь и планирует ресурс на двенадцать недель подряд.
 *
 * На шкале перекрытие видно сразу: две полосы на одних и тех же неделях
 * означают две задачи в работе одновременно. Это и есть содержание плана,
 * а не оформление.
 *
 * === Про один тон ===
 *
 * Все полосы одного цвета. Цвет здесь не различает задачи — их различает
 * строка, — а обозначает «работа идёт». Категорийная раскраска шести полос
 * потребовала бы шести цветов, а проверенный порядок содержит пять; шестой
 * пришлось бы взять на глаз, и он сломал бы проверку различимости.
 */

export interface RoadmapTask {
  /** Неделя начала, от 1 */
  from: number;
  /** Неделя окончания включительно */
  to: number;
  title: string;
  /** Критерий готовности — по чему поймём, что задача закрыта */
  done?: string;
}

export function RoadmapBars({
  tasks,
  weeks,
  labelWidth = 620,
  barHeight = 26,
  /** Через сколько недель ставить линию сетки */
  gridEvery = 2,
}: {
  tasks: RoadmapTask[];
  weeks: number;
  labelWidth?: number;
  barHeight?: number;
  gridEvery?: number;
}) {
  const gap = 24;
  /** Доля ширины дорожки на одну неделю */
  const pct = (n: number) => `${(n / weeks) * 100}%`;

  return (
    <div className="flex flex-col gap-4">
      {/* ───── Шапка шкалы ───── */}
      <div className="flex items-end" style={{ gap }}>
        <span className="text-label text-ink-secondary shrink-0" style={{ width: labelWidth }}>
          Неделя
        </span>

        {/*
         * Номера недель стоят по ЦЕНТРУ своей недели, а не по её границе.
         * Полоса задачи «1–2» занимает первые две ячейки целиком, и если
         * подписать границы, её левый край окажется под цифрой 1, а правый
         * под цифрой 3 — план прочитают на неделю длиннее, чем он есть.
         */}
        <div className="flex min-w-0 flex-1">
          {Array.from({ length: weeks }, (_, i) => (
            <span key={i} className="text-label text-ink-secondary flex-1 text-center tabular-nums">
              {i + 1}
            </span>
          ))}
        </div>
      </div>

      {/* ───── Строки задач ───── */}
      <div className="relative flex flex-col">
        {/*
         * Сетка нарисована ОДНИМ слоем на всю высоту списка, а не отрезком
         * в каждой строке. Иначе вертикаль рвётся на просветах между
         * строками и перестаёт работать как общая координата: глаз не
         * может провести её от шапки до нижней полосы.
         */}
        <div
          className="pointer-events-none absolute top-0 bottom-0"
          style={{ left: labelWidth + gap, right: 0 }}
          aria-hidden="true"
        >
          {/* Последняя линия не рисуется: она пришлась бы ровно на правый
              край дорожки, где и так проходит её граница, — и в PDF торчала
              бы за пределы блока на свою толщину */}
          {Array.from({ length: Math.ceil(weeks / gridEvery) - 1 }, (_, i) => (
            <span
              key={i}
              className="bg-line absolute top-0 bottom-0"
              style={{ left: pct((i + 1) * gridEvery), width: 2 }}
            />
          ))}
        </div>

        {tasks.map((task, i) => (
          <div
            key={task.title}
            className={`relative flex items-center py-5 ${i ? "border-line border-t" : ""}`}
            style={{ gap }}
          >
            <div className="flex shrink-0 items-start gap-5" style={{ width: labelWidth }}>
              {/*
               * Диапазон недель продублирован пилюлей слева, хотя он уже
               * нарисован полосой. Это не избыточность: в PDF презентацию
               * читают и с экрана телефона, где полоса в 60px ширины
               * различима, а её точные границы — нет.
               */}
              <span className="bg-fill text-ink text-label rounded-capsule shrink-0 px-4 py-2 tabular-nums">
                {task.from}–{task.to}
              </span>

              <span className="min-w-0 flex-1">
                <span className="text-title-m text-ink block">{task.title}</span>
                {task.done ? (
                  <span className="text-body-m text-ink-secondary mt-1 block">{task.done}</span>
                ) : null}
              </span>
            </div>

            <div className="relative min-w-0 flex-1" style={{ height: barHeight }}>
              <span
                className="absolute top-0 bottom-0"
                style={{
                  left: pct(task.from - 1),
                  width: pct(task.to - task.from + 1),
                  /* Радиус — половина высоты: полоса всегда капсула, тот же
                     закон, что у кнопок системы */
                  borderRadius: barHeight / 2,
                  background: CHART_EMPHASIS,
                }}
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
