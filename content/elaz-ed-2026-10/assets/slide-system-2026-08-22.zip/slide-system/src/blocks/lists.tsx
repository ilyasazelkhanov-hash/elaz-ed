import type { ReactNode } from "react";
import { CheckCircle, CloseCircle } from "@solar-icons/react";

/**
 * Списки. Перенесены из донорского мобильного проекта (courseIntroSections.tsx) и пересчитаны
 * под холст слайда.
 *
 * Все четыре решают одну задачу — перечислить, — и различаются тем, что
 * добавляют к перечислению:
 *
 *   Checklist    — согласие. Галочка читается как «да, это про меня»
 *   NumberedList — порядок. Номер говорит, что шаги идут подряд
 *   Timeline     — путь. Линия говорит, что между шагами есть движение
 *   PillRow      — охват. Пилюли показывают набор, не претендуя на порядок
 *
 * Выбирать по смыслу, а не по тому, что красивее: нумерация там, где порядка
 * нет, обещает последовательность, которой не существует.
 *
 * ВАЖНО: содержимое приходит через props. Донорские данные (уроки курса,
 * аудитория) не перенесены — это его предметная область, а не дизайн-система.
 */

/* ───────────────  Галочки  ─────────────── */

export interface CheckItem {
  title: string;
  /** Пояснение через тире. Необязательно: без него список короче и строже */
  note?: string;
}

/**
 * Знак перед пунктом.
 *
 * === Галочка ≠ красная галочка ===
 *
 * Форма знака несёт смысл сама по себе, отдельно от цвета. Галочка значит
 * «да, есть, хорошо» — и красная галочка перед проблемой читается как
 * «проблема подтверждена и это хорошо». Для списка бед нужен крест.
 *
 * Ошибка была допущена на слайде «что тормозит»: список причин медленной
 * загрузки шёл красными галочками. Цвет менялся, форма — нет.
 */
export type ListTone = "check" | "problem";

const TONE_ICON = { check: CheckCircle, problem: CloseCircle };
const TONE_COLOR = { check: "var(--color-success)", problem: "var(--color-error)" };

export function Checklist({
  items,
  tone = "check",
  accent,
  compact = false,
}: {
  items: CheckItem[];
  tone?: ListTone;
  /** Переопределить цвет знака. Форму задаёт tone, а не цвет */
  accent?: string;
  /**
   * Плотнее: для списка внутри карточки в узкой колонке.
   *
   * Обычный список набран body-l (24/32) со знаком 32px — это размер
   * для списка во всю ширину слайда. В колонке col-span-3 (402px)
   * такой пункт уходит в три строки, и четыре списка рядом перестают
   * помещаться по высоте.
   *
   * Компактный: body-m (20/28), знак 26px, просвет 16 вместо 24.
   * Ниже опускаться нельзя — body-m это последний размер, который
   * на проекторе ещё читается как текст, а не как подпись.
   */
  compact?: boolean;
}) {
  const Icon = TONE_ICON[tone];
  const color = accent ?? TONE_COLOR[tone];

  /* Классы полными литералами — Tailwind не видит собранных из кусков имён */
  const gapOuter = compact ? "gap-4" : "gap-6";
  const gapItem = compact ? "gap-3" : "gap-5";
  const textSize = compact ? "text-body-m" : "text-body-l";

  return (
    <ul className={`flex flex-col ${gapOuter}`}>
      {items.map(({ title, note }) => (
        <li key={title} className={`flex ${gapItem}`}>
          {/*
           * pt-1 ставит знак на оптический центр первой строки. Без него
           * иконка выравнивается по верху бокса строки, а он выше самих
           * букв — глиф кажется приподнятым.
           */}
          <span className="shrink-0 pt-1">
            <Icon size={compact ? 26 : 32} weight="Bold" color={color} />
          </span>
          <p className={`${textSize} text-ink min-w-0`}>
            {title}
            {note ? <span className="text-ink-secondary"> — {note}</span> : null}
          </p>
        </li>
      ))}
    </ul>
  );
}

/* ───────────────  Нумерованный список  ─────────────── */

export interface StepItem {
  id: string;
  title: string;
  /** Вторая строка: время, объём, уточнение */
  meta?: string;
  /** Выделить как текущий шаг */
  current?: boolean;
  /** Приглушить как ещё недоступный */
  muted?: boolean;
}

export function NumberedList({ items }: { items: StepItem[] }) {
  return (
    <ol className="flex flex-col">
      {items.map((item, i) => (
        <li key={item.id} className="flex items-center gap-6 py-5">
          <span
            className={[
              "text-body-m rounded-capsule grid shrink-0 place-items-center tabular-nums",
              item.current ? "bg-action text-action-fg" : "bg-surface text-ink",
              item.muted ? "text-ink-secondary" : "",
            ]
              .filter(Boolean)
              .join(" ")}
            style={{ width: 56, height: 56, fontWeight: 600 }}
          >
            {i + 1}
          </span>

          <span className="min-w-0 flex-1">
            <span
              className={`text-body-l block truncate ${item.muted ? "text-ink-tertiary" : "text-ink"}`}
            >
              {item.title}
            </span>
            {item.meta ? (
              <span className="text-label text-ink-secondary mt-1 block">{item.meta}</span>
            ) : null}
          </span>
        </li>
      ))}
    </ol>
  );
}

/* ───────────────  Лента  ─────────────── */

/**
 * Точки на общей вертикали.
 *
 * Линия рисуется ОДНИМ элементом на весь список, а не отрезком на каждую
 * строку. Иначе она рвётся в промежутках между пунктами, и вместо пути
 * получается пунктир — а пунктир читается как «здесь чего-то не хватает».
 *
 * Кольцо вокруг точки — цвета фона, а не белое: на тёмном слайде белое кольцо
 * превращается в светлую обводку и точка начинает выглядеть выключенной.
 */
export function Timeline({ items }: { items: StepItem[] }) {
  return (
    <div className="relative">
      <span
        aria-hidden="true"
        className="bg-line rounded-capsule absolute"
        style={{ left: 13, top: 20, bottom: 20, width: 4 }}
      />

      <ol className="flex flex-col">
        {items.map((item) => (
          <li key={item.id} className="relative flex gap-8 py-4">
            <span
              className={`shrink-0 rounded-full ${item.muted ? "bg-line" : "bg-action"}`}
              style={{
                width: 30,
                height: 30,
                marginTop: 6,
                boxShadow: "0 0 0 8px var(--t-canvas)",
              }}
            />
            <span className="min-w-0 flex-1">
              <span
                className={`text-body-l block truncate ${item.muted ? "text-ink-tertiary" : "text-ink"}`}
              >
                {item.title}
              </span>
              {item.meta ? (
                <span className="text-label text-ink-secondary mt-1 block">{item.meta}</span>
              ) : null}
            </span>
          </li>
        ))}
      </ol>
    </div>
  );
}

/* ───────────────  Пилюли  ─────────────── */

/**
 * Самый компактный способ перечислить: только названия, без пояснений.
 *
 * Годится, когда важен охват, а не подробности — «мы работаем со всем этим».
 * Как только к пункту нужна вторая строка, пилюли перестают подходить:
 * пояснение в них не помещается, а вынесенное наружу теряет связь с пунктом.
 */
export function PillRow({ items, icon }: { items: string[]; icon?: (item: string) => ReactNode }) {
  return (
    <div className="flex flex-wrap gap-4">
      {items.map((item) => (
        <span
          key={item}
          className="bg-fill text-ink text-body-m rounded-capsule inline-flex items-center gap-3 py-4"
          style={{ paddingLeft: icon ? 12 : 28, paddingRight: 28 }}
        >
          {icon?.(item)}
          {item}
        </span>
      ))}
    </div>
  );
}
