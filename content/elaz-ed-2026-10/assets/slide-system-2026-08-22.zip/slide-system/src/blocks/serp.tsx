import { Global } from "@solar-icons/react";
import IconSquare from "../components/icons/IconSquare";

/**
 * Макет сниппета поисковой выдачи.
 *
 * === Зачем он на слайде аудита ===
 *
 * Рекомендация «сократить description и сделать его уникальным под интент»
 * в виде текста проверить нельзя: клиент не видит, что получится. Сниппет,
 * нарисованный так, как его увидит человек в выдаче, превращает
 * рекомендацию в макет — его можно утвердить или поправить прямо на показе.
 *
 * === Почему это НЕ копия выдачи Google ===
 *
 * Фирменные цвета поисковика сюда не переносятся. Во-первых, это чужой
 * бренд на клиентском слайде. Во-вторых, синий заголовок ссылки в выдаче
 * даёт на белом около 4:1 — ниже порога AA для основного текста, и на
 * проекторе он бы поплыл.
 *
 * Взят токен системы text-accent-fg. Пересчёт на синей шкале заказчика:
 * #155dfc даёт 5.25:1 на белой карточке и 4.90:1 на светлом холсте #f7f7f7,
 * #50a2ff в тёмной теме — 7.09:1 на холсте и 5.73:1 на карточке. (Прежняя
 * запись «5.27:1 на белом и 7.2:1 в тёмной» относилась к паре #006ad1 /
 * #4da3ff, которой в системе больше нет.)
 * Форма при этом узнаётся всё равно — сниппет опознают по СТРУКТУРЕ
 * (адрес крошками, заголовок ссылкой, два предложения описания),
 * а не по конкретному оттенку синего.
 */

export interface SnippetItem {
  /** Какой странице принадлежит сниппет */
  page: string;
  /** Адрес хлебными крошками: «example.ru › catalog › coffee» */
  url: string;
  title: string;
  description: string;
  /** Имя сайта рядом со значком */
  site?: string;
}

export function SerpSnippet({ item, site = "Пример" }: { item: SnippetItem; site?: string }) {
  return (
    /*
     * h-full и flex-1 на панели — чтобы два сниппета в ряду были одной
     * высоты. Без них панель обжимается по своему тексту, и у соседа
     * с двухстрочным заголовком нижний край оказывается на 30px ниже.
     *
     * Замерено на слайде сниппетов: левая панель кончалась на y=660,
     * правая на y=690, и подписи с длиной под ними стояли на разной
     * высоте. Разновысокие карточки в ряду читаются как ошибка вёрстки,
     * даже когда текста в них правда разное количество.
     */
    <div className="flex h-full flex-col gap-4">
      <span className="text-label text-ink-secondary">{item.page}</span>

      <div className="bg-surface rounded-panel flex flex-1 flex-col gap-4 p-8">
        {/* Шапка результата: значок сайта, имя, адрес крошками */}
        <div className="flex items-center gap-4">
          {/* Значок берёт тот же IconSquare, что и вся система, только мельче:
              44 вместо 88. Радиус компонент считает от размера сам, поэтому
              мелкая плитка остаётся той же формой, а не становится квадратнее */}
          <IconSquare Icon={Global} size={44} glyph={22} ring="var(--t-surface-muted)" />
          <span className="flex min-w-0 flex-col">
            <span className="text-body-m text-ink">{item.site ?? site}</span>
            <span className="text-body-m text-ink-secondary truncate">{item.url}</span>
          </span>
        </div>

        <p className="text-title-l text-accent-fg">{item.title}</p>

        <p className="text-body-m text-ink-secondary">{item.description}</p>
      </div>

      {/*
       * Длины считаются из самого текста, а не выписываются рядом руками.
       * Это тот же принцип, что и с числами дека: показатель, вписанный
       * отдельно от того, что он описывает, расходится с ним при первой
       * же правке формулировки.
       *
       * Число здесь по делу: претензия аудита к текущим описаниям — их
       * длина (179–380 знаков), и предложенный вариант должен показывать,
       * что он в норму укладывается.
       */}
      <span className="text-caption text-ink-secondary tabular-nums">
        Title {item.title.length} знаков · Description {item.description.length} знаков
      </span>
    </div>
  );
}

export function SerpSnippets({ items, site }: { items: SnippetItem[]; site?: string }) {
  return (
    <div className="slide-grid">
      {items.map((item) => (
        <div key={item.page} className="col-span-6">
          <SerpSnippet item={item} site={site} />
        </div>
      ))}
    </div>
  );
}
