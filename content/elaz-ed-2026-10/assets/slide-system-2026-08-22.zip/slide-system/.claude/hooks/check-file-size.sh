#!/usr/bin/env bash
#
# PostToolUse hook — предупреждение о разросшемся файле.
#
# Срабатывает после Write и Edit. Если изменённый файл исходного кода
# превысил лимит строк — печатает предупреждение.
#
# Это ПРЕДУПРЕЖДЕНИЕ, а не запрет: скрипт всегда завершается кодом 0.
# Код 2 заблокировал бы действие, а блокировать правку из-за размера файла нельзя.
#
# Причина существования: в одном из донорских проектов файл Home.tsx разросся
# до 2384 строк, потому что правила на размер не было.

set -uo pipefail

LIMIT=400

# jq нет — тихо выходим, работу не ломаем
command -v jq >/dev/null 2>&1 || exit 0

payload="$(cat)"
file_path="$(printf '%s' "$payload" | jq -r '.tool_input.file_path // empty' 2>/dev/null)"

[ -n "$file_path" ] || exit 0
[ -f "$file_path" ] || exit 0

# Только исходники. Markdown, JSON и конфиги под лимит не подпадают.
case "$file_path" in
  *.ts|*.tsx|*.js|*.jsx|*.mjs|*.cjs|*.css|*.scss) ;;
  *) exit 0 ;;
esac

case "$file_path" in
  */node_modules/*|*/dist/*|*/build/*|*/storybook-static/*) exit 0 ;;
esac

lines="$(wc -l < "$file_path" 2>/dev/null | tr -d ' ')"
[ -n "$lines" ] || exit 0

if [ "$lines" -le "$LIMIT" ]; then
  exit 0
fi

msg="Файл ${file_path} — ${lines} строк, лимит ${LIMIT}. Пора разбивать: самостоятельные части в отдельные компоненты, вспомогательную логику в хуки, константы в отдельный файл. Разбивать по смыслу, а не механически по числу строк."

# Человеку — в лог сессии
printf '⚠️  %s\n' "$msg" >&2

# Модели — в контекст, чтобы предложение разбить дошло до следующего шага
jq -n --arg ctx "$msg" \
  '{hookSpecificOutput: {hookEventName: "PostToolUse", additionalContext: $ctx}}'

exit 0
