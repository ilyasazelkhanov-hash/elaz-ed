#!/usr/bin/env bash
#
# PostToolUse hook — автоформатирование через prettier.
#
# Срабатывает после Write и Edit.
#
# ВАЖНО: prettier запускается ТОЛЬКО из node_modules проекта.
# Намеренно не используется `npx prettier`: если пакет не установлен,
# npx лезет в интернет скачивать его при КАЖДОЙ правке файла — это секунды
# задержки на каждое действие, а без сети зависание.
# Пока prettier не установлен, хук тихо выходит и ничего не делает.
#
# Всегда завершается кодом 0 — форматирование не должно блокировать работу.

set -uo pipefail

command -v jq >/dev/null 2>&1 || exit 0

payload="$(cat)"
file_path="$(printf '%s' "$payload" | jq -r '.tool_input.file_path // empty' 2>/dev/null)"

[ -n "$file_path" ] || exit 0
[ -f "$file_path" ] || exit 0

case "$file_path" in
  */node_modules/*|*/dist/*|*/build/*|*/storybook-static/*|*/export/*) exit 0 ;;
esac

# Ищем prettier: сначала корень проекта, затем подъём вверх от самого файла.
# Подъём нужен, если сессия запущена из подпапки.
find_prettier() {
  local candidate dir

  for candidate in \
    "${CLAUDE_PROJECT_DIR:-}/node_modules/.bin/prettier" \
    "$PWD/node_modules/.bin/prettier"
  do
    case "$candidate" in
      /node_modules/*) continue ;;   # CLAUDE_PROJECT_DIR не задана
    esac
    [ -x "$candidate" ] && { printf '%s' "$candidate"; return 0; }
  done

  dir="$(cd "$(dirname "$file_path")" 2>/dev/null && pwd)" || return 1
  while [ -n "$dir" ] && [ "$dir" != "/" ]; do
    [ -x "$dir/node_modules/.bin/prettier" ] && { printf '%s' "$dir/node_modules/.bin/prettier"; return 0; }
    dir="$(dirname "$dir")"
  done

  return 1
}

prettier_bin="$(find_prettier)" || exit 0

# --ignore-unknown: prettier не падает на файлах, для которых у него нет парсера
"$prettier_bin" --write --ignore-unknown "$file_path" >/dev/null 2>&1

exit 0
