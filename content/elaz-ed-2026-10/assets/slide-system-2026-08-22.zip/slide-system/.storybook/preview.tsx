import type { Preview, Decorator } from "@storybook/react-vite";
import SlideFit from "../src/slide/SlideFit";
import "../src/styles/index.css";

/**
 * Декоратор Storybook.
 *
 * Делает две вещи:
 *
 * 1. Ставит тему из тулбара на обёртку story. Слайд, у которого тема задана
 *    своим свойством, эту обёртку перебивает — его data-theme лежит глубже,
 *    а CSS-переменная берётся от ближайшего предка. Так витрина токенов
 *    слушается тулбара, а слайд остаётся в своей теме, и это правильно:
 *    тёмная обложка должна оставаться тёмной в любом режиме просмотра.
 *
 * 2. Для stories слайдов (parameters.slide === true) переключает масштаб.
 *
 * === Про режим масштаба ===
 *
 * «Вписать» удобно смотреть: слайд 1920px целиком влезает в окно ноутбука.
 * Но в этом режиме НЕЛЬЗЯ мерить: слайд сжат через transform: scale, и
 * getBoundingClientRect вернёт числа ПОСЛЕ сжатия — отступ 120px окажется,
 * например, 74.9px, и вывод «поле не то» будет ложным.
 *
 * Замеры делаются только в режиме 1:1. Это правило, а не рекомендация —
 * подробности в .claude/rules/layout-verification.md
 */
const withCanvas: Decorator = (Story, context) => {
  const theme = String(context.globals.theme ?? "light");
  const isSlide = context.parameters.slide === true;
  const fit = String(context.globals.fit ?? "fit") === "fit";

  if (isSlide) {
    return (
      <div data-theme={theme} className="bg-canvas min-h-screen">
        {fit ? (
          <SlideFit>
            <Story />
          </SlideFit>
        ) : (
          <Story />
        )}
      </div>
    );
  }

  return (
    <div data-theme={theme} className="bg-canvas text-ink min-h-screen p-16">
      <Story />
    </div>
  );
};

const preview: Preview = {
  decorators: [withCanvas],

  initialGlobals: {
    theme: "light",
    fit: "fit",
  },

  globalTypes: {
    theme: {
      description: "Тема",
      toolbar: {
        title: "Тема",
        icon: "paintbrush",
        items: [
          { value: "light", title: "Светлая" },
          { value: "dark", title: "Тёмная" },
        ],
        dynamicTitle: true,
      },
    },
    fit: {
      description: "Масштаб слайда. Замеры — только в 1:1",
      toolbar: {
        title: "Масштаб",
        icon: "grow",
        items: [
          { value: "fit", title: "Вписать в окно" },
          { value: "actual", title: "1:1 — для замеров" },
        ],
        dynamicTitle: true,
      },
    },
  },

  parameters: {
    layout: "fullscreen",

    viewport: {
      options: {
        slide: {
          name: "Слайд 1920×1080",
          styles: { width: "1920px", height: "1080px" },
          type: "desktop",
        },
        laptop: {
          name: "Ноутбук 1440×900",
          styles: { width: "1440px", height: "900px" },
          type: "desktop",
        },
      },
    },

    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/i,
      },
    },
  },
};

export default preview;
